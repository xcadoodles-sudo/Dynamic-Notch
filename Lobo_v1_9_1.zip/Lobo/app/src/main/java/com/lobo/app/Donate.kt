package com.lobo.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast

/**
 * Pengaturan tab Donate ("Buy Lobo a meat").
 *
 * CUKUP ISI [URL] dengan link halaman donasi kamu (Trakteer / Saweria / Sociabuzz / Ko-fi, dst), lalu build ulang.
 * Selama [URL] kosong, tombolnya tampil "Segera hadir" dan tidak membuka apa-apa.
 */
object Donate {
    /** Contoh: "https://trakteer.id/namakamu" atau "https://saweria.co/namakamu". */
    val URL: String = ""
}

/**
 * Panel "Buy Lobo a meat": logo serigala melayang pelan dengan potongan daging di sudutnya, ajakan singkat, dan tombol
 * ke halaman donasi. Animasi hanya jalan selama panel terlihat ([PanelLife]), jadi tidak makan CPU saat notch idle / mode hemat.
 */
class DonatePanel(private val c: Context) : FrameLayout(c), Refreshable, PanelLife {
    /** Diisi NotchView: tutup panel dulu, baru buka browser (sama seperti Launcher / Alerts). */
    var closeThen: ((() -> Unit) -> Unit)? = null

    private val logo = ImageView(c)
    private val meats = arrayOf("🍖", "🍗", "🥩")
    private var meatIdx = 0
    private val meat = c.tv(meats[0], 26f)
    private var bob: ObjectAnimator? = null
    private var wobble: ObjectAnimator? = null

    init {
        val hasUrl = Donate.URL.isNotBlank()

        val card = LinearLayout(c)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = glass(C.GLASS, c.dpf(18))
        card.setPadding(c.dp(10), c.dp(6), c.dp(16), c.dp(6))

        // ---- kiri: logo Lobo + potongan daging
        val logoBox = FrameLayout(c)
        logo.setImageResource(R.drawable.ic_launcher_fg)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        logo.setOnClickListener { hop() }
        logoBox.addView(logo, LayoutParams(MATCH, MATCH))
        val ml = LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END)
        ml.setMargins(0, 0, c.dp(6), c.dp(8))
        meat.isClickable = false
        logoBox.addView(meat, ml)
        card.addView(logoBox, c.llp(c.dp(118), c.dp(118), 0f, 0, 0, 10, 0))

        // ---- kanan: judul, ajakan, tombol
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_VERTICAL

        col.addView(c.tv("Buy Lobo a meat", 20f, C.TEXT, true), c.llp(WRAP, WRAP, 0f, 0, 0, 0, 4))

        val desc = c.tv(
            "Lobo gratis & tanpa iklan. Traktir sepotong daging: dukunganmu dipakai buat langganan Claude Premium " +
                "supaya Lobo terus dikembangkan.",
            12.5f, C.SUB
        )
        desc.maxLines = 3
        desc.ellipsize = TextUtils.TruncateAt.END
        desc.setLineSpacing(0f, 1.1f)
        col.addView(desc, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 10))

        val btns = LinearLayout(c)
        btns.gravity = Gravity.CENTER_VERTICAL
        val buy = c.pill(
            if (hasUrl) "🍖  Traktir daging" else "Segera hadir",
            if (hasUrl) MEAT_RED else C.GLASS2, C.TEXT, 13f
        ) { openDonate() }
        btns.addView(buy, c.llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        if (hasUrl) {
            btns.addView(c.pill("Salin link", C.GLASS2, C.TEXT, 12f) { copyLink() }, c.llp(WRAP, WRAP, 0f, 0, 0, 10, 0))
        }
        val thanks = c.tv("Makasih, berapa pun itu ♥", 11.5f, C.SUB)
        thanks.maxLines = 2
        btns.addView(thanks, c.llp(0, WRAP, 1f))
        col.addView(btns, c.llp(MATCH, WRAP))

        card.addView(col, c.llp(0, MATCH, 1f))
        addView(card, LayoutParams(MATCH, MATCH))
    }

    private fun openDonate() {
        val url = Donate.URL.trim()
        if (url.isEmpty()) {
            Toast.makeText(c, "Link donasi belum diisi", Toast.LENGTH_SHORT).show()
            return
        }
        val go: () -> Unit = {
            try {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                c.startActivity(i)
            } catch (e: Exception) {
                Toast.makeText(c, "Tidak ada browser untuk membuka link", Toast.LENGTH_SHORT).show()
            }
        }
        val ct = closeThen
        if (ct != null) ct(go) else go()
    }

    private fun copyLink() {
        try {
            val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Lobo", Donate.URL.trim()))
            Toast.makeText(c, "Link disalin", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
        }
    }

    /** Ketuk logo: Lobo melompat kecil dan dagingnya ganti (🍖 → 🍗 → 🥩). */
    private fun hop() {
        meatIdx = (meatIdx + 1) % meats.size
        meat.text = meats[meatIdx]
        logo.animate().cancel()
        logo.scaleX = 0.86f
        logo.scaleY = 0.86f
        logo.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(OvershootInterpolator(3f)).start()
    }

    private fun startAnim() {
        if (bob == null) {
            bob = ObjectAnimator.ofFloat(logo, View.TRANSLATION_Y, -c.dpf(3), c.dpf(3)).apply {
                duration = 1700
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                interpolator = AccelerateDecelerateInterpolator()
            }
        }
        if (wobble == null) {
            wobble = ObjectAnimator.ofFloat(meat, View.ROTATION, -12f, 12f).apply {
                duration = 900
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                interpolator = AccelerateDecelerateInterpolator()
            }
        }
        if (bob?.isStarted != true) bob?.start()
        if (wobble?.isStarted != true) wobble?.start()
    }

    private fun stopAnim() {
        bob?.cancel()
        wobble?.cancel()
        bob = null
        wobble = null
        logo.translationY = 0f
        meat.rotation = 0f
    }

    override fun onVisible(v: Boolean) {
        if (v) startAnim() else stopAnim()
    }

    override fun onDetachedFromWindow() {
        stopAnim()
        super.onDetachedFromWindow()
    }

    override fun refresh() {
        // statis: tidak ada data yang perlu diperbarui
    }

    private companion object {
        val MEAT_RED = 0xFFFF5A4D.toInt()
    }
}
