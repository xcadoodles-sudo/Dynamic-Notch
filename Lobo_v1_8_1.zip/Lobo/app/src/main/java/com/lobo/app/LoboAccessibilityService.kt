package com.lobo.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Tidak membaca apa pun dari layar. Fungsinya cuma menyediakan jendela overlay jenis
 * TYPE_ACCESSIBILITY_OVERLAY, yang boleh menempel di tepi atas dan menerima sentuhan
 * di atas status bar.
 */
class LoboAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: LoboAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        NotchService.instance?.rebuildOverlay()
    }

    /** Aksi global (screenshot, recents, kunci layar) untuk tab Launcher. */
    fun act(code: Int): Boolean {
        return try {
            performGlobalAction(code)
        } catch (e: Exception) {
            false
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    }

    override fun onInterrupt() {
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        NotchService.instance?.rebuildOverlay()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
