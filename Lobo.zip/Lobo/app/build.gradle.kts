plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lobo.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.lobo.app"
        minSdk = 26
        targetSdk = 34
        // versionCode = menit sejak 1970 -> SELALU naik di tiap build, walau repo dibuat ulang / dipindah ke
        // repo private (nomor run GitHub akan mulai dari 1 lagi dan Android menolak "downgrade").
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "1.9.1"
    }

    // Kunci tanda tangan TETAP, TIDAK ikut di repo. Di GitHub: secret LOBO_KEYSTORE_B64 (file .jks, base64) dan
    // LOBO_KEYSTORE_PASSWORD (workflow memasangnya sebagai file + variabel env). Alias kunci: "lobo".
    // Tanpa keduanya (mis. build lokal / fork), APK tetap jadi tapi bertanda tangan debug, dan app menandainya
    // "bukan build resmi" (lihat Donate.isOfficial).
    signingConfigs {
        val ksPass = System.getenv("LOBO_KEYSTORE_PASSWORD")
        val ksFile = file("lobo-release-key.jks")
        if (!ksPass.isNullOrEmpty() && ksFile.exists()) {
            create("lobo") {
                storeFile = ksFile
                storePassword = ksPass
                keyAlias = "lobo"
                keyPassword = ksPass
            }
        }
    }
    val loboSigning = signingConfigs.findByName("lobo")

    buildTypes {
        debug {
            // build non-debuggable: tanpa agen debug, lebih ringan di RAM/CPU
            isDebuggable = false
            if (loboSigning != null) signingConfig = loboSigning
        }
        release {
            // R8: kode diperkecil + nama kelas/fungsi diacak, jadi APK jauh lebih sulit dibaca & diutak-atik
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro")
            signingConfig = loboSigning ?: signingConfigs.getByName("debug")
        }
    }
    lint {
        // lintVital tidak perlu menggagalkan build rilis di GitHub
        checkReleaseBuilds = false
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
