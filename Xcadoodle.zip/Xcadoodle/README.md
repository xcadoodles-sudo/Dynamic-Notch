# Xcadoodle untuk Android

"Living notch" yang menempel di tepi atas layar, dengan maskot serigala kecil.
Dibuat untuk Xiaomi Pad 6S Pro. Kotlin murni, tanpa Compose, dependensi cuma `androidx.core` + Shizuku.

## Cara build
- **Android Studio**: buka folder `Xcadoodle`, tunggu Gradle sync, Run / Build APK.
- **GitHub Actions**: upload folder ini ke repo, workflow ada di `.github/workflows/build.yml`.
  Hasil APK ada di Artifacts (`Xcadoodle-debug-apk`).

Pertama kali buka app, beri izin dari atas ke bawah (Display over other apps, Notification access,
Accessibility, dst), lalu tekan **Start notch**.

> Nama paket sekarang `com.xcadoodle.app`, jadi ini terpasang sebagai aplikasi BARU (bukan update dari Nusa).
> Uninstall Nusa lama, lalu beri izin ulang sekali.

## Maskot serigala
Kepala bulat gemuk dengan mata menyala dan outline neon ungu. Tinggal di sisi kiri pil saat tidak ada musik.

| Kondisi | Yang dilakukan |
|---|---|
| Idle | duduk, berkedip, melirik kiri/kanan, telinga berkedut, ekor goyang, bernapas |
| Tiap beberapa detik | jalan lenggak-lenggok ke kiri/kanan sepanjang pil: badan bergoyang, kaki bergantian, telinga berayun, wajah menoleh ke arah jalan |
| Diam ~20 detik | mengantuk (kelopak turun, kepala angguk-angguk), lalu meringkuk tidur dengan ekor melingkar dan "z z z" |
| Disentuh / panel dibuka | bangun, melar, duduk lagi |
| Notifikasi masuk | kaget dan melompat kecil |
| Tekan lama | dielus: mata senang, ekor cepat, hati melayang |

Waktu tidur, lama tidur, kecepatan jalan, dan kecepatan langkah ada di konstanta bagian atas `PetView` (`Mascot.kt`).
Ikon tab, tombol tutup, dan ikon alert digambar di `Icons.kt` (garis tipis minimalis, tanpa emoji).

## Alert / notifikasi
Pil alert berbentuk kapsul penuh: ikon garis di dalam lingkaran bertint lembut (warna sesuai jenis alert), judul medium + keterangan redup, isi di tengah. Notifikasi app lain menampilkan ikon app dalam kotak membulat. Ikon pop kecil saat alert muncul.

Ikon aplikasi (launcher) memakai kepala maskot dengan latar gelap, dan ada versi monochrome untuk themed icon Android 13+.

## Equalizer
- Bar bergerak dari gelombang sinus bertumpuk, jadi halus (tidak loncat acak). Naik cepat, turun pelan.
- Warna gradasi dari dua warna utama cover album yang sedang diputar; berubah mulus saat lagu ganti.
- Berhenti menggambar sendiri saat musik pause (hemat baterai).

## Tab Music
- Saat musik berjalan: judul, lirik, kontrol, dan **logo app sumber** (Spotify dll) di pojok cover. Ketuk cover/logo/judul untuk masuk ke app-nya.
- Saat tidak ada sesi musik (**standby**): tampil lagu terakhir yang diputar beserta covernya. Tekan play untuk melanjutkan **tanpa membuka Spotify**
  (dikirim sebagai tombol media PLAY, seperti tombol headset). Kalau Spotify belum merespons, tombol play meredup sebentar.

## Tab Device
Header menampilkan chipset dan GPU, mis. `Snapdragon 8 Gen 2 · Adreno 740`. Chipset dibaca dari `Build.SOC_MODEL` lewat tabel di `ChipInfo.kt`
(tambahkan baris sendiri kalau chipset Anda belum ada); nama GPU dibaca dari driver OpenGL.

## Warna notch
Pil saat idle (dan alert/panel tanpa warna album) memakai gradasi violet ke navy: `NOTCH_A` dan `NOTCH_B` di `NotchShape.kt`.

## Fitur lain
Music (lirik LRCLIB), Device (CPU/GPU/RAM/suhu, lebih lengkap dengan Shizuku), Markets (chart ala TradingView),
Calendar + cuaca, Shelf (drop/share file). Alert untuk baterai, jaringan, Bluetooth, dan notifikasi app lain.
Ukuran notch (lebar, tebal, jarak dari atas) bisa disetel di pengaturan app.
