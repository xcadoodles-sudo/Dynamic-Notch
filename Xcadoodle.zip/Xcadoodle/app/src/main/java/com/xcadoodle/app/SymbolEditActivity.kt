package com.xcadoodle.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread

/** Dialog kecil: tambah pair ke watchlist (simbol format Yahoo Finance) atau hapus pair. */
class SymbolEditActivity : Activity() {
    private val presets = listOf(
        Sym("SOLUSD", "Solana / US Dollar", "SOL-USD", null, 2),
        Sym("XAGUSD", "Silver Spot / US Dollar", "XAGUSD=X", "SI=F", 3),
        Sym("GBPUSD", "British Pound / US Dollar", "GBPUSD=X", null, 5),
        Sym("USDJPY", "US Dollar / Japanese Yen", "JPY=X", null, 3),
        Sym("USDIDR", "US Dollar / Rupiah", "IDR=X", null, 0),
        Sym("SPX", "S&P 500", "^GSPC", null, 2),
        Sym("BRENT", "Brent Crude Oil", "BZ=F", null, 2)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val remove = intent.getStringExtra("remove")
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(22), dp(18), dp(22), dp(14))

        if (remove != null) {
            root.addView(tv("Remove $remove?", 20f, C.TEXT, true), llp(WRAP, WRAP, 0f, 0, 0, 0, 6))
            root.addView(tv("It will disappear from the watchlist.", 13f, C.SUB), llp(WRAP, WRAP, 0f, 0, 0, 0, 14))
            val btns = LinearLayout(this)
            btns.gravity = Gravity.END
            btns.addView(pill("Cancel", C.CARD2, C.TEXT, 13f) { finish() }, llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
            btns.addView(pill("Remove", C.RED, C.TEXT, 13f) {
                Markets.remove(remove)
                Bus.changed()
                finish()
            })
            root.addView(btns, llp(MATCH, WRAP))
            setContentView(root)
            return
        }

        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        root.addView(tv("Add pair", 20f, C.TEXT, true), llp(WRAP, WRAP, 0f, 0, 0, 0, 4))
        root.addView(tv("Yahoo Finance symbol, e.g. BTC-USD, EURUSD=X, GC=F, ^GSPC, AAPL", 12f, C.SUB), llp(WRAP, WRAP, 0f, 0, 0, 0, 10))
        val et = EditText(this)
        et.hint = "Symbol"
        et.setSingleLine(true)
        root.addView(et, llp(dp(320), WRAP))

        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val chips = LinearLayout(this)
        for (p in presets) {
            val t: TextView = pill(p.id, C.CARD2, C.TEXT, 12f) { tryAdd(p) }
            chips.addView(t, llp(WRAP, WRAP, 0f, 0, 0, 6, 0))
        }
        hs.addView(chips)
        root.addView(hs, llp(dp(320), WRAP, 0f, 0, 10, 0, 0))

        val btns = LinearLayout(this)
        btns.gravity = Gravity.END
        btns.addView(pill("Cancel", C.CARD2, C.TEXT, 13f) { finish() }, llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        btns.addView(pill("Add", C.ACCENT, C.TEXT, 13f) {
            val y = et.text.toString().trim().uppercase()
            if (y.isEmpty()) {
                et.error = "Required"
            } else {
                val id = y.replace("=X", "").replace("-USD", "USD").replace("^", "").replace("=F", "")
                tryAdd(Sym(id, y, y, null, 2))
            }
        })
        root.addView(btns, llp(MATCH, WRAP, 0f, 0, 14, 0, 0))
        setContentView(root)
    }

    private fun tryAdd(s: Sym) {
        Toast.makeText(this, "Checking ${s.yahoo}…", Toast.LENGTH_SHORT).show()
        thread {
            val q = Markets.fetch(s.yahoo, Markets.tfs[0]) ?: s.alt?.let { Markets.fetch(it, Markets.tfs[0]) }
            runOnUiThread {
                if (q == null) {
                    Toast.makeText(this, "Symbol not found: ${s.yahoo}", Toast.LENGTH_LONG).show()
                } else {
                    // desimal menyesuaikan besaran harga kalau simbol custom
                    val dec = if (s.dec != 2) s.dec else if (q.price >= 1000) 2 else if (q.price >= 10) 2 else if (q.price >= 1) 4 else 5
                    Markets.add(Sym(s.id, s.name, s.yahoo, s.alt, dec))
                    Bus.changed()
                    finish()
                }
            }
        }
    }
}
