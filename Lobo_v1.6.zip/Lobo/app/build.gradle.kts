plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lobo.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.lobo.app"
        minSdk = 26
        targetSdk = 34
        // versionCode naik otomatis di tiap build GitHub Actions (nomor run), jadi APK baru selalu dianggap
        // update oleh Android. Build lokal (Android Studio) memakai 100.
        versionCode = 100 + (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0)
        versionName = "1.6.0"
    }

    // Kunci tanda tangan TETAP (ikut di repo). Tanpa ini tiap build GitHub memakai debug key acak,
    // dan Android menolak update di atas versi sebelumnya (harus uninstall + izin ulang).
    signingConfigs {
        create("lobo") {
            storeFile = file("lobo-release-key.jks")
            storePassword = "lobo-notch"
            keyAlias = "lobo"
            keyPassword = "lobo-notch"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("lobo")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("lobo")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
