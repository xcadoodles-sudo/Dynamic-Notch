# Xcadoodle untuk Android

"Living notch" yang menempel di tepi atas layar, dengan maskot serigala kecil.
Dibuat untuk Xiaomi Pad 6S Pro. Kotlin murni, tanpa Compose, dependensi cuma `androidx.core` + Shizuku.

## Cara build
- **Android Studio**: buka folder `Xcadoodle`, tunggu Gradle sync, Run / Build APK.
- **GitHub Actions**: upload folder ini ke repo, workflow ada di `.github/workflows/build.yml`.
  Hasil APK ada di Artifacts (`Xcadoodle-debug-apk`).

Pertama kali buka app, beri izin dari atas ke bawah (Display over other apps, Notification access,
Accessibility, dst), lalu tekan **Start notch**.

> Nama paket sekarang `com.xcadoodle.app`, jadi ini terpasang sebagai aplikasi BARU (bukan update dari Nusa).
> Uninstall Nusa lama, lalu beri izin ulang sekali.

## Maskot serigala
Tinggal di sisi kiri pil saat tidak ada musik.

| Kondisi | Yang dilakukan |
|---|---|
| Idle | duduk, berkedip, telinga berkedut, ekor goyang, bernapas |
| Tiap beberapa detik | jalan-jalan ke kiri/kanan sepanjang pil, badan menoleh sesuai arah |
| Diam ~20 detik | mengantuk (kepala angguk-angguk), lalu meringkuk tidur dengan "z z z" |
| Disentuh / panel dibuka | bangun, melar, duduk lagi |
| Notifikasi masuk | kaget dan melompat kecil |
| Tekan lama | dielus: mata senang, ekor cepat, hati melayang |

Waktu tidur, lama tidur, dan kecepatan jalan ada di konstanta bagian atas `PetView` (`Mascot.kt`).

## Equalizer
- Bar bergerak dari gelombang sinus bertumpuk, jadi halus (tidak loncat acak). Naik cepat, turun pelan.
- Warna gradasi dari dua warna utama cover album yang sedang diputar; berubah mulus saat lagu ganti.
- Berhenti menggambar sendiri saat musik pause (hemat baterai).

## Fitur lain
Music (lirik LRCLIB), Device (CPU/GPU/RAM/suhu, lebih lengkap dengan Shizuku), Markets (chart ala TradingView),
Calendar + cuaca, Shelf (drop/share file). Alert untuk baterai, jaringan, Bluetooth, dan notifikasi app lain.
Ukuran notch (lebar, tebal, jarak dari atas) bisa disetel di pengaturan app.
