package com.lobo.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/**
 * Jendela notch tidak bisa menerima keyboard kalau memakai overlay Accessibility, jadi menambah
 * to-do dilakukan di kotak kecil transparan di atas layar. Setelah tersimpan, tab Widgets dibuka lagi.
 */
class TodoInputActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val input = EditText(this)
        fun send() {
            val t = input.text.toString().trim()
            if (t.isEmpty()) return
            TodoStore.add(t)
            Bus.changed()
            finish()
            NotchService.instance?.openTab(NotchView.TAB_WIDGETS)
        }

        val root = FrameLayout(this)
        root.setBackgroundColor(0x66000000)
        root.setOnClickListener { finish() }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = rounded(0xFF0A0A0D.toInt(), dpf(28))
        card.setPadding(dp(18), dp(10), dp(10), dp(10))
        card.isClickable = true

        input.hint = "Add a to-do…"
        input.setHintTextColor(0x66FFFFFF)
        input.setTextColor(C.TEXT)
        input.textSize = 15f
        input.background = null
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        input.imeOptions = EditorInfo.IME_ACTION_DONE
        input.maxLines = 2
        input.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_DONE) {
                send()
                true
            } else {
                false
            }
        }
        card.addView(input, llp(0, WRAP, 1f))
        val btn = LineIconView(this, IconKind.SEND, C.BLACK, 18f, 2f)
        btn.background = rounded(C.TEXT, dpf(20))
        btn.setOnClickListener { send() }
        card.addView(btn, llp(dp(40), dp(40), 0f, 8, 0, 0, 0))

        val sw = resources.displayMetrics.widthPixels
        val lp = FrameLayout.LayoutParams(minOf(sw - dp(24), dp(520)), WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        lp.topMargin = dp(12)
        root.addView(card, lp)
        setContentView(root)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        input.requestFocus()
    }
}

/** Activity tak terlihat: begitu mendapat fokus, baca clipboard (satu-satunya cara resmi di Android 10+), lalu tutup. */
class ClipReadActivity : Activity() {
    private var done = false

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || done) return
        done = true
        val ok = ClipWatcher.captureNow(this)
        if (!ok && ClipStore.items().isEmpty()) {
            Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
        }
        finish()
        overridePendingTransition(0, 0)
    }
}

/** Pilih app untuk satu slot di tab Launcher. */
class AppPickActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val slot = intent.getIntExtra("slot", 0)
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN)
        q.addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(C.APP_BG)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(28), dp(20), dp(32))
        col.addView(tv("Choose an app", 20f, C.TEXT, true), llp(MATCH, WRAP, 0f, 0, 0, 0, 14))

        for (a in apps) {
            val pkg = a.first
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(9), dp(12), dp(9))
            row.background = rounded(C.CARD, dpf(14))
            val ic = ImageView(this)
            try {
                ic.setImageDrawable(pm.getApplicationIcon(pkg))
            } catch (e: Exception) {
            }
            row.addView(ic, llp(dp(36), dp(36), 0f, 0, 0, 14, 0))
            row.addView(tv(a.second, 15f, C.TEXT), llp(0, WRAP, 1f))
            row.setOnClickListener {
                LauncherStore.set(slot, pkg)
                Bus.changed()
                finish()
            }
            col.addView(row, llp(MATCH, WRAP, 0f, 0, 0, 0, 6))
        }
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        setContentView(scroll)
    }
}
