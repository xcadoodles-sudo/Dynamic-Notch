package com.xcadoodle.app

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.Choreographer
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.Interpolator
import android.widget.FrameLayout

/**
 * Pegas teredam kritis (tanpa overshoot): mulai halus, cepat di tengah, mendarat lembut.
 * w makin besar = makin cepat mendarat.
 */
class Spring(private val w: Float) : Interpolator {
    private val norm = 1f - (1f + w) * Math.exp(-w.toDouble()).toFloat()

    override fun getInterpolation(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return (1f - (1f + w * x) * Math.exp((-w * x).toDouble()).toFloat()) / norm
    }
}

/**
 * Bentuk notch. Dua lapis:
 *  - lapisan bawah menggambar siluet penuh (termasuk "telinga" cekung di sudut atas, seperti
 *    notch MacBook) dengan gradasi warna;
 *  - lapisan [content] di atasnya, di-clip ke badan notch (tanpa telinga), tempat semua isi ditaruh.
 *
 * Bentuk (lebar, tinggi, radius) dianimasikan lewat [animate]. Selama animasi tidak ada layout
 * ulang dan tidak ada perubahan ukuran jendela: yang berubah cuma outline dan siluet.
 */
class NotchShape(c: Context) : FrameLayout(c) {
    val content = FrameLayout(c)

    var vW = 0f
        private set
    var vH = 0f
        private set
    var vR = 0f
        private set
    var tint = C.BLACK
        private set

    /** Menempel di tepi atas layar (atas datar + telinga). false = pil melayang. */
    var flat = true

    /** Radius telinga (px). 0 = tanpa telinga. */
    var ear = 0f

    private val bgView = object : View(c) {
        override fun onDraw(canvas: Canvas) {
            drawShape(canvas)
        }
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val arc = RectF()
    private val gm = Matrix()
    private var shader: LinearGradient? = null

    private val choreo = Choreographer.getInstance()
    private val argb = ArgbEvaluator()
    private var running = false
    private var dur = 1f
    private var el = 0f
    private var last = 0L
    private var w0 = 0f
    private var h0 = 0f
    private var r0 = 0f
    private var w1 = 0f
    private var h1 = 0f
    private var r1 = 0f
    private var t0 = 0
    private var t1 = 0
    private var eW: Interpolator = Spring(9f)
    private var eH: Interpolator = Spring(10f)
    private var onProg: ((Float) -> Unit)? = null
    private var onDone: (() -> Unit)? = null
    private var tintAnim: ValueAnimator? = null

    // ---- aura idle: cahaya biru -> indigo -> ungu di dalam & sekeliling notch (seperti awal video promo)
    private val dens = c.resources.displayMetrics.density
    private val auraM = Matrix()
    private val innerM = Matrix()
    private val rimPath = Path()
    private val rimShader = LinearGradient(
        0f, 0f, 1f, 0f,
        intArrayOf(0xFF3DB8FF.toInt(), 0xFF6C5CFF.toInt(), 0xFFB06BFF.toInt()),
        floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
    )
    private val innerShader = RadialGradient(
        0f, 0f, 1f,
        intArrayOf(0xB35B7CFF.toInt(), 0x667C4DFF.toInt(), 0x007C4DFF),
        floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
    )
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        shader = rimShader
    }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        shader = rimShader
    }
    private val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = innerShader }
    private val haloAlpha = floatArrayOf(0.14f, 0.12f, 0.10f, 0.08f, 0.055f, 0.035f)

    /** 0 = polos hitam (dipakai alert/panel), 1 = aura penuh (pil idle). Dipudarkan saat morph. */
    var auraAlpha = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            bgView.invalidate()
        }

    val animating: Boolean get() = running

    init {
        addView(bgView, LayoutParams(MATCH, MATCH))
        addView(content, LayoutParams(MATCH, MATCH))
        content.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val cx = view.width / 2f
                val l = Math.round(cx - vW / 2f)
                val r = Math.round(cx + vW / 2f)
                val top = if (flat) -Math.round(vR) - 2 else 0
                outline.setRoundRect(l, top, r, Math.round(vH), vR)
            }
        }
        content.clipToOutline = true
        buildShader(C.BLACK)
    }

    // ------------------------------------------------------------ warna

    private fun buildShader(col: Int) {
        val dark = Color.rgb((Color.red(col) * 0.5f).toInt(), (Color.green(col) * 0.5f).toInt(), (Color.blue(col) * 0.5f).toInt())
        shader = LinearGradient(0f, 0f, 1f, 0f, col, dark, Shader.TileMode.CLAMP)
        paint.shader = shader
    }

    fun setTintNow(col: Int) {
        tint = col
        buildShader(col)
        bgView.invalidate()
    }

    /** Pindah warna halus (dipakai saat warna album berubah). Diabaikan selagi bentuk beranimasi. */
    fun animateTint(target: Int) {
        if (target == tint || running) return
        if (tintAnim?.isRunning == true) return
        val a = ValueAnimator.ofArgb(tint, target)
        a.duration = 350
        a.addUpdateListener { setTintNow(it.animatedValue as Int) }
        a.start()
        tintAnim = a
    }

    // ------------------------------------------------------------ gambar

    private fun drawShape(cv: Canvas) {
        if (vW <= 0f || vH <= 0f) return
        val cx = width / 2f
        val l = cx - vW / 2f
        val r = cx + vW / 2f
        val br = minOf(vR, vH / 2f, vW / 2f)
        path.reset()
        if (flat && ear > 0.5f) {
            val e = minOf(ear, vH - br)
            path.moveTo(l - e, 0f)
            path.lineTo(r + e, 0f)
            // telinga kanan: lengkung cekung dari tepi atas turun ke sisi badan
            arc.set(r, 0f, r + 2f * e, 2f * e)
            path.arcTo(arc, 270f, -90f)
            path.lineTo(r, vH - br)
            arc.set(r - 2f * br, vH - 2f * br, r, vH)
            path.arcTo(arc, 0f, 90f)
            path.lineTo(l + br, vH)
            arc.set(l, vH - 2f * br, l + 2f * br, vH)
            path.arcTo(arc, 90f, 90f)
            path.lineTo(l, e)
            // telinga kiri
            arc.set(l - 2f * e, 0f, l, 2f * e)
            path.arcTo(arc, 0f, -90f)
            path.close()
        } else {
            val top = if (flat) -br - 2f else 0f
            path.addRoundRect(l, top, r, vH, br, br, Path.Direction.CW)
        }
        gm.setScale(vW, 1f)
        gm.postTranslate(l, 0f)
        shader?.setLocalMatrix(gm)
        val a = auraAlpha
        if (a > 0.01f) {
            auraM.setScale(vW, 1f)
            auraM.postTranslate(l, 0f)
            rimShader.setLocalMatrix(auraM)
            // halo: lapisan garis tebal makin lebar & makin pudar di sekeliling siluet (efek blur murah)
            for (i in haloAlpha.indices) {
                haloPaint.strokeWidth = dens * 2.4f * (i + 1)
                haloPaint.alpha = (255f * haloAlpha[i] * a).toInt()
                cv.drawPath(path, haloPaint)
            }
        }
        cv.drawPath(path, paint)
        if (a > 0.01f) {
            // cahaya dalam: naik dari dasar notch
            innerM.setScale(vW * 0.62f, vH * 1.15f)
            innerM.postTranslate(cx, vH)
            innerShader.setLocalMatrix(innerM)
            innerPaint.alpha = (255f * a).toInt()
            cv.drawPath(path, innerPaint)
            // garis tepi bercahaya di separuh bawah
            val inset = dens * 0.8f
            val top = maxOf(if (flat) minOf(ear, vH) else 0f, vH * 0.45f)
            rimPath.reset()
            rimPath.moveTo(l + inset, top)
            rimPath.lineTo(l + inset, vH - inset - br)
            arc.set(l + inset, vH - 2f * br - inset, l + inset + 2f * br, vH - inset)
            rimPath.arcTo(arc, 180f, -90f)
            rimPath.lineTo(r - inset - br, vH - inset)
            arc.set(r - inset - 2f * br, vH - 2f * br - inset, r - inset, vH - inset)
            rimPath.arcTo(arc, 90f, -90f)
            rimPath.lineTo(r - inset, top)
            rimPaint.strokeWidth = dens * 3.2f
            rimPaint.alpha = (255f * 0.28f * a).toInt()
            cv.drawPath(rimPath, rimPaint)
            rimPaint.strokeWidth = dens * 1.2f
            rimPaint.alpha = (255f * 0.95f * a).toInt()
            cv.drawPath(rimPath, rimPaint)
        }
    }

    private fun touch() {
        content.invalidateOutline()
        bgView.invalidate()
    }

    // ------------------------------------------------------------ animasi

    fun setShapeNow(w: Float, h: Float, r: Float) {
        stopAnim()
        vW = w
        vH = h
        vR = r
        touch()
    }

    private fun stopAnim() {
        if (running) {
            choreo.removeFrameCallback(frameCb)
            running = false
        }
        onProg = null
        onDone = null
    }

    fun release() {
        stopAnim()
        tintAnim?.cancel()
    }

    /**
     * Morph ke bentuk baru mulai dari bentuk yang tampil sekarang (aman dipanggil ulang di tengah
     * animasi). [onProgress] menerima kemajuan 0..1 yang sudah di-ease; [onEnd] dipanggil sekali
     * di akhir (tidak dipanggil kalau animasi diganti animasi lain).
     */
    fun animate(
        w: Float, h: Float, r: Float, tintTo: Int, durMs: Long, omega: Float,
        onProgress: ((Float) -> Unit)? = null, onEnd: (() -> Unit)? = null
    ) {
        if (running) {
            choreo.removeFrameCallback(frameCb)
            running = false
        }
        tintAnim?.cancel()
        w0 = vW
        h0 = vH
        r0 = vR
        w1 = w
        h1 = h
        r1 = r
        t0 = tint
        t1 = tintTo
        eW = Spring(omega)
        eH = Spring(omega * 1.18f)
        dur = durMs.toFloat()
        el = 0f
        last = 0L
        onProg = onProgress
        onDone = onEnd
        running = true
        choreo.postFrameCallback(frameCb)
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            if (last == 0L) {
                last = frameTimeNanos
            } else {
                // dt dibatasi supaya frame tersendat tidak bikin animasi melompat
                el += ((frameTimeNanos - last) / 1_000_000f).coerceIn(0f, 32f)
                last = frameTimeNanos
            }
            val u = (el / dur).coerceAtMost(1f)
            val f = eW.getInterpolation(u)
            val fh = eH.getInterpolation(u)
            vW = w0 + (w1 - w0) * f
            vH = h0 + (h1 - h0) * fh
            vR = r0 + (r1 - r0) * f
            if (t1 != t0) {
                tint = argb.evaluate(f, t0, t1) as Int
                buildShader(tint)
            }
            touch()
            onProg?.invoke(f)
            if (u >= 1f) {
                running = false
                vW = w1
                vH = h1
                vR = r1
                if (t1 != t0) {
                    tint = t1
                    buildShader(t1)
                }
                touch()
                val d = onDone
                onDone = null
                onProg = null
                d?.invoke()
            } else {
                choreo.postFrameCallback(this)
            }
        }
    }

    override fun onDetachedFromWindow() {
        stopAnim()
        tintAnim?.cancel()
        super.onDetachedFromWindow()
    }
}
