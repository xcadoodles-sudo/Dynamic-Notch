package com.xcadoodle.app

import android.animation.ArgbEvaluator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.Choreographer
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Ambil dua warna utama dari cover album: yang paling dominan (jenuh + terang) dan satu warna
 * kedua yang berbeda. Kalau cover nyaris abu-abu, dipakai putih-kebiruan -> abu-biru.
 */
object ArtPalette {
    private const val SIZE = 24

    fun of(src: Bitmap): IntArray? {
        return try {
            val bm = Bitmap.createScaledBitmap(src, SIZE, SIZE, true)
            val px = IntArray(SIZE * SIZE)
            bm.getPixels(px, 0, SIZE, 0, 0, SIZE, SIZE)
            if (bm !== src) bm.recycle()

            val hsv = FloatArray(3)
            val wSum = FloatArray(12)
            val hSum = FloatArray(12)
            val sSum = FloatArray(12)
            val vSum = FloatArray(12)
            var total = 0f
            for (p in px) {
                if (Color.alpha(p) < 40) continue
                Color.colorToHSV(p, hsv)
                val s = hsv[1]
                val v = hsv[2]
                if (v < 0.18f || s < 0.15f) continue
                val w = s * s * (0.4f + v)
                val b = (hsv[0] / 30f).toInt().coerceIn(0, 11)
                wSum[b] += w
                hSum[b] += w * hsv[0]
                sSum[b] += w * s
                vSum[b] += w * v
                total += w
            }
            if (total < 6f) return intArrayOf(0xFFEAF1FF.toInt(), 0xFF8E9BB8.toInt())

            // bin terbaik (digabung dengan tetangganya supaya warna yang "pecah" di batas bin tetap menang)
            var b0 = 0
            var best = -1f
            for (b in 0 until 12) {
                val sc = wSum[b] + 0.5f * (wSum[(b + 11) % 12] + wSum[(b + 1) % 12])
                if (wSum[b] > 0f && sc > best) {
                    best = sc
                    b0 = b
                }
            }
            val h0 = hSum[b0] / wSum[b0]
            val s0 = sSum[b0] / wSum[b0]
            val v0 = vSum[b0] / wSum[b0]
            val a = Color.HSVToColor(floatArrayOf(h0, s0.coerceIn(0.55f, 1f), (v0 * 1.15f).coerceIn(0.85f, 1f)))

            // warna kedua: bin yang jauh (>= 60 derajat) dengan bobot cukup
            var b1 = -1
            var w1 = 0f
            for (b in 0 until 12) {
                val d = min((b - b0 + 12) % 12, (b0 - b + 12) % 12)
                if (d >= 2 && wSum[b] > w1) {
                    w1 = wSum[b]
                    b1 = b
                }
            }
            val second = if (b1 >= 0 && w1 >= 0.22f * wSum[b0]) {
                Color.HSVToColor(
                    floatArrayOf(
                        hSum[b1] / wSum[b1],
                        (sSum[b1] / wSum[b1]).coerceIn(0.55f, 1f),
                        (vSum[b1] / wSum[b1] * 1.1f).coerceIn(0.8f, 1f)
                    )
                )
            } else {
                // cover satu warna: geser hue sedikit supaya gradasinya tetap terlihat
                Color.HSVToColor(floatArrayOf((h0 + 38f) % 360f, s0.coerceIn(0.55f, 1f), (v0 * 0.9f).coerceIn(0.75f, 1f)))
            }
            intArrayOf(a, second)
        } catch (e: Throwable) {
            null
        }
    }
}

/**
 * Equalizer di pil notch saat musik jalan.
 *  - Tinggi bar digerakkan gelombang sinus bertumpuk (halus, tidak loncat acak) + denyut ringan bersama.
 *  - Naik cepat, turun pelan (peredam eksponensial, tidak bergantung frame rate).
 *  - Saat musik berhenti bar turun mulus ke tinggi istirahat lalu loop berhenti (hemat baterai).
 *  - Warna: gradasi vertikal dari 2 warna cover album, bertransisi mulus saat lagu ganti.
 */
class EqView(c: Context) : View(c) {
    companion object {
        private const val N = 5
        private const val REST = 0.16f
        private val DEF_A = 0xFF8B7BFF.toInt()
        private val DEF_B = 0xFF40C8E0.toInt()
        private val F1 = doubleArrayOf(1.7, 2.3, 1.2, 2.9, 1.9)
        private val F2 = doubleArrayOf(3.1, 4.1, 2.7, 3.7, 4.9)
        private val F3 = doubleArrayOf(0.7, 0.5, 0.9, 0.6, 0.8)
        private val P1 = doubleArrayOf(0.0, 1.9, 3.7, 5.1, 2.6)
        private val P2 = doubleArrayOf(2.2, 0.4, 4.4, 1.3, 5.6)
        private val P3 = doubleArrayOf(4.1, 3.3, 0.8, 2.0, 1.1)
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val argb = ArgbEvaluator()
    private val lv = FloatArray(N) { REST }

    private var tm = 0.0
    private var lastT = 0L
    private var posted = false

    private var aFrom = DEF_A
    private var bFrom = DEF_B
    private var aTo = DEF_A
    private var bTo = DEF_B
    private var curA = DEF_A
    private var curB = DEF_B
    private var colT = 1f
    private var lastArt: Bitmap? = null

    /** Dua warna gradasi yang sedang dituju (dari cover album). Dipakai juga oleh aura notch. */
    val colA: Int get() = aTo
    val colB: Int get() = bTo

    /** Rata-rata tinggi bar di atas tinggi istirahat, 0..1. Sumber denyut aura notch. */
    val energy: Float
        get() {
            var s = 0f
            for (v in lv) s += v
            return ((s / N - REST) / (1f - REST)).coerceIn(0f, 1f)
        }

    var active = true
        set(v) {
            if (field == v) return
            field = v
            if (v) start()
        }

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            posted = false
            if (!isAttachedToWindow || visibility != VISIBLE) return
            val t = frameTimeNanos / 1_000_000L
            val dt = if (lastT == 0L) 0.016f else ((t - lastT).coerceIn(1L, 50L)) / 1000f
            lastT = t
            val settled = update(dt)
            invalidate()
            if (!settled) {
                posted = true
                Choreographer.getInstance().postFrameCallback(this)
            } else {
                lastT = 0L
            }
        }
    }

    private fun start() {
        if (posted || !isAttachedToWindow || visibility != VISIBLE) return
        posted = true
        lastT = 0L
        Choreographer.getInstance().postFrameCallback(frame)
    }

    /** Pakai warna dari cover album. null = warna bawaan. Aman dipanggil berulang. */
    fun setArt(b: Bitmap?) {
        if (b === lastArt) return
        lastArt = b
        val p = if (b == null) null else ArtPalette.of(b)
        setColors(p?.get(0) ?: DEF_A, p?.get(1) ?: DEF_B)
    }

    private fun setColors(a: Int, b: Int) {
        if (a == aTo && b == bTo) return
        aFrom = curA
        bFrom = curB
        aTo = a
        bTo = b
        colT = 0f
        start()
    }

    /** @return true kalau semua sudah diam (loop boleh berhenti). */
    private fun update(dt: Float): Boolean {
        tm += dt.toDouble()
        var settled = true

        if (colT < 1f) {
            colT = min(1f, colT + dt / 0.8f)
            val e = colT * colT * (3f - 2f * colT)
            curA = argb.evaluate(e, aFrom, aTo) as Int
            curB = argb.evaluate(e, bFrom, bTo) as Int
            rebuildShader()
            settled = false
        }

        val beat = (0.5 + 0.5 * sin(2.0 * PI * 1.95 * tm)).toFloat()
        for (i in 0 until N) {
            val target = if (active) {
                val a = sin(2.0 * PI * F1[i] * tm + P1[i])
                val b = sin(2.0 * PI * F2[i] * tm + P2[i])
                val c = sin(2.0 * PI * F3[i] * tm + P3[i])
                val v = (0.5 + 0.5 * (0.5 * a + 0.3 * b + 0.2 * c)).toFloat().coerceIn(0f, 1f)
                val amp = (0.12f + 0.88f * v.pow(1.35f)) * (0.82f + 0.18f * beat)
                REST + (1f - REST) * amp
            } else {
                REST
            }
            val k = if (target > lv[i]) 16f else 6.5f
            lv[i] += (target - lv[i]) * (1f - exp(-k * dt))
            if (active || abs(target - lv[i]) > 0.002f) settled = false
        }
        return settled
    }

    private fun rebuildShader() {
        val h = height.toFloat()
        if (h <= 0f) return
        paint.shader = LinearGradient(0f, 0f, 0f, h, curA, curB, Shader.TileMode.CLAMP)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        rebuildShader()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        rebuildShader()
        start()
    }

    override fun onDetachedFromWindow() {
        posted = false
        Choreographer.getInstance().removeFrameCallback(frame)
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) start()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val gapRatio = 0.65f
        val bw = w / (N + (N - 1) * gapRatio)
        val gap = bw * gapRatio
        for (i in 0 until N) {
            val bh = max(bw, h * lv[i])
            val x = i * (bw + gap)
            canvas.drawRoundRect(x, h - bh, x + bw, h, bw / 2f, bw / 2f, paint)
        }
    }
}
