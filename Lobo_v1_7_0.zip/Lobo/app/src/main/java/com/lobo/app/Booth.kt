package com.lobo.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.display.DisplayManager
import android.media.MediaActionSound
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

// ------------------------------------------------------------------ penyimpanan foto

/**
 * Foto Photo Booth disimpan dua kali: salinan privat di filesDir/LoboBooth (untuk strip di panel notch + berbagi lewat
 * FileProvider) dan salinan di galeri (Pictures/Lobo Photo Booth). Salinan privat dibatasi [MAX] terakhir.
 */
object BoothStore {
    private const val MAX = 12

    val dir: File
        get() {
            val d = File(Lobo.app.filesDir, "LoboBooth")
            d.mkdirs()
            return d
        }

    fun items(): List<File> =
        (dir.listFiles()?.filter { it.isFile && it.extension.equals("jpg", true) } ?: emptyList()).sortedByDescending { it.lastModified() }

    fun uriFor(f: File): Uri = FileProvider.getUriForFile(Lobo.app, Lobo.app.packageName + ".files", f)

    fun save(ctx: Context, bmp: Bitmap): File? {
        val name = "LoboBooth_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val f = File(dir, name)
        try {
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 94, it) }
        } catch (e: Exception) {
            f.delete()
            return null
        }
        exportToGallery(ctx, f, name)
        items().drop(MAX).forEach { it.delete() }
        return f
    }

    private fun exportToGallery(ctx: Context, f: File, name: String) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.Images.Media.DISPLAY_NAME, name)
                v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Lobo Photo Booth")
                v.put(MediaStore.Images.Media.IS_PENDING, 1)
                val r = ctx.contentResolver
                val uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
                r.openOutputStream(uri)?.use { o -> f.inputStream().use { i -> i.copyTo(o) } }
                val done = ContentValues()
                done.put(MediaStore.Images.Media.IS_PENDING, 0)
                r.update(uri, done, null, null)
            } else {
                @Suppress("DEPRECATION")
                val pics = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val d = File(pics, "Lobo Photo Booth")
                d.mkdirs()
                val out = File(d, name)
                f.copyTo(out, true)
                MediaScannerConnection.scanFile(ctx, arrayOf(out.absolutePath), arrayOf("image/jpeg"), null)
            }
        } catch (e: Exception) {
            // salinan galeri gagal (izin ditolak, penyimpanan penuh): salinan privat tetap ada
        }
    }
}

// ------------------------------------------------------------------ efek warna (ColorMatrix)

private fun fxMat(vararg v: Float): ColorMatrix = ColorMatrix(v)

private fun fxSat(s: Float): ColorMatrix {
    val m = ColorMatrix()
    m.setSaturation(s)
    return m
}

private fun fxCat(a: ColorMatrix, b: ColorMatrix): ColorMatrix {
    val r = ColorMatrix(a)
    r.postConcat(b)
    return r
}

private fun fxContrast(c: Float, bright: Float = 0f): ColorMatrix {
    val t = (0.5f - 0.5f * c) * 255f + bright
    return fxMat(
        c, 0f, 0f, 0f, t,
        0f, c, 0f, 0f, t,
        0f, 0f, c, 0f, t,
        0f, 0f, 0f, 1f, 0f
    )
}

private class BoothFx(val name: String, val matrix: ColorMatrix?) {
    fun paint(): Paint? {
        val m = matrix ?: return null
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.colorFilter = ColorMatrixColorFilter(m)
        return p
    }
}

private val BOOTH_FX: List<BoothFx> = listOf(
    BoothFx("Normal", null),
    BoothFx("Mono", fxSat(0f)),
    BoothFx("Noir", fxCat(fxSat(0f), fxContrast(1.4f, -6f))),
    BoothFx(
        "Sepia", fxMat(
            0.393f, 0.769f, 0.189f, 0f, 0f,
            0.349f, 0.686f, 0.168f, 0f, 0f,
            0.272f, 0.534f, 0.131f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )
    ),
    BoothFx("Fade", fxCat(fxSat(0.55f), fxContrast(0.82f, 14f))),
    BoothFx("Vivid", fxCat(fxSat(1.7f), fxContrast(1.1f))),
    BoothFx("Pop", fxCat(fxSat(2.4f), fxContrast(1.3f))),
    BoothFx(
        "Warm", fxMat(
            1.16f, 0f, 0f, 0f, 10f,
            0f, 1.02f, 0f, 0f, 4f,
            0f, 0f, 0.84f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )
    ),
    BoothFx(
        "Cool", fxMat(
            0.88f, 0f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f, 6f,
            0f, 0f, 1.18f, 0f, 12f,
            0f, 0f, 0f, 1f, 0f
        )
    ),
    BoothFx(
        "Neon", fxMat(
            0.284f, 0.558f, 0.108f, 0f, 0f,
            0.105f, 0.205f, 0.040f, 0f, 0f,
            0.344f, 0.675f, 0.131f, 0f, 8f,
            0f, 0f, 0f, 1f, 0f
        )
    ),
    BoothFx(
        "X-Ray", fxCat(
            fxCat(
                fxSat(0f), fxMat(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )
            ),
            fxMat(
                0.55f, 0f, 0f, 0f, 0f,
                0f, 0.85f, 0f, 0f, 8f,
                0f, 0f, 1.15f, 0f, 22f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )
)

// ------------------------------------------------------------------ panel di notch (tab Tools -> Booth)

/** Tombol buka Photo Booth + strip foto terakhir. Ketuk foto = buka, tekan lama = hapus. */
class BoothPanel(private val c: Context) : FrameLayout(c), Refreshable {
    /** Diisi NotchView: tutup panel dulu, baru jalankan aksi (buka kamera / galeri). */
    var closeThen: ((() -> Unit) -> Unit)? = null
    private val strip = LinearLayout(c)
    private var sig = "?"
    private val thumbs = HashMap<String, Bitmap>()

    init {
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL

        val head = LinearLayout(c)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(c.tv("Photo Booth", 14f, C.TEXT, true))
        head.addView(View(c), c.llp(0, 1, 1f))
        head.addView(c.tv("Tap a photo to open · hold to delete", 10.5f, C.SUB))
        col.addView(head, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 8))

        val row = LinearLayout(c)
        row.gravity = Gravity.CENTER_VERTICAL

        val open = LinearLayout(c)
        open.orientation = LinearLayout.VERTICAL
        open.gravity = Gravity.CENTER
        open.background = glass(C.GLASS2, c.dpf(18))
        open.addView(LineIconView(c, IconKind.CAMERA, C.TEXT, 26f, 1.5f), c.llp(c.dp(32), c.dp(32)))
        open.addView(c.tv("Open Booth", 12.5f, C.TEXT, true), c.llp(WRAP, WRAP, 0f, 0, 6, 0, 0))
        open.addView(c.tv("Effects · 4-Up · Strip", 10f, C.SUB), c.llp(WRAP, WRAP, 0f, 0, 2, 0, 0))
        open.setOnClickListener { launch { startBooth() } }
        row.addView(open, c.llp(c.dp(150), MATCH, 0f, 0, 0, 10, 0))

        val scroll = HorizontalScrollView(c)
        scroll.isHorizontalScrollBarEnabled = false
        strip.orientation = LinearLayout.HORIZONTAL
        strip.gravity = Gravity.CENTER_VERTICAL
        scroll.addView(strip, FrameLayout.LayoutParams(WRAP, MATCH))
        row.addView(scroll, c.llp(0, MATCH, 1f))

        col.addView(row, c.llp(MATCH, 0, 1f))
        addView(col, LayoutParams(MATCH, MATCH))
    }

    private fun launch(go: () -> Unit) {
        val ct = closeThen
        if (ct != null) ct(go) else go()
    }

    private fun startBooth() {
        try {
            val i = Intent(c, PhotoBoothActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
        } catch (e: Exception) {
        }
    }

    private fun openPhoto(f: File) {
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(BoothStore.uriFor(f), "image/jpeg")
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            c.startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(c, "No app to open photos", Toast.LENGTH_SHORT).show()
        }
    }

    private fun thumb(f: File): Bitmap? {
        val key = f.absolutePath + f.lastModified()
        thumbs[key]?.let { return it }
        return try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(f.absolutePath, o)
            var s = 1
            while (o.outWidth / (s * 2) >= 260 && o.outHeight / (s * 2) >= 260) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val b = BitmapFactory.decodeFile(f.absolutePath, o2)
            if (b != null) thumbs[key] = b
            b
        } catch (e: Throwable) {
            null
        }
    }

    override fun refresh() {
        val items = BoothStore.items().take(8)
        val s = items.joinToString("|") { it.absolutePath + it.lastModified() }
        if (s == sig) return
        sig = s
        strip.removeAllViews()
        val keep = items.map { it.absolutePath + it.lastModified() }.toSet()
        thumbs.keys.retainAll(keep)
        if (items.isEmpty()) {
            strip.addView(c.tv("No photos yet. Open the booth and smile.", 13f, C.SUB), c.llp(WRAP, WRAP, 0f, 4, 0, 0, 0))
            return
        }
        for (f in items) {
            val iv = ImageView(c)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(thumb(f))
            iv.background = glass(C.GLASS, c.dpf(16))
            iv.roundClip(c.dpf(16))
            iv.setOnClickListener { launch { openPhoto(f) } }
            iv.setOnLongClickListener {
                f.delete()
                sig = "?"
                refresh()
                true
            }
            strip.addView(iv, c.llp(c.dp(104), c.dp(104), 0f, 0, 0, 8, 0))
        }
    }
}

// ------------------------------------------------------------------ Photo Booth (layar penuh, Camera2)

/** TextureView yang menjaga rasio gambar: muat di dalam ruang yang tersedia, sudut membulat. */
private class AspectTextureView(c: Context) : TextureView(c) {
    private var aw = 0
    private var ah = 0

    init {
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, c.dpf(24))
            }
        }
        clipToOutline = true
    }

    fun setAspect(w: Int, h: Int) {
        if (w == aw && h == ah) return
        aw = w
        ah = h
        requestLayout()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        invalidateOutline()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val maxW = MeasureSpec.getSize(wSpec)
        val maxH = MeasureSpec.getSize(hSpec)
        if (aw <= 0 || ah <= 0) {
            setMeasuredDimension(maxW, maxH)
            return
        }
        var w = maxW
        var h = (w.toLong() * ah / aw).toInt()
        if (h > maxH) {
            h = maxH
            w = (h.toLong() * aw / ah).toInt()
        }
        setMeasuredDimension(w, h)
    }
}

/**
 * Photo Booth ala macOS: preview cermin kamera depan, deretan efek, hitung mundur 3-2-1 dengan kilat layar,
 * mode Photo / 4-Up (2x2) / Strip (4 foto vertikal). Foto otomatis tersimpan ke galeri (Pictures/Lobo Photo Booth).
 * Murni Camera2 + TextureView, tanpa dependensi tambahan.
 */
class PhotoBoothActivity : Activity(), TextureView.SurfaceTextureListener {
    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var camThread: HandlerThread? = null
    private var camHandler: Handler? = null
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var previewSize: Size? = null
    private var sensorOrient = 90
    private var afContinuous = false
    private var front = true          // yang diminta pengguna
    private var facingFront = true    // yang benar-benar terbuka (kalau perangkat tidak punya kamera depan)
    private var resumed = false
    private var opening = false
    private var sound: MediaActionSound? = null

    private lateinit var tex: AspectTextureView
    private lateinit var host: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var fxScroll: HorizontalScrollView
    private lateinit var modeRow: LinearLayout
    private lateinit var shutter: FrameLayout
    private lateinit var status: TextView
    private lateinit var countNum: TextView
    private lateinit var flash: View
    private lateinit var resultLayer: FrameLayout
    private lateinit var resultImg: ImageView
    private lateinit var resultNote: TextView
    private lateinit var permLayer: FrameLayout
    private lateinit var timerChip: TextView
    private val fxChips = ArrayList<TextView>()
    private val modeChips = ArrayList<TextView>()

    private var fx = 0
    private var mode = 0                         // 0 Photo, 1 4-Up, 2 Strip
    private var timerIdx = 0
    private val timers = intArrayOf(3, 5, 0)
    private var busy = false
    private val shots = ArrayList<Bitmap>()
    private var resultBmp: Bitmap? = null
    private var resultFile: File? = null
    private var lastCompact: Boolean? = null
    private var permRequested = false

    private val paper = 0xFFF6F3EC.toInt()

    // ---------------------------------------------------------------- hidup-mati

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try {
            sound = MediaActionSound()
            sound?.load(MediaActionSound.SHUTTER_CLICK)
        } catch (e: Throwable) {
        }
        buildUi()
        setContentView(root)
        arrange()
    }

    private lateinit var root: FrameLayout

    override fun onResume() {
        super.onResume()
        resumed = true
        val t = HandlerThread("lobo-booth-cam")
        t.start()
        camThread = t
        camHandler = Handler(t.looper)
        try {
            (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(dispListener, ui)
        } catch (e: Exception) {
        }
        if (!hasCamPerm()) {
            // dialog izin hanya diminta sekali per sesi (dialog menutup-membuka Activity ini, jangan diulang terus)
            if (!permRequested) {
                permRequested = true
                askPerms()
            } else {
                permLayer.visibility = View.VISIBLE
            }
        } else {
            permLayer.visibility = View.GONE
            if (tex.isAvailable) openCamera()
        }
    }

    override fun onPause() {
        resumed = false
        cancelSequence()
        try {
            (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(dispListener)
        } catch (e: Exception) {
        }
        closeCamera()
        camThread?.quitSafely()
        camThread = null
        camHandler = null
        super.onPause()
    }

    override fun onDestroy() {
        try {
            sound?.release()
        } catch (e: Throwable) {
        }
        io.shutdown()
        resultBmp?.recycle()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        arrange()
        applyAspect()
    }

    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        if (resultLayer.visibility == View.VISIBLE) {
            closeResult()
        } else if (busy) {
            cancelSequence()
        } else {
            super.onBackPressed()
        }
    }

    // ---------------------------------------------------------------- izin

    private fun hasCamPerm(): Boolean = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun askPerms() {
        val need = ArrayList<String>()
        need.add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        requestPermissions(need.toTypedArray(), 77)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 77) return
        if (hasCamPerm()) {
            permLayer.visibility = View.GONE
            if (resumed && tex.isAvailable) openCamera()
        } else {
            permLayer.visibility = View.VISIBLE
        }
    }

    // ---------------------------------------------------------------- UI

    private fun styleChip(t: TextView, sel: Boolean) {
        t.background = rounded(if (sel) 0xFFFFFFFF.toInt() else 0x26FFFFFF, dpf(100))
        t.setTextColor(if (sel) C.BLACK else C.TEXT)
        t.setShadowLayer(0f, 0f, 0f, 0)
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val t = tv(text, 13f, C.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(8), dp(14), dp(8))
        t.setOnClickListener { onClick() }
        styleChip(t, false)
        return t
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(0xFF08080B.toInt())
        content = LinearLayout(this)

        // ----- bar atas
        topBar = LinearLayout(this)
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setPadding(dp(8), 0, dp(8), 0)
        val close = tv("✕", 20f, C.TEXT, false)
        close.gravity = Gravity.CENTER
        close.setOnClickListener { finish() }
        topBar.addView(close, llp(dp(48), dp(48)))
        val title = tv("Photo Booth", 16f, C.TEXT, true)
        title.gravity = Gravity.CENTER
        topBar.addView(title, llp(0, WRAP, 1f))
        val flip = LineIconView(this, IconKind.FLIP, C.TEXT, 22f, 1.6f)
        flip.setOnClickListener { flipCamera() }
        topBar.addView(flip, llp(dp(48), dp(48)))

        // ----- preview + lapisan
        host = FrameLayout(this)
        tex = AspectTextureView(this)
        tex.surfaceTextureListener = this
        tex.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> configureTransform(r - l, b - t) }
        host.addView(tex, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))

        status = tv("", 14f, C.TEXT, true)
        status.setPadding(dp(14), dp(6), dp(14), dp(6))
        status.background = rounded(0x99000000.toInt(), dpf(100))
        status.visibility = View.GONE
        val slp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        slp.topMargin = dp(14)
        host.addView(status, slp)

        countNum = tv("", 150f, C.TEXT, true)
        countNum.gravity = Gravity.CENTER
        countNum.setShadowLayer(dpf(18), 0f, dpf(2), 0xAA000000.toInt())
        countNum.visibility = View.GONE
        host.addView(countNum, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        flash = View(this)
        flash.setBackgroundColor(0xFFFFFFFF.toInt())
        flash.alpha = 0f
        flash.isClickable = false
        host.addView(flash, FrameLayout.LayoutParams(MATCH, MATCH))

        // ----- deretan efek
        fxScroll = HorizontalScrollView(this)
        fxScroll.isHorizontalScrollBarEnabled = false
        val fxRow = LinearLayout(this)
        fxRow.gravity = Gravity.CENTER_VERTICAL
        fxRow.setPadding(dp(14), 0, dp(14), 0)
        for (i in BOOTH_FX.indices) {
            val ch = chip(BOOTH_FX[i].name) { selectFx(i) }
            fxChips.add(ch)
            fxRow.addView(ch, llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        }
        fxScroll.addView(fxRow, FrameLayout.LayoutParams(WRAP, MATCH))
        styleChip(fxChips[0], true)

        // ----- mode + timer
        modeRow = LinearLayout(this)
        modeRow.gravity = Gravity.CENTER
        val names = arrayOf("Photo", "4-Up", "Strip")
        for (i in names.indices) {
            val ch = chip(names[i]) { selectMode(i) }
            modeChips.add(ch)
            modeRow.addView(ch, llp(WRAP, WRAP, 0f, 4, 4, 4, 4))
        }
        styleChip(modeChips[0], true)
        timerChip = chip("") {
            timerIdx = (timerIdx + 1) % timers.size
            updateTimerChip()
        }
        updateTimerChip()
        modeRow.addView(timerChip, llp(WRAP, WRAP, 0f, 12, 4, 4, 4))

        // ----- tombol rana (merah, ikon kamera, cincin putih)
        shutter = FrameLayout(this)
        val ring = GradientDrawable()
        ring.shape = GradientDrawable.OVAL
        ring.setColor(0)
        ring.setStroke(dp(4), 0xFFFFFFFF.toInt())
        shutter.background = ring
        val inner = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFFF6B6B.toInt(), 0xFFE0245E.toInt()))
        inner.shape = GradientDrawable.OVAL
        val innerV = FrameLayout(this)
        innerV.background = inner
        innerV.addView(LineIconView(this, IconKind.CAMERA, C.TEXT, 28f, 1.7f), FrameLayout.LayoutParams(MATCH, MATCH))
        shutter.addView(innerV, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER))
        shutter.setOnClickListener {
            if (busy) cancelSequence() else startSequence()
        }

        root.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))

        // ----- hasil (setelah jepret)
        resultLayer = FrameLayout(this)
        resultLayer.setBackgroundColor(0xF208080B.toInt())
        resultLayer.visibility = View.GONE
        resultLayer.isClickable = true
        val rc = LinearLayout(this)
        rc.orientation = LinearLayout.VERTICAL
        rc.gravity = Gravity.CENTER_HORIZONTAL
        resultImg = ImageView(this)
        resultImg.scaleType = ImageView.ScaleType.FIT_CENTER
        rc.addView(resultImg, llp(MATCH, 0, 1f, 20, 24, 20, 8))
        resultNote = tv("Saved to Pictures › Lobo Photo Booth", 12f, C.SUB)
        resultNote.gravity = Gravity.CENTER
        rc.addView(resultNote, llp(WRAP, WRAP, 0f, 0, 0, 0, 12))
        val btns = LinearLayout(this)
        btns.gravity = Gravity.CENTER
        val share = chip("Share") { shareResult() }
        val done = chip("Done") { closeResult() }
        styleChip(done, true)
        btns.addView(share, llp(WRAP, WRAP, 0f, 0, 0, 12, 0))
        btns.addView(done, llp(WRAP, WRAP))
        rc.addView(btns, llp(MATCH, WRAP, 0f, 0, 0, 0, 28))
        resultLayer.addView(rc, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(resultLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        // ----- izin kamera ditolak
        permLayer = FrameLayout(this)
        permLayer.setBackgroundColor(0xFF08080B.toInt())
        permLayer.visibility = View.GONE
        permLayer.isClickable = true
        val pc = LinearLayout(this)
        pc.orientation = LinearLayout.VERTICAL
        pc.gravity = Gravity.CENTER
        pc.setPadding(dp(32), 0, dp(32), 0)
        pc.addView(LineIconView(this, IconKind.CAMERA, C.TEXT, 40f, 1.4f), llp(dp(56), dp(56)))
        val pt = tv("Photo Booth needs the camera", 16f, C.TEXT, true)
        pt.gravity = Gravity.CENTER
        pc.addView(pt, llp(WRAP, WRAP, 0f, 0, 14, 0, 6))
        val pd = tv("Allow camera access to see yourself and take photos. Nothing leaves your device.", 13f, C.SUB)
        pd.gravity = Gravity.CENTER
        pc.addView(pd, llp(WRAP, WRAP, 0f, 0, 0, 0, 18))
        val pb = chip("Allow camera") {
            if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
                askPerms()
            } else {
                // sudah ditolak permanen: izin hanya bisa diberikan lewat setelan app
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                }
            }
        }
        styleChip(pb, true)
        pc.addView(pb, llp(WRAP, WRAP))
        val px = tv("✕", 20f, C.TEXT, false)
        px.gravity = Gravity.CENTER
        px.setOnClickListener { finish() }
        permLayer.addView(pc, FrameLayout.LayoutParams(MATCH, MATCH))
        permLayer.addView(px, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP or Gravity.START))
        root.addView(permLayer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /** Portrait / tablet: tumpuk vertikal. Ponsel landscape (pendek): kontrol pindah ke kolom kanan. */
    private fun arrange() {
        val cfg = resources.configuration
        val compactLand = cfg.orientation == Configuration.ORIENTATION_LANDSCAPE && cfg.screenHeightDp < 560
        if (lastCompact == compactLand) return
        lastCompact = compactLand
        for (v in arrayOf<View>(topBar, host, fxScroll, modeRow, shutter)) (v.parent as? ViewGroup)?.removeView(v)
        content.removeAllViews()
        if (!compactLand) {
            content.orientation = LinearLayout.VERTICAL
            modeRow.orientation = LinearLayout.HORIZONTAL
            content.addView(topBar, llp(MATCH, dp(56)))
            content.addView(host, llp(MATCH, 0, 1f, 14, 0, 14, 0))
            content.addView(fxScroll, llp(MATCH, dp(54)))
            content.addView(modeRow, llp(MATCH, dp(48)))
            val lp = llp(dp(84), dp(84), 0f, 0, 6, 0, 14)
            lp.gravity = Gravity.CENTER_HORIZONTAL
            content.addView(shutter, lp)
        } else {
            content.orientation = LinearLayout.HORIZONTAL
            modeRow.orientation = LinearLayout.VERTICAL
            val left = LinearLayout(this)
            left.orientation = LinearLayout.VERTICAL
            left.addView(topBar, llp(MATCH, dp(48)))
            left.addView(host, llp(MATCH, 0, 1f, 12, 0, 12, 0))
            left.addView(fxScroll, llp(MATCH, dp(50)))
            val right = LinearLayout(this)
            right.orientation = LinearLayout.VERTICAL
            right.gravity = Gravity.CENTER
            right.addView(modeRow, llp(WRAP, WRAP, 0f, 0, 0, 0, 10))
            right.addView(shutter, llp(dp(76), dp(76)))
            content.addView(left, llp(0, MATCH, 1f))
            content.addView(right, llp(dp(150), MATCH))
        }
    }

    private fun updateTimerChip() {
        val s = timers[timerIdx]
        timerChip.text = if (s == 0) "Timer off" else "Timer ${s}s"
    }

    private fun selectFx(i: Int) {
        fx = i
        for (k in fxChips.indices) styleChip(fxChips[k], k == i)
        applyFxToPreview()
    }

    private fun selectMode(i: Int) {
        if (busy) return
        mode = i
        for (k in modeChips.indices) styleChip(modeChips[k], k == i)
    }

    private fun applyFxToPreview() {
        tex.setLayerPaint(BOOTH_FX[fx].paint())
        tex.invalidate()
    }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------------------- kamera (Camera2)

    override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
        if (resumed && hasCamPerm()) openCamera()
    }

    override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {
        configureTransform(width, height)
    }

    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
        closeCamera()
        return true
    }

    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}

    private val dispListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            ui.post {
                applyAspect()
                if (tex.width > 0) configureTransform(tex.width, tex.height)
            }
        }
    }

    private fun pickCamera(mgr: CameraManager): String? {
        var any: String? = null
        for (id in mgr.cameraIdList) {
            val facing = mgr.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING)
            if (any == null) any = id
            if (front && facing == CameraCharacteristics.LENS_FACING_FRONT) return id
            if (!front && facing == CameraCharacteristics.LENS_FACING_BACK) return id
        }
        return any
    }

    private fun choosePreview(sizes: Array<Size>): Size {
        val ratio43 = sizes.filter { it.width * 3 == it.height * 4 && it.width <= 1600 }
        val best = ratio43.maxByOrNull { it.width * it.height }
        if (best != null) return best
        val any = sizes.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height }
        return any ?: sizes[0]
    }

    /** Ukuran gambar tegak menurut orientasi alami layar (tukar kalau sensor terpasang miring 90/270). */
    private fun naturalSize(ps: Size): Pair<Int, Int> =
        if (sensorOrient % 180 == 90) Pair(ps.height, ps.width) else Pair(ps.width, ps.height)

    @Suppress("DEPRECATION")
    private fun displayRot(): Int = windowManager.defaultDisplay.rotation

    private fun applyAspect() {
        val ps = previewSize ?: return
        val (nw, nh) = naturalSize(ps)
        val rot = displayRot()
        if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) tex.setAspect(nh, nw) else tex.setAspect(nw, nh)
    }

    /** Sama seperti sampel camera2basic, tapi memakai orientasi sensor (bukan asumsi layar portrait) + cermin kamera depan. */
    private fun configureTransform(viewW: Int, viewH: Int) {
        val ps = previewSize ?: return
        if (viewW <= 0 || viewH <= 0) return
        val rot = displayRot()
        val (nw, nh) = naturalSize(ps)
        val m = Matrix()
        val vr = RectF(0f, 0f, viewW.toFloat(), viewH.toFloat())
        val cx = vr.centerX()
        val cy = vr.centerY()
        if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) {
            val br = RectF(0f, 0f, nw.toFloat(), nh.toFloat())
            br.offset(cx - br.centerX(), cy - br.centerY())
            m.setRectToRect(vr, br, Matrix.ScaleToFit.FILL)
            val sc = maxOf(viewH.toFloat() / nw, viewW.toFloat() / nh)
            m.postScale(sc, sc, cx, cy)
            m.postRotate(90f * (rot - 2), cx, cy)
        } else if (rot == Surface.ROTATION_180) {
            m.postRotate(180f, cx, cy)
        }
        if (facingFront) m.postScale(-1f, 1f, cx, cy) // cermin, seperti Photo Booth di Mac
        tex.setTransform(m)
    }

    @SuppressLint("MissingPermission")
    private fun openCamera() {
        if (!resumed || device != null || opening || !tex.isAvailable) return
        if (!hasCamPerm()) return
        try {
            val mgr = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = pickCamera(mgr)
            if (id == null) {
                toast("No camera found")
                return
            }
            val cc = mgr.getCameraCharacteristics(id)
            sensorOrient = cc.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            facingFront = cc.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            val af = cc.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
            afContinuous = af != null && af.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            val map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(SurfaceTexture::class.java)
            if (sizes == null || sizes.isEmpty()) {
                toast("Camera not supported")
                return
            }
            previewSize = choosePreview(sizes)
            applyAspect()
            opening = true
            mgr.openCamera(id, stateCb, camHandler)
        } catch (e: Exception) {
            opening = false
            toast("Can't open the camera")
        }
    }

    private val stateCb = object : CameraDevice.StateCallback() {
        override fun onOpened(cd: CameraDevice) {
            opening = false
            if (!resumed) {
                cd.close()
                return
            }
            device = cd
            startPreview(cd)
        }

        override fun onDisconnected(cd: CameraDevice) {
            opening = false
            cd.close()
            if (device === cd) device = null
        }

        override fun onError(cd: CameraDevice, error: Int) {
            opening = false
            cd.close()
            if (device === cd) device = null
            ui.post { toast("Camera error") }
        }
    }

    @Suppress("DEPRECATION")
    private fun startPreview(cd: CameraDevice) {
        val st = tex.surfaceTexture ?: return
        val ps = previewSize ?: return
        try {
            st.setDefaultBufferSize(ps.width, ps.height)
            val surface = Surface(st)
            val req = cd.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            req.addTarget(surface)
            if (afContinuous) req.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            cd.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (device !== cd) {
                        s.close()
                        return
                    }
                    session = s
                    try {
                        s.setRepeatingRequest(req.build(), null, camHandler)
                    } catch (e: Exception) {
                    }
                    ui.post {
                        applyAspect()
                        applyFxToPreview()
                        if (tex.width > 0) configureTransform(tex.width, tex.height)
                    }
                }

                override fun onConfigureFailed(s: CameraCaptureSession) {
                    ui.post { toast("Camera error") }
                }
            }, camHandler)
        } catch (e: Exception) {
            ui.post { toast("Camera error") }
        }
    }

    private fun closeCamera() {
        try {
            session?.close()
        } catch (e: Exception) {
        }
        session = null
        try {
            device?.close()
        } catch (e: Exception) {
        }
        device = null
        opening = false
    }

    private fun flipCamera() {
        if (busy || opening) return
        front = !front
        closeCamera()
        ui.postDelayed({ if (resumed) openCamera() }, 200)
    }

    // ---------------------------------------------------------------- jepret

    private fun startSequence() {
        if (busy || session == null) return
        busy = true
        shots.clear()
        setFxEnabled(false)
        nextShot(0, if (mode == 0) 1 else 4)
    }

    private fun setFxEnabled(on: Boolean) {
        val a = if (on) 1f else 0.4f
        modeRow.alpha = a
        fxScroll.alpha = a
        for (c in fxChips) c.isEnabled = on
        for (c in modeChips) c.isEnabled = on
        timerChip.isEnabled = on
    }

    private fun nextShot(i: Int, total: Int) {
        if (!busy) return
        if (total > 1) {
            status.text = "${i + 1} / $total"
            status.visibility = View.VISIBLE
        } else {
            status.visibility = View.GONE
        }
        val t = timers[timerIdx]
        val secs = if (i == 0) t else (if (t == 0) 1 else 2)
        countdown(secs) {
            capture { bmp ->
                if (!busy) {
                    bmp.recycle()
                    return@capture
                }
                shots.add(bmp)
                if (i + 1 < total) {
                    ui.postDelayed({ nextShot(i + 1, total) }, 450)
                } else {
                    finishSequence()
                }
            }
        }
    }

    private fun countdown(n: Int, done: () -> Unit) {
        if (!busy) return
        if (n <= 0) {
            countNum.visibility = View.GONE
            done()
            return
        }
        countNum.text = n.toString()
        countNum.visibility = View.VISIBLE
        countNum.alpha = 0.2f
        countNum.scaleX = 1.5f
        countNum.scaleY = 1.5f
        countNum.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).start()
        ui.postDelayed({ countdown(n - 1, done) }, 1000)
    }

    /**
     * Kilat layar menutupi tangkapan. Paint efek dilepas dulu supaya bitmap dari TextureView pasti mentah,
     * lalu efek dipasang manual ke bitmap itu (hasil sama persis dengan preview, tanpa risiko efek ganda).
     */
    private fun capture(cb: (Bitmap) -> Unit) {
        try {
            sound?.play(MediaActionSound.SHUTTER_CLICK)
        } catch (e: Throwable) {
        }
        flash.animate().cancel()
        flash.alpha = 1f
        tex.setLayerPaint(null)
        tex.invalidate()
        ui.postDelayed({
            var out: Bitmap? = null
            try {
                val raw: Bitmap? = tex.bitmap
                if (raw != null) {
                    val p = BOOTH_FX[fx].paint()
                    if (p == null) {
                        out = raw
                    } else {
                        val b = Bitmap.createBitmap(raw.width, raw.height, Bitmap.Config.ARGB_8888)
                        Canvas(b).drawBitmap(raw, 0f, 0f, p)
                        raw.recycle()
                        out = b
                    }
                }
            } catch (e: Throwable) {
                out = null
            }
            applyFxToPreview()
            flash.animate().alpha(0f).setDuration(380).start()
            if (out == null) {
                toast("Couldn't capture, try again")
                cancelSequence()
            } else {
                cb(out)
            }
        }, 120)
    }

    private fun cancelSequence() {
        busy = false
        ui.removeCallbacksAndMessages(null)
        countNum.animate().cancel()
        countNum.visibility = View.GONE
        status.visibility = View.GONE
        flash.animate().cancel()
        flash.alpha = 0f
        if (::tex.isInitialized) applyFxToPreview()
        for (b in shots) b.recycle()
        shots.clear()
        setFxEnabled(true)
    }

    private fun finishSequence() {
        val list = ArrayList(shots)
        shots.clear()
        status.text = "Saving…"
        status.visibility = View.VISIBLE
        val m = mode
        io.execute {
            var result: Bitmap? = null
            try {
                result = when (m) {
                    0 -> list[0]
                    1 -> composeGrid(list)
                    else -> composeStrip(list)
                }
            } catch (t: Throwable) {
                result = null
            }
            val bmp = result
            val f = if (bmp != null) BoothStore.save(applicationContext, bmp) else null
            if (m != 0) for (b in list) b.recycle()
            ui.post {
                busy = false
                status.visibility = View.GONE
                setFxEnabled(true)
                if (bmp == null) toast("Couldn't build the photo") else showResult(bmp, f)
            }
        }
    }

    // ---------------------------------------------------------------- komposisi 4-Up / Strip

    private fun composeGrid(l: List<Bitmap>): Bitmap {
        val w0 = l[0].width
        val h0 = l[0].height
        val sc = minOf(1f, 1000f / maxOf(w0, h0))
        val cw = (w0 * sc).toInt()
        val ch = (h0 * sc).toInt()
        val gap = maxOf(8, (cw * 0.035f).toInt())
        val out = Bitmap.createBitmap(cw * 2 + gap * 3, ch * 2 + gap * 3, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.drawColor(paper)
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until 4) {
            val x = gap + (i % 2) * (cw + gap)
            val y = gap + (i / 2) * (ch + gap)
            cv.drawBitmap(l[i], null, Rect(x, y, x + cw, y + ch), p)
        }
        return out
    }

    private fun composeStrip(l: List<Bitmap>): Bitmap {
        val fw = 800
        val fh = 600
        val m = 44
        val foot = 170
        val out = Bitmap.createBitmap(fw + 2 * m, 4 * m + 4 * fh + foot, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.drawColor(paper)
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val tr = fw.toFloat() / fh
        for (i in 0 until 4) {
            val b = l[i]
            val bw = b.width
            val bh = b.height
            val src = if (bw.toFloat() / bh > tr) {
                val nw = (bh * tr).toInt()
                Rect((bw - nw) / 2, 0, (bw - nw) / 2 + nw, bh)
            } else {
                val nh = (bw / tr).toInt()
                Rect(0, (bh - nh) / 2, bw, (bh - nh) / 2 + nh)
            }
            val y = m + i * (fh + m)
            cv.drawBitmap(b, src, Rect(m, y, m + fw, y + fh), p)
        }
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.color = 0xFF9B968C.toInt()
        tp.textAlign = Paint.Align.CENTER
        tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tp.textSize = 40f
        tp.letterSpacing = 0.18f
        val cx = out.width / 2f
        val base = (4 * m + 4 * fh).toFloat() + 70f
        cv.drawText("LOBO PHOTO BOOTH", cx, base, tp)
        tp.textSize = 30f
        tp.letterSpacing = 0.05f
        cv.drawText(SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date()), cx, base + 52f, tp)
        return out
    }

    // ---------------------------------------------------------------- hasil

    private fun showResult(bmp: Bitmap, f: File?) {
        resultBmp?.let {
            resultImg.setImageBitmap(null)
            it.recycle()
        }
        resultBmp = bmp
        resultFile = f
        resultImg.setImageBitmap(bmp)
        resultNote.text = if (f != null) "Saved to Pictures › Lobo Photo Booth" else "Couldn't save the photo"
        resultLayer.alpha = 0f
        resultLayer.visibility = View.VISIBLE
        resultLayer.animate().alpha(1f).setDuration(220).start()
    }

    private fun closeResult() {
        resultLayer.animate().alpha(0f).setDuration(160).withEndAction {
            resultLayer.visibility = View.GONE
            resultImg.setImageBitmap(null)
            resultBmp?.recycle()
            resultBmp = null
        }.start()
    }

    private fun shareResult() {
        val f = resultFile
        if (f == null) {
            toast("Nothing to share")
            return
        }
        try {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "image/jpeg"
            i.putExtra(Intent.EXTRA_STREAM, BoothStore.uriFor(f))
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Share photo"))
        } catch (e: Exception) {
            toast("Can't share")
        }
    }
}
