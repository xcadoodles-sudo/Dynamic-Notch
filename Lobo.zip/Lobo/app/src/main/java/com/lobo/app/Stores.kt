package com.lobo.app

import android.app.PendingIntent
import android.content.ClipboardManager
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject

// ------------------------------------------------------------------ notifikasi (tab Notifications)

class NotifItem(
    val key: String,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val time: Long,
    val icon: Drawable?,
    val pi: PendingIntent?
)

object NotifStore {
    private val list = ArrayList<NotifItem>()

    @Synchronized
    fun items(): List<NotifItem> = ArrayList(list)

    @Synchronized
    fun put(n: NotifItem) {
        list.removeAll { it.key == n.key }
        list.add(0, n)
        while (list.size > 40) list.removeAt(list.size - 1)
    }

    @Synchronized
    fun remove(key: String) {
        list.removeAll { it.key == key }
    }

    @Synchronized
    fun clear() {
        list.clear()
    }
}

// ------------------------------------------------------------------ clipboard (tab Clipboard)

object ClipStore {
    private const val MAX = 20

    fun items(): List<String> {
        return try {
            val a = JSONArray(Lobo.prefs.clipJson)
            val out = ArrayList<String>()
            for (i in 0 until a.length()) out.add(a.getString(i))
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(l: List<String>) {
        val a = JSONArray()
        for (t in l) a.put(t)
        Lobo.prefs.clipJson = a.toString()
    }

    fun add(raw: String): Boolean {
        val t = raw.trim().take(2000)
        if (t.isEmpty()) return false
        val l = items().toMutableList()
        if (l.isNotEmpty() && l[0] == t) return false
        l.remove(t)
        l.add(0, t)
        while (l.size > MAX) l.removeAt(l.size - 1)
        save(l)
        return true
    }

    fun remove(t: String) {
        save(items().filter { it != t })
    }

    fun clear() {
        save(emptyList())
    }
}

/**
 * Android 10+ hanya mengizinkan app yang sedang fokus membaca clipboard. Listener di sini menangkap
 * kalau sistem mengizinkan; selain itu tombol "Paste" di tab Clipboard membuka [ClipReadActivity]
 * sekejap (fokus) untuk membaca isi clipboard.
 */
object ClipWatcher {
    private var cm: ClipboardManager? = null
    private var muteUntil = 0L
    private val listener = ClipboardManager.OnPrimaryClipChangedListener { captureNow(Lobo.app) }

    fun start(ctx: Context) {
        stop()
        cm = ctx.getSystemService(ClipboardManager::class.java)
        try {
            cm?.addPrimaryClipChangedListener(listener)
        } catch (e: Exception) {
        }
    }

    fun stop() {
        try {
            cm?.removePrimaryClipChangedListener(listener)
        } catch (e: Exception) {
        }
        cm = null
    }

    /** Abaikan perubahan clipboard sesaat (dipakai saat kita sendiri yang menyalin balik). */
    fun mute(ms: Long = 1200L) {
        muteUntil = SystemClock.elapsedRealtime() + ms
    }

    fun captureNow(ctx: Context): Boolean {
        if (SystemClock.elapsedRealtime() < muteUntil) return false
        return try {
            val m = ctx.getSystemService(ClipboardManager::class.java) ?: return false
            val c = m.primaryClip ?: return false
            if (c.itemCount == 0) return false
            val t = c.getItemAt(0).coerceToText(ctx).toString()
            if (ClipStore.add(t)) {
                Bus.changed()
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }
}

// ------------------------------------------------------------------ to-do (tab Widgets)

class TodoItem(val text: String, var done: Boolean)

object TodoStore {
    fun items(): MutableList<TodoItem> {
        val out = ArrayList<TodoItem>()
        try {
            val a = JSONArray(Lobo.prefs.todoJson)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(TodoItem(o.getString("t"), o.optBoolean("d", false)))
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun save(l: List<TodoItem>) {
        val a = JSONArray()
        for (i in l) {
            val o = JSONObject()
            o.put("t", i.text)
            o.put("d", i.done)
            a.put(o)
        }
        Lobo.prefs.todoJson = a.toString()
    }

    fun add(raw: String) {
        val t = raw.trim().take(120)
        if (t.isEmpty()) return
        val l = items()
        l.add(0, TodoItem(t, false))
        save(l.take(30))
    }

    /** Selesai -> pindah ke bawah; dibatalkan -> naik ke atas. */
    fun toggle(i: Int) {
        val l = items()
        if (i !in l.indices) return
        val item = l.removeAt(i)
        item.done = !item.done
        if (item.done) l.add(item) else l.add(0, item)
        save(l)
    }

    fun remove(i: Int) {
        val l = items()
        if (i !in l.indices) return
        l.removeAt(i)
        save(l)
    }

    fun pending(): Int = items().count { !it.done }
}

// ------------------------------------------------------------------ slot app (tab Launcher)

object LauncherStore {
    const val SLOTS = 12

    fun get(): MutableList<String> {
        val l = Lobo.prefs.launcherApps.split(",").toMutableList()
        while (l.size < SLOTS) l.add("")
        return l.take(SLOTS).toMutableList()
    }

    fun set(i: Int, pkg: String) {
        val l = get()
        if (i in 0 until SLOTS) l[i] = pkg
        Lobo.prefs.launcherApps = l.joinToString(",")
    }
}

// ------------------------------------------------------------------ tema (Rosé, Peach, ...)

object Themes {
    val names = arrayOf("Default", "Rosé", "Peach", "Ocean", "Forest")
    val tint = intArrayOf(0, 0xFF3B1230.toInt(), 0xFF3A2520.toInt(), 0xFF0E2A3F.toInt(), 0xFF11301F.toInt())
    val glow = arrayOf(
        intArrayOf(0, 0),
        intArrayOf(0xFFFF5FA2.toInt(), 0xFFB0306E.toInt()),
        intArrayOf(0xFFFFA07A.toInt(), 0xFFC96A4A.toInt()),
        intArrayOf(0xFF3DB8FF.toInt(), 0xFF2A5BD7.toInt()),
        intArrayOf(0xFF4ADE80.toInt(), 0xFF15803D.toInt())
    )

    fun cur(): Int = Lobo.prefs.theme.coerceIn(0, names.size - 1)
}
