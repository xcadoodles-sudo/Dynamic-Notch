package com.xcadoodle.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.Choreographer
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Parser path SVG mini: hanya M, L, C, Z (absolut), dipisah spasi. */
internal fun svgPath(d: String): Path {
    val p = Path()
    val t = d.trim().split(' ').filter { it.isNotEmpty() }
    var i = 0
    fun n(): Float = t[i++].toFloat()
    while (i < t.size) {
        when (t[i++]) {
            "M" -> p.moveTo(n(), n())
            "L" -> p.lineTo(n(), n())
            "C" -> p.cubicTo(n(), n(), n(), n(), n(), n())
            "Z" -> p.close()
        }
    }
    return p
}

/** Bentuk serigala dalam kotak 100x100. Dibuat sekali, dipakai ulang tiap frame. */
private object Wolf {
    // --- duduk (tampak depan)
    val head = svgPath("M 50 17 C 63 17 76 21 84 29 C 91 36 94 46 92 55 L 100 60 L 90 63 L 97 73 L 84 72 C 77 80 64 83 50 83 C 36 83 23 80 16 72 L 3 73 L 10 63 L 0 60 L 8 55 C 6 46 9 36 16 29 C 24 21 37 17 50 17 Z")
    val earR = svgPath("M 57 26 C 65 15 74 8 85 3 C 90 14 92 27 91 40 Z")
    val earInR = svgPath("M 67 25 C 72 19 77 15 83 11 C 85 18 86 25 85 32 Z")
    val earL = svgPath("M 43 26 C 35 15 26 8 15 3 C 10 14 8 27 9 40 Z")
    val earInL = svgPath("M 33 25 C 28 19 23 15 17 11 C 15 18 14 25 15 32 Z")
    val muzzle = svgPath("M 50 50 C 60 50 67 56 66 65 C 65 75 58 83 50 83 C 42 83 35 75 34 65 C 33 56 40 50 50 50 Z")
    val nose = svgPath("M 44.5 58 C 44.5 55 55.5 55 55.5 58 C 55.5 62 52 65 50 65 C 48 65 44.5 62 44.5 58 Z")
    val bodyFront = svgPath("M 28 100 C 26 86 33 75 50 75 C 67 75 74 86 72 100 Z")
    val tailFront = svgPath("M 70 96 C 82 96 92 90 94 78 C 95 86 90 99 74 100 Z")

    // --- jalan (tampak samping, menghadap kanan)
    val bodySide = svgPath("M 18 56 C 18 44 30 40 44 40 C 58 40 70 44 70 56 C 70 70 60 78 44 78 C 28 78 18 70 18 56 Z")
    val headSide = svgPath("M 55 40 C 56 28 66 22 76 25 C 82 27 86 31 88 35 L 95 38 C 99 40 99 46 95 48 L 86 51 C 82 58 70 61 62 56 C 56 52 54 46 55 40 Z")
    val earSide = svgPath("M 62 29 C 63 20 66 12 72 6 C 76 12 79 19 80 27 Z")
    val earInSide = svgPath("M 66 27 C 67 21 69 17 72 13 C 74 17 76 21 77 26 Z")
    val tuftSide = svgPath("M 58 54 L 50 62 L 62 59 Z")
    val tailSide = svgPath("M 22 58 C 8 58 1 46 4 32 C 10 38 15 44 28 50 Z")
    val noseSide = svgPath("M 94 36 C 97 35 100 37 99 40 C 98 43 94 42 93 40 Z")
    val muzzleSide = svgPath("M 80 44 C 86 44 93 45 96 47 L 86 51 C 83 52 80 52 78 50 Z")
    val leg = Path().apply { addRoundRect(RectF(-4.5f, 0f, 4.5f, 17f), 4.5f, 4.5f, Path.Direction.CW) }

    // --- tidur (meringkuk, menghadap kanan)
    val loaf = svgPath("M 8 82 C 6 64 22 54 44 54 C 66 54 80 64 80 82 C 80 90 74 94 66 94 L 22 94 C 14 94 9 90 8 82 Z")
    val slHead = svgPath("M 60 80 C 60 68 70 62 80 64 C 86 65 90 69 91 73 L 97 77 C 100 79 100 84 97 86 L 90 90 C 84 95 70 95 64 90 C 61 87 60 84 60 80 Z")
    val slEar = svgPath("M 66 66 C 67 60 70 55 75 52 C 78 57 80 62 80 66 Z")
    val slEarIn = svgPath("M 70 66 C 71 61 73 58 75 56 C 77 59 78 63 78 66 Z")
    val slTail = svgPath("M 10 86 C 6 74 14 66 28 70 C 22 74 20 80 24 88 L 22 94 L 12 94 Z")
    val slMuzzle = svgPath("M 82 79 C 88 79 94 80 97 82 L 91 88 C 87 89 83 88 80 86 Z")
    val slNose = svgPath("M 94 76 C 97 75 100 77 99 80 C 98 83 94 82 93 80 Z")
    val slEye = svgPath("M 70 76 C 73 79 78 79 81 76 L 81.8 77.6 C 78 81.4 73 81.4 69.2 77.6 Z")

    // --- hiasan
    val heart = svgPath("M 0 6 C -9 0 -6 -7 0 -3 C 6 -7 9 0 0 6 Z")
    val zee = svgPath("M 0 0 L 8 0 L 0 9 L 8 9")
    val happyEyeL = svgPath("M 27 50 C 29 39 37 39 39 50")
    val happyEyeR = svgPath("M 61 50 C 63 39 71 39 73 50")
}

/**
 * Maskot serigala Xcadoodle di sisi kiri pil notch.
 *
 *  SIT   : duduk menghadap depan, berkedip, telinga berkedut, ekor goyang, bernapas
 *  WALK  : jalan-jalan ke kiri/kanan sepanjang pil, menoleh sesuai arah
 *  DOZE  : mengantuk, kepala terangguk-angguk
 *  SLEEP : meringkuk tidur, napas pelan, "z z z" melayang
 *  WAKE  : bangun, melar (stretch), lalu duduk lagi
 *
 * Interaksi: [perk] (notifikasi masuk -> kaget & lompat), [poke] (disentuh -> bangun),
 * [pat] (tekan lama -> senang, ekor cepat, hati melayang).
 */
class PetView(c: Context) : View(c) {
    private enum class Mode { SIT, WALK, DOZE, SLEEP, WAKE }

    companion object {
        // Atur di sini kalau mau lebih cepat/lambat.
        private const val SLEEP_AFTER_MS = 20_000L // diam selama ini -> mulai mengantuk
        private const val DOZE_MS = 2_600L         // lama mengantuk sebelum benar-benar tidur
        private const val NAP_MS = 75_000L         // lama tidur sebelum bangun sendiri
        private const val WAKE_MS = 750L           // lama animasi bangun
        private const val WALK_DP_PER_SEC = 30f

        private val BODY = 0xFF2B2B33.toInt()
        private val FAR = 0xFF1C1C23.toInt()
        private val EYE = 0xFFEAF1FF.toInt()
        private val HEART = 0xFF8B7BFF.toInt()
        private const val TWO_PI = 2.0 * PI
    }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val rect = RectF()
    private val glow = LinearGradient(0f, 60f, 0f, 100f, 0x007C6CFF, 0xDD4A8CFF.toInt(), Shader.TileMode.CLAMP)

    private var mode = Mode.SIT
    private var modeAt = 0L
    private var petX = 0f
    private var targetX = 0f
    private var face = 1
    private var phase = 0f
    private var lastT = 0L
    private var lastTouch = 0L
    private var nextAct = 0L
    private var nextBlink = 0L
    private var blinkAt = -10_000L
    private var nextEar = 0L
    private var earAt = -10_000L
    private var popAt = -10_000L
    private var hopAt = -10_000L
    private var happyUntil = 0L
    private var skip = 0
    private var posted = false

    /** true = animasi berhenti (mis. saat panel/alert terbuka). Saat lanjut, serigala bangun. */
    var paused = false
        set(v) {
            if (field == v) return
            field = v
            if (!v) poke()
            sync()
        }

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!posted) return
            val t = frameTimeNanos / 1_000_000L
            val dt = if (lastT == 0L) 16L else (t - lastT).coerceIn(1L, 50L)
            lastT = t
            step(t, dt / 1000f)
            val busy = mode == Mode.WALK || mode == Mode.WAKE || t - popAt < 300L || t - hopAt < 700L || t < happyUntil
            skip++
            if (busy || (skip and 1) == 0) invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun clock(): Long = SystemClock.uptimeMillis()

    private fun sprite(): Float = min(height * 0.78f, context.dpf(26))

    private fun range(): Float = max(0f, width - sprite())

    private fun sync() {
        val want = isAttachedToWindow && visibility == VISIBLE && windowVisibility == VISIBLE && !paused
        if (want && !posted) {
            posted = true
            lastT = 0L
            Choreographer.getInstance().postFrameCallback(frame)
        } else if (!want && posted) {
            posted = false
            Choreographer.getInstance().removeFrameCallback(frame)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val t = clock()
        lastTouch = t
        nextAct = t + 3_000L
        nextBlink = t + 1_500L
        nextEar = t + 5_000L
        mode = Mode.SIT
        modeAt = t
        sync()
    }

    override fun onDetachedFromWindow() {
        posted = false
        Choreographer.getInstance().removeFrameCallback(frame)
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        sync()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        sync()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        petX = petX.coerceIn(0f, range())
    }

    // ------------------------------------------------------------ interaksi

    /** Disentuh / tombol ditekan: bangun kalau sedang tidur. */
    fun poke() {
        val t = clock()
        lastTouch = t
        if (mode == Mode.SLEEP || mode == Mode.DOZE) enter(Mode.WAKE, t)
    }

    /** Ada notifikasi/alert: kaget, melompat kecil, bangun kalau tidur. */
    fun perk() {
        val t = clock()
        lastTouch = t
        hopAt = t
        when (mode) {
            Mode.SLEEP, Mode.DOZE -> enter(Mode.WAKE, t)
            Mode.WALK -> enter(Mode.SIT, t)
            else -> {
            }
        }
        nextAct = t + 3_000L
    }

    /** Ditahan lama = dielus: senang, ekor cepat, hati melayang. */
    fun pat() {
        val t = clock()
        lastTouch = t
        hopAt = t
        happyUntil = t + 1_900L
        when (mode) {
            Mode.SLEEP, Mode.DOZE -> enter(Mode.WAKE, t)
            Mode.WALK -> enter(Mode.SIT, t)
            else -> {
            }
        }
        nextAct = t + 4_000L
    }

    // ------------------------------------------------------------ logika

    private fun enter(m: Mode, t: Long) {
        mode = m
        modeAt = t
        popAt = t
    }

    private fun startWalk(t: Long, r: Float) {
        val far = if (petX < r / 2f) r else 0f
        targetX = if (Random.nextFloat() < 0.4f) far else Random.nextFloat() * r
        if (abs(targetX - petX) < sprite() * 0.5f) targetX = far
        face = if (targetX >= petX) 1 else -1
        phase = 0f
        enter(Mode.WALK, t)
    }

    private fun step(t: Long, dt: Float) {
        val r = range()
        if (petX > r) petX = r
        when (mode) {
            Mode.SIT -> {
                if (t - lastTouch > SLEEP_AFTER_MS) {
                    enter(Mode.DOZE, t)
                    return
                }
                if (t >= nextAct) {
                    nextAct = t + 3_500L + Random.nextLong(6_500L)
                    if (r > sprite() * 0.6f && Random.nextFloat() < 0.75f) startWalk(t, r)
                }
                if (t >= nextBlink) {
                    blinkAt = t
                    nextBlink = t + 2_200L + Random.nextLong(3_800L)
                }
                if (t >= nextEar) {
                    earAt = t
                    nextEar = t + 6_000L + Random.nextLong(7_000L)
                }
            }
            Mode.WALK -> {
                val stepPx = context.dpf(WALK_DP_PER_SEC) * dt
                val dx = targetX - petX
                if (abs(dx) <= stepPx) {
                    petX = targetX
                    enter(Mode.SIT, t)
                    nextAct = t + 2_500L + Random.nextLong(5_000L)
                } else {
                    petX += if (dx > 0f) stepPx else -stepPx
                    phase += dt * 14f
                }
            }
            Mode.DOZE -> if (t - modeAt > DOZE_MS) enter(Mode.SLEEP, t)
            Mode.SLEEP -> if (t - modeAt > NAP_MS) enter(Mode.WAKE, t)
            Mode.WAKE -> if (t - modeAt > WAKE_MS) {
                enter(Mode.SIT, t)
                lastTouch = t
                nextAct = t + 2_500L + Random.nextLong(3_000L)
            }
        }
    }

    // ------------------------------------------------------------ gambar

    private fun wave(t: Long, hz: Double): Float = sin(t / 1000.0 * TWO_PI * hz).toFloat()

    private fun body(cv: Canvas, p: Path) {
        fill.shader = null
        fill.color = BODY
        cv.drawPath(p, fill)
        fill.shader = glow
        cv.drawPath(p, fill)
        fill.shader = null
    }

    private fun light(cv: Canvas, p: Path, a: Int) {
        fill.shader = null
        fill.color = Color.argb(a, 0xEA, 0xF1, 0xFF)
        cv.drawPath(p, fill)
    }

    private fun eye(cv: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, rot: Float) {
        fill.shader = null
        fill.color = EYE
        cv.save()
        cv.rotate(rot, cx, cy)
        rect.set(cx - rx, cy - ry, cx + rx, cy + ry)
        cv.drawOval(rect, fill)
        cv.restore()
    }

    override fun onDraw(cv: Canvas) {
        if (width <= 0 || height <= 0) return
        val t = clock()
        val s = sprite()
        val u = s / 100f
        val top = (height - s) / 2f + s * 0.06f

        // "pop" kecil tiap ganti pose + lompat + melar saat bangun
        val pp = ((t - popAt) / 240f).coerceIn(0f, 1f)
        val k = (1f - pp) * (1f - pp)
        var sx = 1f + 0.10f * k
        var sy = 1f - 0.14f * k
        if (mode == Mode.WAKE) {
            val wp = ((t - modeAt).toFloat() / WAKE_MS).coerceIn(0f, 1f)
            val st = sin(wp * PI.toFloat())
            sx *= 1f + 0.10f * st
            sy *= 1f - 0.07f * st
        }
        val hp = ((t - hopAt) / 650f).coerceIn(0f, 1f)
        val hop = if (hp < 1f) 4f * hp * (1f - hp) * 14f else 0f

        cv.save()
        cv.translate(petX, top)
        cv.scale(u, u)
        cv.translate(0f, -hop)
        cv.scale(sx, sy, 50f, 100f)
        when (mode) {
            Mode.SIT, Mode.WAKE -> drawSit(cv, t, 0f)
            Mode.DOZE -> {
                val d = ((t - modeAt).toFloat() / DOZE_MS).coerceIn(0f, 1f)
                drawSit(cv, t, d)
                if (d > 0.45f) drawZ(cv, t, 80f, 30f, 1)
            }
            Mode.WALK -> {
                if (face < 0) cv.scale(-1f, 1f, 50f, 50f)
                drawWalk(cv, t)
            }
            Mode.SLEEP -> {
                if (face < 0) cv.scale(-1f, 1f, 50f, 50f)
                drawSleep(cv, t)
            }
        }
        cv.restore()
    }

    private fun drawSit(cv: Canvas, t: Long, doze: Float) {
        val happy = t < happyUntil
        val br = wave(t, 1.0 / 3.2)
        val wag = wave(t, if (happy) 4.5 else 1.1) * (if (happy) 18f else 7f)

        // ekor
        cv.save()
        cv.rotate(wag, 72f, 98f)
        body(cv, Wolf.tailFront)
        cv.restore()

        // badan + kaki depan
        cv.save()
        cv.scale(1f, 1f + 0.012f * br, 50f, 100f)
        body(cv, Wolf.bodyFront)
        cv.restore()
        fill.shader = null
        fill.color = Color.argb(60, 0xEA, 0xF1, 0xFF)
        rect.set(36f, 92f, 48f, 100f)
        cv.drawRoundRect(rect, 4f, 4f, fill)
        rect.set(52f, 92f, 64f, 100f)
        cv.drawRoundRect(rect, 4f, 4f, fill)

        // kepala (mengangguk kalau mengantuk)
        val nod = doze * (3f + 1.8f * wave(t, 1.05))
        cv.save()
        cv.translate(0f, nod + 0.45f * br)

        val ep = (t - earAt) / 260f
        val twitch = if (ep in 0f..1f) -14f * sin(ep * PI.toFloat()) else 0f
        cv.save()
        cv.rotate(twitch, 75f, 32f)
        body(cv, Wolf.earR)
        light(cv, Wolf.earInR, 60)
        cv.restore()
        body(cv, Wolf.earL)
        light(cv, Wolf.earInL, 60)

        body(cv, Wolf.head)
        light(cv, Wolf.muzzle, 62)
        light(cv, Wolf.nose, 255)

        if (happy) {
            line.shader = null
            line.color = EYE
            line.strokeWidth = 3.4f
            cv.drawPath(Wolf.happyEyeL, line)
            cv.drawPath(Wolf.happyEyeR, line)
        } else {
            val bp = (t - blinkAt) / 180f
            val blink = if (bp in 0f..1f) sin(bp * PI.toFloat()) else 0f
            val ry = 8.5f * (1f - 0.9f * max(blink, doze * 0.9f))
            eye(cv, 33f, 44f, 5.4f, ry, -14f)
            eye(cv, 67f, 44f, 5.4f, ry, 14f)
        }
        cv.restore()

        if (happy) drawHearts(cv, t)
    }

    private fun drawWalk(cv: Canvas, t: Long) {
        val sw = phase
        val bob = -abs(sin(sw)) * 2.2f
        cv.save()
        cv.translate(0f, bob)

        // kaki jauh (lebih gelap)
        fill.shader = null
        fill.color = FAR
        leg(cv, 28f, 72f, -30f * sin(sw), false)
        leg(cv, 58f, 73f, 30f * sin(sw), false)

        // ekor
        cv.save()
        cv.rotate(9f * sin(sw * 0.5f), 24f, 56f)
        body(cv, Wolf.tailSide)
        cv.restore()

        body(cv, Wolf.bodySide)

        // kaki dekat
        leg(cv, 34f, 74f, 30f * sin(sw), true)
        leg(cv, 52f, 74f, -30f * sin(sw), true)

        // kepala sedikit memantul
        cv.save()
        cv.translate(0f, -0.8f * sin(sw * 2f))
        body(cv, Wolf.earSide)
        light(cv, Wolf.earInSide, 60)
        body(cv, Wolf.headSide)
        body(cv, Wolf.tuftSide)
        light(cv, Wolf.muzzleSide, 40)
        light(cv, Wolf.noseSide, 255)
        val bp = (t - blinkAt) / 180f
        val blink = if (bp in 0f..1f) sin(bp * PI.toFloat()) else 0f
        eye(cv, 76f, 38f, 3.3f, 4.4f * (1f - 0.9f * blink), -10f)
        cv.restore()

        cv.restore()
    }

    private fun leg(cv: Canvas, hx: Float, hy: Float, angle: Float, near: Boolean) {
        cv.save()
        cv.translate(hx, hy)
        cv.rotate(angle)
        if (near) body(cv, Wolf.leg) else cv.drawPath(Wolf.leg, fill)
        cv.restore()
    }

    private fun drawSleep(cv: Canvas, t: Long) {
        val s = 1f + 0.025f * wave(t, 1.0 / 3.6)
        cv.save()
        cv.scale(1f, s, 50f, 94f)
        body(cv, Wolf.loaf)
        body(cv, Wolf.slTail)
        body(cv, Wolf.slEar)
        light(cv, Wolf.slEarIn, 60)
        body(cv, Wolf.slHead)
        light(cv, Wolf.slMuzzle, 40)
        light(cv, Wolf.slNose, 255)
        light(cv, Wolf.slEye, 255)
        fill.shader = null
        fill.color = Color.argb(50, 0xEA, 0xF1, 0xFF)
        rect.set(60f, 88f, 78f, 94f)
        cv.drawRoundRect(rect, 3f, 3f, fill)
        cv.restore()

        for (i in 0 until 3) drawZ(cv, t, 78f, 46f, i)
    }

    /** Huruf "z" melayang naik sambil memudar. */
    private fun drawZ(cv: Canvas, t: Long, bx: Float, by: Float, i: Int) {
        val q = ((t / 3200.0) + i / 3.0) % 1.0
        val qf = q.toFloat()
        val a = sin(qf * PI.toFloat())
        if (a <= 0.02f) return
        cv.save()
        cv.translate(bx + qf * 14f, by - qf * 34f)
        val sc = 0.5f + 0.7f * qf
        cv.scale(sc, sc)
        line.shader = null
        line.color = Color.argb((a * 230f).toInt(), 0xEA, 0xF1, 0xFF)
        line.strokeWidth = 2.4f
        cv.drawPath(Wolf.zee, line)
        cv.restore()
    }

    /** Hati melayang waktu dielus; muncul di sisi yang masih ada ruang. */
    private fun drawHearts(cv: Canvas, t: Long) {
        val s = sprite()
        val onRight = petX + s * 1.2f <= width
        val hx = if (onRight) 108f else -8f
        for (i in 0 until 3) {
            val q = (((t + i * 470L) % 1400L) / 1400f)
            val a = 1f - q
            cv.save()
            cv.translate(hx + (i - 1) * 3f, 70f - q * 55f)
            val sc = 0.7f + 0.4f * q
            cv.scale(sc, sc)
            fill.shader = null
            fill.color = Color.argb((a * 255f).toInt(), Color.red(HEART), Color.green(HEART), Color.blue(HEART))
            cv.drawPath(Wolf.heart, fill)
            cv.restore()
        }
    }
}
