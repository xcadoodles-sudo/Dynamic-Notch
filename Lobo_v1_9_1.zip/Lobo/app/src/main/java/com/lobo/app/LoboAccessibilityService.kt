package com.lobo.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Tidak membaca isi layar. Fungsinya: (1) menyediakan jendela overlay jenis TYPE_ACCESSIBILITY_OVERLAY, yang boleh
 * menempel di tepi atas dan menerima sentuhan di atas status bar; (2) mengetahui app mana yang sedang di depan
 * (hanya NAMA PAKET dari event ganti-jendela, tanpa polling) untuk memicu mode game.
 */
class LoboAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: LoboAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        NotchService.instance?.rebuildOverlay()
    }

    /** Aksi global (screenshot, recents, kunci layar) untuk tab Launcher. */
    fun act(code: Int): Boolean {
        return try {
            performGlobalAction(code)
        } catch (e: Exception) {
            false
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = event.packageName?.toString() ?: return
        GameMode.onForeground(this, p)
    }

    override fun onInterrupt() {
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        // tanpa pendeteksi, mode game tidak akan pernah padam sendiri: bangunkan Lobo
        GameMode.reset()
        NotchService.instance?.rebuildOverlay()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
