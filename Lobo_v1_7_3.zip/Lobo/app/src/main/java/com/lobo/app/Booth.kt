package com.lobo.app

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.display.DisplayManager
import android.media.MediaActionSound
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ penyimpanan foto

/**
 * Foto Photo Booth disimpan dua kali: salinan privat di filesDir/LoboBooth (untuk strip di panel notch + berbagi lewat
 * FileProvider) dan salinan di galeri (Pictures/Lobo Photo Booth). Salinan privat dibatasi [MAX] terakhir.
 */
object BoothStore {
    private const val MAX = 12

    val dir: File
        get() {
            val d = File(Lobo.app.filesDir, "LoboBooth")
            d.mkdirs()
            return d
        }

    fun items(): List<File> =
        (dir.listFiles()?.filter { it.isFile && it.extension.equals("jpg", true) } ?: emptyList()).sortedByDescending { it.lastModified() }

    fun uriFor(f: File): Uri = FileProvider.getUriForFile(Lobo.app, Lobo.app.packageName + ".files", f)

    fun save(ctx: Context, bmp: Bitmap): File? {
        val name = "LoboBooth_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val f = File(dir, name)
        try {
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 94, it) }
        } catch (e: Exception) {
            f.delete()
            return null
        }
        exportToGallery(ctx, f, name)
        items().drop(MAX).forEach { it.delete() }
        return f
    }

    private fun exportToGallery(ctx: Context, f: File, name: String) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.Images.Media.DISPLAY_NAME, name)
                v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Lobo Photo Booth")
                v.put(MediaStore.Images.Media.IS_PENDING, 1)
                val r = ctx.contentResolver
                val uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
                r.openOutputStream(uri)?.use { o -> f.inputStream().use { i -> i.copyTo(o) } }
                val done = ContentValues()
                done.put(MediaStore.Images.Media.IS_PENDING, 0)
                r.update(uri, done, null, null)
            } else {
                @Suppress("DEPRECATION")
                val pics = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val d = File(pics, "Lobo Photo Booth")
                d.mkdirs()
                val out = File(d, name)
                f.copyTo(out, true)
                MediaScannerConnection.scanFile(ctx, arrayOf(out.absolutePath), arrayOf("image/jpeg"), null)
            }
        } catch (e: Exception) {
            // salinan galeri gagal (izin ditolak, penyimpanan penuh): salinan privat tetap ada
        }
    }
}

// ------------------------------------------------------------------ efek warna (ColorMatrix)

private fun fxMat(vararg v: Float): ColorMatrix = ColorMatrix(v)

private fun fxSat(s: Float): ColorMatrix {
    val m = ColorMatrix()
    m.setSaturation(s)
    return m
}

private fun fxCat(a: ColorMatrix, b: ColorMatrix): ColorMatrix {
    val r = ColorMatrix(a)
    r.postConcat(b)
    return r
}

private fun fxContrast(c: Float, bright: Float = 0f): ColorMatrix {
    val t = (0.5f - 0.5f * c) * 255f + bright
    return fxMat(
        c, 0f, 0f, 0f, t,
        0f, c, 0f, 0f, t,
        0f, 0f, c, 0f, t,
        0f, 0f, 0f, 1f, 0f
    )
}

/**
 * Satu efek di tab Filter. [matrix] = efek warna lama (jalan di semua Android), [agsl] = shader GPU bergaya 3D dari
 * [BoothShaders] (Android 13+). [anim] = shader memakai waktu (bergerak), [aim] = pusat efek bisa digeser dengan jari.
 */
private class BoothFx(
    val name: String,
    val matrix: ColorMatrix? = null,
    val agsl: String? = null,
    val anim: Boolean = false,
    val aim: Boolean = false
) {
    fun paint(): Paint? {
        val m = matrix ?: return null
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.colorFilter = ColorMatrixColorFilter(m)
        return p
    }
}

private val BOOTH_FX: List<BoothFx> = listOf(
    BoothFx("Normal"),
    // --- lensa & distorsi (geser jari di preview untuk memindah pusatnya)
    BoothFx("Bulge", agsl = BoothShaders.BULGE, aim = true),
    BoothFx("Dent", agsl = BoothShaders.DENT, aim = true),
    BoothFx("Twirl", agsl = BoothShaders.TWIRL, aim = true),
    BoothFx("Orb", agsl = BoothShaders.ORB, aim = true),
    BoothFx("Glass", agsl = BoothShaders.GLASS, aim = true),
    BoothFx("Stretch", agsl = BoothShaders.STRETCH, aim = true),
    // --- kedalaman / 3D
    BoothFx("3D", agsl = BoothShaders.ANAGLYPH, aim = true),
    BoothFx("Tunnel", agsl = BoothShaders.TUNNEL, anim = true, aim = true),
    BoothFx("Kaleido", agsl = BoothShaders.KALEIDO, anim = true, aim = true),
    BoothFx("Mirror", agsl = BoothShaders.MIRROR, aim = true),
    // --- gaya
    BoothFx("Holo", agsl = BoothShaders.HOLO, anim = true),
    BoothFx("Neon", agsl = BoothShaders.NEON, anim = true),
    BoothFx("Thermal", agsl = BoothShaders.THERMAL),
    BoothFx("Comic", agsl = BoothShaders.COMIC),
    BoothFx("Sketch", agsl = BoothShaders.SKETCH),
    // --- warna (jalan di semua Android)
    BoothFx("Noir", fxCat(fxSat(0f), fxContrast(1.4f, -6f))),
    BoothFx(
        "X-Ray", fxCat(
            fxCat(
                fxSat(0f), fxMat(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )
            ),
            fxMat(
                0.55f, 0f, 0f, 0f, 0f,
                0f, 0.85f, 0f, 0f, 8f,
                0f, 0f, 1.15f, 0f, 22f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )
)


// ------------------------------------------------------------------ view bantu

/** TextureView yang menjaga rasio gambar (muat di dalam ruang yang ada), sudut membulat. */
private class AspectTextureView(c: Context, private val radius: Float) : TextureView(c) {
    private var aw = 0
    private var ah = 0

    init {
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        clipToOutline = true
    }

    fun setAspect(w: Int, h: Int) {
        if (w == aw && h == ah) return
        aw = w
        ah = h
        requestLayout()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        invalidateOutline()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val maxW = MeasureSpec.getSize(wSpec)
        val maxH = MeasureSpec.getSize(hSpec)
        if (aw <= 0 || ah <= 0) {
            setMeasuredDimension(maxW, maxH)
            return
        }
        var w = maxW
        var h = (w.toLong() * ah / aw).toInt()
        if (h > maxH) {
            h = maxH
            w = (h.toLong() * aw / ah).toInt()
        }
        setMeasuredDimension(w, h)
    }
}

/** FrameLayout dengan sudut membulat yang ikut ukuran (untuk panggung preview). */
private class RoundFrame(c: Context, private val radius: Float) : FrameLayout(c) {
    init {
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        clipToOutline = true
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        invalidateOutline()
    }
}

// ------------------------------------------------------------------ Photo Booth di dalam notch

/**
 * Photo Booth ala macOS yang hidup sepenuhnya di panel notch (tab Tools -> Booth): preview cermin, deretan efek,
 * hitung mundur, mode Photo / 4-Up / Strip. Tidak membuka app/Activity lain. Kamera HANYA menyala selama panel
 * ini terlihat; begitu tab pindah / panel ditutup, kamera, sound, dan bitmap dilepas (hemat RAM, CPU, baterai).
 * Murni Camera2 + TextureView di thread utama (preview tanpa callback per-frame), tanpa dependensi tambahan.
 */
class BoothPanel(private val c: Context) : FrameLayout(c), Refreshable, PanelLife, TextureView.SurfaceTextureListener {
    /** Diisi NotchView: tutup panel dulu, baru jalankan aksi (buka galeri / bagikan). */
    var closeThen: ((() -> Unit) -> Unit)? = null

    private val ui = Handler(Looper.getMainLooper())
    private val seq = Handler(Looper.getMainLooper()) // semua jadwal urutan jepret (hitung mundur, foto berikutnya)
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var previewSize: Size? = null
    private var sensorOrient = 90
    private var afContinuous = false
    private var fps: Range<Int>? = null
    private var front = true          // yang diminta
    private var facingFront = true    // yang benar-benar terbuka
    private var showing = false
    private var opening = false
    private var tries = 0
    private var sound: MediaActionSound? = null

    private val tex = AspectTextureView(c, c.dpf(14))
    private val props = PropsView(c, c.dpf(14))
    private val stage = RoundFrame(c, c.dpf(16))
    private val status = c.tv("", 12f, C.TEXT, true)
    private val countNum = c.tv("", 90f, C.TEXT, true)
    private val flash = View(c)
    private val resultLayer = FrameLayout(c)
    private val resultImg = ImageView(c)
    private val msgLayer = LinearLayout(c)
    private val msgText = c.tv("", 12.5f, C.TEXT)
    private val msgBtn = TextView(c)
    private val thumb = ImageView(c)
    private val timerChip: TextView
    private val fxChips = ArrayList<TextView>()
    private val propChips = ArrayList<TextView>()
    private val tplChips = ArrayList<TextView>()
    private val tabChips = ArrayList<TextView>()
    private val tabPages = ArrayList<View>()
    private val modeChips = ArrayList<TextView>()
    private val ctrl = ArrayList<View>()
    private lateinit var shutter: FrameLayout

    private var msgKind = 0           // 0 tidak ada, 1 izin, 2 galat
    private var fx = 0
    // putaran tambahan (x90 derajat) kalau orientasi kamera perangkat ini tidak cocok dengan perhitungan standar;
    // diatur lewat tombol Rotate dan diingat
    private var extraRot = c.getSharedPreferences("lobo_booth", Context.MODE_PRIVATE).getInt("rot", 0) and 3
    // pita hitam bawaan kamera (pecahan 0..1 dari bitmap natural); dideteksi otomatis lalu dipotong dari preview & foto
    private var cropL = 0f
    private var cropT = 0f
    private var cropR = 0f
    private var cropB = 0f
    private var cropTries = 0
    private var fxCx = 0.5f           // pusat efek lensa/distorsi (0..1), digeser dengan jari
    private var fxCy = 0.45f
    private val fxT0 = SystemClock.uptimeMillis()
    private val live: BoothShaders.Live? = if (BoothShaders.supported) BoothShaders.Live(tex) else null
    private var prop = 0              // 0 = tanpa prop (lihat PropArt.names)
    private var tpl = 0               // template 4-Up / Strip (lihat BoothTpl.names)
    private var mode = 0              // 0 Photo, 1 4-Up, 2 Strip
    private var timerIdx = 0
    private val timers = intArrayOf(3, 5, 0)
    private var busy = false
    private val shots = ArrayList<Bitmap>()
    private var resultBmp: Bitmap? = null
    private var resultFile: File? = null
    private var thumbSig = ""

    // pelacak wajah untuk prop (hanya jalan saat prop dipilih)
    private val finder = FaceFinder { p -> props.onFace(p) }
    private var natBmp: Bitmap? = null
    private var upBmp: Bitmap? = null

    companion object {
        const val PANEL = 11
    }

    init {
        // ----- panggung preview (kiri)
        stage.background = rounded(0x33000000, c.dpf(16))
        tex.surfaceTextureListener = this
        tex.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            configureTransform(r - l, b - t)
            pushFx()
        }
        stage.addView(tex, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
        stage.setOnTouchListener { _, e ->
            val f = BOOTH_FX[fx]
            if (f.agsl == null || !f.aim || busy || tex.width <= 0 || tex.height <= 0) {
                false
            } else {
                if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
                    fxCx = ((e.x - tex.left) / tex.width).coerceIn(0.05f, 0.95f)
                    fxCy = ((e.y - tex.top) / tex.height).coerceIn(0.05f, 0.95f)
                    pushFx()
                    if (e.actionMasked == MotionEvent.ACTION_DOWN) stage.parent?.requestDisallowInterceptTouchEvent(true)
                }
                true
            }
        }
        stage.addView(props, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        status.setPadding(c.dp(10), c.dp(4), c.dp(10), c.dp(4))
        status.background = rounded(0x99000000.toInt(), c.dpf(100))
        status.visibility = View.GONE
        val slp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        slp.topMargin = c.dp(8)
        stage.addView(status, slp)

        countNum.gravity = Gravity.CENTER
        countNum.setShadowLayer(c.dpf(14), 0f, c.dpf(2), 0xAA000000.toInt())
        countNum.visibility = View.GONE
        stage.addView(countNum, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        flash.setBackgroundColor(0xFFFFFFFF.toInt())
        flash.alpha = 0f
        stage.addView(flash, FrameLayout.LayoutParams(MATCH, MATCH))

        // hasil jepretan (sebentar, lalu hilang sendiri)
        resultLayer.setBackgroundColor(0xE6000000.toInt())
        resultLayer.visibility = View.GONE
        resultLayer.setOnClickListener { closeResult() }
        resultImg.scaleType = ImageView.ScaleType.FIT_CENTER
        val rlp = FrameLayout.LayoutParams(MATCH, MATCH)
        rlp.bottomMargin = c.dp(34)
        resultLayer.addView(resultImg, rlp)
        val rb = LinearLayout(c)
        rb.gravity = Gravity.CENTER
        rb.addView(chip("Share") { shareResult() }, c.llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        rb.addView(chip("Done") { closeResult() })
        resultLayer.addView(rb, FrameLayout.LayoutParams(MATCH, c.dp(34), Gravity.BOTTOM))
        stage.addView(resultLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        // pesan (izin kamera / galat)
        msgLayer.orientation = LinearLayout.VERTICAL
        msgLayer.gravity = Gravity.CENTER
        msgLayer.setBackgroundColor(0xCC000000.toInt())
        msgLayer.visibility = View.GONE
        msgLayer.isClickable = true
        msgText.gravity = Gravity.CENTER
        msgLayer.addView(msgText, c.llp(WRAP, WRAP, 0f, 12, 0, 12, 8))
        msgBtn.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
        msgBtn.typeface = Typeface.DEFAULT_BOLD
        msgBtn.setTextColor(C.BLACK)
        msgBtn.gravity = Gravity.CENTER
        msgBtn.setPadding(c.dp(14), c.dp(6), c.dp(14), c.dp(6))
        msgBtn.background = rounded(0xFFFFFFFF.toInt(), c.dpf(100))
        msgLayer.addView(msgBtn, c.llp(WRAP, WRAP))
        stage.addView(msgLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        // ----- baris kontrol di bawah preview: mode, timer, balik kamera, foto terakhir
        val ctrlRow = LinearLayout(c)
        ctrlRow.gravity = Gravity.CENTER_VERTICAL
        val names = arrayOf("Photo", "4-Up", "Strip")
        for (i in names.indices) {
            val ch = chip(names[i]) { selectMode(i) }
            modeChips.add(ch)
            ctrl.add(ch)
            ctrlRow.addView(ch, c.llp(WRAP, WRAP, 0f, 0, 0, 4, 0))
        }
        styleChip(modeChips[0], true)
        ctrlRow.addView(View(c), c.llp(0, 1, 1f))
        timerChip = chip("") {
            timerIdx = (timerIdx + 1) % timers.size
            updateTimerChip()
        }
        updateTimerChip()
        ctrl.add(timerChip)
        ctrlRow.addView(timerChip, c.llp(WRAP, WRAP, 0f, 0, 0, 2, 0))
        val rotChip = chip("Rotate") { rotateView() }
        ctrl.add(rotChip)
        ctrlRow.addView(rotChip, c.llp(WRAP, WRAP, 0f, 0, 0, 2, 0))
        val flip = LineIconView(c, IconKind.FLIP, C.TEXT, 17f, 1.5f)
        flip.setOnClickListener { flipCamera() }
        ctrl.add(flip)
        ctrlRow.addView(flip, c.llp(c.dp(32), c.dp(30)))
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.background = glass(C.GLASS, c.dpf(8))
        thumb.roundClip(c.dpf(8))
        thumb.visibility = View.GONE
        thumb.setOnClickListener { openLast() }
        ctrlRow.addView(thumb, c.llp(c.dp(30), c.dp(30), 0f, 4, 0, 0, 0))

        val left = LinearLayout(c)
        left.orientation = LinearLayout.VERTICAL
        left.addView(stage, c.llp(MATCH, 0, 1f))
        left.addView(ctrlRow, c.llp(MATCH, c.dp(36), 0f, 0, 6, 0, 0))

        // ----- kolom kanan: tab Filter / Props / Frame (2 kolom, bisa digulir) + tombol rana
        val fxCol = chipGrid(BOOTH_FX.map { it.name }, fxChips) { selectFx(it) }
        styleChip(fxChips[0], true)
        val propCol = chipGrid(PropArt.names, propChips) { selectProp(it) }
        styleChip(propChips[0], true)
        val tplCol = LinearLayout(c)
        tplCol.orientation = LinearLayout.VERTICAL
        tplCol.addView(chipGrid(BoothTpl.names, tplChips) { selectTpl(it) })
        val tplNote = c.tv("Frame style for 4-Up and Strip", 10f, C.SUB)
        tplNote.gravity = Gravity.CENTER
        tplCol.addView(tplNote, c.llp(MATCH, WRAP, 0f, 0, 2, 0, 0))
        styleChip(tplChips[0], true)

        tabPages.add(fxCol)
        tabPages.add(propCol)
        tabPages.add(tplCol)
        val pages = FrameLayout(c)
        for (pg in tabPages) pages.addView(pg, FrameLayout.LayoutParams(MATCH, WRAP))
        val fxScroll = ScrollView(c)
        fxScroll.isVerticalScrollBarEnabled = false
        fxScroll.overScrollMode = OVER_SCROLL_NEVER
        fxScroll.addView(pages, FrameLayout.LayoutParams(MATCH, WRAP))

        val tabRow = LinearLayout(c)
        val tabNames = arrayOf("Filter", "Props", "Frame")
        for (i in tabNames.indices) {
            val tb = c.tv(tabNames[i], 10.5f, C.TEXT, true)
            tb.gravity = Gravity.CENTER
            tb.setPadding(c.dp(2), c.dp(5), c.dp(2), c.dp(5))
            tb.setOnClickListener { selectTab(i) }
            tabChips.add(tb)
            tabRow.addView(tb, c.llp(0, WRAP, 1f, if (i > 0) 3 else 0, 0, 0, 0))
        }
        selectTab(0)

        shutter = FrameLayout(c)
        val ring = GradientDrawable()
        ring.shape = GradientDrawable.OVAL
        ring.setColor(0)
        ring.setStroke(c.dp(3), 0xFFFFFFFF.toInt())
        shutter.background = ring
        val inner = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFFF6B6B.toInt(), 0xFFE0245E.toInt()))
        inner.shape = GradientDrawable.OVAL
        val innerV = FrameLayout(c)
        innerV.background = inner
        innerV.addView(LineIconView(c, IconKind.CAMERA, C.TEXT, 22f, 1.6f), FrameLayout.LayoutParams(MATCH, MATCH))
        shutter.addView(innerV, FrameLayout.LayoutParams(c.dp(42), c.dp(42), Gravity.CENTER))
        shutter.setOnClickListener {
            if (busy) cancelSequence() else startSequence()
        }

        val right = LinearLayout(c)
        right.orientation = LinearLayout.VERTICAL
        right.addView(tabRow, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 6))
        right.addView(fxScroll, c.llp(MATCH, 0, 1f))
        val slp2 = c.llp(c.dp(52), c.dp(52), 0f, 0, 6, 0, 0)
        slp2.gravity = Gravity.CENTER_HORIZONTAL
        right.addView(shutter, slp2)

        val row = LinearLayout(c)
        row.addView(left, c.llp(0, MATCH, 1f))
        row.addView(right, c.llp(c.dp(120), MATCH, 0f, 10, 0, 0, 0))
        addView(row, LayoutParams(MATCH, MATCH))
    }

    // ---------------------------------------------------------------- UI kecil

    private fun styleChip(t: TextView, sel: Boolean) {
        t.background = if (sel) rounded(0xFFFFFFFF.toInt(), c.dpf(100)) else glass(C.GLASS2, c.dpf(100))
        t.setTextColor(if (sel) C.BLACK else C.TEXT)
        t.setShadowLayer(0f, 0f, 0f, 0)
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val t = c.tv(text, 11.5f, C.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(c.dp(9), c.dp(5), c.dp(9), c.dp(5))
        t.setOnClickListener { onClick() }
        styleChip(t, false)
        return t
    }

    /** Grid chip 2 kolom (dipakai tab Filter / Props / Frame). */
    private fun chipGrid(names: List<String>, into: ArrayList<TextView>, onSel: (Int) -> Unit): LinearLayout {
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        var rowL: LinearLayout? = null
        for (i in names.indices) {
            if (i % 2 == 0) {
                rowL = LinearLayout(c)
                col.addView(rowL, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 4))
            }
            val ch = chip(names[i]) { onSel(i) }
            ch.setPadding(c.dp(4), c.dp(5), c.dp(4), c.dp(5))
            into.add(ch)
            ctrl.add(ch)
            rowL?.addView(ch, c.llp(0, WRAP, 1f, if (i % 2 == 1) 4 else 0, 0, 0, 0))
        }
        return col
    }

    private fun selectTab(i: Int) {
        for (k in tabPages.indices) tabPages[k].visibility = if (k == i) View.VISIBLE else View.GONE
        for (k in tabChips.indices) {
            val t = tabChips[k]
            t.background = if (k == i) rounded(0x40FFFFFF, c.dpf(100)) else null
            t.alpha = if (k == i) 1f else 0.6f
        }
    }

    private fun selectProp(i: Int) {
        prop = i
        for (k in propChips.indices) styleChip(propChips[k], k == i)
        props.prop = i
        if (i == 0) stopTracking() else startTracking()
    }

    private fun selectTpl(i: Int) {
        tpl = i
        for (k in tplChips.indices) styleChip(tplChips[k], k == i)
    }

    private fun updateTimerChip() {
        val s = timers[timerIdx]
        timerChip.text = if (s == 0) "Off" else "${s}s"
    }

    private fun selectFx(i: Int) {
        fx = i
        for (k in fxChips.indices) styleChip(fxChips[k], k == i)
        val f = BOOTH_FX[i]
        if (f.agsl != null && !BoothShaders.supported) {
            Toast.makeText(c, "${f.name} needs Android 13 or newer", Toast.LENGTH_SHORT).show()
        } else if (f.agsl != null && f.aim && !busy) {
            hint("Drag on the preview to move the effect")
        }
        applyFxToPreview()
    }

    private val hintOff = Runnable { if (!busy) status.visibility = View.GONE }

    private fun hint(text: String) {
        status.text = text
        status.visibility = View.VISIBLE
        ui.removeCallbacks(hintOff)
        ui.postDelayed(hintOff, 1800L)
    }

    /** Waktu (detik) untuk efek yang bergerak; diputar tiap 1 jam supaya float tetap presisi. */
    private fun fxTime(): Float = ((SystemClock.uptimeMillis() - fxT0) % 3600000L) / 1000f

    private fun pushFx() {
        val lv = live ?: return
        val f = BOOTH_FX[fx]
        lv.apply(f.agsl, fxCx, fxCy, fxTime())
    }

    private val fxTick: Runnable = object : Runnable {
        override fun run() {
            val f = BOOTH_FX[fx]
            if (!showing || f.agsl == null || !f.anim) return
            pushFx()
            ui.postDelayed(this, 50L) // ~20 fps cukup untuk gerak pelan, hemat baterai
        }
    }

    private fun selectMode(i: Int) {
        if (busy) return
        mode = i
        for (k in modeChips.indices) styleChip(modeChips[k], k == i)
    }

    private fun setControlsEnabled(on: Boolean) {
        for (v in ctrl) {
            v.isEnabled = on
            v.alpha = if (on) 1f else 0.4f
        }
    }

    private fun applyFxToPreview() {
        val f = BOOTH_FX[fx]
        tex.setLayerPaint(f.paint())
        pushFx()
        ui.removeCallbacks(fxTick)
        if (showing && f.agsl != null && f.anim && live != null) ui.postDelayed(fxTick, 50L)
        tex.invalidate()
    }

    private fun showMsg(kind: Int, text: String, btn: String, act: () -> Unit) {
        msgKind = kind
        msgText.text = text
        msgBtn.text = btn
        msgBtn.setOnClickListener { act() }
        msgLayer.visibility = View.VISIBLE
    }

    private fun hideMsg() {
        msgKind = 0
        msgLayer.visibility = View.GONE
    }

    private fun hasPerm(): Boolean = c.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    // ---------------------------------------------------------------- siklus hidup (kamera hanya saat terlihat)

    private val openRunnable = Runnable { ensureCamera() }

    override fun onVisible(v: Boolean) {
        if (v == showing) return
        showing = v
        if (v) {
            tries = 0
            registerDisplay()
            updateThumb()
            // tunggu animasi buka panel selesai dulu supaya tidak tersendat
            ui.postDelayed(openRunnable, 520)
        } else {
            stopAll()
        }
    }

    override fun onDetachedFromWindow() {
        if (showing) {
            showing = false
            stopAll()
        }
        super.onDetachedFromWindow()
    }

    private fun stopAll() {
        ui.removeCallbacks(openRunnable)
        cancelSequence()
        closeResultNow()
        closeCamera()
        unregisterDisplay()
        finder.stop()
        natBmp = null
        upBmp = null
        try {
            NotchService.instance?.cameraMode(false)
        } catch (e: Exception) {
        }
        try {
            sound?.release()
        } catch (e: Throwable) {
        }
        sound = null
        ui.removeCallbacks(fxTick)
        ui.removeCallbacks(hintOff)
        live?.apply(null, fxCx, fxCy, 0f)
        tex.setLayerPaint(null)
    }

    /** Dipanggil NotchView berkala saat tab ini terbuka: pulihkan kamera setelah izin diberikan / gagal sesaat. */
    override fun refresh() {
        if (!showing || device != null || opening || busy) return
        if (hasPerm()) {
            if (msgKind == 1) {
                hideMsg()
                tries = 0
            }
            if (msgKind == 0 && tries < 3) {
                tries++
                ensureCamera()
            }
        }
        updateThumb()
    }

    private fun ensureCamera() {
        if (!showing || device != null || opening) return
        if (!hasPerm()) {
            showMsg(1, "Allow camera access to use Photo Booth", "Allow") { requestPerm() }
            return
        }
        if (!tex.isAvailable) return // onSurfaceTextureAvailable memanggil lagi
        hideMsg()
        // Android 11+: kamera hanya boleh dipakai service kalau tipe foreground-nya "camera"
        try {
            NotchService.instance?.cameraMode(true)
        } catch (e: Exception) {
        }
        openCamera()
    }

    private fun requestPerm() {
        try {
            val i = Intent(c, CamPermActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
        } catch (e: Exception) {
        }
    }

    // ---------------------------------------------------------------- kamera (Camera2)

    override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
        if (showing) ensureCamera()
    }

    override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {
        configureTransform(width, height)
    }

    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
        closeCamera()
        return true
    }

    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}

    private val dispListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            ui.post {
                applyAspect()
                if (tex.width > 0) configureTransform(tex.width, tex.height)
            }
        }
    }

    private fun registerDisplay() {
        try {
            (c.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(dispListener, ui)
        } catch (e: Exception) {
        }
    }

    private fun unregisterDisplay() {
        try {
            (c.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(dispListener)
        } catch (e: Exception) {
        }
    }

    private fun pickCamera(mgr: CameraManager): String? {
        var any: String? = null
        for (id in mgr.cameraIdList) {
            val facing = mgr.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING)
            if (any == null) any = id
            if (front && facing == CameraCharacteristics.LENS_FACING_FRONT) return id
            if (!front && facing == CameraCharacteristics.LENS_FACING_BACK) return id
        }
        return any
    }

    /** 4:3 terbesar sampai 1280 lebar (cukup tajam untuk foto booth, ringan di GPU/RAM). */
    private fun choosePreview(sizes: Array<Size>): Size {
        val ratio43 = sizes.filter { it.width * 3 == it.height * 4 && it.width <= 1280 }
        val best = ratio43.maxByOrNull { it.width * it.height }
        if (best != null) return best
        val any = sizes.filter { it.width <= 1280 }.maxByOrNull { it.width * it.height }
        return any ?: sizes[0]
    }

    private fun naturalSize(ps: Size): Pair<Int, Int> =
        if (sensorOrient % 180 == 90) Pair(ps.height, ps.width) else Pair(ps.width, ps.height)

    @Suppress("DEPRECATION")
    private fun displayRot(): Int =
        ((c.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation + extraRot) and 3

    /** Putar tampilan kamera 90 derajat (preview, foto, dan pelacak wajah ikut), disimpan untuk berikutnya. */
    private fun rotateView() {
        extraRot = (extraRot + 1) and 3
        c.getSharedPreferences("lobo_booth", Context.MODE_PRIVATE).edit().putInt("rot", extraRot).apply()
        applyAspect()
        if (tex.width > 0) configureTransform(tex.width, tex.height)
        pushFx()
    }

    private fun applyAspect() {
        val ps = previewSize ?: return
        val (nw, nh) = naturalSize(ps)
        val cw = maxOf(1, ((1f - cropL - cropR) * nw).toInt())
        val ch = maxOf(1, ((1f - cropT - cropB) * nh).toInt())
        val rot = displayRot()
        if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) {
            tex.setAspect(ch, cw)
            props.setAspect(ch, cw)
        } else {
            tex.setAspect(cw, ch)
            props.setAspect(cw, ch)
        }
    }

    /** Persegi isi gambar (piksel) di dalam bitmap natural w x h, tanpa pita hitam bawaan kamera. */
    private fun contentRect(w: Int, h: Int): Rect {
        val l = (cropL * w).toInt()
        val t = (cropT * h).toInt()
        val r = w - (cropR * w).toInt()
        val b = h - (cropB * h).toInt()
        return if (r - l < 8 || b - t < 8) Rect(0, 0, w, h) else Rect(l, t, r, b)
    }

    private val cropRunnable = Runnable { detectCrop() }

    /**
     * Beberapa kamera (mis. kamera depan tablet) mengirim frame dengan pita hitam murni di tepi (gambar aslinya lebih kecil
     * dari buffer). Pita itu dicari sekali per kamera yang dibuka (baris/kolom yang SEMUA pikselnya hitam), lalu dipotong
     * dari preview, foto, dan pelacak wajah supaya gambar memenuhi bingkai.
     */
    private fun detectCrop() {
        if (!showing || device == null || !tex.isAvailable || busy) return
        val ps = previewSize ?: return
        val (nw, nh) = naturalSize(ps)
        val sc = 192f / maxOf(nw, nh)
        val bw = maxOf(16, (nw * sc).toInt())
        val bh = maxOf(16, (nh * sc).toInt())
        var l = 0f
        var t = 0f
        var r = 0f
        var b = 0f
        var ok = false
        try {
            val bmp = tex.getBitmap(bw, bh)
            val px = IntArray(bw * bh)
            bmp.getPixels(px, 0, bw, 0, 0, bw, bh)
            bmp.recycle()
            fun dark(i: Int): Boolean {
                val p = px[i]
                return ((p shr 16) and 255) <= 3 && ((p shr 8) and 255) <= 3 && (p and 255) <= 3
            }
            fun rowDark(y: Int): Boolean {
                for (x in 0 until bw) if (!dark(y * bw + x)) return false
                return true
            }
            fun colDark(x: Int): Boolean {
                for (y in 0 until bh) if (!dark(y * bw + x)) return false
                return true
            }
            var top = 0
            while (top < bh && rowDark(top)) top++
            if (top < bh) {
                var bot = 0
                while (bot < bh && rowDark(bh - 1 - bot)) bot++
                var left = 0
                while (left < bw && colDark(left)) left++
                var right = 0
                while (right < bw && colDark(bw - 1 - right)) right++
                fun frac(a: Int, n: Int): Float {
                    val v = a.toFloat() / n
                    return if (v < 0.02f || v > 0.40f) 0f else v
                }
                l = frac(left, bw)
                r = frac(right, bw)
                t = frac(top, bh)
                b = frac(bot, bh)
                ok = true
            }
        } catch (e: Throwable) {
        }
        if (!ok) {
            // frame masih hitam penuh / gagal baca: coba lagi sebentar
            if (cropTries++ < 4) ui.postDelayed(cropRunnable, 600L)
            return
        }
        if (l != cropL || t != cropT || r != cropR || b != cropB) {
            cropL = l
            cropT = t
            cropR = r
            cropB = b
            applyAspect()
            if (tex.width > 0) configureTransform(tex.width, tex.height)
        }
    }

    /**
     * Matriks yang memutar gambar dari orientasi NATURAL perangkat (hasil TextureView.getBitmap) ke tegak sesuai rotasi
     * layar sekarang, lalu mencerminkan kamera depan - hasilnya sama persis dengan yang terlihat di preview.
     */
    private fun uprightMatrix(w: Int, h: Int, rot: Int, mirror: Boolean, ox: Float = 0f, oy: Float = 0f): Matrix {
        val m = Matrix()
        m.postTranslate(-ox, -oy) // (ox, oy) = pojok kiri-atas potongan; w x h = ukuran potongan
        m.postRotate(-90f * rot, w / 2f, h / 2f)
        val swap = rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270
        val ow = if (swap) h else w
        val oh = if (swap) w else h
        m.postTranslate((ow - w) / 2f, (oh - h) / 2f)
        if (mirror) m.postScale(-1f, 1f, ow / 2f, oh / 2f)
        return m
    }

    /** Putar/skala preview sesuai orientasi sensor & layar, lalu cerminkan kamera depan (seperti Photo Booth di Mac). */
    private fun configureTransform(viewW: Int, viewH: Int) {
        if (previewSize == null || viewW <= 0 || viewH <= 0) return
        val rot = displayRot()
        val cw = 1f - cropL - cropR
        val ch = 1f - cropT - cropB
        // titik di quad TextureView (buffer natural yang direnggangkan ke view) -> koordinat satuan buffer ->
        // buang pita hitam -> putar tegak -> skala ke ukuran view (rasio view sudah = rasio potongan yang diputar)
        val m = Matrix()
        m.setScale(1f / viewW, 1f / viewH)
        m.postTranslate(-cropL, -cropT)
        m.postScale(1f / cw, 1f / ch)
        m.postRotate(-90f * rot, 0.5f, 0.5f)
        m.postScale(viewW.toFloat(), viewH.toFloat())
        if (facingFront) m.postScale(-1f, 1f, viewW / 2f, viewH / 2f)
        tex.setTransform(m)
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun openCamera() {
        if (!showing || device != null || opening || !tex.isAvailable || !hasPerm()) return
        try {
            val mgr = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = pickCamera(mgr)
            if (id == null) {
                showMsg(2, "No camera found", "Retry") { retry() }
                return
            }
            val cc = mgr.getCameraCharacteristics(id)
            sensorOrient = cc.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            facingFront = cc.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            val af = cc.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
            afContinuous = af != null && af.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            // frame rate preview dibatasi (<= 24 fps) supaya CPU/GPU/baterai hemat
            val ranges = cc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            fps = ranges?.filter { it.upper <= 24 }?.maxWithOrNull(compareBy<Range<Int>>({ it.upper }, { it.lower }))
            val map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(SurfaceTexture::class.java)
            if (sizes == null || sizes.isEmpty()) {
                showMsg(2, "Camera not supported", "Retry") { retry() }
                return
            }
            previewSize = choosePreview(sizes)
            applyAspect()
            opening = true
            mgr.openCamera(id, stateCb, ui)
        } catch (e: Exception) {
            opening = false
            showMsg(2, "Can't open the camera", "Retry") { retry() }
        }
    }

    private fun retry() {
        hideMsg()
        tries = 0
        ensureCamera()
    }

    private val stateCb = object : CameraDevice.StateCallback() {
        override fun onOpened(cd: CameraDevice) {
            opening = false
            if (!showing) {
                cd.close()
                return
            }
            device = cd
            startPreview(cd)
        }

        override fun onDisconnected(cd: CameraDevice) {
            opening = false
            cd.close()
            if (device === cd) device = null
        }

        override fun onError(cd: CameraDevice, error: Int) {
            opening = false
            cd.close()
            if (device === cd) device = null
            if (showing) showMsg(2, "Camera is busy or blocked", "Retry") { retry() }
        }
    }

    @Suppress("DEPRECATION")
    private fun startPreview(cd: CameraDevice) {
        val st = tex.surfaceTexture ?: return
        val ps = previewSize ?: return
        try {
            st.setDefaultBufferSize(ps.width, ps.height)
            val surface = Surface(st)
            val req = cd.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            req.addTarget(surface)
            if (afContinuous) req.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            fps?.let { req.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
            cd.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (device !== cd || !showing) {
                        s.close()
                        return
                    }
                    session = s
                    try {
                        s.setRepeatingRequest(req.build(), null, ui)
                    } catch (e: Exception) {
                    }
                    applyAspect()
                    applyFxToPreview()
                    if (tex.width > 0) configureTransform(tex.width, tex.height)
                    if (prop != 0) startTracking()
                    cropTries = 0
                    ui.removeCallbacks(cropRunnable)
                    ui.postDelayed(cropRunnable, 700L)
                }

                override fun onConfigureFailed(s: CameraCaptureSession) {
                    if (showing) showMsg(2, "Camera error", "Retry") { retry() }
                }
            }, ui)
        } catch (e: Exception) {
            if (showing) showMsg(2, "Camera error", "Retry") { retry() }
        }
    }

    private fun closeCamera() {
        stopTracking()
        try {
            session?.close()
        } catch (e: Exception) {
        }
        session = null
        try {
            device?.close()
        } catch (e: Exception) {
        }
        device = null
        opening = false
        ui.removeCallbacks(cropRunnable)
        cropL = 0f
        cropT = 0f
        cropR = 0f
        cropB = 0f
    }

    private fun flipCamera() {
        if (busy || opening) return
        front = !front
        closeCamera()
        ui.postDelayed({ if (showing) ensureCamera() }, 200)
    }

    // ---------------------------------------------------------------- pelacakan wajah untuk prop

    private val trackTick: Runnable = object : Runnable {
        override fun run() {
            if (!showing || prop == 0 || device == null) return
            if (!finder.busy) grabFrame() // tetap jalan saat hitung mundur supaya prop tidak memudar sebelum jepret
            ui.postDelayed(this, 140L)
        }
    }

    private fun startTracking() {
        ui.removeCallbacks(trackTick)
        if (!showing || prop == 0 || device == null) return
        finder.start()
        ui.post(trackTick)
    }

    private fun stopTracking() {
        ui.removeCallbacks(trackTick)
        props.clearFace()
    }

    /** Ambil frame kecil dari preview (sudah tegak + dicermin, sama dengan yang dilihat) lalu kirim ke pencari wajah. */
    private fun grabFrame() {
        val ps = previewSize ?: return
        if (!tex.isAvailable) return
        val (nw, nh) = naturalSize(ps)
        val rot = displayRot()
        val sc = 224f / maxOf(nw, nh)
        val tw = maxOf(2, (nw * sc).toInt() / 2 * 2)
        val th = maxOf(2, (nh * sc).toInt() / 2 * 2)
        val cr = contentRect(tw, th)
        val cw = maxOf(2, cr.width() / 2 * 2)
        val chh = maxOf(2, cr.height() / 2 * 2)
        val swap = rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270
        val uw = if (swap) chh else cw
        val uh = if (swap) cw else chh
        val nb: Bitmap = natBmp?.takeIf { it.width == tw && it.height == th }
            ?: Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888).also { natBmp = it }
        val ub: Bitmap = upBmp?.takeIf { it.width == uw && it.height == uh }
            ?: Bitmap.createBitmap(uw, uh, Bitmap.Config.RGB_565).also { upBmp = it }
        try {
            tex.getBitmap(nb)
            Canvas(ub).drawBitmap(nb, uprightMatrix(cw, chh, rot, facingFront, cr.left.toFloat(), cr.top.toFloat()), null)
            finder.submit(ub)
        } catch (e: Throwable) {
        }
    }

    // ---------------------------------------------------------------- jepret

    private fun startSequence() {
        if (busy || session == null) return
        busy = true
        shots.clear()
        setControlsEnabled(false)
        nextShot(0, if (mode == 0) 1 else 4)
    }

    private fun nextShot(i: Int, total: Int) {
        if (!busy) return
        if (total > 1) {
            status.text = "${i + 1} / $total"
            status.visibility = View.VISIBLE
        } else {
            status.visibility = View.GONE
        }
        val t = timers[timerIdx]
        val secs = if (i == 0) t else (if (t == 0) 1 else 2)
        countdown(secs) {
            capture { bmp ->
                if (!busy) {
                    bmp.recycle()
                    return@capture
                }
                shots.add(bmp)
                if (i + 1 < total) {
                    seq.postDelayed({ nextShot(i + 1, total) }, 450)
                } else {
                    finishSequence()
                }
            }
        }
    }

    private fun countdown(n: Int, done: () -> Unit) {
        if (!busy) return
        if (n <= 0) {
            countNum.visibility = View.GONE
            done()
            return
        }
        countNum.text = n.toString()
        countNum.visibility = View.VISIBLE
        countNum.alpha = 0.2f
        countNum.scaleX = 1.5f
        countNum.scaleY = 1.5f
        countNum.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).start()
        seq.postDelayed({ countdown(n - 1, done) }, 1000)
    }

    /**
     * Kilat menutupi tangkapan. Paint efek dilepas dulu supaya bitmap TextureView pasti mentah, lalu efek dipasang
     * manual (hasil sama dengan preview, tanpa risiko efek ganda). Ukuran bitmap = resolusi asli preview.
     */
    private fun capture(cb: (Bitmap) -> Unit) {
        try {
            if (sound == null) {
                sound = MediaActionSound()
                sound?.load(MediaActionSound.SHUTTER_CLICK)
            }
            sound?.play(MediaActionSound.SHUTTER_CLICK)
        } catch (e: Throwable) {
        }
        flash.animate().cancel()
        flash.alpha = 1f
        tex.setLayerPaint(null)
        tex.invalidate()
        seq.postDelayed({
            var out: Bitmap? = null
            try {
                val ps = previewSize
                // getBitmap mengembalikan gambar dalam orientasi NATURAL perangkat -> minta ukuran natural (bukan ukuran layar,
                // itu yang bikin foto melar), lalu putar/cermin sendiri supaya sama dengan preview.
                val raw: Bitmap? = if (ps != null) {
                    val (nw, nh) = naturalSize(ps)
                    tex.getBitmap(nw, nh)
                } else {
                    tex.bitmap
                }
                if (raw != null) out = orient(raw)
            } catch (e: Throwable) {
                out = null
            }
            applyFxToPreview()
            flash.animate().alpha(0f).setDuration(380).start()
            if (out == null) {
                Toast.makeText(c, "Couldn't capture, try again", Toast.LENGTH_SHORT).show()
                cancelSequence()
            } else {
                cb(out)
            }
        }, 120)
    }

    /** Putar ke tegak + cermin (kamera depan) + terapkan filter warna + gambar prop. Melepas [raw]. */
    private fun orient(full: Bitmap): Bitmap {
        val rot = displayRot()
        val cr = contentRect(full.width, full.height)
        val raw: Bitmap = if (cr.width() != full.width || cr.height() != full.height) {
            val cut = Bitmap.createBitmap(full, cr.left, cr.top, cr.width(), cr.height())
            if (cut !== full) full.recycle()
            cut
        } else {
            full
        }
        val swap = rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270
        val ow = if (swap) raw.height else raw.width
        val oh = if (swap) raw.width else raw.height
        val b = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val p: Paint = BOOTH_FX[fx].paint() ?: Paint(Paint.FILTER_BITMAP_FLAG)
        Canvas(b).drawBitmap(raw, uprightMatrix(raw.width, raw.height, rot, facingFront), p)
        raw.recycle()
        var out = b
        val code = BOOTH_FX[fx].agsl
        if (code != null && BoothShaders.supported) {
            // shader yang sama dengan preview dijalankan GPU ke foto; kalau gagal, foto tetap jadi (tanpa efek)
            val fxd = BoothShaders.render(b, code, fxCx, fxCy, fxTime())
            if (fxd != null) {
                b.recycle()
                out = fxd
            }
        }
        props.drawOnto(out)
        return out
    }

    private fun cancelSequence() {
        busy = false
        seq.removeCallbacksAndMessages(null)
        countNum.animate().cancel()
        countNum.visibility = View.GONE
        status.visibility = View.GONE
        flash.animate().cancel()
        flash.alpha = 0f
        for (b in shots) b.recycle()
        shots.clear()
        setControlsEnabled(true)
        if (device != null) applyFxToPreview()
    }

    private fun finishSequence() {
        val list = ArrayList(shots)
        shots.clear()
        status.text = "Saving…"
        status.visibility = View.VISIBLE
        val m = mode
        val tp = tpl
        val app = c.applicationContext
        Thread {
            var result: Bitmap? = null
            try {
                result = when (m) {
                    0 -> list[0]
                    1 -> BoothTpl.grid(list, tp)
                    else -> BoothTpl.strip(list, tp)
                }
            } catch (t: Throwable) {
                result = null
            }
            val bmp = result
            val f = if (bmp != null) BoothStore.save(app, bmp) else null
            if (m != 0) for (b in list) b.recycle()
            ui.post {
                busy = false
                status.visibility = View.GONE
                setControlsEnabled(true)
                if (bmp == null) {
                    Toast.makeText(c, "Couldn't build the photo", Toast.LENGTH_SHORT).show()
                } else if (showing) {
                    showResult(bmp, f)
                } else {
                    bmp.recycle()
                }
                updateThumb()
            }
        }.start()
    }

    // ---------------------------------------------------------------- hasil

    private val autoClose = Runnable { closeResult() }

    private fun showResult(bmp: Bitmap, f: File?) {
        closeResultNow()
        resultBmp = bmp
        resultFile = f
        resultImg.setImageBitmap(bmp)
        resultLayer.alpha = 0f
        resultLayer.visibility = View.VISIBLE
        resultLayer.animate().alpha(1f).setDuration(200).start()
        ui.postDelayed(autoClose, 6000)
    }

    private fun closeResult() {
        ui.removeCallbacks(autoClose)
        resultLayer.animate().cancel()
        resultLayer.animate().alpha(0f).setDuration(160).withEndAction { closeResultNow() }.start()
    }

    /** Lepas bitmap hasil segera (RAM). */
    private fun closeResultNow() {
        ui.removeCallbacks(autoClose)
        resultLayer.animate().cancel()
        resultLayer.visibility = View.GONE
        resultImg.setImageBitmap(null)
        resultBmp?.recycle()
        resultBmp = null
    }

    private fun shareResult() {
        val f = resultFile
        if (f == null) {
            Toast.makeText(c, "Nothing to share", Toast.LENGTH_SHORT).show()
            return
        }
        val go: () -> Unit = {
            try {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "image/jpeg"
                i.putExtra(Intent.EXTRA_STREAM, BoothStore.uriFor(f))
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val ch = Intent.createChooser(i, "Share photo")
                ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                c.startActivity(ch)
            } catch (e: Exception) {
            }
        }
        val ct = closeThen
        if (ct != null) ct(go) else go()
    }

    // ---------------------------------------------------------------- foto terakhir

    private fun updateThumb() {
        val f = BoothStore.items().firstOrNull()
        val sig = if (f == null) "" else f.absolutePath + f.lastModified()
        if (sig == thumbSig) return
        thumbSig = sig
        if (f == null) {
            thumb.setImageBitmap(null)
            thumb.visibility = View.GONE
            return
        }
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(f.absolutePath, o)
            var s = 1
            while (o.outWidth / (s * 2) >= 128 && o.outHeight / (s * 2) >= 128) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            thumb.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath, o2))
            thumb.visibility = View.VISIBLE
        } catch (e: Throwable) {
            thumb.visibility = View.GONE
        }
    }

    private fun openLast() {
        val f = BoothStore.items().firstOrNull() ?: return
        val go: () -> Unit = {
            try {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(BoothStore.uriFor(f), "image/jpeg")
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                c.startActivity(i)
            } catch (e: Exception) {
                Toast.makeText(c, "No app to open photos", Toast.LENGTH_SHORT).show()
            }
        }
        val ct = closeThen
        if (ct != null) ct(go) else go()
    }
}

/**
 * Activity transparan sekejap: satu-satunya cara meminta izin kamera (overlay tidak bisa menampilkan dialog izin).
 * Setelah dijawab langsung menutup dan membuka lagi tab Booth di notch.
 */
class CamPermActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            done()
        } else {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 9)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        done()
    }

    private fun done() {
        finish()
        overridePendingTransition(0, 0)
        Bus.changed()
        NotchService.instance?.openTab(BoothPanel.PANEL)
    }
}
