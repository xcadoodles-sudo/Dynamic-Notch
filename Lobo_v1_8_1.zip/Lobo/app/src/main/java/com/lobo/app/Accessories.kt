package com.lobo.app

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader

/**
 * Aksesoris maskot bergaya semi-3D (v1.8.1). Cahaya datang dari kiri-atas, jadi tiap benda punya:
 * gradasi volume, sisi gelap di kanan/bawah, kilau (specular), tepi/ketebalan, dan bayangan jatuh ke kepala.
 * Koordinat sama dengan kotak kepala 100x100 di [PetView]; semua Path & Shader dibuat sekali (tanpa alokasi per frame).
 *
 * Berkas ini dihasilkan dari desain vektor; mengubah warna cukup edit angka 0xAARRGGBB di bawah.
 */
internal object AccArt {
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private fun lg(x0: Float, y0: Float, x1: Float, y1: Float, c: IntArray, s: FloatArray): Shader =
        LinearGradient(x0, y0, x1, y1, c, s, Shader.TileMode.CLAMP)

    private fun rg(cx: Float, cy: Float, r: Float, c: IntArray, s: FloatArray): Shader =
        RadialGradient(cx, cy, r, c, s, Shader.TileMode.CLAMP)

    private fun fillS(cv: Canvas, p: Path, sh: Shader) {
        fillP.shader = sh
        fillP.color = 0xFFFFFFFF.toInt()
        cv.drawPath(p, fillP)
        fillP.shader = null
    }

    private fun fillC(cv: Canvas, p: Path, color: Int) {
        fillP.shader = null
        fillP.color = color
        cv.drawPath(p, fillP)
    }

    private fun strokeS(cv: Canvas, p: Path, w: Float, sh: Shader) {
        lineP.shader = sh
        lineP.color = 0xFFFFFFFF.toInt()
        lineP.strokeWidth = w
        cv.drawPath(p, lineP)
        lineP.shader = null
    }

    private fun strokeC(cv: Canvas, p: Path, w: Float, color: Int) {
        lineP.shader = null
        lineP.color = color
        lineP.strokeWidth = w
        cv.drawPath(p, lineP)
    }

    // ------------------------------------------------------------ gradasi

    private val g_shadowV = lg(0f, 33f, 0f, 46f, intArrayOf(0x66000000.toInt(), 0x00000000.toInt()), floatArrayOf(0f, 1f))
    private val g_bnDome = rg(38f, 9f, 52f, intArrayOf(0xFF86AEFF.toInt(), 0xFF4A78E0.toInt(), 0xFF243F94.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_bnShade = lg(24f, 0f, 80f, 0f, intArrayOf(0x18FFFFFF.toInt(), 0x00FFFFFF.toInt(), 0x00000000.toInt(), 0x66000000.toInt()), floatArrayOf(0f, 0.35f, 0.6f, 1f))
    private val g_bnCuff = lg(0f, 26f, 0f, 39f, intArrayOf(0xFF7AA2FA.toInt(), 0xFF456FD6.toInt(), 0xFF2B4BA8.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_bnCuffShade = lg(19f, 0f, 81f, 0f, intArrayOf(0x2AFFFFFF.toInt(), 0x00FFFFFF.toInt(), 0x00000000.toInt(), 0x6A000000.toInt()), floatArrayOf(0f, 0.35f, 0.6f, 1f))
    private val g_bnPom = rg(47f, -2.5f, 10.5f, intArrayOf(0xFFFFFFFF.toInt(), 0xFFDCE3F8.toInt(), 0xFF8F9CC8.toInt()), floatArrayOf(0f, 0.55f, 1f))
    private val g_snBody = rg(36f, 9f, 66f, intArrayOf(0xFFFF7378.toInt(), 0xFFD8323A.toInt(), 0xFF8A1822.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_snTrim = lg(0f, 25f, 0f, 42f, intArrayOf(0xFFFFFFFF.toInt(), 0xFFE9ECF6.toInt(), 0xFFB9BFD8.toInt()), floatArrayOf(0f, 0.6f, 1f))
    private val g_snTrimShade = lg(19f, 0f, 81f, 0f, intArrayOf(0x00FFFFFF.toInt(), 0x00FFFFFF.toInt(), 0x00000000.toInt(), 0x4A000000.toInt()), floatArrayOf(0f, 0.35f, 0.6f, 1f))
    private val g_snPom = rg(86.5f, 44f, 12f, intArrayOf(0xFFFFFFFF.toInt(), 0xFFDFE3F1.toInt(), 0xFF9AA2C2.toInt()), floatArrayOf(0f, 0.55f, 1f))
    private val g_shadowV2 = lg(0f, 33f, 0f, 46f, intArrayOf(0x40000000.toInt(), 0x00000000.toInt()), floatArrayOf(0f, 1f))
    private val g_pcCone = lg(32f, 0f, 74f, 0f, intArrayOf(0xFFFF9AD2.toInt(), 0xFFE85FA8.toInt(), 0xFF9F2C6C.toInt()), floatArrayOf(0f, 0.42f, 1f))
    private val g_pcStripe = lg(0f, 0f, 0f, 30f, intArrayOf(0xFFFFF29A.toInt(), 0xFFEDB944.toInt()), floatArrayOf(0f, 1f))
    private val g_pcShade = lg(32f, 0f, 74f, 0f, intArrayOf(0x2CFFFFFF.toInt(), 0x00FFFFFF.toInt(), 0x00000000.toInt(), 0x5A300020.toInt()), floatArrayOf(0f, 0.3f, 0.55f, 1f))
    private val g_pcBall = rg(51.4f, -5.2f, 8.4f, intArrayOf(0xFFFFF7B8.toInt(), 0xFFF2C14E.toInt(), 0xFFB07A14.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_crWall = lg(0f, 7f, 0f, 30f, intArrayOf(0xFFC88F20.toInt(), 0xFF6E440A.toInt()), floatArrayOf(0f, 1f))
    private val g_crGold = lg(0f, 5f, 0f, 41f, intArrayOf(0xFFFFF3B8.toInt(), 0xFFF7C94E.toInt(), 0xFFDA9E28.toInt(), 0xFFA16C14.toInt()), floatArrayOf(0f, 0.3f, 0.65f, 1f))
    private val g_crShade = lg(26f, 0f, 74f, 0f, intArrayOf(0x40FFFFFF.toInt(), 0x00FFFFFF.toInt(), 0x10000000.toInt(), 0x66000000.toInt()), floatArrayOf(0f, 0.3f, 0.5f, 1f))
    private val g_crBand = lg(0f, 29f, 0f, 41f, intArrayOf(0xFFE8B03C.toInt(), 0xFFC8861C.toInt(), 0xFF8F5A0C.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_crRuby = rg(48.8f, 34.3f, 5.5f, intArrayOf(0xFFFFB3BE.toInt(), 0xFFE8303F.toInt(), 0xFF800C1A.toInt()), floatArrayOf(0f, 0.45f, 1f))
    private val g_crSap = rg(37.8f, 35.4f, 3.8f, intArrayOf(0xFFB8D4FF.toInt(), 0xFF3E73E0.toInt(), 0xFF16337C.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_crSap2 = rg(60.8f, 35.4f, 3.8f, intArrayOf(0xFFB8D4FF.toInt(), 0xFF3E73E0.toInt(), 0xFF16337C.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_crPearl0 = rg(24.6f, 12.2f, 4.2f, intArrayOf(0xFFFFFFFF.toInt(), 0xFFF1E8E0.toInt(), 0xFFB9A99A.toInt()), floatArrayOf(0f, 0.6f, 1f))
    private val g_crPearl1 = rg(37.6f, 7.2f, 4.2f, intArrayOf(0xFFFFFFFF.toInt(), 0xFFF1E8E0.toInt(), 0xFFB9A99A.toInt()), floatArrayOf(0f, 0.6f, 1f))
    private val g_crPearl2 = rg(49.1f, 3.2f, 4.2f, intArrayOf(0xFFFFFFFF.toInt(), 0xFFF1E8E0.toInt(), 0xFFB9A99A.toInt()), floatArrayOf(0f, 0.6f, 1f))
    private val g_crPearl3 = rg(60.6f, 7.2f, 4.2f, intArrayOf(0xFFFFFFFF.toInt(), 0xFFF1E8E0.toInt(), 0xFFB9A99A.toInt()), floatArrayOf(0f, 0.6f, 1f))
    private val g_crPearl4 = rg(73.6f, 12.2f, 4.2f, intArrayOf(0xFFFFFFFF.toInt(), 0xFFF1E8E0.toInt(), 0xFFB9A99A.toInt()), floatArrayOf(0f, 0.6f, 1f))
    private val g_shadowW = lg(0f, 36f, 0f, 50f, intArrayOf(0x66000000.toInt(), 0x00000000.toInt()), floatArrayOf(0f, 1f))
    private val g_wtUnder = lg(0f, 20f, 0f, 38f, intArrayOf(0xFF2A1658.toInt(), 0xFF160B34.toInt()), floatArrayOf(0f, 1f))
    private val g_wtBrim = rg(34f, 19f, 60f, intArrayOf(0xFF7852C8.toInt(), 0xFF4B2D86.toInt(), 0xFF2A1758.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_wtBrimShade = lg(5f, 0f, 95f, 0f, intArrayOf(0x22FFFFFF.toInt(), 0x00FFFFFF.toInt(), 0x00000000.toInt(), 0x55000000.toInt()), floatArrayOf(0f, 0.4f, 0.6f, 1f))
    private val g_wtCone = lg(29f, 0f, 71f, 0f, intArrayOf(0xFF8560D6.toInt(), 0xFF5B3AA0.toInt(), 0xFF2B1862.toInt()), floatArrayOf(0f, 0.45f, 1f))
    private val g_wtConeShade = lg(29f, 0f, 71f, 0f, intArrayOf(0x30FFFFFF.toInt(), 0x00FFFFFF.toInt(), 0x00000000.toInt(), 0x55000000.toInt()), floatArrayOf(0f, 0.3f, 0.55f, 1f))
    private val g_wtBand = lg(0f, 20f, 0f, 31f, intArrayOf(0xFFFFB863.toInt(), 0xFFE8913A.toInt(), 0xFFB05A14.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_wtBandShade = lg(29f, 0f, 71f, 0f, intArrayOf(0x22FFFFFF.toInt(), 0x00000000.toInt(), 0x44000000.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_wtBuckle = lg(44f, 22f, 56f, 31f, intArrayOf(0xFFFFF0B0.toInt(), 0xFFE8B53E.toInt(), 0xFF9A6A14.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_wtBuckleIn = lg(0f, 24f, 0f, 29f, intArrayOf(0xFF9A5A14.toInt(), 0xFFD07F2C.toInt()), floatArrayOf(0f, 1f))
    private val g_shLensL = lg(24f, 37f, 48f, 57f, intArrayOf(0xF03E3A60.toInt(), 0xF0171426.toInt(), 0xF00A0910.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_shGlintL = lg(31f, 40f, 28f, 52f, intArrayOf(0x66FFFFFF.toInt(), 0x00FFFFFF.toInt()), floatArrayOf(0f, 1f))
    private val g_shLensR = lg(76f, 37f, 52f, 57f, intArrayOf(0xF03E3A60.toInt(), 0xF0171426.toInt(), 0xF00A0910.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_shGlintR = lg(69f, 40f, 72f, 52f, intArrayOf(0x66FFFFFF.toInt(), 0x00FFFFFF.toInt()), floatArrayOf(0f, 1f))
    private val g_glGoldD = lg(13f, 0f, 26f, 0f, intArrayOf(0xFF9A6A18.toInt(), 0xFFD9A53A.toInt()), floatArrayOf(0f, 1f))
    private val g_glGoldD2 = lg(87f, 0f, 74f, 0f, intArrayOf(0xFF9A6A18.toInt(), 0xFFD9A53A.toInt()), floatArrayOf(0f, 1f))
    private val g_glLensL = rg(32.5f, 41f, 16f, intArrayOf(0x3CE6F1FF.toInt(), 0x12A8C8F0.toInt()), floatArrayOf(0f, 1f))
    private val g_glGoldL = lg(26.5f, 36f, 46.5f, 57f, intArrayOf(0xFFFFEFB0.toInt(), 0xFFE2AD3C.toInt(), 0xFF98681A.toInt()), floatArrayOf(0f, 0.45f, 1f))
    private val g_glLensR = rg(59.5f, 41f, 16f, intArrayOf(0x3CE6F1FF.toInt(), 0x12A8C8F0.toInt()), floatArrayOf(0f, 1f))
    private val g_glGoldR = lg(53.5f, 36f, 73.5f, 57f, intArrayOf(0xFFFFEFB0.toInt(), 0xFFE2AD3C.toInt(), 0xFF98681A.toInt()), floatArrayOf(0f, 0.45f, 1f))
    private val g_glBridge = lg(47f, 42f, 53f, 45f, intArrayOf(0xFFE2AD3C.toInt(), 0xFFB07A20.toInt()), floatArrayOf(0f, 1f))
    private val g_pk0 = lg(16.3f, 13.82f, 42.7f, 30.46f, intArrayOf(0xFFEE8A2C.toInt(), 0xFFC4660E.toInt(), 0xFF8F4206.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_pk1 = lg(57.3f, 13.82f, 83.7f, 30.46f, intArrayOf(0xFFEE8A2C.toInt(), 0xFFC4660E.toInt(), 0xFF8F4206.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_pk2 = lg(26.6f, 12.22f, 51.4f, 30.16f, intArrayOf(0xFFFFA547.toInt(), 0xFFEE7F1E.toInt(), 0xFFB4560A.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_pk3 = lg(48.6f, 12.22f, 73.4f, 30.16f, intArrayOf(0xFFFFA547.toInt(), 0xFFEE7F1E.toInt(), 0xFFB4560A.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_pk4 = lg(38.4f, 11.48f, 61.6f, 29.94f, intArrayOf(0xFFFFC36A.toInt(), 0xFFF7922C.toInt(), 0xFFC9690F.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_pkShade = lg(38f, 0f, 62f, 0f, intArrayOf(0x00000000.toInt(), 0x22000000.toInt()), floatArrayOf(0f, 1f))
    private val g_pkStem = lg(46f, 0f, 55f, 0f, intArrayOf(0xFF8DBE52.toInt(), 0xFF55832A.toInt(), 0xFF33561A.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_pkLeaf = lg(35f, 3f, 47f, 10f, intArrayOf(0xFF8DBE52.toInt(), 0xFF3F6A20.toInt()), floatArrayOf(0f, 1f))
    private val g_pkVine = lg(54f, 0f, 64f, 0f, intArrayOf(0xFF4F7C26.toInt(), 0xFF8DBE52.toInt()), floatArrayOf(0f, 1f))
    private val g_bwTailL = lg(46f, 30f, 78f, 46f, intArrayOf(0xFFFF8FB8.toInt(), 0xFFE04880.toInt(), 0xFF9A2656.toInt()), floatArrayOf(0f, 0.55f, 1f))
    private val g_bwTailR = lg(46f, 30f, 78f, 46f, intArrayOf(0xFFFF8FB8.toInt(), 0xFFE04880.toInt(), 0xFF9A2656.toInt()), floatArrayOf(0f, 0.55f, 1f))
    private val g_bwL = rg(54.5f, 12f, 28f, intArrayOf(0xFFFFA6CB.toInt(), 0xFFE9528A.toInt(), 0xFFA52A5A.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_bwR = rg(78.5f, 12f, 28f, intArrayOf(0xFFFFA6CB.toInt(), 0xFFE9528A.toInt(), 0xFFA52A5A.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_bwKnot = rg(66f, 18f, 7f, intArrayOf(0xFFFF9EC4.toInt(), 0xFFE04880.toInt(), 0xFF9A2656.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_scShadow = lg(0f, 86f, 0f, 102f, intArrayOf(0x44000000.toInt(), 0x00000000.toInt()), floatArrayOf(0f, 1f))
    private val g_scTail = lg(60f, 0f, 80f, 0f, intArrayOf(0xFFF0545C.toInt(), 0xFFD8323A.toInt(), 0xFF9A1B24.toInt()), floatArrayOf(0f, 0.5f, 1f))
    private val g_scTailV = lg(0f, 84f, 0f, 101f, intArrayOf(0x66000000.toInt(), 0x00000000.toInt()), floatArrayOf(0f, 0.25f))
    private val g_scBand = lg(0f, 71f, 0f, 96f, intArrayOf(0xFF8C1A22.toInt(), 0xFFE24650.toInt(), 0xFFD8323A.toInt(), 0xFF9A1B24.toInt()), floatArrayOf(0f, 0.38f, 0.62f, 1f))
    private val g_scBandShade = lg(15f, 0f, 85f, 0f, intArrayOf(0x2CFFFFFF.toInt(), 0x00FFFFFF.toInt(), 0x00000000.toInt(), 0x58000000.toInt()), floatArrayOf(0f, 0.35f, 0.6f, 1f))
    private val g_scKnot = rg(64f, 82f, 12f, intArrayOf(0xFFF4666C.toInt(), 0xFFD22F38.toInt(), 0xFF8F1720.toInt()), floatArrayOf(0f, 0.55f, 1f))

    // ------------------------------------------------------------ bentuk
    private val beas0 = svgPath("M 21 33 C 33 39 67 39 79 33 L 78 37 C 66 47 34 47 22 37 Z")
    private val bea0 = svgPath("M 22.5 35 C 17 14 31 1.5 50 1.5 C 69 1.5 83 14 77.5 35 Z")
    private val bea1 = svgPath("M 22.5 35 C 17 14 31 1.5 50 1.5 C 69 1.5 83 14 77.5 35 Z")
    private val bea2 = svgPath("M 50 3.5 C 38.26 9 28.48 20 27.5 30 M 50 3.5 C 42.43 9 36.13 20 35.5 30 M 50 3.5 C 46.35 9 43.3 20 43 30 M 50 3.5 C 50 9 50 20 50 30 M 50 3.5 C 53.65 9 56.7 20 57 30 M 50 3.5 C 57.83 9 64.35 20 65 30 M 50 3.5 C 61.74 9 71.52 20 72.5 30")
    private val bea3 = svgPath("M 19 26 C 31 31 69 31 81 26 L 80.5 33.5 C 69 38.5 31 38.5 19.5 33.5 Z")
    private val bea4 = svgPath("M 19 26 C 31 31 69 31 81 26 L 80.5 33.5 C 69 38.5 31 38.5 19.5 33.5 Z")
    private val bea5 = svgPath("M 23.5 28.69 L 23.5 33.5 M 28.8 29.69 L 28.8 34.55 M 34.1 30.33 L 34.1 35.21 M 39.4 30.74 L 39.4 35.63 M 44.7 30.97 L 44.7 35.87 M 50 31.05 L 50 35.95 M 55.3 30.97 L 55.3 35.87 M 60.6 30.74 L 60.6 35.63 M 65.9 30.33 L 65.9 35.21 M 71.2 29.69 L 71.2 34.55 M 76.5 28.69 L 76.5 33.5")
    private val bea6 = svgPath("M 20.5 27.4 C 32 32.2 68 32.2 79.5 27.4")
    private val bea7 = svgPath("M 19.5 33.5 C 31 38.5 69 38.5 80.5 33.5")
    private val bea8 = svgPath("M 56.6 0.5 C 56.6 3.92 53.65 6.7 50 6.7 C 46.35 6.7 43.4 3.92 43.4 0.5 C 43.4 -2.92 46.35 -5.7 50 -5.7 C 53.65 -5.7 56.6 -2.92 56.6 0.5 Z")
    private val bea9 = svgPath("M 50 -2.4 C 50 -1.52 48.93 -0.8 47.6 -0.8 C 46.27 -0.8 45.2 -1.52 45.2 -2.4 C 45.2 -3.28 46.27 -4 47.6 -4 C 48.93 -4 50 -3.28 50 -2.4 Z")
    private val sans0 = svgPath("M 21 34 C 33 40 67 40 79 34 L 78 38 C 66 48 34 48 22 38 Z")
    private val san0 = svgPath("M 21 34 C 17 16 30 3.5 46 3 C 63 2.5 78 9 86.5 22 C 91.5 29.5 93 38 90.5 46 C 84 40 78.5 35.5 76 34 Z")
    private val san1 = svgPath("M 86.5 22 C 91.5 29.5 93 38 90.5 46 C 91.5 36 88 27 81 19.5 Z")
    private val san2 = svgPath("M 30 15 C 34 9.5 40 6 47 5")
    private val san3 = svgPath("M 62 8.5 C 74 12 83 24 86 38")
    private val san4 = svgPath("M 19.5 25.5 C 31 30.5 69 30.5 80.5 25.5 L 81 34.5 C 80.41 37.7 76.7 39.27 76.11 36.07 C 75.34 39.27 70.49 40.45 69.72 37.25 C 68.82 40.45 63.15 41.23 62.26 38.03 C 61.29 41.23 55.13 41.63 54.16 38.43 C 53.16 41.63 46.84 41.63 45.84 38.43 C 44.87 41.63 38.71 41.23 37.74 38.03 C 36.85 41.23 31.18 40.45 30.28 37.25 C 29.51 40.45 24.66 39.27 23.89 36.07 C 23.3 39.27 19.59 37.7 19 34.5 Z")
    private val san5 = svgPath("M 19.5 25.5 C 31 30.5 69 30.5 80.5 25.5 L 81 34.5 C 80.41 37.7 76.7 39.27 76.11 36.07 C 75.34 39.27 70.49 40.45 69.72 37.25 C 68.82 40.45 63.15 41.23 62.26 38.03 C 61.29 41.23 55.13 41.63 54.16 38.43 C 53.16 41.63 46.84 41.63 45.84 38.43 C 44.87 41.63 38.71 41.23 37.74 38.03 C 36.85 41.23 31.18 40.45 30.28 37.25 C 29.51 40.45 24.66 39.27 23.89 36.07 C 23.3 39.27 19.59 37.7 19 34.5 Z")
    private val san6 = svgPath("M 21 27 C 32 31.8 68 31.8 79 27")
    private val san7 = svgPath("M 97.6 47.5 C 97.6 51.59 94.2 54.9 90 54.9 C 85.8 54.9 82.4 51.59 82.4 47.5 C 82.4 43.41 85.8 40.1 90 40.1 C 94.2 40.1 97.6 43.41 97.6 47.5 Z")
    private val san8 = svgPath("M 89.6 44.6 C 89.6 45.48 88.53 46.2 87.2 46.2 C 85.87 46.2 84.8 45.48 84.8 44.6 C 84.8 43.72 85.87 43 87.2 43 C 88.53 43 89.6 43.72 89.6 44.6 Z")
    private val pars0 = svgPath("M 31 31 C 40 37.5 65 37.5 74 31 L 73 35 C 63 45 41 45 32 35 Z")
    private val par0 = svgPath("M 32 30 L 53 -3 L 74 30 C 65 36.5 41 36.5 32 30 Z")
    private val par1 = svgPath("M 49.18 3 C 56.18 6.29 49.82 6.29 56.82 3 L 59.68 7.5 C 52.68 11.65 53.32 11.65 46.32 7.5 Z")
    private val par2 = svgPath("M 42.82 13 C 49.82 18.19 56.18 18.19 63.18 13 L 66.36 18 C 59.36 24.13 46.64 24.13 39.64 18 Z")
    private val par3 = svgPath("M 36.14 23.5 C 43.14 30.67 62.86 30.67 69.86 23.5 L 73.05 28.5 C 66.05 36.62 39.95 36.62 32.95 28.5 Z")
    private val par4 = svgPath("M 32 30 L 53 -3 L 74 30 C 65 36.5 41 36.5 32 30 Z")
    private val par5 = svgPath("M 32 30 C 41 36.5 65 36.5 74 30")
    private val par6 = svgPath("M 40 21 L 51.5 1")
    private val par7 = svgPath("M 58 -3.5 C 58 -0.74 55.76 1.5 53 1.5 C 50.24 1.5 48 -0.74 48 -3.5 C 48 -6.26 50.24 -8.5 53 -8.5 C 55.76 -8.5 58 -6.26 58 -3.5 Z")
    private val par8 = svgPath("M 53 -5.2 C 53 -4.59 52.33 -4.1 51.5 -4.1 C 50.67 -4.1 50 -4.59 50 -5.2 C 50 -5.81 50.67 -6.3 51.5 -6.3 C 52.33 -6.3 53 -5.81 53 -5.2 Z")
    private val cros0 = svgPath("M 28 37 C 40 43 60 43 72 37 L 71 40 C 60 50 40 50 29 40 Z")
    private val cro0 = svgPath("M 27.5 22 C 27 15 35 8.5 50 7 C 65 8.5 73 15 72.5 22 L 72.5 30 L 27.5 30 Z")
    private val cro1 = svgPath("M 28 37 L 25.5 14 L 32.5 24.5 L 38.5 9 L 44.5 22.5 L 50 5 L 55.5 22.5 L 61.5 9 L 67.5 24.5 L 74.5 14 L 72 37 C 62 41.5 38 41.5 28 37 Z")
    private val cro2 = svgPath("M 28 37 L 25.5 14 L 32.5 24.5 L 38.5 9 L 44.5 22.5 L 50 5 L 55.5 22.5 L 61.5 9 L 67.5 24.5 L 74.5 14 L 72 37 C 62 41.5 38 41.5 28 37 Z")
    private val cro3 = svgPath("M 28 37 L 25.5 14 L 32.5 24.5 L 38.5 9 L 44.5 22.5 L 50 5 L 55.5 22.5 L 61.5 9 L 67.5 24.5 L 74.5 14 L 72 37 C 62 41.5 38 41.5 28 37 Z")
    private val cro4 = svgPath("M 27.2 29.5 C 38 34.3 62 34.3 72.8 29.5 L 72 37 C 62 41.5 38 41.5 28 37 Z")
    private val cro5 = svgPath("M 27.2 29.5 C 38 34.3 62 34.3 72.8 29.5")
    private val cro6 = svgPath("M 28.2 33.6 C 39 38.6 61 38.6 71.8 33.6")
    private val cro7 = svgPath("M 53.6 35.8 C 53.6 37.62 51.99 39.1 50 39.1 C 48.01 39.1 46.4 37.62 46.4 35.8 C 46.4 33.98 48.01 32.5 50 32.5 C 51.99 32.5 53.6 33.98 53.6 35.8 Z")
    private val cro8 = svgPath("M 50.3 34.6 C 50.3 35.04 49.81 35.4 49.2 35.4 C 48.59 35.4 48.1 35.04 48.1 34.6 C 48.1 34.16 48.59 33.8 49.2 33.8 C 49.81 33.8 50.3 34.16 50.3 34.6 Z")
    private val cro9 = svgPath("M 40.8 36.3 C 40.8 37.46 39.77 38.4 38.5 38.4 C 37.23 38.4 36.2 37.46 36.2 36.3 C 36.2 35.14 37.23 34.2 38.5 34.2 C 39.77 34.2 40.8 35.14 40.8 36.3 Z")
    private val cro10 = svgPath("M 63.8 36.3 C 63.8 37.46 62.77 38.4 61.5 38.4 C 60.23 38.4 59.2 37.46 59.2 36.3 C 59.2 35.14 60.23 34.2 61.5 34.2 C 62.77 34.2 63.8 35.14 63.8 36.3 Z")
    private val cro11 = svgPath("M 28.1 13.2 C 28.1 14.64 26.94 15.8 25.5 15.8 C 24.06 15.8 22.9 14.64 22.9 13.2 C 22.9 11.76 24.06 10.6 25.5 10.6 C 26.94 10.6 28.1 11.76 28.1 13.2 Z")
    private val cro12 = svgPath("M 41.1 8.2 C 41.1 9.64 39.94 10.8 38.5 10.8 C 37.06 10.8 35.9 9.64 35.9 8.2 C 35.9 6.76 37.06 5.6 38.5 5.6 C 39.94 5.6 41.1 6.76 41.1 8.2 Z")
    private val cro13 = svgPath("M 52.6 4.2 C 52.6 5.64 51.44 6.8 50 6.8 C 48.56 6.8 47.4 5.64 47.4 4.2 C 47.4 2.76 48.56 1.6 50 1.6 C 51.44 1.6 52.6 2.76 52.6 4.2 Z")
    private val cro14 = svgPath("M 64.1 8.2 C 64.1 9.64 62.94 10.8 61.5 10.8 C 60.06 10.8 58.9 9.64 58.9 8.2 C 58.9 6.76 60.06 5.6 61.5 5.6 C 62.94 5.6 64.1 6.76 64.1 8.2 Z")
    private val cro15 = svgPath("M 77.1 13.2 C 77.1 14.64 75.94 15.8 74.5 15.8 C 73.06 15.8 71.9 14.64 71.9 13.2 C 71.9 11.76 73.06 10.6 74.5 10.6 C 75.94 10.6 77.1 11.76 77.1 13.2 Z")
    private val wits0 = svgPath("M 13 33 C 28 46 72 46 87 33 L 87 37 C 72 54 28 54 13 37 Z")
    private val wit0 = svgPath("M 95 28.6 C 95 33.68 74.85 37.8 50 37.8 C 25.15 37.8 5 33.68 5 28.6 C 5 23.52 25.15 19.4 50 19.4 C 74.85 19.4 95 23.52 95 28.6 Z")
    private val wit1 = svgPath("M 95 26 C 95 30.97 74.85 35 50 35 C 25.15 35 5 30.97 5 26 C 5 21.03 25.15 17 50 17 C 74.85 17 95 21.03 95 26 Z")
    private val wit2 = svgPath("M 95 26 C 95 30.97 74.85 35 50 35 C 25.15 35 5 30.97 5 26 C 5 21.03 25.15 17 50 17 C 74.85 17 95 21.03 95 26 Z")
    private val wit3 = svgPath("M 9 29 C 22 36 40 36.5 50 36.5")
    private val wit4 = svgPath("M 29 26 C 31 15 38 4 47 -3 C 52 -7 59 -9 66.5 -6 C 61 -4.5 59 -0.5 59.5 4.5 C 62 11 68 19 71 26 C 62 31.5 38 31.5 29 26 Z")
    private val wit5 = svgPath("M 29 26 C 31 15 38 4 47 -3 C 52 -7 59 -9 66.5 -6 C 61 -4.5 59 -0.5 59.5 4.5 C 62 11 68 19 71 26 C 62 31.5 38 31.5 29 26 Z")
    private val wit6 = svgPath("M 36 21 C 38 13 43 6 49 -1")
    private val wit7 = svgPath("M 29.6 20.5 C 40 25.5 60 25.5 70.4 20.5 L 71.2 26 C 61 30.8 39 30.8 28.8 26 Z")
    private val wit8 = svgPath("M 29.6 20.5 C 40 25.5 60 25.5 70.4 20.5 L 71.2 26 C 61 30.8 39 30.8 28.8 26 Z")
    private val wit9 = svgPath("M 71.2 26 C 61 30.8 39 30.8 28.8 26")
    private val wit10 = svgPath("M 44.5 22.2 L 55.5 22.2 L 55.5 31 L 44.5 31 Z")
    private val wit11 = svgPath("M 47.2 24.6 L 52.8 24.6 L 52.8 28.7 L 47.2 28.7 Z")
    private val shas0 = svgPath("M 25 42.6 C 25 40.2 26.6 39.6 29 39.6 L 46.5 39.6 C 48.6 39.6 49.2 41 49 43.6 C 48.4 52.6 45.2 59.6 39 59.6 L 34.5 59.6 C 28.5 59.6 25.4 53.1 25 44.6 Z")
    private val shas1 = svgPath("M 77 42.6 C 77 40.2 75.4 39.6 73 39.6 L 55.5 39.6 C 53.4 39.6 52.8 41 53 43.6 C 53.6 52.6 56.8 59.6 63 59.6 L 67.5 59.6 C 73.5 59.6 76.6 53.1 77 44.6 Z")
    private val sha0 = svgPath("M 24.5 40.5 C 20 40 16 40.6 12 42.5")
    private val sha1 = svgPath("M 75.5 40.5 C 80 40 84 40.6 88 42.5")
    private val sha2 = svgPath("M 24 40 C 24 37.6 25.6 37 28 37 L 45.5 37 C 47.6 37 48.2 38.4 48 41 C 47.4 50 44.2 57 38 57 L 33.5 57 C 27.5 57 24.4 50.5 24 42 Z")
    private val sha3 = svgPath("M 29 40 L 34.5 40 L 29.2 52 L 26.4 49.5 Z")
    private val sha4 = svgPath("M 37 40 L 39.6 40 L 34.6 52 L 33.2 52 Z")
    private val sha5 = svgPath("M 24 40 C 24 37.6 25.6 37 28 37 L 45.5 37 C 47.6 37 48.2 38.4 48 41 C 47.4 50 44.2 57 38 57 L 33.5 57 C 27.5 57 24.4 50.5 24 42 Z")
    private val sha6 = svgPath("M 24.6 38.4 C 25.4 37.6 26.6 37.5 28 37.5 L 45 37.5")
    private val sha7 = svgPath("M 76 40 C 76 37.6 74.4 37 72 37 L 54.5 37 C 52.4 37 51.8 38.4 52 41 C 52.6 50 55.8 57 62 57 L 66.5 57 C 72.5 57 75.6 50.5 76 42 Z")
    private val sha8 = svgPath("M 71 40 L 65.5 40 L 70.8 52 L 73.6 49.5 Z")
    private val sha9 = svgPath("M 63 40 L 60.4 40 L 65.4 52 L 66.8 52 Z")
    private val sha10 = svgPath("M 76 40 C 76 37.6 74.4 37 72 37 L 54.5 37 C 52.4 37 51.8 38.4 52 41 C 52.6 50 55.8 57 62 57 L 66.5 57 C 72.5 57 75.6 50.5 76 42 Z")
    private val sha11 = svgPath("M 75.4 38.4 C 74.6 37.6 73.4 37.5 72 37.5 L 55 37.5")
    private val sha12 = svgPath("M 47.6 39.6 C 49.2 38 50.8 38 52.4 39.6")
    private val glas0 = svgPath("M 48.1 48.2 C 48.1 53.83 43.26 58.4 37.3 58.4 C 31.34 58.4 26.5 53.83 26.5 48.2 C 26.5 42.57 31.34 38 37.3 38 C 43.26 38 48.1 42.57 48.1 48.2 Z")
    private val glas1 = svgPath("M 75.1 48.2 C 75.1 53.83 70.26 58.4 64.3 58.4 C 58.34 58.4 53.5 53.83 53.5 48.2 C 53.5 42.57 58.34 38 64.3 38 C 70.26 38 75.1 42.57 75.1 48.2 Z")
    private val gla0 = svgPath("M 25.8 45 C 21 44.4 17 44.6 13 46.5")
    private val gla1 = svgPath("M 74.2 45 C 79 44.4 83 44.6 87 46.5")
    private val gla2 = svgPath("M 47.3 46.5 C 47.3 52.13 42.46 56.7 36.5 56.7 C 30.54 56.7 25.7 52.13 25.7 46.5 C 25.7 40.87 30.54 36.3 36.5 36.3 C 42.46 36.3 47.3 40.87 47.3 46.5 Z")
    private val gla3 = svgPath("M 47.3 46.5 C 47.3 52.13 42.46 56.7 36.5 56.7 C 30.54 56.7 25.7 52.13 25.7 46.5 C 25.7 40.87 30.54 36.3 36.5 36.3 C 42.46 36.3 47.3 40.87 47.3 46.5 Z")
    private val gla4 = svgPath("M 29.5 42.2 C 31 38.9 34 37.6 37 37.8")
    private val gla5 = svgPath("M 41 52.4 L 42.9 50.8")
    private val gla6 = svgPath("M 74.3 46.5 C 74.3 52.13 69.46 56.7 63.5 56.7 C 57.54 56.7 52.7 52.13 52.7 46.5 C 52.7 40.87 57.54 36.3 63.5 36.3 C 69.46 36.3 74.3 40.87 74.3 46.5 Z")
    private val gla7 = svgPath("M 74.3 46.5 C 74.3 52.13 69.46 56.7 63.5 56.7 C 57.54 56.7 52.7 52.13 52.7 46.5 C 52.7 40.87 57.54 36.3 63.5 36.3 C 69.46 36.3 74.3 40.87 74.3 46.5 Z")
    private val gla8 = svgPath("M 70.5 42.2 C 69 38.9 66 37.6 63 37.8")
    private val gla9 = svgPath("M 59 52.4 L 57.1 50.8")
    private val gla10 = svgPath("M 47.3 44.6 C 49 42.9 51 42.9 52.7 44.6")
    private val pums0 = svgPath("M 19 33 C 33 41 67 41 81 33 L 80 37 C 67 49 33 49 20 37 Z")
    private val pum0 = svgPath("M 42.7 21.5 C 42.7 28.57 36.79 34.3 29.5 34.3 C 22.21 34.3 16.3 28.57 16.3 21.5 C 16.3 14.43 22.21 8.7 29.5 8.7 C 36.79 8.7 42.7 14.43 42.7 21.5 Z")
    private val pum1 = svgPath("M 42.7 21.5 C 42.7 28.57 36.79 34.3 29.5 34.3 C 22.21 34.3 16.3 28.57 16.3 21.5 C 16.3 14.43 22.21 8.7 29.5 8.7 C 36.79 8.7 42.7 14.43 42.7 21.5 Z")
    private val pum2 = svgPath("M 83.7 21.5 C 83.7 28.57 77.79 34.3 70.5 34.3 C 63.21 34.3 57.3 28.57 57.3 21.5 C 57.3 14.43 63.21 8.7 70.5 8.7 C 77.79 8.7 83.7 14.43 83.7 21.5 Z")
    private val pum3 = svgPath("M 83.7 21.5 C 83.7 28.57 77.79 34.3 70.5 34.3 C 63.21 34.3 57.3 28.57 57.3 21.5 C 57.3 14.43 63.21 8.7 70.5 8.7 C 77.79 8.7 83.7 14.43 83.7 21.5 Z")
    private val pum4 = svgPath("M 51.4 20.5 C 51.4 28.12 45.85 34.3 39 34.3 C 32.15 34.3 26.6 28.12 26.6 20.5 C 26.6 12.88 32.15 6.7 39 6.7 C 45.85 6.7 51.4 12.88 51.4 20.5 Z")
    private val pum5 = svgPath("M 51.4 20.5 C 51.4 28.12 45.85 34.3 39 34.3 C 32.15 34.3 26.6 28.12 26.6 20.5 C 26.6 12.88 32.15 6.7 39 6.7 C 45.85 6.7 51.4 12.88 51.4 20.5 Z")
    private val pum6 = svgPath("M 73.4 20.5 C 73.4 28.12 67.85 34.3 61 34.3 C 54.15 34.3 48.6 28.12 48.6 20.5 C 48.6 12.88 54.15 6.7 61 6.7 C 67.85 6.7 73.4 12.88 73.4 20.5 Z")
    private val pum7 = svgPath("M 73.4 20.5 C 73.4 28.12 67.85 34.3 61 34.3 C 54.15 34.3 48.6 28.12 48.6 20.5 C 48.6 12.88 54.15 6.7 61 6.7 C 67.85 6.7 73.4 12.88 73.4 20.5 Z")
    private val pum8 = svgPath("M 61.6 20 C 61.6 27.84 56.41 34.2 50 34.2 C 43.59 34.2 38.4 27.84 38.4 20 C 38.4 12.16 43.59 5.8 50 5.8 C 56.41 5.8 61.6 12.16 61.6 20 Z")
    private val pum9 = svgPath("M 61.6 20 C 61.6 27.84 56.41 34.2 50 34.2 C 43.59 34.2 38.4 27.84 38.4 20 C 38.4 12.16 43.59 5.8 50 5.8 C 56.41 5.8 61.6 12.16 61.6 20 Z")
    private val pum10 = svgPath("M 48.2 11.5 C 48.2 12.83 46.32 13.9 44 13.9 C 41.68 13.9 39.8 12.83 39.8 11.5 C 39.8 10.17 41.68 9.1 44 9.1 C 46.32 9.1 48.2 10.17 48.2 11.5 Z")
    private val pum11 = svgPath("M 61.6 22 C 61.6 29.84 56.41 36.2 50 36.2 C 43.59 36.2 38.4 29.84 38.4 22 C 38.4 14.16 43.59 7.8 50 7.8 C 56.41 7.8 61.6 14.16 61.6 22 Z")
    private val pum12 = svgPath("M 46.5 8.5 C 45.5 3.5 47 -1 50.5 -3.5 C 52.8 -4.8 55 -3.6 54.6 -1.4 C 54 0.6 53.6 3.2 54.2 8.4 C 52 10 48.6 10 46.5 8.5 Z")
    private val pum13 = svgPath("M 47 7 C 41 2.5 35.5 4 34.5 7.5 C 39.5 10 45 9.8 47 7 Z")
    private val pum14 = svgPath("M 46.5 7.4 C 43 6.4 39.5 6.4 36.5 7.4")
    private val pum15 = svgPath("M 54 2.5 C 60 0.5 64.5 3.5 62.5 6.8 C 61 8.8 58.8 7.4 59.8 5.6")
    private val bows0 = svgPath("M 67.9 22.6 C 67.29 12.66 58.8 7.45 53.95 12.42 C 49.71 17.03 51.17 27.7 59.41 27.7 C 63.05 27.58 65.96 25.41 67.9 22.6 Z")
    private val bows1 = svgPath("M 67.9 22.6 C 73.11 14.11 83.05 13.5 85 20.16 C 86.58 26.23 80.28 34.96 73 31.09 C 69.84 29.27 68.29 26 67.9 22.6 Z")
    private val bow0 = svgPath("M 64.32 22.55 C 59.96 27.64 55.11 32.62 49.53 36.38 L 54.58 36.4 L 55.89 41.06 C 59.91 34.85 63.3 29.51 66.07 24.22 Z")
    private val bow1 = svgPath("M 67.23 23.27 C 68.2 29.7 69.42 35.16 72.21 40.49 L 68.21 38.77 L 65.57 41.93 C 65.2 35.14 65.17 29.46 65.48 24.08 Z")
    private val bow2 = svgPath("M 66.5 20 C 65.89 10.06 57.4 4.85 52.55 9.82 C 48.31 14.43 49.77 25.1 58.01 25.1 C 61.65 24.98 64.56 22.81 66.5 20 Z")
    private val bow3 = svgPath("M 64.9 19.81 C 64.22 14.28 59.1 10.42 55.87 13.02 C 53.76 15.28 54.52 21.75 58.69 22.38 C 61.7 22.72 63.69 21.36 64.9 19.81 Z")
    private val bow4 = svgPath("M 65.09 17.38 C 64.43 11.76 58.73 7.76 55.29 10.4")
    private val bow5 = svgPath("M 66.5 20 C 71.71 11.51 81.65 10.9 83.6 17.56 C 85.18 23.63 78.88 32.36 71.6 28.49 C 68.44 26.67 66.89 23.4 66.5 20 Z")
    private val bow6 = svgPath("M 68 20.58 C 71.2 16.02 77.53 15.02 79.16 18.83 C 79.96 21.81 76.25 27.17 72.28 25.77 C 69.46 24.65 68.34 22.52 68 20.58 Z")
    private val bow7 = svgPath("M 68.97 18.35 C 72.2 13.69 79.11 12.84 80.9 16.79")
    private val bow8 = svgPath("M 70.19 21.33 C 69.57 23.8 67.38 25.37 65.29 24.85 C 63.2 24.33 62 21.91 62.62 19.44 C 63.23 16.98 65.43 15.4 67.52 15.92 C 69.6 16.44 70.8 18.87 70.19 21.33 Z")
    private val bow9 = svgPath("M 66.86 18.54 C 66.76 18.97 66.15 19.19 65.5 19.03 C 64.86 18.87 64.43 18.39 64.53 17.96 C 64.64 17.54 65.25 17.32 65.89 17.48 C 66.53 17.64 66.97 18.12 66.86 18.54 Z")
    private val scas0 = svgPath("M 17 84 C 29 99 71 99 83 84 L 84 87 C 71 103 29 103 16 87 Z")
    private val sca0 = svgPath("M 60 85 L 76 84 C 77.5 90 78.5 95 79.4 100 L 62.6 101.2 C 61.6 95.5 60.6 90 60 85 Z")
    private val sca1 = svgPath("M 60 85 L 76 84 C 77.5 90 78.5 95 79.4 100 L 62.6 101.2 C 61.6 95.5 60.6 90 60 85 Z")
    private val sca2 = svgPath("M 61.2 93.5 C 66 94.9 72 94.1 78.6 92.7")
    private val sca3 = svgPath("M 63.4 100.6 L 63.2 102.2 M 66.6 100.5 L 66.5 102.3 M 69.8 100.4 L 69.9 102.2 M 73 100.3 L 73.4 102.1 M 76.2 100.2 L 76.8 102")
    private val sca4 = svgPath("M 19 71 C 31 83.5 69 83.5 81 71 L 84.5 81 C 72 95.5 28 95.5 15.5 81 Z")
    private val sca5 = svgPath("M 19 71 C 31 83.5 69 83.5 81 71 L 84.5 81 C 72 95.5 28 95.5 15.5 81 Z")
    private val sca6 = svgPath("M 17.6 77 C 30 88.4 70 88.4 82.4 77")
    private val sca7 = svgPath("M 22 81.52 L 23.5 83.92 M 26.7 84.1 L 28.2 86.5 M 31.4 85.84 L 32.9 88.24 M 36.1 87.02 L 37.6 89.42 M 40.8 87.8 L 42.3 90.2 M 45.5 88.24 L 47 90.64 M 50.2 88.37 L 51.7 90.77 M 54.9 88.21 L 56.4 90.61 M 59.6 87.75 L 61.1 90.15 M 64.3 86.93 L 65.8 89.33 M 69 85.71 L 70.5 88.11 M 73.7 83.92 L 75.2 86.32 M 78.4 81.25 L 79.9 83.65")
    private val sca8 = svgPath("M 75.5 85 C 75.5 88.09 71.92 90.6 67.5 90.6 C 63.08 90.6 59.5 88.09 59.5 85 C 59.5 81.91 63.08 79.4 67.5 79.4 C 71.92 79.4 75.5 81.91 75.5 85 Z")
    private val sca9 = svgPath("M 61.4 82.4 C 64 80.6 68.4 80.4 71.6 81.6")

    // ------------------------------------------------------------ gambar

    private fun drawBeanie(cv: Canvas) {
        fillS(cv, beas0, g_shadowV)
        fillS(cv, bea0, g_bnDome)
        fillS(cv, bea1, g_bnShade)
        strokeC(cv, bea2, 0.9f, 0x44152A70.toInt())
        fillS(cv, bea3, g_bnCuff)
        fillS(cv, bea4, g_bnCuffShade)
        strokeC(cv, bea5, 0.9f, 0x40152A70.toInt())
        strokeC(cv, bea6, 1.1f, 0x66FFFFFF.toInt())
        strokeC(cv, bea7, 1.3f, 0x4D101C4A.toInt())
        fillS(cv, bea8, g_bnPom)
        fillC(cv, bea9, 0x99FFFFFF.toInt())
    }

    private fun drawSanta(cv: Canvas) {
        fillS(cv, sans0, g_shadowV)
        fillS(cv, san0, g_snBody)
        fillC(cv, san1, 0x38000000.toInt())
        strokeC(cv, san2, 1.7f, 0x40FFFFFF.toInt())
        strokeC(cv, san3, 1.5f, 0x2E5A0A10.toInt())
        fillS(cv, san4, g_snTrim)
        fillS(cv, san5, g_snTrimShade)
        strokeC(cv, san6, 1f, 0x30B0B8D2.toInt())
        fillS(cv, san7, g_snPom)
        fillC(cv, san8, 0x88FFFFFF.toInt())
    }

    private fun drawParty(cv: Canvas) {
        fillS(cv, pars0, g_shadowV2)
        cv.save()
        cv.rotate(7f, 52f, 32f)
            fillS(cv, par0, g_pcCone)
            fillS(cv, par1, g_pcStripe)
            fillS(cv, par2, g_pcStripe)
            fillS(cv, par3, g_pcStripe)
            fillS(cv, par4, g_pcShade)
            strokeC(cv, par5, 1.5f, 0x77701A4A.toInt())
            strokeC(cv, par6, 1.8f, 0x55FFFFFF.toInt())
            fillS(cv, par7, g_pcBall)
            fillC(cv, par8, 0x99FFFFFF.toInt())
        cv.restore()
    }

    private fun drawCrown(cv: Canvas) {
        fillS(cv, cros0, g_shadowV)
        fillS(cv, cro0, g_crWall)
        fillS(cv, cro1, g_crGold)
        fillS(cv, cro2, g_crShade)
        strokeC(cv, cro3, 0.9f, 0x55703F08.toInt())
        fillS(cv, cro4, g_crBand)
        strokeC(cv, cro5, 1.1f, 0x99FFF3C0.toInt())
        strokeC(cv, cro6, 0.7f, 0x55FFE9A0.toInt())
        fillS(cv, cro7, g_crRuby)
        fillC(cv, cro8, 0xCCFFFFFF.toInt())
        fillS(cv, cro9, g_crSap)
        fillS(cv, cro10, g_crSap2)
        fillS(cv, cro11, g_crPearl0)
        fillS(cv, cro12, g_crPearl1)
        fillS(cv, cro13, g_crPearl2)
        fillS(cv, cro14, g_crPearl3)
        fillS(cv, cro15, g_crPearl4)
    }

    private fun drawWitch(cv: Canvas) {
        fillS(cv, wits0, g_shadowW)
        fillS(cv, wit0, g_wtUnder)
        fillS(cv, wit1, g_wtBrim)
        fillS(cv, wit2, g_wtBrimShade)
        strokeC(cv, wit3, 1.1f, 0x30FFFFFF.toInt())
        fillS(cv, wit4, g_wtCone)
        fillS(cv, wit5, g_wtConeShade)
        strokeC(cv, wit6, 1.6f, 0x40FFFFFF.toInt())
        fillS(cv, wit7, g_wtBand)
        fillS(cv, wit8, g_wtBandShade)
        strokeC(cv, wit9, 1.1f, 0x44401800.toInt())
        fillS(cv, wit10, g_wtBuckle)
        fillS(cv, wit11, g_wtBuckleIn)
    }

    private fun drawShades(cv: Canvas) {
        fillC(cv, shas0, 0x33000000.toInt())
        fillC(cv, shas1, 0x33000000.toInt())
        strokeC(cv, sha0, 2.2f, 0xFF1A1824.toInt())
        strokeC(cv, sha1, 2.2f, 0xFF1A1824.toInt())
        fillS(cv, sha2, g_shLensL)
        fillS(cv, sha3, g_shGlintL)
        fillC(cv, sha4, 0x1AFFFFFF.toInt())
        strokeC(cv, sha5, 2.5f, 0xFF14121C.toInt())
        strokeC(cv, sha6, 0.9f, 0x665A5678.toInt())
        fillS(cv, sha7, g_shLensR)
        fillS(cv, sha8, g_shGlintR)
        fillC(cv, sha9, 0x1AFFFFFF.toInt())
        strokeC(cv, sha10, 2.5f, 0xFF14121C.toInt())
        strokeC(cv, sha11, 0.9f, 0x665A5678.toInt())
        strokeC(cv, sha12, 2.6f, 0xFF14121C.toInt())
    }

    private fun drawGlasses(cv: Canvas) {
        strokeC(cv, glas0, 2.2f, 0x2E000000.toInt())
        strokeC(cv, glas1, 2.2f, 0x2E000000.toInt())
        strokeS(cv, gla0, 1.5f, g_glGoldD)
        strokeS(cv, gla1, 1.5f, g_glGoldD2)
        fillS(cv, gla2, g_glLensL)
        strokeS(cv, gla3, 2.1f, g_glGoldL)
        strokeC(cv, gla4, 1.4f, 0x99FFFFFF.toInt())
        strokeC(cv, gla5, 1.1f, 0x55FFFFFF.toInt())
        fillS(cv, gla6, g_glLensR)
        strokeS(cv, gla7, 2.1f, g_glGoldR)
        strokeC(cv, gla8, 1.4f, 0x99FFFFFF.toInt())
        strokeC(cv, gla9, 1.1f, 0x55FFFFFF.toInt())
        strokeS(cv, gla10, 1.8f, g_glBridge)
    }

    private fun drawPumpkin(cv: Canvas) {
        fillS(cv, pums0, g_shadowV)
        fillS(cv, pum0, g_pk0)
        strokeC(cv, pum1, 1f, 0x59803A04.toInt())
        fillS(cv, pum2, g_pk1)
        strokeC(cv, pum3, 1f, 0x59803A04.toInt())
        fillS(cv, pum4, g_pk2)
        strokeC(cv, pum5, 1f, 0x59803A04.toInt())
        fillS(cv, pum6, g_pk3)
        strokeC(cv, pum7, 1f, 0x59803A04.toInt())
        fillS(cv, pum8, g_pk4)
        strokeC(cv, pum9, 1f, 0x59803A04.toInt())
        fillC(cv, pum10, 0x66FFFFFF.toInt())
        fillS(cv, pum11, g_pkShade)
        fillS(cv, pum12, g_pkStem)
        fillS(cv, pum13, g_pkLeaf)
        strokeC(cv, pum14, 0.7f, 0x552A4A12.toInt())
        strokeS(cv, pum15, 1.2f, g_pkVine)
    }

    private fun drawBow(cv: Canvas) {
        fillC(cv, bows0, 0x30000000.toInt())
        fillC(cv, bows1, 0x30000000.toInt())
        fillS(cv, bow0, g_bwTailL)
        fillS(cv, bow1, g_bwTailR)
        fillS(cv, bow2, g_bwL)
        fillC(cv, bow3, 0x59A02458.toInt())
        strokeC(cv, bow4, 1.2f, 0x66FFFFFF.toInt())
        fillS(cv, bow5, g_bwR)
        fillC(cv, bow6, 0x59A02458.toInt())
        strokeC(cv, bow7, 1.2f, 0x66FFFFFF.toInt())
        fillS(cv, bow8, g_bwKnot)
        fillC(cv, bow9, 0x99FFFFFF.toInt())
    }

    private fun drawScarf(cv: Canvas) {
        fillS(cv, scas0, g_scShadow)
        fillS(cv, sca0, g_scTail)
        fillS(cv, sca1, g_scTailV)
        strokeC(cv, sca2, 1.5f, 0xF0FFF8F8.toInt())
        strokeC(cv, sca3, 0.9f, 0xFFB8242C.toInt())
        fillS(cv, sca4, g_scBand)
        fillS(cv, sca5, g_scBandShade)
        strokeC(cv, sca6, 1.6f, 0xE6FFF8F8.toInt())
        strokeC(cv, sca7, 0.8f, 0x26601018.toInt())
        fillS(cv, sca8, g_scKnot)
        strokeC(cv, sca9, 1.1f, 0x55FFFFFF.toInt())
    }

    /** Topi / kacamata / hiasan kepala. Dipanggil di akhir [PetView] kepala (koordinat kepala 100x100). */
    fun drawHat(cv: Canvas, acc: PetAcc) {
        when (acc) {
            PetAcc.BEANIE -> drawBeanie(cv)
            PetAcc.SANTA -> drawSanta(cv)
            PetAcc.PARTY -> drawParty(cv)
            PetAcc.CROWN -> drawCrown(cv)
            PetAcc.WITCH -> drawWitch(cv)
            PetAcc.SHADES -> drawShades(cv)
            PetAcc.GLASSES -> drawGlasses(cv)
            PetAcc.PUMPKIN -> drawPumpkin(cv)
            PetAcc.BOW -> drawBow(cv)
            else -> {
            }
        }
    }

    /** Syal: dipanggil dari badan (koordinat badan 100x100), setelah jumbai leher. */
    fun drawScarfBody(cv: Canvas) = drawScarf(cv)
}
