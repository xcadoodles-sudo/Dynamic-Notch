package com.lobo.app

import android.app.ActivityOptions
import android.app.Application
import android.app.PendingIntent
import android.os.Build
import android.os.SystemClock
import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** Satu "notifikasi" yang tampil di notch. tab >= 0 -> ketuk membuka tab panel itu. */
data class Alert(
    val title: String,
    val sub: String,
    val glyph: String,
    val color: Int,
    val icon: Drawable? = null,
    val ms: Long = 3500L,
    val tab: Int = -1,
    val onClick: (() -> Unit)? = null,
    /** Kalau tidak null: notifikasi ini bisa dibalas dari notch (mengirim teks, true = terkirim). */
    val reply: ((String) -> Boolean)? = null
)

object Bus {
    private val main = Handler(Looper.getMainLooper())
    @Volatile var sink: ((Alert) -> Unit)? = null
    @Volatile var dataChanged: (() -> Unit)? = null
    fun alert(a: Alert) {
        main.post { sink?.invoke(a) }
    }
    fun changed() {
        main.post { dataChanged?.invoke() }
    }
}

/** Dipakai agar balasan yang barusan kita kirim tidak muncul lagi sebagai notifikasi baru di notch. */
object ReplyGuard {
    @Volatile var key = ""
    @Volatile var until = 0L
    fun mute(k: String, ms: Long = 6000L) {
        key = k
        until = SystemClock.elapsedRealtime() + ms
    }
    fun muted(k: String): Boolean = k == key && SystemClock.elapsedRealtime() < until
}

/** Jembatan ke ReplyActivity (dipakai kalau jendela overlay tidak bisa menerima keyboard). */
object ReplyBridge {
    @Volatile var title = ""
    @Volatile var fn: ((String) -> Boolean)? = null
}

/** Kirim PendingIntent milik app lain (buka chat WA, dll) dengan izin start activity dari background. */
fun fireIntent(ctx: Context, pi: PendingIntent?) {
    if (pi == null) return
    try {
        if (Build.VERSION.SDK_INT >= 34) {
            val o = ActivityOptions.makeBasic()
            o.setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
            pi.send(ctx, 0, null, null, null, null, o.toBundle())
        } else {
            pi.send()
        }
    } catch (e: Exception) {
        try {
            pi.send()
        } catch (e2: Exception) {
        }
    }
}

class LoboApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Lobo.init(this)
    }
}

/** Mode tampilan notch/panel: Liquid Glass atau Dark. Dibaca saat menggambar, jadi ganti mode langsung terlihat. */
object Look {
    @Volatile var dark = false

    fun set(d: Boolean) {
        dark = d
        Lobo.prefs.darkMode = d
    }
}

object Lobo {
    lateinit var prefs: Prefs
    lateinit var shelf: ShelfStore
    lateinit var app: Application
    fun init(a: Application) {
        app = a
        prefs = Prefs(a)
        shelf = ShelfStore(a)
        Look.dark = prefs.darkMode
    }
}

class BoolPref(private val sp: SharedPreferences, private val key: String, private val def: Boolean) : ReadWriteProperty<Any?, Boolean> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = sp.getBoolean(key, def)
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
        sp.edit().putBoolean(key, value).apply()
    }
}

class IntPref(private val sp: SharedPreferences, private val key: String, private val def: Int) : ReadWriteProperty<Any?, Int> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): Int = sp.getInt(key, def)
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
        sp.edit().putInt(key, value).apply()
    }
}

class LongPref(private val sp: SharedPreferences, private val key: String, private val def: Long) : ReadWriteProperty<Any?, Long> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): Long = sp.getLong(key, def)
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Long) {
        sp.edit().putLong(key, value).apply()
    }
}

class StrPref(private val sp: SharedPreferences, private val key: String, private val def: String) : ReadWriteProperty<Any?, String> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): String = sp.getString(key, def) ?: def
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
        sp.edit().putString(key, value).apply()
    }
}

class Prefs(ctx: Context) {
    val sp: SharedPreferences = ctx.getSharedPreferences("lobo", Context.MODE_PRIVATE)
    var pet by BoolPref(sp, "pet", true)
    var mascotAcc by StrPref(sp, "mascotAcc", "auto")
    var mascotReact by BoolPref(sp, "mascotReact", true)
    var minimal by BoolPref(sp, "minimal", false)
    var notifAlerts by BoolPref(sp, "notifAlerts", true)
    var startOnBoot by BoolPref(sp, "boot", false)
    var topOffset by IntPref(sp, "topOff2", 0)
    var showLyrics by BoolPref(sp, "showLyrics", true)
    var lastTab by IntPref(sp, "lastTab", 0)
    var notchW by IntPref(sp, "notchW", 160)
    var notchH by IntPref(sp, "notchH", 33)
    var mkSelected by StrPref(sp, "mkSel", "BTCUSD")
    var mkRange by StrPref(sp, "mkRange", "m5")
    var mkCandles by BoolPref(sp, "mkCandles", true)
    var mkSymbols by StrPref(sp, "mkSyms", "")
    var wxCache by StrPref(sp, "wxCache", "")
    var wxLat by StrPref(sp, "wxLat", "")
    var wxLon by StrPref(sp, "wxLon", "")
    var lastTitle by StrPref(sp, "ltTitle", "")
    var lastArtist by StrPref(sp, "ltArtist", "")
    var lastPkg by StrPref(sp, "ltPkg", "")
    var theme by IntPref(sp, "theme", 0)
    /** false = Liquid Glass (tembus pandang), true = Dark (pekat, gradasi tetap ada). */
    var darkMode by BoolPref(sp, "darkMode", false)
    /** Kepekatan kaca panel/alert, persen (rendah = lebih tembus pandang). */
    var glassPct by IntPref(sp, "glassPct", 64)
    var todoJson by StrPref(sp, "todo", "[]")
    var clipJson by StrPref(sp, "clips", "[]")
    var launcherApps by StrPref(sp, "launcher", "")
}

fun dayKey(): Int {
    val c = Calendar.getInstance()
    return c.get(Calendar.YEAR) * 10000 + (c.get(Calendar.MONTH) + 1) * 100 + c.get(Calendar.DAY_OF_MONTH)
}

fun nowMinutes(): Int {
    val c = Calendar.getInstance()
    return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
}

// ---------------------------------------------------------------- Shelf

class ShelfStore(private val ctx: Context) {
    val dir: File
        get() {
            val d = File(ctx.filesDir, "LoboShelf")
            d.mkdirs()
            return d
        }

    fun items(): List<File> = (dir.listFiles()?.filter { it.isFile } ?: emptyList()).sortedByDescending { it.lastModified() }

    fun isLink(f: File): Boolean = f.extension.equals("url", true)

    fun linkTarget(f: File): String? {
        return try {
            f.readLines().firstOrNull { it.startsWith("URL=") }?.substring(4)?.trim()
        } catch (e: Exception) {
            null
        }
    }

    fun uriFor(f: File): Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)

    private fun uniqueFile(name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = if (name.contains('.')) name.substringBeforeLast('.') else name
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var i = 1
        while (true) {
            f = File(dir, "$base ($i)$ext")
            if (!f.exists()) return f
            i++
        }
    }

    private fun clean(n: String): String {
        val s = n.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        return if (s.isEmpty()) "file" else s
    }

    fun addUri(uri: Uri): Boolean {
        return try {
            var name: String? = null
            try {
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) name = it.getString(0)
                }
            } catch (e: Exception) {
            }
            val n = clean(name ?: uri.lastPathSegment ?: "file")
            val out = uniqueFile(n)
            val input = ctx.contentResolver.openInputStream(uri) ?: return false
            try {
                input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            } catch (e: Exception) {
                out.delete() // jangan tinggalkan file setengah jadi di shelf
                throw e
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun addLink(url: String) {
        val host = try {
            Uri.parse(url).host ?: "link"
        } catch (e: Exception) {
            "link"
        }
        val f = uniqueFile(clean(host) + ".url")
        f.writeText("[InternetShortcut]\nURL=$url\n")
    }

    fun remove(f: File) {
        f.delete()
    }

    fun clear() {
        items().forEach { it.delete() }
    }
}
