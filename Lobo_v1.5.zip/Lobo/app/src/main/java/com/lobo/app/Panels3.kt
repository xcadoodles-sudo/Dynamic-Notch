package com.lobo.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ helper kecil

/** Judul panel (kecil, ala NotchPixel) + view di kanan. */
private fun Context.panelHead(title: String, vararg right: View): LinearLayout {
    val h = LinearLayout(this)
    h.gravity = Gravity.CENTER_VERTICAL
    h.addView(tv(title, 14f, C.TEXT, true))
    h.addView(View(this), llp(0, 1, 1f))
    for (v in right) h.addView(v, llp(WRAP, WRAP, 0f, 6, 0, 0, 0))
    return h
}

private fun Context.smallPill(text: String, bg: Int = C.GLASS2, fg: Int = C.TEXT, onClick: () -> Unit): TextView {
    val t = pill(text, bg, fg, 11f, onClick)
    t.setPadding(dp(11), dp(5), dp(11), dp(5))
    return t
}

private fun Context.card(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.background = glass(C.GLASS, dpf(16))
    l.setPadding(dp(12), dp(10), dp(12), dp(10))
    return l
}

private fun ago(ms: Long): String {
    val d = (System.currentTimeMillis() - ms) / 1000
    return when {
        d < 60 -> "now"
        d < 3600 -> "${d / 60}m"
        d < 86400 -> "${d / 3600}h"
        else -> "${d / 86400}d"
    }
}

/** Slider seret halus (dipakai Mixer). Mencegah baris tab ikut tergeser saat menyeret. */
class LevelSlider(private val c: Context) : View(c) {
    var frac: Float = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var color: Int = C.TEXT
    var onChange: ((Float) -> Unit)? = null
    var dragging = false
        private set
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val h = c.dpf(5)
        val cy = height / 2f
        val pad = c.dpf(8)
        val w = width - 2 * pad
        p.color = 0x33FFFFFF
        cv.drawRoundRect(pad, cy - h / 2f, pad + w, cy + h / 2f, h, h, p)
        p.color = color
        cv.drawRoundRect(pad, cy - h / 2f, pad + w * frac, cy + h / 2f, h, h, p)
        cv.drawCircle(pad + w * frac, cy, c.dpf(6.5f), p)
    }

    private fun touchTo(x: Float) {
        val pad = c.dpf(8)
        val w = width - 2 * pad
        if (w <= 0f) return
        frac = ((x - pad) / w).coerceIn(0f, 1f)
        onChange?.invoke(frac)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                touchTo(e.x)
            }
            MotionEvent.ACTION_MOVE -> touchTo(e.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }
}

// ------------------------------------------------------------------ NOTIFICATIONS

class NotifPanel(private val c: Context) : FrameLayout(c), Refreshable {
    /** Diisi NotchView: tutup panel dulu, baru jalankan aksi (mis. buka app). */
    var closeThen: ((() -> Unit) -> Unit)? = null
    private val list = LinearLayout(c)
    private val tCount = c.tv("", 11f, C.SUB)
    private var sig = ""

    init {
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        val clear = c.smallPill("Clear all") {
            try {
                LoboNotificationListener.instance?.cancelAllNotifications()
            } catch (e: Exception) {
            }
            NotifStore.clear()
            sig = ""
            refresh()
        }
        col.addView(c.panelHead("Notifications", tCount, clear), c.llp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        val sv = ScrollView(c)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = OVER_SCROLL_NEVER
        list.orientation = LinearLayout.VERTICAL
        sv.addView(list, LayoutParams(MATCH, WRAP))
        col.addView(sv, c.llp(MATCH, 0, 1f))
        addView(col, LayoutParams(MATCH, MATCH))
    }

    private fun row(n: NotifItem): View {
        val r = LinearLayout(c)
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = glass(C.GLASS, c.dpf(14))
        r.setPadding(c.dp(10), c.dp(8), c.dp(6), c.dp(8))
        val ic = ImageView(c)
        if (n.icon != null) ic.setImageDrawable(n.icon)
        ic.roundClip(c.dpf(9))
        r.addView(ic, c.llp(c.dp(30), c.dp(30), 0f, 0, 0, 10, 0))
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        val t = c.tv(n.title, 12.5f, C.TEXT, true)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        val s = c.tv(n.text, 11.5f, C.SUB)
        s.maxLines = 1
        s.ellipsize = TextUtils.TruncateAt.END
        col.addView(t)
        col.addView(s, c.llp(MATCH, WRAP, 0f, 0, 2, 0, 0))
        r.addView(col, c.llp(0, WRAP, 1f))
        r.addView(c.tv(ago(n.time), 10.5f, C.SUB), c.llp(WRAP, WRAP, 0f, 8, 0, 0, 0))
        val x = c.tv("✕", 12f, C.SUB)
        x.setPadding(c.dp(10), c.dp(6), c.dp(8), c.dp(6))
        x.setOnClickListener {
            try {
                LoboNotificationListener.instance?.cancelNotification(n.key)
            } catch (e: Exception) {
            }
            NotifStore.remove(n.key)
            sig = ""
            refresh()
        }
        r.addView(x)
        r.setOnClickListener {
            val go: () -> Unit = { fireIntent(c, n.pi) }
            val ct = closeThen
            if (ct != null) ct(go) else go()
        }
        return r
    }

    override fun refresh() {
        val items = NotifStore.items()
        val s = items.joinToString("|") { it.key + it.time } + "#" + (System.currentTimeMillis() / 60000)
        if (s == sig) return
        sig = s
        list.removeAllViews()
        tCount.text = if (items.isEmpty()) "" else "${items.size} · scroll for more"
        if (items.isEmpty()) {
            list.addView(c.tv("No notifications", 13f, C.SUB), c.llp(WRAP, WRAP, 0f, 4, 12, 0, 0))
            return
        }
        for (n in items) list.addView(row(n), c.llp(MATCH, WRAP, 0f, 0, 0, 0, 6))
    }
}

// ------------------------------------------------------------------ CLIPBOARD

class ClipPanel(private val c: Context) : FrameLayout(c), Refreshable, PanelLife {
    private val list = LinearLayout(c)
    private var sig = ""

    init {
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        val paste = c.smallPill("+ Paste", C.ACCENT, C.TEXT) {
            try {
                val i = Intent(c, ClipReadActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                c.startActivity(i)
            } catch (e: Exception) {
            }
        }
        val clear = c.smallPill("Clear", C.GLASS2, C.RED) {
            ClipStore.clear()
            sig = ""
            refresh()
        }
        col.addView(c.panelHead("Clipboard", paste, clear), c.llp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        val sv = ScrollView(c)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = OVER_SCROLL_NEVER
        list.orientation = LinearLayout.VERTICAL
        sv.addView(list, LayoutParams(MATCH, WRAP))
        col.addView(sv, c.llp(MATCH, 0, 1f))
        addView(col, LayoutParams(MATCH, MATCH))
    }

    override fun onVisible(v: Boolean) {
        if (v) {
            // kalau sistem mengizinkan, ambil isi clipboard sekarang
            ClipWatcher.captureNow(c)
            sig = ""
            refresh()
        }
    }

    private fun row(text: String): View {
        val r = LinearLayout(c)
        r.gravity = Gravity.CENTER_VERTICAL
        r.background = glass(C.GLASS, c.dpf(14))
        r.setPadding(c.dp(12), c.dp(9), c.dp(6), c.dp(9))
        val t = c.tv(text.replace('\n', ' '), 12f, C.TEXT)
        t.maxLines = 2
        t.ellipsize = TextUtils.TruncateAt.END
        r.addView(t, c.llp(0, WRAP, 1f))
        val x = c.tv("✕", 12f, C.SUB)
        x.setPadding(c.dp(10), c.dp(6), c.dp(8), c.dp(6))
        x.setOnClickListener {
            ClipStore.remove(text)
            sig = ""
            refresh()
        }
        r.addView(x)
        r.setOnClickListener {
            try {
                val cm = c.getSystemService(ClipboardManager::class.java)
                ClipWatcher.mute()
                cm?.setPrimaryClip(ClipData.newPlainText("lobo", text))
                val shown = t.text
                t.text = "Copied ✓"
                t.setTextColor(C.GREEN)
                t.postDelayed({
                    t.text = shown
                    t.setTextColor(C.TEXT)
                }, 800)
            } catch (e: Exception) {
            }
        }
        return r
    }

    override fun refresh() {
        val items = ClipStore.items()
        val s = items.joinToString("\u0001")
        if (s == sig) return
        sig = s
        list.removeAllViews()
        if (items.isEmpty()) {
            list.addView(c.tv("Nothing copied yet.\nCopy something, then tap + Paste.", 12.5f, C.SUB), c.llp(WRAP, WRAP, 0f, 4, 12, 0, 0))
            return
        }
        for (t in items) list.addView(row(t), c.llp(MATCH, WRAP, 0f, 0, 0, 0, 6))
    }
}

// ------------------------------------------------------------------ WIDGETS (jam, to-do, cuaca, baterai)

class WidgetsPanel(private val c: Context) : FrameLayout(c), Refreshable, PanelLife {
    private val tTime = c.tv("", 28f, C.TEXT, true)
    private val tAmPm = c.tv("", 11f, C.SUB, true)
    private val tDate = c.tv("", 11.5f, C.SUB)
    private val tWxIcon = c.tv("", 24f)
    private val tWxTemp = c.tv("--°", 24f, C.TEXT, true)
    private val tWxCond = c.tv("Loading…", 11f, C.TEXT)
    private val tWxHiLo = c.tv("", 10.5f, C.SUB)
    private val tTodoHead = c.tv("To do", 12.5f, C.TEXT, true)
    private val todoList = LinearLayout(c)
    private val tBatName = c.tv("This device", 11f, C.SUB)
    private val tBatPct = c.tv("--%", 18f, C.TEXT, true)
    private val batBar = ProgressLine(c)
    private var todoSig = ""
    private var wxSig = ""

    init {
        val root = LinearLayout(c)

        // ---- kiri: jam + cuaca
        val left = LinearLayout(c)
        left.orientation = LinearLayout.VERTICAL
        val clock = c.card()
        val tr = LinearLayout(c)
        tr.gravity = Gravity.BOTTOM
        tr.addView(tTime)
        tr.addView(tAmPm, c.llp(WRAP, WRAP, 0f, 4, 0, 0, 4))
        clock.addView(tr)
        clock.addView(tDate, c.llp(WRAP, WRAP, 0f, 0, 4, 0, 0))
        left.addView(clock, c.llp(MATCH, 0, 1f, 0, 0, 0, 8))
        val wx = c.card()
        val wr = LinearLayout(c)
        wr.gravity = Gravity.CENTER_VERTICAL
        wr.addView(tWxIcon, c.llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        wr.addView(tWxTemp)
        wx.addView(wr)
        tWxCond.maxLines = 1
        tWxCond.ellipsize = TextUtils.TruncateAt.END
        tWxHiLo.maxLines = 1
        tWxHiLo.ellipsize = TextUtils.TruncateAt.END
        wx.addView(tWxCond, c.llp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        wx.addView(tWxHiLo, c.llp(MATCH, WRAP, 0f, 0, 1, 0, 0))
        left.addView(wx, c.llp(MATCH, 0, 1f))
        root.addView(left, c.llp(0, MATCH, 1f, 0, 0, 8, 0))

        // ---- kanan: to-do + baterai
        val right = LinearLayout(c)
        right.orientation = LinearLayout.VERTICAL
        val todo = c.card()
        val th = LinearLayout(c)
        th.gravity = Gravity.CENTER_VERTICAL
        th.addView(tTodoHead)
        th.addView(View(c), c.llp(0, 1, 1f))
        val add = LineIconView(c, IconKind.PLUS, C.TEXT, 14f, 1.5f)
        add.background = glass(C.GLASS2, c.dpf(100))
        add.setOnClickListener {
            try {
                val i = Intent(c, TodoInputActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                c.startActivity(i)
            } catch (e: Exception) {
            }
        }
        th.addView(add, c.llp(c.dp(26), c.dp(26)))
        todo.addView(th, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 6))
        todoList.orientation = LinearLayout.VERTICAL
        todo.addView(todoList, c.llp(MATCH, WRAP))
        right.addView(todo, c.llp(MATCH, 0, 1.7f, 0, 0, 0, 8))
        val bat = c.card()
        val bt = LinearLayout(c)
        bt.gravity = Gravity.CENTER_VERTICAL
        bt.addView(tBatName)
        bt.addView(View(c), c.llp(0, 1, 1f))
        bt.addView(tBatPct)
        bat.addView(bt)
        bat.addView(batBar, c.llp(MATCH, c.dp(10), 0f, 0, 6, 0, 0))
        right.addView(bat, c.llp(MATCH, 0, 1f))
        root.addView(right, c.llp(0, MATCH, 1f))
        addView(root, LayoutParams(MATCH, MATCH))
    }

    override fun onVisible(v: Boolean) {
        if (v) {
            WeatherRepo.refresh(c)
            todoSig = ""
            wxSig = ""
            refresh()
        }
    }

    private fun updateClock() {
        val loc = Locale.getDefault()
        val now = Date()
        if (android.text.format.DateFormat.is24HourFormat(c)) {
            tTime.text = SimpleDateFormat("HH:mm", loc).format(now)
            tAmPm.text = ""
        } else {
            tTime.text = SimpleDateFormat("h:mm", loc).format(now)
            tAmPm.text = SimpleDateFormat("a", loc).format(now).uppercase(loc)
        }
        tDate.text = SimpleDateFormat("EEE, d MMM", loc).format(now)
    }

    private fun updateWeather() {
        WeatherRepo.loadCache()
        val w = WeatherRepo.current
        val s = if (w == null) "none" else "${w.at}"
        if (s == wxSig) return
        wxSig = s
        if (w == null) {
            tWxIcon.text = ""
            tWxTemp.text = "--°"
            tWxCond.text = "Loading…"
            tWxHiLo.text = ""
            return
        }
        tWxIcon.text = Weather.emoji(w.code, w.isDay)
        tWxTemp.text = "%.0f°".format(w.temp)
        tWxCond.text = Weather.text(w.code)
        val hi = if (w.dayHi.isNotEmpty()) "%.0f°".format(w.dayHi[0]) else "--"
        val lo = if (w.dayLo.isNotEmpty()) "%.0f°".format(w.dayLo[0]) else "--"
        tWxHiLo.text = "H $hi  L $lo · ${w.place}"
    }

    private fun updateBattery() {
        try {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
            val lv = i.getIntExtra("level", -1)
            val sc = i.getIntExtra("scale", 100)
            val st = i.getIntExtra("status", -1)
            if (lv < 0 || sc <= 0) return
            val pct = lv * 100 / sc
            val charging = st == 2 || st == 5
            tBatPct.text = "$pct%"
            batBar.frac = pct / 100f
            batBar.fillColor = if (pct <= 15 && !charging) C.RED else C.GREEN
            tBatName.text = if (charging) "Charging" else "This device"
        } catch (e: Exception) {
        }
    }

    private fun updateTodo() {
        val items = TodoStore.items()
        val s = items.joinToString("|") { it.text + it.done }
        if (s == todoSig) return
        todoSig = s
        val pend = items.count { !it.done }
        tTodoHead.text = if (pend > 0) "To do  $pend" else "To do"
        todoList.removeAllViews()
        if (items.isEmpty()) {
            todoList.addView(c.tv("All clear. Tap + to add.", 11.5f, C.SUB))
            return
        }
        for (idx in items.indices) {
            if (idx >= 3) break
            val td = items[idx]
            val r = LinearLayout(c)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(0, c.dp(4), 0, c.dp(4))
            val dot = View(c)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            if (td.done) g.setColor(C.GREEN) else g.setStroke(c.dp(1), 0x88FFFFFF.toInt())
            dot.background = g
            r.addView(dot, c.llp(c.dp(12), c.dp(12), 0f, 0, 0, 8, 0))
            val t = c.tv(td.text, 12f, if (td.done) C.SUB else C.TEXT)
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            if (td.done) t.paintFlags = t.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            r.addView(t, c.llp(0, WRAP, 1f))
            r.setOnClickListener {
                TodoStore.toggle(idx)
                todoSig = ""
                refresh()
            }
            r.setOnLongClickListener {
                TodoStore.remove(idx)
                todoSig = ""
                refresh()
                true
            }
            todoList.addView(r)
        }
        if (items.size > 3) todoList.addView(c.tv("+${items.size - 3} more", 10.5f, C.SUB), c.llp(WRAP, WRAP, 0f, 0, 2, 0, 0))
    }

    override fun refresh() {
        updateClock()
        updateWeather()
        updateBattery()
        updateTodo()
    }
}

// ------------------------------------------------------------------ MIXER

class MixerPanel(private val c: Context) : FrameLayout(c), Refreshable, PanelLife {
    private class Row(val stream: Int, val slider: LevelSlider, val pct: TextView)

    private val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val rows = ArrayList<Row>()

    init {
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.addView(c.panelHead("Mixer"), c.llp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        val defs = listOf(
            Triple("Media", AudioManager.STREAM_MUSIC, IconKind.SPEAKER),
            Triple("Ring", AudioManager.STREAM_RING, IconKind.BELL),
            Triple("Alarm", AudioManager.STREAM_ALARM, IconKind.CLOCK),
            Triple("Alerts", AudioManager.STREAM_NOTIFICATION, IconKind.CHAT)
        )
        for (r in 0 until 2) {
            val line = LinearLayout(c)
            for (k in 0 until 2) {
                val d = defs[r * 2 + k]
                val cell = c.card()
                cell.setPadding(c.dp(12), c.dp(8), c.dp(10), c.dp(6))
                val top = LinearLayout(c)
                top.gravity = Gravity.CENTER_VERTICAL
                top.addView(LineIconView(c, d.third, C.SUB, 14f, 1.4f), c.llp(c.dp(18), c.dp(18), 0f, 0, 0, 6, 0))
                top.addView(c.tv(d.first, 11.5f, C.TEXT, true))
                top.addView(View(c), c.llp(0, 1, 1f))
                val pct = c.tv("", 11f, C.SUB)
                top.addView(pct)
                cell.addView(top)
                val sl = LevelSlider(c)
                sl.onChange = { f ->
                    try {
                        val mx = am.getStreamMaxVolume(d.second)
                        val v = Math.round(f * mx)
                        am.setStreamVolume(d.second, v, 0)
                        pct.text = (if (mx > 0) v * 100 / mx else 0).toString() + "%"
                    } catch (e: Exception) {
                    }
                }
                cell.addView(sl, c.llp(MATCH, 0, 1f))
                rows.add(Row(d.second, sl, pct))
                line.addView(cell, c.llp(0, MATCH, 1f, 0, 0, if (k == 0) 8 else 0, 0))
            }
            col.addView(line, c.llp(MATCH, 0, 1f, 0, 0, 0, if (r == 0) 8 else 0))
        }
        addView(col, LayoutParams(MATCH, MATCH))
    }

    override fun onVisible(v: Boolean) {
        if (v) refresh()
    }

    override fun refresh() {
        for (r in rows) {
            if (r.slider.dragging) continue
            try {
                val mx = am.getStreamMaxVolume(r.stream)
                val cur = am.getStreamVolume(r.stream)
                r.slider.frac = if (mx > 0) cur.toFloat() / mx else 0f
                r.pct.text = (if (mx > 0) cur * 100 / mx else 0).toString() + "%"
            } catch (e: Exception) {
            }
        }
    }
}

// ------------------------------------------------------------------ LAUNCHER

class LauncherPanel(private val c: Context) : FrameLayout(c), Refreshable {
    /** Diisi NotchView: tutup panel dulu, baru jalankan aksi. */
    var closeThen: ((() -> Unit) -> Unit)? = null
    private val grid = LinearLayout(c)
    private var sig = ""

    init {
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.addView(c.panelHead("Launcher"), c.llp(MATCH, WRAP, 0f, 0, 0, 0, 8))

        val acts = LinearLayout(c)
        acts.addView(actionBtn("Screenshot", IconKind.CAMERA, 0), c.llp(0, MATCH, 1f, 0, 0, 8, 0))
        acts.addView(actionBtn("Recents", IconKind.RECENTS, 1), c.llp(0, MATCH, 1f, 0, 0, 8, 0))
        acts.addView(actionBtn("Lock", IconKind.LOCK, 2), c.llp(0, MATCH, 1f))
        col.addView(acts, c.llp(MATCH, c.dp(46), 0f, 0, 0, 0, 10))

        grid.orientation = LinearLayout.VERTICAL
        col.addView(grid, c.llp(MATCH, 0, 1f))
        addView(col, LayoutParams(MATCH, MATCH))
    }

    private fun actionBtn(label: String, kind: IconKind, which: Int): View {
        val b = LinearLayout(c)
        b.gravity = Gravity.CENTER
        b.background = glass(C.GLASS2, c.dpf(14))
        b.addView(LineIconView(c, kind, C.TEXT, 15f, 1.4f), c.llp(c.dp(20), c.dp(20), 0f, 0, 0, 6, 0))
        b.addView(c.tv(label, 12f, C.TEXT, true))
        b.setOnClickListener { runAction(which) }
        return b
    }

    /** 0 = screenshot, 1 = recents, 2 = kunci layar (lewat izin Accessibility). */
    private fun runAction(which: Int) {
        val go: () -> Unit = {
            val s = LoboAccessibilityService.instance
            val need = if (which == 1) 0 else 28
            if (s == null || Build.VERSION.SDK_INT < need) {
                Bus.alert(Alert("Accessibility needed", "Turn on Lobo in Accessibility settings", "!", C.ORANGE))
            } else {
                when (which) {
                    0 -> s.act(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
                    1 -> s.act(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
                    else -> s.act(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                }
            }
        }
        val ct = closeThen
        if (ct != null) ct(go) else go()
    }

    private fun slot(i: Int, pkg: String): View {
        val f = FrameLayout(c)
        if (pkg.isEmpty()) {
            val g = GradientDrawable()
            g.cornerRadius = c.dpf(14)
            g.setColor(0x0DFFFFFF)
            g.setStroke(c.dp(1), 0x33FFFFFF, c.dpf(4), c.dpf(4))
            f.background = g
            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER
            val plus = LineIconView(c, IconKind.PLUS, C.TEXT, 14f, 1.4f)
            plus.alpha = 0.55f
            col.addView(plus, c.llp(c.dp(18), c.dp(18)))
            val t = c.tv("Add", 9.5f, C.SUB)
            col.addView(t, c.llp(WRAP, WRAP, 0f, 0, 2, 0, 0))
            f.addView(col, LayoutParams(MATCH, MATCH))
            f.setOnClickListener {
                try {
                    val pi = Intent(c, AppPickActivity::class.java)
                    pi.putExtra("slot", i)
                    pi.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    c.startActivity(pi)
                } catch (e: Exception) {
                }
            }
        } else {
            f.background = glass(C.GLASS, c.dpf(14))
            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER
            val iv = ImageView(c)
            var label = pkg
            try {
                iv.setImageDrawable(c.packageManager.getApplicationIcon(pkg))
                label = c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
            }
            col.addView(iv, c.llp(c.dp(28), c.dp(28)))
            val t = c.tv(label, 9.5f, C.TEXT)
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.gravity = Gravity.CENTER
            col.addView(t, c.llp(MATCH, WRAP, 0f, 4, 3, 4, 0))
            f.addView(col, LayoutParams(MATCH, MATCH))
            f.setOnClickListener {
                val go: () -> Unit = {
                    try {
                        val li = c.packageManager.getLaunchIntentForPackage(pkg)
                        if (li != null) {
                            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            c.startActivity(li)
                        }
                    } catch (e: Exception) {
                    }
                }
                val ct = closeThen
                if (ct != null) ct(go) else go()
            }
            f.setOnLongClickListener {
                LauncherStore.set(i, "")
                sig = ""
                refresh()
                true
            }
        }
        return f
    }

    override fun refresh() {
        val slots = LauncherStore.get()
        val s = slots.joinToString(",")
        if (s == sig) return
        sig = s
        grid.removeAllViews()
        for (r in 0 until 2) {
            val line = LinearLayout(c)
            for (k in 0 until 6) {
                val i = r * 6 + k
                line.addView(slot(i, slots[i]), c.llp(0, MATCH, 1f, 0, 0, if (k < 5) 6 else 0, 0))
            }
            grid.addView(line, c.llp(MATCH, 0, 1f, 0, 0, 0, if (r == 0) 6 else 0))
        }
    }
}

// ------------------------------------------------------------------ CALLS (mute mic + output)

class CallsPanel(private val c: Context) : FrameLayout(c), Refreshable, PanelLife {
    private val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val btn = FrameLayout(c)
    private val ic = LineIconView(c, IconKind.MIC, C.TEXT, 28f, 1.8f)
    private val tHint = c.tv("Tap to mute", 11.5f, C.SUB)
    private val tTimer = c.tv("0:00", 30f, C.TEXT, true)
    private val tTag = c.tv("", 11.5f, C.SUB, true)
    private val tSpk = c.tv("", 12f, C.TEXT, true)
    private val tOut = c.tv("", 12f, C.TEXT)
    private var callStart = 0L

    init {
        tTimer.typeface = Typeface.MONOSPACE
        val root = LinearLayout(c)
        root.gravity = Gravity.CENTER_VERTICAL

        val left = LinearLayout(c)
        left.orientation = LinearLayout.VERTICAL
        left.gravity = Gravity.CENTER_HORIZONTAL
        btn.addView(ic, LayoutParams(c.dp(34), c.dp(34), Gravity.CENTER))
        btn.setOnClickListener {
            try {
                am.isMicrophoneMute = !am.isMicrophoneMute
            } catch (e: Exception) {
            }
            refresh()
        }
        left.addView(btn, c.llp(c.dp(76), c.dp(76)))
        left.addView(tHint, c.llp(WRAP, WRAP, 0f, 0, 8, 0, 0))
        root.addView(left, c.llp(c.dp(130), MATCH, 0f, 0, 0, 14, 0))

        val right = LinearLayout(c)
        right.orientation = LinearLayout.VERTICAL
        right.gravity = Gravity.CENTER_VERTICAL
        val tr = LinearLayout(c)
        tr.gravity = Gravity.CENTER_VERTICAL
        tr.addView(tTimer)
        tr.addView(tTag, c.llp(WRAP, WRAP, 0f, 10, 0, 0, 0))
        right.addView(tr, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 10))

        val spk = LinearLayout(c)
        spk.gravity = Gravity.CENTER_VERTICAL
        spk.background = glass(C.GLASS, c.dpf(14))
        spk.setPadding(c.dp(12), c.dp(9), c.dp(12), c.dp(9))
        spk.addView(LineIconView(c, IconKind.SPEAKER, C.SUB, 14f, 1.4f), c.llp(c.dp(18), c.dp(18), 0f, 0, 0, 8, 0))
        spk.addView(c.tv("Speakerphone", 12f, C.TEXT), c.llp(0, WRAP, 1f))
        spk.addView(tSpk)
        spk.setOnClickListener {
            try {
                am.isSpeakerphoneOn = !am.isSpeakerphoneOn
            } catch (e: Exception) {
            }
            refresh()
        }
        right.addView(spk, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 6))

        val out = LinearLayout(c)
        out.gravity = Gravity.CENTER_VERTICAL
        out.background = glass(C.GLASS, c.dpf(14))
        out.setPadding(c.dp(12), c.dp(9), c.dp(12), c.dp(9))
        out.addView(LineIconView(c, IconKind.HEADPHONES, C.SUB, 14f, 1.4f), c.llp(c.dp(18), c.dp(18), 0f, 0, 0, 8, 0))
        out.addView(c.tv("Output", 12f, C.TEXT), c.llp(0, WRAP, 1f))
        tOut.maxLines = 1
        tOut.ellipsize = TextUtils.TruncateAt.END
        out.addView(tOut)
        right.addView(out, c.llp(MATCH, WRAP))
        root.addView(right, c.llp(0, MATCH, 1f))
        addView(root, LayoutParams(MATCH, MATCH))
    }

    override fun onVisible(v: Boolean) {
        if (v) refresh()
    }

    private fun outputName(): String {
        try {
            for (d in am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                when (d.type) {
                    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> {
                        val n = d.productName?.toString() ?: ""
                        return if (n.isBlank()) "Bluetooth" else n
                    }
                    AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_USB_HEADSET -> return "Headphones"
                }
            }
        } catch (e: Exception) {
        }
        return if (am.isSpeakerphoneOn) "Speaker" else "Built-in"
    }

    override fun refresh() {
        val muted = try {
            am.isMicrophoneMute
        } catch (e: Exception) {
            false
        }
        val inCall = am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION
        if (inCall) {
            if (callStart == 0L) callStart = SystemClock.elapsedRealtime()
        } else {
            callStart = 0L
        }
        tTimer.text = if (callStart > 0L) fmtTime(SystemClock.elapsedRealtime() - callStart) else "0:00"
        if (muted) {
            tTag.text = "Muted"
            tTag.setTextColor(C.RED)
        } else if (inCall) {
            tTag.text = "live"
            tTag.setTextColor(C.GREEN)
        } else {
            tTag.text = "no call"
            tTag.setTextColor(C.SUB)
        }
        btn.background = (if (muted) rounded(C.RED, c.dpf(100)) else glass(C.GLASS2, c.dpf(100)))
        ic.set(if (muted) IconKind.MIC_OFF else IconKind.MIC, C.TEXT)
        tHint.text = if (muted) "Muted · tap to unmute" else "Tap to mute"
        tSpk.text = if (am.isSpeakerphoneOn) "On" else "Off"
        tSpk.setTextColor(if (am.isSpeakerphoneOn) C.GREEN else C.SUB)
        tOut.text = outputName()
    }
}
