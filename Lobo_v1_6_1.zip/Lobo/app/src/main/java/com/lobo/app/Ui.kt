package com.lobo.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.Resources
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

const val MATCH = -1
const val WRAP = -2

object C {
    val BLACK = 0xFF000000.toInt()
    val APP_BG = 0xFF0B0B10.toInt()
    val CARD = 0xFF1C1C21.toInt()
    val CARD2 = 0xFF2A2A31.toInt()
    val TEXT = 0xFFFFFFFF.toInt()
    val SUB = 0xFFCDCDD8.toInt()
    val ACCENT = 0xFF8B7BFF.toInt()
    val GREEN = 0xFF30D158.toInt()
    val RED = 0xFFFF453A.toInt()
    val BLUE = 0xFF0A84FF.toInt()
    val ORANGE = 0xFFFF9F0A.toInt()
    val CYAN = 0xFF40C8E0.toInt()

    // kaca (liquid glass) untuk isi panel notch: putih tipis tembus pandang, bukan abu pekat
    val GLASS = 0x1CFFFFFF
    val GLASS2 = 0x33FFFFFF
    val GLASS_SEL = 0x40FFFFFF
}

interface Refreshable {
    fun refresh()
}

fun Context.dp(v: Number): Int = (v.toFloat() * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Number): Float = v.toFloat() * resources.displayMetrics.density

/** LayoutParams untuk LinearLayout. w/h dalam px (pakai dp() / MATCH / WRAP), margin dalam dp. */
fun Context.llp(w: Int, h: Int, weight: Float = 0f, ml: Int = 0, mt: Int = 0, mr: Int = 0, mb: Int = 0): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(dp(ml), dp(mt), dp(mr), dp(mb))
    return p
}

fun rounded(color: Int, radiusPx: Float): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radiusPx
    return g
}

/**
 * Latar ala liquid glass: isi tembus pandang + kilau lembut di bagian atas + garis tepi terang
 * (terang di kiri-atas & kanan-bawah, redup di tengah). Dipakai untuk kartu, tombol, dan chip.
 */
class GlassDrawable(private val fill: Int, private val radius: Float, private val rim: Float = 1f) : Drawable() {
    private val dens = Resources.getSystem().displayMetrics.density
    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pGloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pRim = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pBottom = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private var a = 255

    init {
        pRim.style = Paint.Style.STROKE
        pRim.strokeWidth = dens * 1f
        apply()
    }

    private fun apply() {
        pFill.color = fill
        pFill.alpha = Color.alpha(fill) * a / 255
        pGloss.alpha = a
        pBottom.alpha = a
        pRim.alpha = (255f * rim).toInt().coerceIn(0, 255) * a / 255
    }

    override fun onBoundsChange(b: Rect) {
        val h = b.height().toFloat()
        pGloss.shader = LinearGradient(
            0f, b.top.toFloat(), 0f, b.top + h * 0.62f,
            0x30FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP
        )
        pBottom.shader = LinearGradient(
            0f, b.bottom - h * 0.4f, 0f, b.bottom.toFloat(),
            0x00FFFFFF, 0x24FFFFFF, Shader.TileMode.CLAMP
        )
        pRim.shader = LinearGradient(
            b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(),
            intArrayOf(0xB3FFFFFF.toInt(), 0x1FFFFFFF, 0x66FFFFFF),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        apply()
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val r = minOf(radius, b.height() / 2f, b.width() / 2f)
        rf.set(b)
        canvas.drawRoundRect(rf, r, r, pFill)
        canvas.drawRoundRect(rf, r, r, pGloss)
        canvas.drawRoundRect(rf, r, r, pBottom)
        val h = pRim.strokeWidth / 2f
        rf.inset(h, h)
        canvas.drawRoundRect(rf, r - h, r - h, pRim)
    }

    override fun setAlpha(alpha: Int) {
        a = alpha
        apply()
        invalidateSelf()
    }

    override fun setColorFilter(cf: ColorFilter?) {}

    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

fun glass(color: Int, radiusPx: Float, rim: Float = 1f): Drawable = GlassDrawable(color, radiusPx, rim)

fun Context.tv(text: String, sp: Float, color: Int = C.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    t.includeFontPadding = false
    // bayangan tipis supaya teks kecil tetap terbaca di atas kaca yang tembus pandang
    t.setShadowLayer(dpf(1.6f), 0f, dpf(0.6f), 0x99000000.toInt())
    return t
}

fun Context.pill(text: String, bg: Int, fg: Int = C.TEXT, sp: Float = 13f, onClick: () -> Unit): TextView {
    val t = tv(text, sp, fg, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(14), dp(8), dp(14), dp(8))
    t.background = if (Color.alpha(bg) < 255) glass(bg, dpf(100)) else rounded(bg, dpf(100))
    t.setOnClickListener { onClick() }
    return t
}

fun View.roundClip(radiusPx: Float) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    clipToOutline = true
}

fun fmtTime(ms: Long): String {
    val s = (if (ms < 0) 0L else ms) / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

fun fmtCountdown(ms: Long): String {
    val s = ((if (ms < 0) 0L else ms) + 999) / 1000
    return "%02d:%02d".format(s / 60, s % 60)
}

/** Garis progress tipis; bisa disentuh untuk seek kalau onSeek di-set. */
class ProgressLine(private val c: Context) : View(c) {
    var frac: Float = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var fillColor: Int = C.TEXT
        set(v) {
            field = v
            invalidate()
        }
    var onSeek: ((Float) -> Unit)? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        track.color = 0x33FFFFFF
    }

    override fun onDraw(canvas: Canvas) {
        val t = c.dpf(3)
        val cy = height / 2f
        canvas.drawRoundRect(0f, cy - t, width.toFloat(), cy + t, t, t, track)
        fill.color = fillColor
        canvas.drawRoundRect(0f, cy - t, width * frac, cy + t, t, t, fill)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val cb = onSeek ?: return false
        if (e.action == MotionEvent.ACTION_UP && width > 0) {
            cb((e.x / width).coerceIn(0f, 1f))
        }
        return true
    }
}

/** Panel yang perlu tahu kapan sedang terlihat (untuk start/stop polling). */
interface PanelLife {
    fun onVisible(v: Boolean)
}

/** Chart candlestick atau garis+area ala TradingView. Sentuh/geser untuk melihat harga per titik. */
class ChartView(private val c: Context) : View(c) {
    private var times = LongArray(0)
    private var opens = DoubleArray(0)
    private var highs = DoubleArray(0)
    private var lows = DoubleArray(0)
    private var closes = DoubleArray(0)
    private var base = Double.NaN
    private var color = C.GREEN
    private var dec = 2
    private var touchX = -1f
    private var intraday = true
    private var candles = true
    private val maxCandles = 90

    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dash = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tag = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        line.style = Paint.Style.STROKE
        line.strokeWidth = c.dpf(1.8f)
        line.strokeJoin = Paint.Join.ROUND
        line.strokeCap = Paint.Cap.ROUND
        dash.style = Paint.Style.STROKE
        dash.strokeWidth = c.dpf(1)
        dash.color = 0x55FFFFFF
        dash.pathEffect = DashPathEffect(floatArrayOf(c.dpf(3), c.dpf(4)), 0f)
        txt.textSize = c.dpf(10)
        txt.color = 0x99FFFFFF.toInt()
    }

    fun setData(q: Quote, baseline: Double, up: Boolean, decimals: Int, intra: Boolean, asCandles: Boolean) {
        times = q.times
        opens = q.opens
        highs = q.highs
        lows = q.lows
        closes = q.closes
        base = baseline
        color = if (up) C.GREEN else C.RED
        dec = decimals
        intraday = intra
        candles = asCandles
        invalidate()
    }

    private fun fmtTime(ts: Long): String {
        val f = java.text.SimpleDateFormat(if (intraday) "d MMM HH:mm" else "d MMM yy", java.util.Locale.getDefault())
        return f.format(java.util.Date(ts * 1000))
    }

    override fun onDraw(cv: Canvas) {
        val total = closes.size
        val w = width.toFloat()
        val h = height.toFloat()
        if (total < 2 || w <= 0f) {
            txt.textAlign = Paint.Align.CENTER
            cv.drawText("Loading chart…", w / 2f, h / 2f, txt)
            return
        }
        val s0 = if (candles) maxOf(0, total - maxCandles) else 0
        val n = total - s0
        var lo = if (candles) lows[s0] else closes[s0]
        var hi = if (candles) highs[s0] else closes[s0]
        for (i in s0 until total) {
            val a = if (candles) lows[i] else closes[i]
            val b = if (candles) highs[i] else closes[i]
            if (a < lo) lo = a
            if (b > hi) hi = b
        }
        if (!candles && !base.isNaN() && intraday) {
            lo = minOf(lo, base)
            hi = maxOf(hi, base)
        }
        if (hi - lo < 1e-9) {
            hi += 1.0
            lo -= 1.0
        }
        val padT = c.dpf(14)
        val padB = c.dpf(4)
        val padR = c.dpf(50)
        val cw = w - padR
        val step = cw / n
        fun xs(k: Int) = if (candles) step * (k + 0.5f) else cw * k / (n - 1)
        fun ys(v: Double) = (padT + (hi - v) / (hi - lo) * (h - padT - padB)).toFloat()

        val lastUp = closes[total - 1] >= opens[total - 1]
        if (candles) {
            val bw = (step * 0.68f).coerceAtLeast(c.dpf(1.5f))
            for (k in 0 until n) {
                val i = s0 + k
                val up = closes[i] >= opens[i]
                line.color = if (up) C.GREEN else C.RED
                line.strokeWidth = c.dpf(1)
                val x = xs(k)
                cv.drawLine(x, ys(highs[i]), x, ys(lows[i]), line)
                fill.shader = null
                fill.style = Paint.Style.FILL
                fill.color = line.color
                val yO = ys(opens[i])
                val yC = ys(closes[i])
                val top = minOf(yO, yC)
                val bot = maxOf(yO, yC).coerceAtLeast(top + c.dpf(1))
                cv.drawRect(x - bw / 2f, top, x + bw / 2f, bot, fill)
            }
            line.strokeWidth = c.dpf(1.8f)
        } else {
            val path = Path()
            for (k in 0 until n) {
                val x = xs(k)
                val y = ys(closes[s0 + k])
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val area = Path(path)
            area.lineTo(xs(n - 1), h)
            area.lineTo(0f, h)
            area.close()
            fill.style = Paint.Style.FILL
            fill.shader = LinearGradient(0f, padT, 0f, h, (color and 0x00FFFFFF) or 0x55000000, (color and 0x00FFFFFF), Shader.TileMode.CLAMP)
            cv.drawPath(area, fill)
            line.color = color
            cv.drawPath(path, line)
            if (!base.isNaN() && intraday) {
                val by = ys(base)
                cv.drawLine(0f, by, cw, by, dash)
            }
        }

        // label hi/lo di kanan
        txt.textAlign = Paint.Align.LEFT
        cv.drawText(fmtPrice(hi, dec), cw + c.dpf(4), padT + c.dpf(3), txt)
        cv.drawText(fmtPrice(lo, dec), cw + c.dpf(4), h - padB, txt)

        // harga terakhir: garis putus-putus + tag berwarna
        val lastY = ys(closes[total - 1])
        val lc = if (candles) (if (lastUp) C.GREEN else C.RED) else color
        if (candles) cv.drawLine(0f, lastY, cw, lastY, dash)
        tag.color = lc
        val label = fmtPrice(closes[total - 1], dec)
        txt.textAlign = Paint.Align.LEFT
        val tw = txt.measureText(label)
        val th = c.dpf(14)
        cv.drawRoundRect(cw + c.dpf(2), lastY - th / 2f, cw + c.dpf(6) + tw, lastY + th / 2f, c.dpf(3), c.dpf(3), tag)
        txt.color = C.TEXT
        cv.drawText(label, cw + c.dpf(4), lastY + c.dpf(3.5f), txt)
        txt.color = 0x99FFFFFF.toInt()

        if (touchX >= 0f) {
            val k = (touchX / cw * n).toInt().coerceIn(0, n - 1)
            val i = s0 + k
            val px = xs(k)
            dash.color = 0x88FFFFFF.toInt()
            cv.drawLine(px, 0f, px, h, dash)
            dash.color = 0x55FFFFFF
            txt.color = C.TEXT
            val msg = if (candles) "O ${fmtPrice(opens[i], dec)}  H ${fmtPrice(highs[i], dec)}  L ${fmtPrice(lows[i], dec)}  C ${fmtPrice(closes[i], dec)}"
            else fmtPrice(closes[i], dec) + "  " + fmtTime(times[i])
            txt.textAlign = Paint.Align.LEFT
            cv.drawText(msg, c.dpf(2), c.dpf(10), txt)
            if (candles) {
                txt.textAlign = Paint.Align.RIGHT
                cv.drawText(fmtTime(times[i]), cw, h - padB - c.dpf(2), txt)
            }
            txt.color = 0x99FFFFFF.toInt()
        } else if (!candles) {
            dot.color = color
            cv.drawCircle(xs(n - 1), ys(closes[total - 1]), c.dpf(3.2f), dot)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                touchX = e.x
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touchX = -1f
                invalidate()
            }
        }
        return true
    }
}
