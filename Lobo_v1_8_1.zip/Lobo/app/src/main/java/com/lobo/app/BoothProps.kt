package com.lobo.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Typeface
import android.media.FaceDetector
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.ViewOutlineProvider
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ------------------------------------------------------------------ posisi kepala

/**
 * Posisi kepala dalam koordinat ternormalisasi terhadap frame yang sudah tegak & dicermin (persis seperti preview):
 * cx/cy = titik di antara kedua mata (0..1 dari lebar/tinggi), eye = jarak antar mata (0..1 dari LEBAR frame).
 * Karena ternormalisasi, pose yang sama bisa dipakai untuk menggambar di preview maupun di foto hasil.
 */
class HeadPose {
    var cx: Float = 0.5f
    var cy: Float = 0.4f
    var eye: Float = 0.12f

    fun set(o: HeadPose) {
        cx = o.cx
        cy = o.cy
        eye = o.eye
    }
}

// ------------------------------------------------------------------ pencari wajah (thread latar)

/**
 * Pencari wajah ringan memakai android.media.FaceDetector (bawaan sistem, tanpa dependensi). Frame kecil (RGB_565,
 * lebar genap) dari preview dikirim lewat [submit]; deteksi jalan di thread latar, hasilnya dikembalikan di thread utama.
 * Hanya satu pekerjaan sekali jalan ([busy]) supaya CPU tetap hemat.
 */
class FaceFinder(private val onResult: (HeadPose?) -> Unit) {
    @Volatile
    var busy: Boolean = false
        private set

    private var thread: HandlerThread? = null
    private var bg: Handler? = null
    private val main = Handler(Looper.getMainLooper())
    private var det: FaceDetector? = null
    private var dw = 0
    private var dh = 0

    fun start() {
        if (thread != null) return
        val t = HandlerThread("lobo-face")
        t.start()
        thread = t
        bg = Handler(t.looper)
    }

    fun stop() {
        bg?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        thread = null
        bg = null
        det = null
        busy = false
    }

    private fun detector(w: Int, h: Int): FaceDetector {
        val cached = det
        if (cached != null && w == dw && h == dh) return cached
        val nd = FaceDetector(w, h, 1)
        det = nd
        dw = w
        dh = h
        return nd
    }

    fun submit(bmp: Bitmap) {
        val h = bg ?: return
        if (busy) return
        busy = true
        h.post {
            var res: HeadPose? = null
            try {
                val w = bmp.width
                val hh = bmp.height
                val d: FaceDetector = detector(w, hh)
                val faces = arrayOfNulls<FaceDetector.Face>(1)
                val mid = PointF()
                val n = d.findFaces(bmp, faces)
                val f: FaceDetector.Face? = if (n > 0) faces[0] else null
                if (f != null && f.confidence() > 0.4f) {
                    f.getMidPoint(mid)
                    val p = HeadPose()
                    p.cx = mid.x / w
                    p.cy = mid.y / hh
                    p.eye = f.eyesDistance() / w
                    res = p
                }
            } catch (t: Throwable) {
                res = null
            }
            busy = false
            val r = res
            main.post { onResult(r) }
        }
    }
}

// ------------------------------------------------------------------ view overlay (di atas preview)

/**
 * Lapisan transparan di atas preview yang menggambar prop animasi di kepala. Ukuran & posisi mengikuti TextureView
 * (rasio sama), jadi koordinat ternormalisasi sama persis dengan foto hasil. Animasi hanya berjalan saat ada prop terpilih.
 */
class PropsView(c: Context, private val radius: Float) : View(c) {
    var prop: Int = 0
        set(v) {
            if (field == v) return
            field = v
            invalidate()
        }

    private val cur = HeadPose()
    private val tgt = HeadPose()
    private var inited = false
    private var seen = 0L
    private var vis = 0f
    private var lastT = 0L
    private val t0 = SystemClock.uptimeMillis()
    private var aw = 0
    private var ah = 0
    private val hintP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hintBg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hintR = RectF()

    init {
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        clipToOutline = true
        hintP.color = 0xFFFFFFFF.toInt()
        hintP.textAlign = Paint.Align.CENTER
        hintP.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        hintBg.color = 0x99000000.toInt()
    }

    fun setAspect(w: Int, h: Int) {
        if (w == aw && h == ah) return
        aw = w
        ah = h
        requestLayout()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val maxW = MeasureSpec.getSize(wSpec)
        val maxH = MeasureSpec.getSize(hSpec)
        if (aw <= 0 || ah <= 0) {
            setMeasuredDimension(maxW, maxH)
            return
        }
        var w = maxW
        var h = (w.toLong() * ah / aw).toInt()
        if (h > maxH) {
            h = maxH
            w = (h.toLong() * aw / ah).toInt()
        }
        setMeasuredDimension(w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        invalidateOutline()
    }

    /** Hasil deteksi terbaru (thread utama). null = wajah tidak terlihat di frame ini. */
    fun onFace(p: HeadPose?) {
        if (p == null) return
        tgt.set(p)
        seen = SystemClock.uptimeMillis()
        if (!inited) {
            cur.set(p)
            inited = true
        }
        if (prop != 0) invalidate()
    }

    fun clearFace() {
        inited = false
        seen = 0L
        vis = 0f
        lastT = 0L
    }

    /** Gambar prop ke foto hasil jepretan (pose terakhir yang valid, maksimal ~2,5 dtk lalu). */
    fun drawOnto(bmp: Bitmap) {
        if (prop == 0 || !inited) return
        val now = SystemClock.uptimeMillis()
        if (now - seen > 2500L) return
        PropArt.draw(Canvas(bmp), bmp.width, bmp.height, prop, cur, (now - t0) / 1000f, 1f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (prop == 0) return
        val now = SystemClock.uptimeMillis()
        val dt = if (lastT == 0L) 0.033f else ((now - lastT).coerceIn(1L, 100L)) / 1000f
        lastT = now
        if (inited) {
            val k = 1f - exp(-dt / 0.09f)
            cur.cx += (tgt.cx - cur.cx) * k
            cur.cy += (tgt.cy - cur.cy) * k
            cur.eye += (tgt.eye - cur.eye) * k
        }
        val found = inited && now - seen < 900L
        val goal = if (found) 1f else 0f
        vis += (goal - vis) * (1f - exp(-dt / 0.12f))
        if (inited) PropArt.draw(canvas, width, height, prop, cur, (now - t0) / 1000f, vis)
        if (!found && (seen == 0L || now - seen > 1800L)) drawHint(canvas)
        postInvalidateDelayed(32L)
    }

    private fun drawHint(cv: Canvas) {
        val s = max(11f, width * 0.045f)
        hintP.textSize = s
        val txt = "Looking for your face…"
        val tw = hintP.measureText(txt)
        val cx = width / 2f
        val cy = height - s * 2.2f
        hintR.set(cx - tw / 2f - s, cy - s * 1.1f, cx + tw / 2f + s, cy + s * 0.6f)
        cv.drawRoundRect(hintR, s, s, hintBg)
        cv.drawText(txt, cx, cy, hintP)
    }
}

// ------------------------------------------------------------------ gambar prop (vektor, tanpa aset)

object PropArt {
    val names: List<String> = listOf(
        "None", "Halo", "Crown", "Cat", "Bunny", "Party",
        "Devil", "Hearts", "Stars", "Cloud", "Shades", "Flowers"
    )

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rf = RectF()
    private val TAU: Float = 6.2831855f

    private fun fill(col: Int): Paint {
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = col
        return p
    }

    private fun line(col: Int, w: Float): Paint {
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.color = col
        p.strokeWidth = w
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        return p
    }

    private fun alpha(col: Int, a: Float): Int {
        val v = (a.coerceIn(0f, 1f) * 255f).toInt()
        return (v shl 24) or (col and 0x00FFFFFF)
    }

    /** Acak deterministik 0..1 dari indeks (supaya posisi partikel stabil antar frame). */
    private fun fr(i: Int, salt: Float = 0f): Float {
        val x = sin((i + 1) * 12.9898f + salt * 78.233f) * 43758.547f
        return x - Math.floor(x.toDouble()).toFloat()
    }

    private fun cyc(x: Float): Float = x - Math.floor(x.toDouble()).toFloat()

    fun draw(cv: Canvas, w: Int, h: Int, prop: Int, pose: HeadPose, t: Float, vis: Float) {
        if (prop <= 0 || prop >= names.size || vis <= 0.02f) return
        val u = pose.eye * w
        if (u < 4f) return
        val cx = pose.cx * w
        val cy = pose.cy * h
        val top = cy - 1.75f * u
        val saved = if (vis < 0.98f) cv.saveLayerAlpha(0f, 0f, w.toFloat(), h.toFloat(), (vis * 255f).toInt()) else cv.save()
        when (prop) {
            1 -> halo(cv, cx, u, top, t)
            2 -> crown(cv, cx, u, top, t)
            3 -> cat(cv, cx, cy, u, top, t)
            4 -> bunny(cv, cx, u, top, t)
            5 -> party(cv, cx, u, top, t)
            6 -> devil(cv, cx, u, top, t)
            7 -> hearts(cv, cx, u, top, t)
            8 -> stars(cv, cx, u, top, t)
            9 -> cloud(cv, cx, cy, u, top, t)
            10 -> shades(cv, cx, cy, u, t)
            11 -> flowers(cv, cx, u, top, t)
        }
        cv.restoreToCount(saved)
    }

    // ---- bentuk dasar

    private fun sparkle(cv: Canvas, x: Float, y: Float, r: Float, col: Int) {
        val k = r * 0.26f
        path.reset()
        path.moveTo(x, y - r)
        path.quadTo(x + k, y - k, x + r, y)
        path.quadTo(x + k, y + k, x, y + r)
        path.quadTo(x - k, y + k, x - r, y)
        path.quadTo(x - k, y - k, x, y - r)
        path.close()
        cv.drawPath(path, fill(col))
    }

    private fun star(cv: Canvas, x: Float, y: Float, r: Float, rot: Float, col: Int) {
        path.reset()
        for (i in 0 until 10) {
            val rr = if (i % 2 == 0) r else r * 0.45f
            val a = rot + i * (TAU / 10f) - TAU / 4f
            val px = x + cos(a) * rr
            val py = y + sin(a) * rr
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        cv.drawPath(path, fill(col))
    }

    private fun heart(cv: Canvas, x: Float, y: Float, r: Float, col: Int) {
        path.reset()
        path.moveTo(x, y + r * 0.9f)
        path.cubicTo(x - r * 1.6f, y - r * 0.1f, x - r * 0.9f, y - r * 1.3f, x, y - r * 0.45f)
        path.cubicTo(x + r * 0.9f, y - r * 1.3f, x + r * 1.6f, y - r * 0.1f, x, y + r * 0.9f)
        path.close()
        cv.drawPath(path, fill(col))
    }

    // ---- prop

    private fun halo(cv: Canvas, cx: Float, u: Float, top: Float, t: Float) {
        val y = top - 0.30f * u + sin(t * 2.6f) * 0.06f * u
        val rx = 0.85f * u
        val ry = 0.20f * u
        cv.save()
        cv.rotate(sin(t * 1.7f) * 5f, cx, y)
        rf.set(cx - rx, y - ry, cx + rx, y + ry)
        cv.drawOval(rf, line(alpha(0xFFFFD34E.toInt(), 0.10f), 0.34f * u))
        cv.drawOval(rf, line(alpha(0xFFFFD34E.toInt(), 0.18f), 0.24f * u))
        cv.drawOval(rf, line(alpha(0xFFFFD34E.toInt(), 0.35f), 0.16f * u))
        cv.drawOval(rf, line(0xFFFFD34E.toInt(), 0.10f * u))
        cv.drawOval(rf, line(0xFFFFF6C2.toInt(), 0.035f * u))
        cv.restore()
        for (i in 0 until 4) {
            val a = t * 1.3f + i * (TAU / 4f)
            val tw = 0.5f + 0.5f * sin(t * 5f + i * 1.7f)
            sparkle(cv, cx + cos(a) * rx * 1.25f, y + sin(a) * ry * 1.5f - 0.1f * u, (0.07f + 0.10f * tw) * u, 0xFFFFFFFF.toInt())
        }
    }

    private fun crown(cv: Canvas, cx: Float, u: Float, top: Float, t: Float) {
        val wd = 1.5f * u
        val ht = 0.78f * u
        val yb = top + 0.20f * u + sin(t * 2.2f) * 0.03f * u
        cv.save()
        cv.rotate(sin(t * 1.4f) * 3f, cx, yb)
        path.reset()
        path.moveTo(cx - wd / 2f, yb)
        path.lineTo(cx - wd / 2f, yb - ht * 0.78f)
        path.lineTo(cx - wd / 4f, yb - ht * 0.38f)
        path.lineTo(cx, yb - ht)
        path.lineTo(cx + wd / 4f, yb - ht * 0.38f)
        path.lineTo(cx + wd / 2f, yb - ht * 0.78f)
        path.lineTo(cx + wd / 2f, yb)
        path.close()
        cv.drawPath(path, fill(0xFFFFC928.toInt()))
        cv.drawPath(path, line(0xFFC98A00.toInt(), 0.045f * u))
        rf.set(cx - wd / 2f, yb - 0.17f * u, cx + wd / 2f, yb)
        cv.drawRect(rf, fill(0xFFE6A100.toInt()))
        cv.drawCircle(cx - wd / 2f, yb - ht * 0.78f, 0.075f * u, fill(0xFFFFFFFF.toInt()))
        cv.drawCircle(cx, yb - ht, 0.085f * u, fill(0xFFFFFFFF.toInt()))
        cv.drawCircle(cx + wd / 2f, yb - ht * 0.78f, 0.075f * u, fill(0xFFFFFFFF.toInt()))
        cv.drawCircle(cx, yb - 0.40f * u, 0.11f * u, fill(0xFFE5243B.toInt()))
        cv.drawCircle(cx - 0.45f * u, yb - 0.32f * u, 0.08f * u, fill(0xFF2D9CFF.toInt()))
        cv.drawCircle(cx + 0.45f * u, yb - 0.32f * u, 0.08f * u, fill(0xFF2ECC71.toInt()))
        cv.restore()
        val tw = max(0f, sin(t * 3f))
        sparkle(cv, cx + 0.55f * u, yb - ht * 0.9f, (0.05f + 0.14f * tw) * u, 0xFFFFFFFF.toInt())
        val tw2 = max(0f, sin(t * 3f + 2.4f))
        sparkle(cv, cx - 0.6f * u, yb - ht * 0.55f, (0.04f + 0.11f * tw2) * u, 0xFFFFFFFF.toInt())
    }

    private fun catEar(cv: Canvas, bx: Float, by: Float, u: Float, side: Float, twitch: Float) {
        cv.save()
        cv.rotate(side * 8f + twitch, bx, by)
        path.reset()
        path.moveTo(bx - 0.40f * u, by)
        path.lineTo(bx + side * 0.06f * u, by - 1.0f * u)
        path.lineTo(bx + 0.40f * u, by)
        path.close()
        cv.drawPath(path, fill(0xFF2B2B33.toInt()))
        cv.drawPath(path, line(0xFF5A5A66.toInt(), 0.04f * u))
        path.reset()
        path.moveTo(bx - 0.24f * u, by - 0.02f * u)
        path.lineTo(bx + side * 0.05f * u, by - 0.70f * u)
        path.lineTo(bx + 0.24f * u, by - 0.02f * u)
        path.close()
        cv.drawPath(path, fill(0xFFFF8FB1.toInt()))
        cv.restore()
    }

    private fun cat(cv: Canvas, cx: Float, cy: Float, u: Float, top: Float, t: Float) {
        val by = top + 0.50f * u
        val tl = max(0f, sin(t * 0.9f)).let { it * it * it * it * it * it } * 14f
        val tr = max(0f, sin(t * 0.9f + 2.6f)).let { it * it * it * it * it * it } * -14f
        catEar(cv, cx - 0.70f * u, by, u, -1f, tl)
        catEar(cv, cx + 0.70f * u, by, u, 1f, tr)
        // hidung & kumis
        val ny = cy + 0.62f * u
        path.reset()
        path.moveTo(cx - 0.12f * u, ny - 0.07f * u)
        path.lineTo(cx + 0.12f * u, ny - 0.07f * u)
        path.lineTo(cx, ny + 0.08f * u)
        path.close()
        cv.drawPath(path, fill(0xFFFF6F9C.toInt()))
        val wp = line(0xE6FFFFFF.toInt(), 0.03f * u)
        for (s in 0 until 2) {
            val sg = if (s == 0) -1f else 1f
            for (k in 0 until 3) {
                val dy = (k - 1) * 0.16f * u
                cv.drawLine(cx + sg * 0.26f * u, ny + dy * 0.4f, cx + sg * 1.25f * u, ny + dy + sin(t * 3f + k) * 0.02f * u, wp)
            }
        }
    }

    private fun bunny(cv: Canvas, cx: Float, u: Float, top: Float, t: Float) {
        val by = top + 0.30f * u
        for (s in 0 until 2) {
            val sg = if (s == 0) -1f else 1f
            val bx = cx + sg * 0.45f * u
            val ang = sg * (9f + 5f * sin(t * 1.9f + s * 1.3f)) + (if (s == 0) 0f else 2f * sin(t * 4f))
            cv.save()
            cv.rotate(ang, bx, by)
            rf.set(bx - 0.23f * u, by - 1.75f * u, bx + 0.23f * u, by + 0.05f * u)
            cv.drawOval(rf, fill(0xFFFFFFFF.toInt()))
            cv.drawOval(rf, line(0xFFD9D9E3.toInt(), 0.035f * u))
            rf.set(bx - 0.13f * u, by - 1.55f * u, bx + 0.13f * u, by - 0.12f * u)
            cv.drawOval(rf, fill(0xFFFFB3C9.toInt()))
            cv.restore()
        }
    }

    private fun party(cv: Canvas, cx: Float, u: Float, top: Float, t: Float) {
        val by = top + 0.32f * u
        val bw = 1.05f * u
        val th = 1.45f * u
        cv.save()
        cv.rotate(10f + sin(t * 2f) * 2.5f, cx, by)
        path.reset()
        path.moveTo(cx - bw / 2f, by)
        path.lineTo(cx + bw / 2f, by)
        path.lineTo(cx, by - th)
        path.close()
        cv.drawPath(path, fill(0xFFFF5FA2.toInt()))
        cv.save()
        cv.clipPath(path)
        val bandH = th / 6f
        for (k in 0 until 6) {
            if (k % 2 == 0) continue
            rf.set(cx - bw, by - (k + 1) * bandH, cx + bw, by - k * bandH)
            cv.drawRect(rf, fill(0xFFFFE066.toInt()))
        }
        cv.restore()
        cv.drawPath(path, line(0xFFB8336E.toInt(), 0.04f * u))
        val bounce = abs(sin(t * 5f)) * 0.07f * u
        cv.drawCircle(cx, by - th - bounce, 0.16f * u, fill(0xFFFFFFFF.toInt()))
        cv.restore()
        val cols = intArrayOf(0xFFFF5FA2.toInt(), 0xFFFFE066.toInt(), 0xFF4DD6FF.toInt(), 0xFF7CFF8A.toInt(), 0xFFB48CFF.toInt())
        for (i in 0 until 16) {
            val ph = cyc(t * 0.42f + fr(i) * 1.7f)
            val x = cx + (fr(i, 1f) - 0.5f) * 3.4f * u + sin(t * 2f + i) * 0.1f * u
            val y = top - 1.3f * u + ph * 4.2f * u
            cv.save()
            cv.rotate(t * 160f + i * 40f, x, y)
            rf.set(x - 0.06f * u, y - 0.035f * u, x + 0.06f * u, y + 0.035f * u)
            cv.drawRect(rf, fill(alpha(cols[i % cols.size], 1f - ph * 0.6f)))
            cv.restore()
        }
    }

    private fun devil(cv: Canvas, cx: Float, u: Float, top: Float, t: Float) {
        val by = top + 0.55f * u
        val pulse = 0.5f + 0.5f * sin(t * 3.2f)
        for (s in 0 until 2) {
            val sg = if (s == 0) -1f else 1f
            val bx = cx + sg * 0.62f * u
            val tx = bx + sg * 0.34f * u
            val ty = by - 0.85f * u
            cv.drawCircle(tx, ty, (0.35f + 0.12f * pulse) * u, fill(alpha(0xFFFF5A1F.toInt(), 0.10f + 0.10f * pulse)))
            path.reset()
            path.moveTo(bx - 0.20f * u, by + 0.02f * u)
            path.quadTo(bx - 0.18f * u + sg * 0.02f * u, by - 0.50f * u, tx, ty)
            path.quadTo(bx + 0.26f * u, by - 0.40f * u, bx + 0.20f * u, by + 0.02f * u)
            path.close()
            cv.drawPath(path, fill(0xFFE03131.toInt()))
            cv.drawPath(path, line(0xFF8F1313.toInt(), 0.04f * u))
            // bara api naik dari ujung tanduk
            for (k in 0 until 3) {
                val ph = cyc(t * 0.9f + k * 0.34f + s * 0.17f)
                val ex = tx + sin(t * 3f + k * 2f + s) * 0.10f * u
                val ey = ty - ph * 0.9f * u
                cv.drawCircle(ex, ey, (1f - ph) * 0.07f * u, fill(alpha(0xFFFFB02E.toInt(), 1f - ph)))
            }
        }
    }

    private fun hearts(cv: Canvas, cx: Float, u: Float, top: Float, t: Float) {
        val n = 10
        val cols = intArrayOf(0xFFFF3B6B.toInt(), 0xFFFF7BAE.toInt(), 0xFFFF5A5A.toInt(), 0xFFFFA3C7.toInt())
        for (i in 0 until n) {
            val ph = cyc(t * 0.38f + i.toFloat() / n)
            val x = cx + (i.toFloat() / n - 0.5f) * 2.3f * u + sin(t * 1.6f + i * 1.9f) * 0.22f * u
            val y = top + 0.55f * u - ph * 2.4f * u
            val grow = min(1f, ph / 0.15f)
            val r = (0.13f + 0.12f * fr(i, 2f)) * u * grow
            heart(cv, x, y, r, alpha(cols[i % cols.size], min(1f, (1f - ph) * 1.4f)))
        }
    }

    private fun stars(cv: Canvas, cx: Float, u: Float, top: Float, t: Float) {
        val y0 = top + 0.02f * u
        val rx = 1.25f * u
        val ry = 0.30f * u
        val n = 6
        for (i in 0 until n) {
            val a = t * 2.4f + i * (TAU / n)
            val x = cx + cos(a) * rx
            val y = y0 + sin(a) * ry
            val depth = 0.5f + 0.5f * sin(a)
            val r = (0.10f + 0.10f * depth) * u
            star(cv, x, y, r, t * 2f + i, if (i % 2 == 0) 0xFFFFE066.toInt() else 0xFFFFFFFF.toInt())
            val tx = cx + cos(a - 0.35f) * rx
            val ty = y0 + sin(a - 0.35f) * ry
            cv.drawCircle(tx, ty, r * 0.28f, fill(alpha(0xFFFFE066.toInt(), 0.5f)))
        }
        for (i in 0 until 3) {
            val tw = max(0f, sin(t * 4f + i * 2.1f))
            sparkle(cv, cx + (i - 1) * 0.9f * u, y0 - 0.55f * u - i % 2 * 0.2f * u, 0.10f * tw * u, 0xFFFFFFFF.toInt())
        }
    }

    private fun cloud(cv: Canvas, cx: Float, cy: Float, u: Float, top: Float, t: Float) {
        val y = top - 0.55f * u + sin(t * 1.8f) * 0.05f * u
        val flash = (t % 3.6f) < 0.16f
        val body = if (flash) 0xFFEFF3FF.toInt() else 0xFFB8C4D6.toInt()
        val shade = if (flash) 0xFFD6DEF5.toInt() else 0xFF8D9BB3.toInt()
        cv.drawCircle(cx - 0.55f * u, y + 0.12f * u, 0.46f * u, fill(shade))
        cv.drawCircle(cx + 0.58f * u, y + 0.12f * u, 0.44f * u, fill(shade))
        cv.drawCircle(cx - 0.5f * u, y + 0.04f * u, 0.46f * u, fill(body))
        cv.drawCircle(cx + 0.5f * u, y + 0.04f * u, 0.44f * u, fill(body))
        cv.drawCircle(cx - 0.08f * u, y - 0.18f * u, 0.60f * u, fill(body))
        rf.set(cx - 0.55f * u, y - 0.05f * u, cx + 0.58f * u, y + 0.50f * u)
        cv.drawRect(rf, fill(body))
        val cb = y + 0.50f * u
        val bottom = top + 1.05f * u
        val dp = line(0xFF4DA3FF.toInt(), 0.05f * u)
        for (i in 0 until 12) {
            val ph = cyc(t * 1.15f + fr(i, 3f))
            val x = cx + (i / 11f - 0.5f) * 1.75f * u
            val yy = cb + 0.1f * u + ph * (bottom - cb)
            dp.alpha = (min(1f, (1f - ph) * 2f) * 255f).toInt()
            cv.drawLine(x, yy, x - 0.03f * u, yy + 0.2f * u, dp)
        }
        if (flash) {
            path.reset()
            path.moveTo(cx + 0.05f * u, cb)
            path.lineTo(cx - 0.18f * u, cb + 0.55f * u)
            path.lineTo(cx, cb + 0.5f * u)
            path.lineTo(cx - 0.12f * u, cb + 1.1f * u)
            path.lineTo(cx + 0.22f * u, cb + 0.4f * u)
            path.lineTo(cx + 0.04f * u, cb + 0.44f * u)
            path.close()
            cv.drawPath(path, fill(0xFFFFE94D.toInt()))
        }
    }

    private fun shades(cv: Canvas, cx: Float, cy: Float, u: Float, t: Float) {
        val lw = 0.96f * u
        val lh = 0.64f * u
        val y = cy + 0.02f * u
        val fc = 0xFF0E0F14.toInt()
        for (s in 0 until 2) {
            val sg = if (s == 0) -1f else 1f
            val ex = cx + sg * 0.5f * u
            rf.set(ex - lw / 2f, y - lh / 2f, ex + lw / 2f, y + lh / 2f)
            val rr = 0.22f * u
            cv.drawRoundRect(rf, rr, rr, fill(0xEE111318.toInt()))
            cv.save()
            path.reset()
            path.addRoundRect(rf, rr, rr, Path.Direction.CW)
            cv.clipPath(path)
            cv.drawRect(rf.left, rf.top, rf.right, y - 0.02f * u, fill(0x22FFFFFF))
            val sw = cyc(t * 0.45f) * 2.4f - 0.7f
            val gx = rf.left + sw * lw
            val gp = line(0x55FFFFFF, 0.10f * u)
            cv.drawLine(gx, rf.bottom + 0.1f * u, gx + 0.35f * u, rf.top - 0.1f * u, gp)
            cv.drawLine(gx + 0.17f * u, rf.bottom + 0.1f * u, gx + 0.52f * u, rf.top - 0.1f * u, line(0x33FFFFFF, 0.05f * u))
            cv.restore()
            cv.drawRoundRect(rf, rr, rr, line(fc, 0.055f * u))
            cv.drawLine(ex + sg * lw / 2f, y - 0.1f * u, ex + sg * (lw / 2f + 0.55f * u), y - 0.18f * u, line(fc, 0.06f * u))
        }
        cv.drawLine(cx - 0.02f * u, y - 0.08f * u, cx + 0.02f * u, y - 0.08f * u, line(fc, 0.07f * u))
    }

    private fun flowers(cv: Canvas, cx: Float, u: Float, top: Float, t: Float) {
        val ccx = cx
        val ccy = top + 0.95f * u
        val rx = 1.08f * u
        val ry = 0.92f * u
        val petals = intArrayOf(0xFFFF7BAE.toInt(), 0xFFFFFFFF.toInt(), 0xFFB48CFF.toInt(), 0xFFFFA64D.toInt(), 0xFFFF5F8A.toInt())
        val n = 7
        // daun di sela bunga
        val lp = fill(0xFF3DBB6D.toInt())
        for (i in 0 until n - 1) {
            val a = PI.toFloat() * (1.12f + 0.76f * (i + 0.5f) / (n - 1))
            val x = ccx + cos(a) * rx
            val y = ccy + sin(a) * ry
            cv.save()
            cv.rotate((a * 180f / PI.toFloat()) + 90f, x, y)
            rf.set(x - 0.07f * u, y - 0.2f * u, x + 0.07f * u, y + 0.2f * u)
            cv.drawOval(rf, lp)
            cv.restore()
        }
        for (i in 0 until n) {
            val a = PI.toFloat() * (1.12f + 0.76f * i / (n - 1))
            val x = ccx + cos(a) * rx
            val y = ccy + sin(a) * ry
            val sc = 1f + 0.08f * sin(t * 2.4f + i)
            val r = 0.15f * u * sc
            val col = petals[i % petals.size]
            for (k in 0 until 5) {
                val pa = t * 0.5f + k * (TAU / 5f) + i
                cv.drawCircle(x + cos(pa) * r * 0.95f, y + sin(pa) * r * 0.95f, r * 0.62f, fill(col))
            }
            cv.drawCircle(x, y, r * 0.5f, fill(0xFFFFD84D.toInt()))
        }
        val tw = max(0f, sin(t * 3.2f))
        sparkle(cv, ccx + 0.7f * u, ccy - 0.95f * u, (0.04f + 0.10f * tw) * u, 0xFFFFFFFF.toInt())
    }
}
