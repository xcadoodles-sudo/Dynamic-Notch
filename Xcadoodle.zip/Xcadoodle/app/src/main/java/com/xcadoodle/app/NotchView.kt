package com.xcadoodle.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Jembatan ke WindowManager milik service (tipe jendela, posisi, add/remove). */
interface OverlayHost {
    fun params(w: Int, h: Int): WindowManager.LayoutParams
    fun add(v: View, lp: WindowManager.LayoutParams): Boolean
    fun remove(v: View)
}

/**
 * Notch yang menempel di tepi atas layar (atas datar + telinga cekung, bawah melengkung).
 * COMPACT : pil (maskot / album art di kiri, equalizer di kanan)
 * ALERT   : melebar sebentar untuk notifikasi
 * PANEL   : ketuk pil -> Music / Device / Markets / Calendar / Shelf
 *
 * Arsitektur animasi (kenapa tidak goyang lagi):
 *  - Jendela TIDAK PERNAH di-resize selagi terlihat. Pil punya jendela kecil tetap. Untuk ALERT/PANEL
 *    dibuat jendela baru berukuran tetap (sebesar bentuk maksimumnya). Frame pertamanya menggambar
 *    bentuk yang persis sama dengan pil, jadi pergantian jendela tidak terlihat; baru setelah itu
 *    bentuknya dimorph (outline + siluet saja, tanpa layout ulang).
 *  - Saat menutup, bentuk dimorph kembali ke pil, lalu jendela tambahan dibuang.
 *  - Isi lama (pil/alert) tampil sebagai "ghost" (bitmap) yang memudar selama morph.
 */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class NotchView(private val svc: Context, private val media: MediaWatcher, private val host: OverlayHost) : FrameLayout(svc) {
    enum class S { COMPACT, ALERT, PANEL }

    companion object {
        private const val TABS_H = 38
        private const val BODY_PAD_V = 16 // 4 atas + 12 bawah
        private const val PANEL_W = 620
        private const val ALERT_H = 68
        private const val EAR_DP = 10
        private val TAB_H = intArrayOf(196, 196, 290, 290, 290)
    }

    private val ui = Handler(Looper.getMainLooper())
    private val choreo = Choreographer.getInstance()
    var state = S.COMPACT
        private set

    private var flat = Xcadoodle.prefs.topOffset == 0
    private val earPx: Float get() = if (flat) svc.dpf(EAR_DP) else 0f

    /** Ukuran jendela pil (tetap). Dipakai service saat memasang jendela. */
    val winW: Int = evenW(maxOf(svc.dp(Xcadoodle.prefs.notchW), svc.dp(120)) + 2 * earPx.toInt() + svc.dp(24))
    val winH: Int = svc.dp(Xcadoodle.prefs.notchH) + svc.dp(2)

    private val pill = NotchShape(svc)
    private var cur: Stage? = null      // jendela tambahan yang sedang tampil
    private var pend: Stage? = null     // jendela tambahan yang sedang disiapkan (belum tergambar)
    private var closing = false

    private val tabGlow = arrayOf(
        intArrayOf(0xFFFF9A3D.toInt(), 0xFFFF3D7F.toInt()), // music: sunrise oranye -> pink
        intArrayOf(0xFF3DDCFF.toInt(), 0xFF3D6BFF.toInt()), // device: cyan -> biru
        intArrayOf(0xFF35E08A.toInt(), 0xFF12A39A.toInt()), // markets: hijau -> teal
        intArrayOf(0xFFB06BFF.toInt(), 0xFFFF5FB5.toInt()), // calendar: ungu -> magenta
        intArrayOf(0xFFFFD04D.toInt(), 0xFFFF8A3D.toInt())  // shelf: kuning -> oranye
    )

    private var tintArt: Bitmap? = null
    private var tintCache = C.BLACK

    private val compact = LinearLayout(svc)
    private val alertBox = LinearLayout(svc)
    private val panelBox = LinearLayout(svc)

    // --- compact
    private val pet = PetView(svc)
    private val miniArt = ImageView(svc)
    private val gap = View(svc)
    private val eq = EqView(svc)
    private var lastMiniArt: Bitmap? = null

    // --- alert
    private val aIconBox = FrameLayout(svc)
    private val aGlyph = svc.tv("", 18f, C.TEXT, true)
    private val aImg = ImageView(svc)
    private val aTitle = svc.tv("", 15f, C.TEXT, true)
    private val aSub = svc.tv("", 13f, 0x99FFFFFF.toInt())
    private var current: Alert? = null
    private val queue = java.util.ArrayDeque<Alert>()

    // --- panel
    private val tabsRow = LinearLayout(svc)
    private val body = FrameLayout(svc)
    private val music = MusicPanel(svc, media)
    private val device = DevicePanel(svc)
    private val markets = MarketsPanel(svc)
    private val calendar = CalendarPanel(svc)
    private val shelf = ShelfPanel(svc)
    private val panels: List<View> = listOf(music, device, markets, calendar, shelf)
    private val tabIcons = listOf("♪", "📱", "📈", "📅", "📁")
    private val tabViews = ArrayList<TextView>()
    private var tab = 0

    private val endAlert = Runnable {
        current = null
        val n = queue.poll()
        if (n != null) showAlert(n) else showCompact()
    }

    private val uiTick = object : Runnable {
        override fun run() {
            pet.paused = state != S.COMPACT
            when (state) {
                S.COMPACT -> if (!closing) {
                    updateCompact()
                    if (cur == null && pend == null && !pill.animating) fitCompact()
                }
                S.PANEL -> {
                    val st = cur
                    if (st != null && !st.shape.animating) {
                        (panels[tab] as Refreshable).refresh()
                        st.shape.animateTint(wantedTint())
                    }
                }
                S.ALERT -> {
                }
            }
            ui.postDelayed(this, 500)
        }
    }

    // ------------------------------------------------------------ jendela tambahan

    /** Satu jendela tambahan (ALERT atau PANEL), ukuran tetap selama hidupnya. */
    private inner class Stage(val kind: S) : FrameLayout(svc) {
        val shape = NotchShape(svc)
        val glow = GlowView(svc)
        var ghost: ImageView? = null

        init {
            shape.flat = flat
            shape.ear = earPx
            addView(shape, LayoutParams(MATCH, MATCH))
            shape.content.addView(glow, LayoutParams(MATCH, MATCH))
        }

        fun setGhost(b: Bitmap, alpha: Float) {
            ghost?.let { shape.content.removeView(it) }
            val iv = ImageView(svc)
            iv.setImageBitmap(b)
            iv.alpha = alpha
            shape.content.addView(iv, LayoutParams(b.width, b.height, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
            ghost = iv
        }

        fun attach(v: View, w: Int, h: Int) {
            (v.parent as? ViewGroup)?.removeView(v)
            v.pivotX = w / 2f
            v.pivotY = 0f
            shape.content.addView(v, LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        }

        fun release() {
            shape.release()
            for (v in arrayOf<View>(alertBox, panelBox)) {
                if (v.parent === shape.content) shape.content.removeView(v)
            }
        }

        /** Panggil [cb] setelah jendela ini benar-benar tergambar (frame pertama + 1-2 frame). */
        fun whenDrawn(cb: () -> Unit) {
            var fired = false
            val fire = Runnable {
                if (!fired) {
                    fired = true
                    cb()
                }
            }
            viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
                override fun onPreDraw(): Boolean {
                    if (viewTreeObserver.isAlive) viewTreeObserver.removeOnPreDrawListener(this)
                    choreo.postFrameCallback { choreo.postFrameCallback { fire.run() } }
                    return true
                }
            })
            postDelayed(fire, 160) // pengaman kalau PreDraw tidak pernah datang
        }

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            if (stageGate(this, ev)) return true
            return super.dispatchTouchEvent(ev)
        }
    }

    /** true = sentuhan sudah ditangani/ditelan. */
    private fun stageGate(st: Stage, ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_OUTSIDE) {
            if (state == S.PANEL && st === cur && !closing) showCompact()
            return true
        }
        if (closing) return true
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            val cx = st.width / 2f
            val half = st.shape.vW / 2f + st.shape.ear
            val inside = ev.x >= cx - half && ev.x <= cx + half && ev.y <= st.shape.vH
            if (!inside) {
                // ketukan di area transparan (di luar bentuk) dianggap ketukan di luar panel
                if (state == S.PANEL && st === cur) showCompact()
                return true
            }
        }
        return false
    }

    init {
        pill.flat = flat
        pill.ear = earPx

        // ---------- compact: kiri maskot/art, kanan equalizer, tengah kosong (seperti notch MacBook)
        compact.orientation = LinearLayout.HORIZONTAL
        compact.gravity = Gravity.CENTER_VERTICAL
        compact.setPadding(svc.dp(12), 0, svc.dp(12), 0)
        compact.addView(pet, LinearLayout.LayoutParams(svc.dp(24), MATCH, 1f))
        pet.setOnClickListener {
            pet.poke()
            compact.performClick()
        }
        pet.setOnLongClickListener {
            pet.pat()
            true
        }
        miniArt.scaleType = ImageView.ScaleType.CENTER_CROP
        miniArt.roundClip(svc.dpf(6))
        compact.addView(miniArt, LinearLayout.LayoutParams(svc.dp(20), svc.dp(20)))
        compact.addView(gap, LinearLayout.LayoutParams(svc.dp(36), 1, 1f))
        compact.addView(eq, LinearLayout.LayoutParams(svc.dp(18), svc.dp(14)))
        compact.setOnClickListener {
            if (state == S.COMPACT && cur == null && pend == null && !closing) {
                showPanel(if (media.hasSession && media.playing) 0 else Xcadoodle.prefs.lastTab.coerceIn(0, panels.size - 1))
            }
        }

        // ---------- alert
        alertBox.orientation = LinearLayout.HORIZONTAL
        alertBox.gravity = Gravity.CENTER_VERTICAL
        alertBox.setPadding(svc.dp(14), 0, svc.dp(18), 0)
        aGlyph.gravity = Gravity.CENTER
        aIconBox.addView(aGlyph, LayoutParams(MATCH, MATCH))
        aImg.scaleType = ImageView.ScaleType.FIT_CENTER
        aImg.roundClip(svc.dpf(10))
        aIconBox.addView(aImg, LayoutParams(MATCH, MATCH))
        alertBox.addView(aIconBox, svc.llp(svc.dp(40), svc.dp(40)))
        val tcol = LinearLayout(svc)
        tcol.orientation = LinearLayout.VERTICAL
        aTitle.maxLines = 1
        aTitle.ellipsize = TextUtils.TruncateAt.END
        aSub.maxLines = 1
        aSub.ellipsize = TextUtils.TruncateAt.END
        tcol.addView(aTitle)
        tcol.addView(aSub, svc.llp(WRAP, WRAP, 0f, 0, 3, 0, 0))
        alertBox.addView(tcol, svc.llp(0, WRAP, 1f, 12, 0, 0, 0))
        alertBox.setOnClickListener {
            val a = current
            ui.removeCallbacks(endAlert)
            queue.clear()
            current = null
            a?.onClick?.invoke()
            if (a != null && a.tab >= 0) showPanel(a.tab) else showCompact()
        }

        // ---------- panel: strip ikon tab di atas, isi di bawah
        panelBox.orientation = LinearLayout.VERTICAL
        tabsRow.orientation = LinearLayout.HORIZONTAL
        tabsRow.gravity = Gravity.CENTER_VERTICAL
        tabsRow.setPadding(svc.dp(14), 0, svc.dp(10), 0)
        for (i in tabIcons.indices) {
            val t = svc.tv(tabIcons[i], 16f, C.TEXT, true)
            t.gravity = Gravity.CENTER
            t.setOnClickListener { selectTab(i) }
            tabViews.add(t)
            tabsRow.addView(t, svc.llp(0, svc.dp(30), 1f, 4, 0, 4, 0))
        }
        val close = svc.tv("⌃", 18f, 0x99FFFFFF.toInt(), true)
        close.setPadding(svc.dp(12), svc.dp(2), svc.dp(4), svc.dp(2))
        close.setOnClickListener { showCompact() }
        tabsRow.addView(close)
        panelBox.addView(tabsRow, svc.llp(MATCH, svc.dp(TABS_H)))
        body.setPadding(svc.dp(18), svc.dp(4), svc.dp(18), svc.dp(12))
        for (i in panels.indices) {
            // tinggi isi tiap panel tetap (sesuai tabnya) -> tidak ada relayout saat pindah tab
            val ph = svc.dp(TAB_H[i] - TABS_H - BODY_PAD_V)
            panels[i].visibility = GONE
            body.addView(panels[i], LayoutParams(MATCH, ph, Gravity.TOP))
        }
        panelBox.addView(body, svc.llp(MATCH, 0, 1f))

        val (w, h) = compactSize()
        pill.setShapeNow(w.toFloat(), h.toFloat(), compactR(h))
        pill.content.addView(compact, LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        addView(pill, LayoutParams(MATCH, MATCH))
        updateCompact()
    }

    // ------------------------------------------------------------ util

    private fun screenW(): Int {
        return if (Build.VERSION.SDK_INT >= 30) {
            (svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager).currentWindowMetrics.bounds.width()
        } else {
            resources.displayMetrics.widthPixels
        }
    }

    /** Lebar jendela dibuat berparitas sama dengan layar supaya semua jendela persis sepusat. */
    private fun evenW(w: Int): Int = if ((screenW() - w) % 2 != 0) w + 1 else w

    private fun tintFrom(art: Bitmap): Int {
        if (art === tintArt) return tintCache
        var out = C.BLACK
        try {
            val px = Bitmap.createScaledBitmap(art, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(px, hsv)
            hsv[1] = (hsv[1] * 1.15f).coerceAtMost(0.85f)
            hsv[2] = 0.30f
            out = Color.HSVToColor(hsv)
        } catch (e: Exception) {
        }
        tintArt = art
        tintCache = out
        return out
    }

    private fun wantedTint(): Int {
        if (state == S.PANEL && tab == 0 && media.hasSession) {
            val art = media.art
            if (art != null) return tintFrom(art)
        }
        return C.BLACK
    }

    private fun smooth(x: Float): Float {
        val u = x.coerceIn(0f, 1f)
        return u * u * (3f - 2f * u)
    }

    /** Foto isi sebuah view (untuk ghost). fw/fh > 0 memaksa layout ke ukuran itu dulu. */
    private fun snapshot(v: View, fw: Int = 0, fh: Int = 0): Bitmap? {
        try {
            var w = v.width
            var h = v.height
            if (fw > 0 && fh > 0) {
                v.measure(
                    View.MeasureSpec.makeMeasureSpec(fw, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(fh, View.MeasureSpec.EXACTLY)
                )
                v.layout(0, 0, fw, fh)
                w = fw
                h = fh
            }
            if (w <= 0 || h <= 0) return null
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            v.draw(Canvas(b))
            return b
        } catch (e: Throwable) {
            return null
        }
    }

    private fun notifyVisibility() {
        for (i in panels.indices) (panels[i] as? PanelLife)?.onVisible(state == S.PANEL && tab == i)
    }

    // ------------------------------------------------------------ compact

    private fun updateCompact() {
        val pr = Xcadoodle.prefs
        val minimal = pr.minimal
        val musicOn = media.hasSession && media.playing
        val art = media.art
        val showArt = musicOn && art != null && !minimal
        val showPet = !minimal && pr.pet && !showArt
        pet.visibility = if (showPet) VISIBLE else GONE
        gap.visibility = if (showPet) GONE else VISIBLE
        miniArt.visibility = if (showArt) VISIBLE else GONE
        if (showArt && lastMiniArt !== art) {
            lastMiniArt = art
            miniArt.setImageBitmap(art)
        }
        val showEq = musicOn && !minimal
        eq.visibility = if (showEq) VISIBLE else GONE
        eq.setArt(art)
        eq.active = media.playing
    }

    private fun compactSize(): Pair<Int, Int> {
        compact.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        val minimal = Xcadoodle.prefs.minimal
        val bw = svc.dp(Xcadoodle.prefs.notchW)
        val bh = svc.dp(Xcadoodle.prefs.notchH)
        val minW = if (minimal) (bw * 0.75f).toInt() else bw
        val h = if (minimal) (bh * 0.8f).toInt() else bh
        val maxW = winW - 2 * earPx.toInt() - svc.dp(8)
        return Pair(minOf(maxOf(minW, compact.measuredWidth + svc.dp(8)), maxW), minOf(h, winH))
    }

    /** Menempel di tepi: sudut bawah agak kotak. Melayang: pil bulat penuh. */
    private fun compactR(h: Int): Float = if (flat) h * 0.42f else h / 2f

    private fun setCompactLp(w: Int, h: Int) {
        compact.layoutParams = LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
    }

    /** Pil menyesuaikan isi (musik mulai/berhenti): hanya bentuk yang beranimasi, jendela tetap. */
    private fun fitCompact() {
        val (w, h) = compactSize()
        if (Math.abs(pill.vW - w) > svc.dp(2) || Math.abs(pill.vH - h) > 1f) {
            // isi dilebarkan dulu ke ukuran terbesar supaya tidak terpotong selama morph
            setCompactLp(maxOf(w, Math.ceil(pill.vW.toDouble()).toInt()), h)
            pill.animate(w.toFloat(), h.toFloat(), compactR(h), C.BLACK, 280, 12f, null) {
                setCompactLp(w, h)
            }
        }
    }

    private fun resetPillNow() {
        updateCompact()
        val (w, h) = compactSize()
        setCompactLp(w, h)
        pill.setShapeNow(w.toFloat(), h.toFloat(), compactR(h))
        pill.setTintNow(C.BLACK)
    }

    // ------------------------------------------------------------ buka/tutup jendela tambahan

    private fun alertW(): Int = minOf((screenW() * 0.9f).toInt(), svc.dp(400))

    private fun panelW(): Int = minOf(screenW() - svc.dp(24), svc.dp(PANEL_W))

    private fun panelH(t: Int): Int = svc.dp(TAB_H[t])

    private fun stageW(contentW: Int): Int = evenW(contentW + 2 * earPx.toInt() + svc.dp(4))

    private fun removeStage(st: Stage) {
        st.release()
        host.remove(st)
    }

    private fun cancelPending() {
        val p = pend ?: return
        pend = null
        removeStage(p)
    }

    private fun abortStages() {
        cancelPending()
        cur?.let { removeStage(it) }
        cur = null
        closing = false
        pill.release()
    }

    /**
     * Siapkan jendela baru untuk [kind], bentuk awalnya = bentuk yang sedang tampil
     * (pil, atau stage lama kalau [from] != null). Animasi baru jalan setelah jendela tergambar.
     */
    private fun openStage(kind: S, from: Stage?) {
        cancelPending()
        val sw: Int
        val sh: Int
        if (kind == S.PANEL) {
            sw = stageW(panelW())
            sh = svc.dp(TAB_H.max())
        } else {
            sw = stageW(alertW())
            sh = svc.dp(ALERT_H)
        }
        val st = Stage(kind)
        val src = from?.shape ?: pill
        st.shape.setShapeNow(src.vW, src.vH, src.vR)
        st.shape.setTintNow(src.tint)

        // isi lama jadi ghost (tampak identik dengan yang ada di jendela lama)
        val ghostBmp = if (from != null) snapshot(alertBox) else snapshot(compact)
        if (ghostBmp != null) st.setGhost(ghostBmp, 1f)

        // isi baru (transparan dulu, dimunculkan oleh animasi)
        if (kind == S.PANEL) {
            panelBox.alpha = 0f
            panelBox.scaleX = 0.94f
            panelBox.scaleY = 0.94f
            panelBox.visibility = VISIBLE
            st.attach(panelBox, panelW(), sh)
        } else {
            alertBox.alpha = 0f
            alertBox.scaleX = 0.94f
            alertBox.scaleY = 0.94f
            alertBox.visibility = VISIBLE
            st.attach(alertBox, alertW(), svc.dp(ALERT_H))
        }

        pend = st
        st.whenDrawn { onStageReady(st, from) }
        if (!host.add(st, host.params(sw, sh))) {
            pend = null
            st.release()
            state = S.COMPACT
            resetPillNow()
        }
    }

    private fun onStageReady(st: Stage, from: Stage?) {
        if (pend !== st) return
        pend = null
        cur = st
        if (from != null) removeStage(from)
        if (st.kind == S.PANEL) animateOpenPanel(st) else animateOpenAlert(st)
    }

    private fun animateOpenPanel(st: Stage) {
        notifyVisibility()
        val g = tabGlow[tab]
        st.glow.flash(g[0], g[1])
        st.shape.animate(panelW().toFloat(), panelH(tab).toFloat(), svc.dpf(28), wantedTint(), 480, 9f, { f ->
            st.glow.setVisible(st.shape.vW, st.shape.vH)
            st.ghost?.alpha = 1f - smooth(f / 0.3f)
            val a = smooth((f - 0.22f) / 0.5f)
            panelBox.alpha = a
            val s = 0.94f + 0.06f * a
            panelBox.scaleX = s
            panelBox.scaleY = s
        }) {
            panelBox.alpha = 1f
            panelBox.scaleX = 1f
            panelBox.scaleY = 1f
            st.ghost?.alpha = 0f
        }
    }

    private fun animateOpenAlert(st: Stage) {
        ui.removeCallbacks(endAlert)
        ui.postDelayed(endAlert, current?.ms ?: 3500L)
        st.shape.animate(alertW().toFloat(), svc.dp(ALERT_H).toFloat(), svc.dpf(30), C.BLACK, 420, 9.5f, { f ->
            st.ghost?.alpha = 1f - smooth(f / 0.3f)
            val a = smooth((f - 0.2f) / 0.55f)
            alertBox.alpha = a
            val s = 0.94f + 0.06f * a
            alertBox.scaleX = s
            alertBox.scaleY = s
        }) {
            alertBox.alpha = 1f
            alertBox.scaleX = 1f
            alertBox.scaleY = 1f
            st.ghost?.alpha = 0f
        }
    }

    private fun closeStage(st: Stage) {
        if (closing) return
        closing = true
        ui.removeCallbacks(endAlert)
        updateCompact()
        val (w, h) = compactSize()
        setCompactLp(w, h)
        // pil di bawah langsung siap di bentuk akhir (tertutup stage sampai morph selesai)
        pill.setShapeNow(w.toFloat(), h.toFloat(), compactR(h))
        pill.setTintNow(C.BLACK)
        val bmp = snapshot(compact, w, h)
        if (bmp != null) st.setGhost(bmp, 0f)
        st.glow.hide()

        val box: View = if (st.kind == S.PANEL) panelBox else alertBox
        val a0 = box.alpha
        st.shape.animate(w.toFloat(), h.toFloat(), compactR(h), C.BLACK, 340, 10f, { f ->
            st.glow.setVisible(st.shape.vW, st.shape.vH)
            val o = 1f - smooth(f / 0.38f)
            box.alpha = a0 * o
            val s = 0.96f + 0.04f * o
            box.scaleX = s
            box.scaleY = s
            st.ghost?.alpha = smooth((f - 0.5f) / 0.45f)
        }) {
            removeStage(st)
            cur = null
            closing = false
            box.alpha = 1f
            box.scaleX = 1f
            box.scaleY = 1f
            updateCompact()
            val n = queue.poll()
            if (n != null) showAlert(n)
        }
    }

    // ------------------------------------------------------------ public API

    fun showCompact() {
        ui.removeCallbacks(endAlert)
        if (closing) return
        if (state == S.COMPACT && cur == null && pend == null) {
            updateCompact()
            fitCompact()
            return
        }
        state = S.COMPACT
        current = null
        cancelPending()
        notifyVisibility()
        val st = cur
        if (st == null) {
            resetPillNow()
            return
        }
        closeStage(st)
    }

    fun enqueue(a: Alert) {
        pet.perk()
        when {
            state == S.PANEL -> return
            state == S.ALERT || closing || pend != null -> if (queue.size < 4) queue.add(a)
            else -> showAlert(a)
        }
    }

    private fun showAlert(a: Alert) {
        state = S.ALERT
        current = a
        aTitle.text = a.title
        aSub.text = a.sub
        if (a.icon != null) {
            aImg.visibility = VISIBLE
            aImg.setImageDrawable(a.icon)
            aGlyph.visibility = GONE
            aIconBox.background = null
        } else {
            aImg.visibility = GONE
            aGlyph.visibility = VISIBLE
            aGlyph.text = a.glyph
            aIconBox.background = rounded(a.color, svc.dpf(20))
        }
        val st = cur
        if (st != null && st.kind == S.ALERT && !closing) {
            // alert berikutnya: jendela sama, isi diganti dengan fade singkat
            alertBox.alpha = 0f
            alertBox.animate().alpha(1f).setDuration(180).start()
            ui.removeCallbacks(endAlert)
            ui.postDelayed(endAlert, a.ms)
            return
        }
        openStage(S.ALERT, null)
    }

    private fun styleTabs() {
        for (i in tabViews.indices) {
            val sel = i == tab
            tabViews[i].alpha = if (sel) 1f else 0.45f
            tabViews[i].background = if (sel) rounded(0x26FFFFFF, svc.dpf(100)) else null
        }
    }

    private fun preparePanels() {
        for (i in panels.indices) {
            panels[i].alpha = 1f
            panels[i].visibility = if (i == tab) VISIBLE else GONE
        }
        styleTabs()
        (panels[tab] as Refreshable).refresh()
    }

    fun showPanel(t: Int) {
        if (closing) return
        ui.removeCallbacks(endAlert)
        queue.clear()
        current = null
        val nt = t.coerceIn(0, panels.size - 1)
        if (state == S.PANEL && cur != null) {
            selectTab(nt)
            return
        }
        if (state == S.PANEL && pend != null) {
            // panel sedang disiapkan: cukup ganti tab awalnya
            tab = nt
            Xcadoodle.prefs.lastTab = nt
            preparePanels()
            return
        }
        val from = if (state == S.ALERT) cur else null
        state = S.PANEL
        tab = nt
        Xcadoodle.prefs.lastTab = nt
        preparePanels()
        openStage(S.PANEL, from)
    }

    private fun selectTab(t: Int) {
        if (t == tab) return
        val st = cur
        val old = tab
        tab = t
        Xcadoodle.prefs.lastTab = t
        styleTabs()
        val inV = panels[t]
        val outV = panels[old]
        for (i in panels.indices) {
            if (i != t && i != old) panels[i].visibility = GONE
        }
        (inV as Refreshable).refresh()
        inV.alpha = 0f
        inV.visibility = VISIBLE
        if (st == null) {
            outV.visibility = GONE
            inV.alpha = 1f
            notifyVisibility()
            return
        }
        // kalau animasi buka belum selesai, finalkan dulu isinya supaya tidak tersangkut transparan
        panelBox.alpha = 1f
        panelBox.scaleX = 1f
        panelBox.scaleY = 1f
        st.ghost?.alpha = 0f
        val outA = outV.alpha
        val g = tabGlow[t]
        st.glow.flash(g[0], g[1])
        st.shape.animate(panelW().toFloat(), panelH(t).toFloat(), svc.dpf(28), wantedTint(), 340, 11f, { f ->
            outV.alpha = outA * (1f - smooth(f / 0.4f))
            inV.alpha = smooth((f - 0.2f) / 0.6f)
            st.glow.setVisible(st.shape.vW, st.shape.vH)
        }) {
            outV.visibility = GONE
            outV.alpha = 1f
            inV.alpha = 1f
        }
        notifyVisibility()
    }

    fun refreshData() {
        if (state == S.PANEL) (panels[tab] as Refreshable).refresh()
    }

    // ------------------------------------------------------------ system hooks

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        post {
            abortStages()
            ui.removeCallbacks(endAlert)
            queue.clear()
            current = null
            state = S.COMPACT
            notifyVisibility()
            resetPillNow()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ui.post(uiTick)
    }

    override fun onDetachedFromWindow() {
        ui.removeCallbacks(uiTick)
        ui.removeCallbacks(endAlert)
        abortStages()
        Markets.stop()
        PrivSampler.stop()
        super.onDetachedFromWindow()
    }
}
