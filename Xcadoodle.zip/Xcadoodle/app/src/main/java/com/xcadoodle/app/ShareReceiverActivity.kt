package com.xcadoodle.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.IntentCompat

/**
 * Target "Share → Xcadoodle Shelf" dari app lain, sekaligus pemilih file ("+ Add").
 * Tidak punya UI sendiri (tema transparan).
 */
class ShareReceiverActivity : Activity() {
    private val reqPick = 77

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        when (intent.action) {
            Intent.ACTION_SEND -> {
                var n = 0
                val u = IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                if (u != null && Xcadoodle.shelf.addUri(u)) n++
                val text = intent.getStringExtra(Intent.EXTRA_TEXT)
                if (text != null) {
                    val m = Regex("https?://\\S+").find(text)
                    if (m != null) {
                        Xcadoodle.shelf.addLink(m.value)
                        n++
                    }
                }
                done(n)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                var n = 0
                val list = IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
                if (list != null) for (u in list) if (Xcadoodle.shelf.addUri(u)) n++
                done(n)
            }
            "com.xcadoodle.app.PICK" -> {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                @Suppress("DEPRECATION")
                startActivityForResult(i, reqPick)
            }
            else -> finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        var n = 0
        if (requestCode == reqPick && resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) if (Xcadoodle.shelf.addUri(clip.getItemAt(i).uri)) n++
            } else {
                val u = data.data
                if (u != null && Xcadoodle.shelf.addUri(u)) n++
            }
        }
        done(n)
    }

    private fun done(n: Int) {
        if (n > 0) {
            Toast.makeText(this, "Added $n item(s) to Xcadoodle Shelf", Toast.LENGTH_SHORT).show()
            Bus.changed()
        }
        finish()
    }
}
