package com.xcadoodle.app

import android.content.pm.PackageManager
import android.os.SystemClock
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.OutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/** Akses shell (uid 2000) lewat Shizuku. Semua fungsi aman dipanggil walau Shizuku tidak terpasang. */
object Priv {
    fun running(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun granted(): Boolean = try {
        running() && !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun request(code: Int) {
        try {
            Shizuku.requestPermission(code)
        } catch (e: Throwable) {
        }
    }

    /** Buka proses shell (uid 2000) lewat Shizuku, null kalau gagal. */
    fun spawn(argv: Array<String>): Process? {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            m.invoke(null, argv, null, null) as Process
        } catch (e: Throwable) {
            null
        }
    }

    /** Blocking. Jalankan satu perintah `sh -c` sebagai shell; null kalau gagal. */
    fun run(cmd: String): String? {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out
        } catch (e: Throwable) {
            null
        }
    }
}

/**
 * Satu shell `sh` yang dibuka sekali dan dipakai berulang. Jauh lebih cepat dan stabil daripada
 * membuka proses baru tiap sampel (spawn lewat Shizuku bisa makan ratusan ms dan kadang telat,
 * yang bikin GPU sesekali jadi "—").
 */
object PrivShell {
    private var proc: Process? = null
    private var out: OutputStream? = null
    private var inp: BufferedReader? = null
    private const val END = "__XCADOODLE_END__"

    private fun open(): Boolean {
        val p = Priv.spawn(arrayOf("sh")) ?: return false
        proc = p
        out = p.outputStream
        inp = p.inputStream.bufferedReader()
        try {
            out!!.write("exec 2>/dev/null\n".toByteArray())
            out!!.flush()
        } catch (e: Throwable) {
            close()
            return false
        }
        return true
    }

    @Synchronized
    fun close() {
        try {
            proc?.destroy()
        } catch (e: Throwable) {
        }
        proc = null
        out = null
        inp = null
    }

    /** Blocking. Jalankan [cmd] di shell persisten; null kalau gagal/timeout. */
    @Synchronized
    fun exec(cmd: String, timeoutMs: Long = 3000L): String? {
        for (attempt in 0..1) {
            if (proc == null && !open()) return null
            val p = proc
            val o = out
            val r = inp
            if (p == null || o == null || r == null) return null
            val done = AtomicBoolean(false)
            val wd = thread(isDaemon = true, name = "xcadoodle-priv-wd") {
                try {
                    Thread.sleep(timeoutMs)
                } catch (e: InterruptedException) {
                    return@thread
                }
                if (!done.get()) {
                    try {
                        p.destroy()
                    } catch (e: Throwable) {
                    }
                }
            }
            try {
                o.write((cmd + "\necho " + END + "\n").toByteArray())
                o.flush()
                val sb = StringBuilder()
                while (true) {
                    val line = r.readLine() ?: throw java.io.IOException("eof")
                    if (line.trim() == END) break
                    sb.append(line).append('\n')
                }
                return sb.toString()
            } catch (e: Throwable) {
                close() // shell mati/timeout: coba buka ulang sekali
            } finally {
                done.set(true)
                wd.interrupt()
            }
        }
        return null
    }
}

class PrivData(val cpu: Float, val gpu: Float, val cpuT: Float, val gpuT: Float, val gpuMhz: Float, val at: Long)

/** Polling hardware lewat Shizuku di background, hanya selama tab Device terbuka. */
object PrivSampler {
    @Volatile var data: PrivData? = null
    @Volatile private var active = false
    private var th: Thread? = null
    private var pTotal = 0L
    private var pIdle = 0L

    // Urutan sumber GPU: Adreno (kgsl) -> devfreq -> Mali -> MediaTek (GED). Tiap sumber dicoba,
    // yang pertama memberi angka valid dipakai.
    private const val CMD = "head -n1 /proc/stat; " +
        "echo '#G'; cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage; " +
        "echo '#G3'; cat /sys/class/kgsl/kgsl-3d0/devfreq/gpu_load; " +
        "for f in /sys/class/devfreq/*kgsl*/gpu_load /sys/class/devfreq/*gpu*/gpu_load; do cat \$f; done; " +
        "echo '#G2'; cat /sys/class/kgsl/kgsl-3d0/gpubusy; " +
        "echo '#M'; cat /sys/kernel/gpu/gpu_busy; cat /sys/devices/platform/*.mali/utilization; " +
        "echo '#MTK'; cat /sys/kernel/ged/hal/gpu_utilization; cat /sys/module/ged/parameters/gpu_loading; " +
        "echo '#F'; cat /sys/class/kgsl/kgsl-3d0/gpuclk; cat /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq; " +
        "echo '#T'; for z in /sys/class/thermal/thermal_zone*; do echo \"\$(cat \$z/type) \$(cat \$z/temp)\"; done"

    fun start() {
        if (active) return
        active = true
        th = thread(name = "xcadoodle-priv") {
            while (active) {
                if (Priv.granted()) {
                    val out = PrivShell.exec(CMD) ?: Priv.run(CMD)
                    if (out != null) parse(out)
                } else {
                    data = null
                }
                try {
                    Thread.sleep(1000)
                } catch (e: InterruptedException) {
                }
            }
            PrivShell.close()
        }
    }

    fun stop() {
        active = false
        th?.interrupt()
        th = null
    }

    private fun nums(s: String): List<Double> = Regex("[0-9.]+").findAll(s).mapNotNull { it.value.toDoubleOrNull() }.toList()

    private fun parse(out: String) {
        var cpu = -1f
        var gpu = -1f
        var gpuIdleHint = false
        var mhz = -1f
        var section = ""
        val cT = ArrayList<Double>()
        val gT = ArrayList<Double>()
        for (line in out.lines()) {
            val l = line.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("cpu ")) {
                val p = l.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
                if (p.size >= 5) {
                    val idle = p[3] + p[4]
                    val total = p.sum()
                    val dT = total - pTotal
                    val dI = idle - pIdle
                    if (pTotal != 0L && dT > 0) cpu = ((dT - dI).toFloat() / dT * 100f).coerceIn(0f, 100f)
                    pTotal = total
                    pIdle = idle
                }
                continue
            }
            if (l.startsWith("#")) {
                section = l
                continue
            }
            when (section) {
                "#G", "#G3", "#M" -> if (gpu < 0f) nums(l).firstOrNull()?.let { gpu = it.toFloat().coerceIn(0f, 100f) }
                "#G2" -> if (gpu < 0f) {
                    val n = nums(l)
                    if (n.size >= 2) {
                        if (n[1] > 0) gpu = (n[0] / n[1] * 100).toFloat().coerceIn(0f, 100f) else gpuIdleHint = true
                    }
                }
                "#MTK" -> if (gpu < 0f) nums(l).firstOrNull()?.let { gpu = it.toFloat().coerceIn(0f, 100f) }
                "#F" -> if (mhz < 0f) nums(l).firstOrNull()?.let {
                    mhz = when {
                        it >= 1e7 -> (it / 1e6).toFloat()   // Hz
                        it >= 1e4 -> (it / 1e3).toFloat()   // kHz
                        else -> it.toFloat()                // MHz
                    }
                }
                "#T" -> {
                    val parts = l.split(" ")
                    if (parts.size >= 2) {
                        var v = parts.last().toDoubleOrNull() ?: continue
                        if (v > 1000) v /= 1000.0
                        if (v < 10 || v > 130) continue
                        val t = parts[0].lowercase()
                        if (t.startsWith("gpu") || t.contains("kgsl") || t.contains("mali")) gT.add(v)
                        else if (t.startsWith("cpu") || t.contains("mtktscpu") || t.contains("soc_thermal") || t.startsWith("big") || t.startsWith("little")) cT.add(v)
                    }
                }
            }
        }
        // gpubusy "0 0" = GPU idle di jendela sampling itu, bukan "tidak terbaca"
        if (gpu < 0f && gpuIdleHint) gpu = 0f
        data = PrivData(
            cpu, gpu,
            if (cT.isEmpty()) Float.NaN else cT.max().toFloat(),
            if (gT.isEmpty()) Float.NaN else gT.max().toFloat(),
            mhz,
            SystemClock.elapsedRealtime()
        )
    }
}
