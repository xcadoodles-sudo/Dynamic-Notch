package com.lobo.app

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings

/**
 * Mode game: saat sebuah game ada di depan, Lobo menghentikan SEMUA pekerjaannya (jendela notch, maskot,
 * pembaca sesi musik, clipboard, penerima baterai/Bluetooth/jaringan, thread pasar/Shizuku, dan notification
 * listener), lalu membuang view + cache dari RAM. Begitu game ditinggalkan, semuanya dinyalakan lagi.
 *
 * Pemicu: [onForeground] dipanggil [LoboAccessibilityService] tiap jendela di depan berganti (berbasis event,
 * tanpa polling), atau [toggleManual] dari tombol di notifikasi / MainActivity.
 *
 * Game dikenali dari: daftar manual (setelan), lalu kategori app (ApplicationInfo.CATEGORY_GAME) kalau
 * "Auto-detect" aktif. Jendela sistem yang muncul di atas game (keyboard, status bar, dialog bayar Play Store,
 * overlay Game Turbo, dll) diabaikan supaya mode game tidak padam sendiri.
 */
object GameMode {
    private const val EXIT_DELAY_MS = 1200L

    private const val K_NEUTRAL = 0 // jendela sistem/overlay: tidak mengubah apa pun
    private const val K_APP = 1     // app biasa atau launcher: bukan game
    private const val K_GAME = 2

    private val main = Handler(Looper.getMainLooper())
    private val base = HashMap<String, Int>() // hasil klasifikasi per paket (tanpa daftar manual)
    private var exitJob: Runnable? = null
    private var lastFg = ""
    private var snooze = ""

    /** true = dinyalakan dari tombol, jadi tidak padam sendiri saat pindah app. */
    @Volatile
    var manual = false
        private set

    /** Jendela yang sering muncul di atas game tapi bukan "app yang dipakai": jangan dianggap pindah app. */
    private val neutralPkgs = hashSetOf(
        "android",
        "com.android.systemui",
        "com.android.vending",
        "com.google.android.gms",
        "com.google.android.gsf",
        "com.google.android.permissioncontroller",
        "com.android.permissioncontroller",
        "com.google.android.play.games",
        "com.miui.securitycenter",
        "com.miui.gamebooster",
        "com.xiaomi.gamecenter.sdk.service",
        "com.samsung.android.game.gametools",
        "com.samsung.android.game.gos"
    )

    fun csv(s: String): MutableSet<String> {
        val out = LinkedHashSet<String>()
        for (p in s.split(',')) {
            val t = p.trim()
            if (t.isNotEmpty()) out.add(t)
        }
        return out
    }

    /** Dipakai pemilih game di setelan. true = paket ini dianggap game sekarang (manual atau otomatis). */
    fun isGameApp(ctx: Context, pkg: String): Boolean {
        val pr = Lobo.prefs
        if (csv(pr.gameNever).contains(pkg)) return false
        if (csv(pr.gamePkgs).contains(pkg)) return true
        if (!pr.gameAuto) return false
        return base.getOrPut(pkg) { baseKind(ctx, pkg) } == K_GAME
    }

    /** Balik status satu app di daftar: game -> bukan game, bukan game -> game. */
    fun toggleApp(ctx: Context, pkg: String) {
        val pr = Lobo.prefs
        val inc = csv(pr.gamePkgs)
        val exc = csv(pr.gameNever)
        if (isGameApp(ctx, pkg)) {
            inc.remove(pkg)
            exc.add(pkg)
        } else {
            exc.remove(pkg)
            inc.add(pkg)
        }
        pr.gamePkgs = inc.joinToString(",")
        pr.gameNever = exc.joinToString(",")
    }

    private fun classify(ctx: Context, pkg: String): Int {
        if (pkg == ctx.packageName) return K_NEUTRAL
        if (pkg == imePackage(ctx)) return K_NEUTRAL
        val pr = Lobo.prefs
        if (csv(pr.gameNever).contains(pkg)) return K_APP
        if (csv(pr.gamePkgs).contains(pkg)) return K_GAME
        val b = base.getOrPut(pkg) { baseKind(ctx, pkg) }
        return if (b == K_GAME && !pr.gameAuto) K_APP else b
    }

    @Suppress("DEPRECATION")
    private fun baseKind(ctx: Context, pkg: String): Int {
        if (neutralPkgs.contains(pkg)) return K_NEUTRAL
        val pm = ctx.packageManager
        try {
            val ai = pm.getApplicationInfo(pkg, 0)
            if (ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return K_GAME
        } catch (e: Exception) {
            return K_NEUTRAL
        }
        if (isHome(pm, pkg)) return K_APP
        // tanpa ikon peluncur dan bukan launcher = layanan/overlay sistem, bukan app yang dibuka pengguna
        if (pm.getLaunchIntentForPackage(pkg) == null) return K_NEUTRAL
        return K_APP
    }

    private fun isHome(pm: PackageManager, pkg: String): Boolean {
        return try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY).any { it.activityInfo.packageName == pkg }
        } catch (e: Exception) {
            false
        }
    }

    private fun imePackage(ctx: Context): String {
        val s = (try {
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        } catch (e: Exception) {
            null
        }) ?: return ""
        return s.substringBefore('/')
    }

    /** Dari LoboAccessibilityService (thread utama): jendela di depan berganti ke [pkg]. */
    fun onForeground(ctx: Context, pkg: String) {
        val svc = NotchService.instance ?: return
        if (!Lobo.prefs.gameMode) return
        when (classify(ctx, pkg)) {
            K_GAME -> {
                lastFg = pkg
                cancelExit()
                if (pkg == snooze) return
                if (!svc.gaming) svc.setGaming(true)
            }
            K_APP -> {
                lastFg = pkg
                snooze = ""
                if (svc.gaming && !manual) scheduleExit()
            }
            else -> {
            }
        }
    }

    /** Tombol "Game mode" / "Wake" di notifikasi dan di MainActivity. */
    fun toggleManual() {
        val svc = NotchService.instance ?: return
        cancelExit()
        if (svc.gaming) {
            manual = false
            // dibangunkan paksa saat game masih di depan: jangan langsung masuk lagi sampai pindah app
            snooze = lastFg
            svc.setGaming(false)
        } else {
            manual = true
            svc.setGaming(true)
        }
    }

    /** Setelan mode game dimatikan / layanan notch berhenti / pendeteksi (Accessibility) hilang. */
    fun reset() {
        cancelExit()
        manual = false
        snooze = ""
        NotchService.instance?.setGaming(false)
    }

    private fun scheduleExit() {
        if (exitJob != null) return
        val r = Runnable {
            exitJob = null
            NotchService.instance?.setGaming(false)
        }
        exitJob = r
        main.postDelayed(r, EXIT_DELAY_MS)
    }

    private fun cancelExit() {
        exitJob?.let { main.removeCallbacks(it) }
        exitJob = null
    }
}
