package com.xcadoodle.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

enum class IconKind { MUSIC, DEVICE, MARKETS, CALENDAR, SHELF, CHEVRON_UP }

/**
 * Ikon garis minimalis (grid 24x24, garis tipis, ujung bulat) untuk tab dan tombol tutup.
 * Digambar sendiri supaya tidak bergantung emoji/font perangkat dan warnanya konsisten.
 */
class LineIconView(
    c: Context,
    kind: IconKind,
    tint: Int = C.TEXT,
    private val sizeDp: Float = 19f,
    private val strokeDp: Float = 1.5f
) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = tint
    }
    private val path = build(kind)

    override fun onDraw(canvas: Canvas) {
        val box = context.dpf(sizeDp)
        val k = box / 24f
        paint.strokeWidth = context.dpf(strokeDp) / k
        canvas.save()
        canvas.translate((width - box) / 2f, (height - box) / 2f)
        canvas.scale(k, k)
        canvas.drawPath(path, paint)
        canvas.restore()
    }

    private fun build(kind: IconKind): Path {
        val p = Path()
        when (kind) {
            IconKind.MUSIC -> {
                p.moveTo(9f, 18f)
                p.lineTo(9f, 5f)
                p.lineTo(19f, 3f)
                p.lineTo(19f, 16f)
                p.addCircle(6.5f, 18f, 2.5f, Path.Direction.CW)
                p.addCircle(16.5f, 16f, 2.5f, Path.Direction.CW)
            }
            IconKind.DEVICE -> {
                p.addRoundRect(RectF(6f, 6f, 18f, 18f), 2.5f, 2.5f, Path.Direction.CW)
                for (v in floatArrayOf(10f, 14f)) {
                    p.moveTo(v, 3f)
                    p.lineTo(v, 6f)
                    p.moveTo(v, 18f)
                    p.lineTo(v, 21f)
                    p.moveTo(3f, v)
                    p.lineTo(6f, v)
                    p.moveTo(18f, v)
                    p.lineTo(21f, v)
                }
            }
            IconKind.MARKETS -> {
                p.moveTo(3f, 17f)
                p.lineTo(9f, 11f)
                p.lineTo(13f, 15f)
                p.lineTo(21f, 7f)
                p.moveTo(15f, 7f)
                p.lineTo(21f, 7f)
                p.lineTo(21f, 13f)
            }
            IconKind.CALENDAR -> {
                p.addRoundRect(RectF(4f, 5f, 20f, 20f), 3f, 3f, Path.Direction.CW)
                p.moveTo(4f, 10f)
                p.lineTo(20f, 10f)
                p.moveTo(8.5f, 3f)
                p.lineTo(8.5f, 7f)
                p.moveTo(15.5f, 3f)
                p.lineTo(15.5f, 7f)
            }
            IconKind.SHELF -> {
                p.moveTo(4f, 13f)
                p.lineTo(4f, 17f)
                p.cubicTo(4f, 18.7f, 5.3f, 20f, 7f, 20f)
                p.lineTo(17f, 20f)
                p.cubicTo(18.7f, 20f, 20f, 18.7f, 20f, 17f)
                p.lineTo(20f, 13f)
                p.moveTo(12f, 4f)
                p.lineTo(12f, 14.5f)
                p.moveTo(8f, 10.5f)
                p.lineTo(12f, 14.5f)
                p.lineTo(16f, 10.5f)
            }
            IconKind.CHEVRON_UP -> {
                p.moveTo(7f, 14.5f)
                p.lineTo(12f, 9.5f)
                p.lineTo(17f, 14.5f)
            }
        }
        return p
    }
}
