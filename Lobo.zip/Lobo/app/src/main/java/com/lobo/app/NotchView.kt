package com.lobo.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Jembatan ke WindowManager milik service (tipe jendela, posisi, add/remove). */
interface OverlayHost {
    fun params(w: Int, h: Int): WindowManager.LayoutParams
    fun add(v: View, lp: WindowManager.LayoutParams): Boolean
    fun remove(v: View)

    /** Izinkan/larang jendela menerima fokus keyboard (dibutuhkan untuk balas notifikasi). */
    fun setFocusable(v: View, focusable: Boolean)

    /** false = tipe jendela ini tidak bisa menampilkan keyboard (pakai ReplyActivity). */
    fun canType(): Boolean
}

/**
 * Notch yang menempel di tepi atas layar (atas datar + telinga cekung, bawah melengkung).
 * COMPACT : pil (maskot / album art di kiri, equalizer di kanan)
 * ALERT   : melebar sebentar untuk notifikasi
 * PANEL   : ketuk pil -> Music / Device / Markets / Calendar / Shelf
 *
 * Arsitektur animasi (kenapa tidak goyang lagi):
 *  - Jendela TIDAK PERNAH di-resize selagi terlihat. Pil punya jendela kecil tetap. Untuk ALERT/PANEL
 *    dibuat jendela baru berukuran tetap (sebesar bentuk maksimumnya). Frame pertamanya menggambar
 *    bentuk yang persis sama dengan pil, jadi pergantian jendela tidak terlihat; baru setelah itu
 *    bentuknya dimorph (outline + siluet saja, tanpa layout ulang).
 *  - Saat menutup, bentuk dimorph kembali ke pil, lalu jendela tambahan dibuang.
 *  - Isi lama (pil/alert) tampil sebagai "ghost" (bitmap) yang memudar selama morph.
 */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class NotchView(private val svc: Context, private val media: MediaWatcher, private val host: OverlayHost) : FrameLayout(svc) {
    enum class S { COMPACT, ALERT, PANEL }

    companion object {
        private const val TABS_H = 38
        private const val BODY_PAD_V = 16 // 4 atas + 12 bawah
        private const val PANEL_W = 620
        private const val ALERT_H = 76
        private const val ALERT_EXP_H = 138
        private const val ALERT_R = 28
        private const val HALO_PAD = 14
        private const val EAR_DP = 10
        private val TAB_H = intArrayOf(196, 196, 290, 290, 290, 290)
        const val CHAT_TAB = 5
        private const val VISIBLE_TABS = 4
    }

    private val ui = Handler(Looper.getMainLooper())
    private val choreo = Choreographer.getInstance()
    var state = S.COMPACT
        private set

    private var flat = Lobo.prefs.topOffset == 0
    private val earPx: Float get() = if (flat) svc.dpf(EAR_DP) else 0f

    /** Ukuran jendela pil (tetap). Dipakai service saat memasang jendela. */
    val winW: Int = evenW(maxOf(svc.dp(Lobo.prefs.notchW), svc.dp(120)) + 2 * earPx.toInt() + svc.dp(24))
    val winH: Int = svc.dp(Lobo.prefs.notchH) + svc.dp(2) + svc.dp(HALO_PAD)

    private val pill = NotchShape(svc)
    private var cur: Stage? = null      // jendela tambahan yang sedang tampil
    private var pend: Stage? = null     // jendela tambahan yang sedang disiapkan (belum tergambar)
    private var closing = false

    private val tabGlow = arrayOf(
        intArrayOf(0xFFFF9A3D.toInt(), 0xFFFF3D7F.toInt()), // music: sunrise oranye -> pink
        intArrayOf(0xFF3DDCFF.toInt(), 0xFF3D6BFF.toInt()), // device: cyan -> biru
        intArrayOf(0xFF35E08A.toInt(), 0xFF12A39A.toInt()), // markets: (dipakai lewat glowFor, ikut tren harga)
        intArrayOf(0xFFB06BFF.toInt(), 0xFFFF5FB5.toInt()), // calendar: ungu -> magenta
        intArrayOf(0xFFFFD04D.toInt(), 0xFFFF8A3D.toInt()), // shelf: kuning -> oranye
        intArrayOf(0xFFE07B53.toInt(), 0xFFFFB27A.toInt())  // chat: coral Claude -> amber
    )

    // tab Markets: gradasi ikut arah harga simbol yang dipilih
    private val glowUp = intArrayOf(0xFF35E08A.toInt(), 0xFF12A39A.toInt())   // naik: hijau -> teal
    private val glowDown = intArrayOf(0xFFFF4D5A.toInt(), 0xFFC21E56.toInt()) // turun: merah -> crimson
    private val glowIdle = intArrayOf(0xFF8A96B8.toInt(), 0xFF4B5A86.toInt()) // belum ada data: abu-biru

    // tab Music: gradasi dari dua warna cover album (di-cache per bitmap), bawaan oranye -> pink kalau tidak ada cover
    private var glowArt: Bitmap? = null
    private var glowArtCols: IntArray? = null

    private fun albumGlow(): IntArray? {
        val art = media.art
        if (!media.hasSession || art == null) return null
        if (art !== glowArt) {
            glowArt = art
            glowArtCols = ArtPalette.of(art)
        }
        return glowArtCols
    }

    private fun glowFor(t: Int): IntArray {
        if (t == 0) return albumGlow() ?: tabGlow[0]
        if (t != 2) return tabGlow[t]
        return when (markets.trend) {
            1 -> glowUp
            -1 -> glowDown
            else -> glowIdle
        }
    }

    private var tintArt: Bitmap? = null
    private var tintCache = C.BLACK

    private val compact = LinearLayout(svc)
    private val alertBox = LinearLayout(svc)
    private val panelBox = LinearLayout(svc)

    // --- compact
    private val pet = PetView(svc)
    private val miniArt = ImageView(svc)
    private val gap = View(svc)
    private val eq = EqView(svc)
    private var lastMiniArt: Bitmap? = null

    // --- alert
    private val aIconBox = FrameLayout(svc)
    private val aGlyph = svc.tv("", 17f, C.TEXT, true)
    private val aLine = LineIconView(svc, IconKind.BELL, C.TEXT, 20f, 1.6f)
    private val aImg = ImageView(svc)
    private val aTitle = svc.tv("", 15f, C.TEXT, false)
    private val aSub = svc.tv("", 13f, 0xBFFFFFFF.toInt())
    private val aTop = LinearLayout(svc)
    private val aReplyBtn = LineIconView(svc, IconKind.REPLY, C.TEXT, 18f, 1.7f)
    private val aReplyRow = LinearLayout(svc)
    private val aInput = EditText(svc)
    private val aSend = LineIconView(svc, IconKind.SEND, C.BLACK, 18f, 2f)
    private var replying = false
    private var current: Alert? = null
    private val queue = java.util.ArrayDeque<Alert>()

    // --- panel
    private val tabsRow = LinearLayout(svc)
    private val tabsScroll = SnapScroll(svc)
    private val tabCells = ArrayList<FrameLayout>()
    private val body = FrameLayout(svc)
    private val music = MusicPanel(svc, media)
    private val device = DevicePanel(svc)
    private val markets = MarketsPanel(svc)
    private val calendar = CalendarPanel(svc)
    private val shelf = ShelfPanel(svc)
    private val chat = ChatPanel(svc)
    private val panels: List<View> = listOf(music, device, markets, calendar, shelf, chat)
    private val tabIcons = listOf(
        IconKind.MUSIC, IconKind.DEVICE, IconKind.MARKETS,
        IconKind.CALENDAR, IconKind.SHELF, IconKind.CHAT
    )
    private val tabViews = ArrayList<View>()
    private var tab = 0

    private val endAlert = Runnable {
        current = null
        val n = queue.poll()
        if (n != null) showAlert(n) else showCompact()
    }

    private val uiTick = object : Runnable {
        override fun run() {
            pet.paused = state != S.COMPACT
            when (state) {
                S.COMPACT -> if (!closing) {
                    updateCompact()
                    if (cur == null && pend == null && !pill.animating) fitCompact()
                }
                S.PANEL -> {
                    val st = cur
                    if (st != null && !st.shape.animating) {
                        (panels[tab] as Refreshable).refresh()
                        st.shape.animateTint(wantedTint())
                        if (tab == 0 && st.kind == S.PANEL) {
                            // lagu ganti saat tab Music terbuka -> gradasi ikut pindah warna
                            val g = glowFor(0)
                            st.glow.setColors(g[0], g[1])
                        }
                    }
                }
                S.ALERT -> {
                }
            }
            ui.postDelayed(this, 500)
        }
    }

    // ------------------------------------------------------------ jendela tambahan

    /** Satu jendela tambahan (ALERT atau PANEL), ukuran tetap selama hidupnya. */
    private inner class Stage(val kind: S) : FrameLayout(svc) {
        val shape = NotchShape(svc)
        val glow = GlowView(svc)
        var ghost: ImageView? = null
        var winH = 0

        init {
            shape.flat = flat
            shape.ear = earPx
            addView(shape, LayoutParams(MATCH, MATCH))
            shape.content.addView(glow, LayoutParams(MATCH, MATCH))
        }

        fun setGhost(b: Bitmap, alpha: Float) {
            ghost?.let { shape.content.removeView(it) }
            val iv = ImageView(svc)
            iv.setImageBitmap(b)
            iv.alpha = alpha
            shape.content.addView(iv, LayoutParams(b.width, b.height, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
            ghost = iv
        }

        fun attach(v: View, w: Int, h: Int) {
            (v.parent as? ViewGroup)?.removeView(v)
            v.pivotX = w / 2f
            v.pivotY = 0f
            shape.content.addView(v, LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        }

        fun release() {
            shape.release()
            for (v in arrayOf<View>(alertBox, panelBox)) {
                if (v.parent === shape.content) shape.content.removeView(v)
            }
        }

        /** Panggil [cb] setelah jendela ini benar-benar tergambar (frame pertama + 1-2 frame). */
        fun whenDrawn(cb: () -> Unit) {
            var fired = false
            val fire = Runnable {
                if (!fired) {
                    fired = true
                    cb()
                }
            }
            viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
                override fun onPreDraw(): Boolean {
                    if (viewTreeObserver.isAlive) viewTreeObserver.removeOnPreDrawListener(this)
                    choreo.postFrameCallback { choreo.postFrameCallback { fire.run() } }
                    return true
                }
            })
            postDelayed(fire, 160) // pengaman kalau PreDraw tidak pernah datang
        }

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            if (stageGate(this, ev)) return true
            return super.dispatchTouchEvent(ev)
        }
    }

    /** true = sentuhan sudah ditangani/ditelan. */
    private fun stageGate(st: Stage, ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_OUTSIDE) {
            if (st === cur && !closing && (state == S.PANEL || (state == S.ALERT && replying))) showCompact()
            return true
        }
        if (closing) return true
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            val cx = st.width / 2f
            val half = st.shape.vW / 2f + st.shape.ear
            val inside = ev.x >= cx - half && ev.x <= cx + half && ev.y <= st.shape.vH
            if (!inside) {
                // ketukan di area transparan (di luar bentuk) dianggap ketukan di luar panel
                if (st === cur && (state == S.PANEL || (state == S.ALERT && replying))) showCompact()
                return true
            }
        }
        return false
    }

    init {
        pill.flat = flat
        pill.ear = earPx
        pill.auraAlpha = 1f
        pill.energy = { eq.energy }

        // harga naik/turun berubah -> gradasi tab Markets berpindah warna dengan halus
        markets.onTrend = {
            val st = cur
            if (st != null && st.kind == S.PANEL && tab == 2) {
                val g = glowFor(2)
                st.glow.setColors(g[0], g[1])
            }
        }

        // ---------- compact: kiri maskot/art, kanan equalizer, tengah kosong (seperti notch MacBook)
        compact.orientation = LinearLayout.HORIZONTAL
        compact.gravity = Gravity.CENTER_VERTICAL
        compact.setPadding(svc.dp(12), 0, svc.dp(12), 0)
        compact.addView(pet, LinearLayout.LayoutParams(svc.dp(24), MATCH, 1f))
        pet.setOnClickListener {
            pet.poke()
            compact.performClick()
        }
        pet.setOnLongClickListener {
            pet.pat()
            true
        }
        miniArt.scaleType = ImageView.ScaleType.CENTER_CROP
        miniArt.roundClip(svc.dpf(6))
        compact.addView(miniArt, LinearLayout.LayoutParams(svc.dp(20), svc.dp(20)))
        compact.addView(gap, LinearLayout.LayoutParams(svc.dp(36), 1, 1f))
        compact.addView(eq, LinearLayout.LayoutParams(svc.dp(18), svc.dp(14)))
        compact.setOnClickListener {
            if (state == S.COMPACT && cur == null && pend == null && !closing) {
                showPanel(if (media.hasSession && media.playing) 0 else Lobo.prefs.lastTab.coerceIn(0, panels.size - 1))
            }
        }

        // ---------- alert: baris atas (ikon app + judul + isi + tombol balas), baris bawah (kolom balas)
        alertBox.orientation = LinearLayout.VERTICAL
        aTop.orientation = LinearLayout.HORIZONTAL
        aTop.gravity = Gravity.CENTER_VERTICAL
        aTop.setPadding(svc.dp(18), 0, svc.dp(14), 0)
        aTitle.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        aSub.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        aSub.setLineSpacing(0f, 1.06f)
        aGlyph.gravity = Gravity.CENTER
        aIconBox.addView(aGlyph, LayoutParams(MATCH, MATCH))
        aIconBox.addView(aLine, LayoutParams(MATCH, MATCH))
        aImg.scaleType = ImageView.ScaleType.FIT_CENTER
        aImg.roundClip(svc.dpf(11))
        aIconBox.addView(aImg, LayoutParams(MATCH, MATCH))
        aTop.addView(aIconBox, svc.llp(svc.dp(42), svc.dp(42)))
        val tcol = LinearLayout(svc)
        tcol.orientation = LinearLayout.VERTICAL
        tcol.gravity = Gravity.CENTER_VERTICAL
        aTitle.maxLines = 1
        aTitle.ellipsize = TextUtils.TruncateAt.END
        aSub.maxLines = 2
        aSub.ellipsize = TextUtils.TruncateAt.END
        tcol.addView(aTitle)
        tcol.addView(aSub, svc.llp(WRAP, WRAP, 0f, 0, 3, 0, 0))
        aTop.addView(tcol, svc.llp(0, WRAP, 1f, 14, 0, 6, 0))
        aReplyBtn.background = rounded(0x26FFFFFF, svc.dpf(100))
        aReplyBtn.visibility = GONE
        aReplyBtn.setOnClickListener { beginReply() }
        aTop.addView(aReplyBtn, svc.llp(svc.dp(44), svc.dp(36)))
        aTop.setOnClickListener {
            val a = current
            ui.removeCallbacks(endAlert)
            queue.clear()
            current = null
            a?.onClick?.invoke()
            if (a != null && a.tab >= 0) showPanel(a.tab) else showCompact()
        }
        alertBox.addView(aTop, svc.llp(MATCH, svc.dp(ALERT_H)))

        aReplyRow.orientation = LinearLayout.HORIZONTAL
        aReplyRow.gravity = Gravity.CENTER_VERTICAL
        aReplyRow.setPadding(svc.dp(14), 0, svc.dp(12), svc.dp(4))
        aReplyRow.visibility = GONE
        aInput.setTextColor(C.TEXT)
        aInput.setHintTextColor(0x66FFFFFF)
        aInput.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14.5f)
        aInput.background = rounded(0x22FFFFFF, svc.dpf(22))
        aInput.setPadding(svc.dp(16), 0, svc.dp(16), 0)
        aInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        aInput.imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        aInput.setSingleLine(true)
        aInput.setOnEditorActionListener { _, act, _ ->
            if (act == EditorInfo.IME_ACTION_SEND) {
                sendReply()
                true
            } else {
                false
            }
        }
        aReplyRow.addView(aInput, svc.llp(0, svc.dp(44), 1f))
        aSend.background = rounded(C.TEXT, svc.dpf(22))
        aSend.setOnClickListener { sendReply() }
        aReplyRow.addView(aSend, svc.llp(svc.dp(44), svc.dp(44), 0f, 8, 0, 0, 0))
        alertBox.addView(aReplyRow, svc.llp(MATCH, svc.dp(ALERT_EXP_H - ALERT_H)))

        // ---------- panel: strip ikon tab di atas, isi di bawah
        panelBox.orientation = LinearLayout.VERTICAL
        // tab: 4 terlihat sekaligus, sisanya digeser (SnapScroll menempel per tab); tombol tutup tetap di kanan
        tabsRow.orientation = LinearLayout.HORIZONTAL
        tabsRow.gravity = Gravity.CENTER_VERTICAL
        for (i in tabIcons.indices) {
            val t = LineIconView(svc, tabIcons[i], C.TEXT)
            tabViews.add(t)
            val cell = FrameLayout(svc)
            cell.setOnClickListener { selectTab(i) }
            cell.addView(t, FrameLayout.LayoutParams(svc.dp(64), svc.dp(30), Gravity.CENTER))
            tabCells.add(cell)
            tabsRow.addView(cell, LinearLayout.LayoutParams(svc.dp(120), svc.dp(30)))
        }
        tabsScroll.isHorizontalScrollBarEnabled = false
        tabsScroll.overScrollMode = OVER_SCROLL_NEVER
        tabsScroll.addView(tabsRow, FrameLayout.LayoutParams(WRAP, MATCH))
        val tabsBar = LinearLayout(svc)
        tabsBar.orientation = LinearLayout.HORIZONTAL
        tabsBar.gravity = Gravity.CENTER_VERTICAL
        tabsBar.setPadding(svc.dp(14), 0, svc.dp(10), 0)
        tabsBar.addView(tabsScroll, svc.llp(0, MATCH, 1f))
        val close = LineIconView(svc, IconKind.CHEVRON_UP, 0x99FFFFFF.toInt())
        close.setOnClickListener { showCompact() }
        tabsBar.addView(close, svc.llp(svc.dp(36), svc.dp(30), 0f, 6, 0, 0, 0))
        panelBox.addView(tabsBar, svc.llp(MATCH, svc.dp(TABS_H)))
        layoutTabs()
        chat.onRequestType = { beginChatType() }
        body.setPadding(svc.dp(18), svc.dp(4), svc.dp(18), svc.dp(12))
        for (i in panels.indices) {
            // tinggi isi tiap panel tetap (sesuai tabnya) -> tidak ada relayout saat pindah tab
            val ph = svc.dp(TAB_H[i] - TABS_H - BODY_PAD_V)
            panels[i].visibility = GONE
            body.addView(panels[i], LayoutParams(MATCH, ph, Gravity.TOP))
        }
        panelBox.addView(body, svc.llp(MATCH, 0, 1f))

        val (w, h) = compactSize()
        pill.setShapeNow(w.toFloat(), h.toFloat(), compactR(h))
        pill.content.addView(compact, LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        addView(pill, LayoutParams(MATCH, MATCH))
        updateCompact()
    }

    // ------------------------------------------------------------ util

    private fun screenW(): Int {
        return if (Build.VERSION.SDK_INT >= 30) {
            (svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager).currentWindowMetrics.bounds.width()
        } else {
            resources.displayMetrics.widthPixels
        }
    }

    /** Lebar jendela dibuat berparitas sama dengan layar supaya semua jendela persis sepusat. */
    private fun evenW(w: Int): Int = if ((screenW() - w) % 2 != 0) w + 1 else w

    private fun tintFrom(art: Bitmap): Int {
        if (art === tintArt) return tintCache
        var out = C.BLACK
        try {
            val px = Bitmap.createScaledBitmap(art, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(px, hsv)
            hsv[1] = (hsv[1] * 1.15f).coerceAtMost(0.85f)
            hsv[2] = 0.30f
            out = Color.HSVToColor(hsv)
        } catch (e: Exception) {
        }
        tintArt = art
        tintCache = out
        return out
    }

    private fun wantedTint(): Int {
        if (state == S.PANEL && tab == 0 && media.hasSession) {
            val art = media.art
            if (art != null) return tintFrom(art)
        }
        return C.BLACK
    }

    private fun smooth(x: Float): Float {
        val u = x.coerceIn(0f, 1f)
        return u * u * (3f - 2f * u)
    }

    /** Foto isi sebuah view (untuk ghost). fw/fh > 0 memaksa layout ke ukuran itu dulu. */
    private fun snapshot(v: View, fw: Int = 0, fh: Int = 0): Bitmap? {
        try {
            var w = v.width
            var h = v.height
            if (fw > 0 && fh > 0) {
                v.measure(
                    View.MeasureSpec.makeMeasureSpec(fw, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(fh, View.MeasureSpec.EXACTLY)
                )
                v.layout(0, 0, fw, fh)
                w = fw
                h = fh
            }
            if (w <= 0 || h <= 0) return null
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            v.draw(Canvas(b))
            return b
        } catch (e: Throwable) {
            return null
        }
    }

    private fun notifyVisibility() {
        for (i in panels.indices) (panels[i] as? PanelLife)?.onVisible(state == S.PANEL && tab == i)
    }

    // ------------------------------------------------------------ compact

    private fun updateCompact() {
        val pr = Lobo.prefs
        val minimal = pr.minimal
        val musicOn = media.hasSession && media.playing
        val art = media.art
        val showArt = musicOn && art != null && !minimal
        val showPet = !minimal && pr.pet && !showArt
        pet.visibility = if (showPet) VISIBLE else GONE
        gap.visibility = if (showPet) GONE else VISIBLE
        miniArt.visibility = if (showArt) VISIBLE else GONE
        if (showArt && lastMiniArt !== art) {
            lastMiniArt = art
            miniArt.setImageBitmap(art)
        }
        val showEq = musicOn && !minimal
        eq.visibility = if (showEq) VISIBLE else GONE
        eq.setArt(art)
        eq.active = media.playing
        // gradasi di dalam notch bergerak selama musik main, warnanya dari cover album
        pill.setMusic(showEq, eq.colA, eq.colB)
        syncPillPaused()
    }

    /** Pil yang tertutup panel/alert tidak perlu menggambar animasi (hemat baterai). */
    private fun syncPillPaused() {
        pill.paused = cur != null && !closing
    }

    private fun compactSize(): Pair<Int, Int> {
        compact.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        val minimal = Lobo.prefs.minimal
        val bw = svc.dp(Lobo.prefs.notchW)
        val bh = svc.dp(Lobo.prefs.notchH)
        val minW = if (minimal) (bw * 0.75f).toInt() else bw
        val h = if (minimal) (bh * 0.8f).toInt() else bh
        val maxW = winW - 2 * earPx.toInt() - svc.dp(8)
        return Pair(minOf(maxOf(minW, compact.measuredWidth + svc.dp(8)), maxW), minOf(h, winH))
    }

    /** Menempel di tepi: sudut bawah agak kotak. Melayang: pil bulat penuh. */
    private fun compactR(h: Int): Float = if (flat) h * 0.42f else h / 2f

    private fun setCompactLp(w: Int, h: Int) {
        compact.layoutParams = LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
    }

    /** Pil menyesuaikan isi (musik mulai/berhenti): hanya bentuk yang beranimasi, jendela tetap. */
    private fun fitCompact() {
        val (w, h) = compactSize()
        if (Math.abs(pill.vW - w) > svc.dp(2) || Math.abs(pill.vH - h) > 1f) {
            // isi dilebarkan dulu ke ukuran terbesar supaya tidak terpotong selama morph
            setCompactLp(maxOf(w, Math.ceil(pill.vW.toDouble()).toInt()), h)
            pill.animate(w.toFloat(), h.toFloat(), compactR(h), C.BLACK, 280, 12f, null) {
                setCompactLp(w, h)
            }
        }
    }

    private fun resetPillNow() {
        updateCompact()
        val (w, h) = compactSize()
        setCompactLp(w, h)
        pill.setShapeNow(w.toFloat(), h.toFloat(), compactR(h))
        pill.setTintNow(C.BLACK)
        pill.auraAlpha = 1f
    }

    // ------------------------------------------------------------ buka/tutup jendela tambahan

    private fun alertW(): Int = minOf((screenW() * 0.9f).toInt(), svc.dp(400))

    private fun panelW(): Int = minOf(screenW() - svc.dp(24), svc.dp(PANEL_W))

    private fun panelH(t: Int): Int = svc.dp(TAB_H[t])

    private fun stageW(contentW: Int): Int = evenW(contentW + 2 * earPx.toInt() + svc.dp(4))

    private fun removeStage(st: Stage) {
        st.release()
        host.remove(st)
    }

    private fun cancelPending() {
        val p = pend ?: return
        pend = null
        removeStage(p)
    }

    private fun abortStages() {
        cancelPending()
        cur?.let { removeStage(it) }
        cur = null
        closing = false
        pill.release()
    }

    /**
     * Siapkan jendela baru untuk [kind], bentuk awalnya = bentuk yang sedang tampil
     * (pil, atau stage lama kalau [from] != null). Animasi baru jalan setelah jendela tergambar.
     */
    private fun openStage(kind: S, from: Stage?) {
        cancelPending()
        val sw: Int
        val sh: Int
        if (kind == S.PANEL) {
            sw = stageW(panelW())
            sh = svc.dp(TAB_H.max())
        } else {
            sw = stageW(alertW())
            sh = if (current?.reply != null) svc.dp(ALERT_EXP_H) else svc.dp(ALERT_H)
        }
        val st = Stage(kind)
        st.winH = sh
        val src = from?.shape ?: pill
        st.shape.setShapeNow(src.vW, src.vH, src.vR)
        st.shape.setTintNow(src.tint)
        st.shape.copyAuraFrom(src)
        st.shape.auraAlpha = src.auraAlpha

        // isi lama jadi ghost (tampak identik dengan yang ada di jendela lama)
        val ghostBmp = if (from != null) snapshot(alertBox) else snapshot(compact)
        if (ghostBmp != null) st.setGhost(ghostBmp, 1f)

        // isi baru (transparan dulu, dimunculkan oleh animasi)
        if (kind == S.PANEL) {
            panelBox.alpha = 0f
            panelBox.scaleX = 0.94f
            panelBox.scaleY = 0.94f
            panelBox.visibility = VISIBLE
            st.attach(panelBox, panelW(), sh)
        } else {
            alertBox.alpha = 0f
            alertBox.scaleX = 0.94f
            alertBox.scaleY = 0.94f
            alertBox.visibility = VISIBLE
            aReplyRow.visibility = GONE
            st.attach(alertBox, alertW(), sh)
        }

        pend = st
        st.whenDrawn { onStageReady(st, from) }
        if (!host.add(st, host.params(sw, sh))) {
            pend = null
            st.release()
            state = S.COMPACT
            resetPillNow()
        }
    }

    private fun onStageReady(st: Stage, from: Stage?) {
        if (pend !== st) return
        pend = null
        cur = st
        syncPillPaused()
        if (from != null) removeStage(from)
        if (st.kind == S.PANEL) animateOpenPanel(st) else animateOpenAlert(st)
    }

    private fun animateOpenPanel(st: Stage) {
        notifyVisibility()
        val g = glowFor(tab)
        st.glow.flash(g[0], g[1])
        st.shape.animate(panelW().toFloat(), panelH(tab).toFloat(), svc.dpf(28), wantedTint(), 480, 9f, { f ->
            st.glow.setVisible(st.shape.vW, st.shape.vH)
            st.ghost?.alpha = 1f - smooth(f / 0.3f)
            st.shape.auraAlpha = 1f - smooth(f / 0.5f)
            val a = smooth((f - 0.22f) / 0.5f)
            panelBox.alpha = a
            val s = 0.94f + 0.06f * a
            panelBox.scaleX = s
            panelBox.scaleY = s
        }) {
            panelBox.alpha = 1f
            panelBox.scaleX = 1f
            panelBox.scaleY = 1f
            st.ghost?.alpha = 0f
            st.shape.auraAlpha = 0f
        }
    }

    private fun animateOpenAlert(st: Stage) {
        ui.removeCallbacks(endAlert)
        ui.postDelayed(endAlert, current?.ms ?: 3500L)
        st.shape.animate(alertW().toFloat(), svc.dp(ALERT_H).toFloat(), svc.dpf(ALERT_R), C.BLACK, 420, 9.5f, { f ->
            st.ghost?.alpha = 1f - smooth(f / 0.3f)
            st.shape.auraAlpha = 1f - smooth(f / 0.5f)
            val a = smooth((f - 0.2f) / 0.55f)
            alertBox.alpha = a
            val s = 0.94f + 0.06f * a
            alertBox.scaleX = s
            alertBox.scaleY = s
        }) {
            alertBox.alpha = 1f
            alertBox.scaleX = 1f
            alertBox.scaleY = 1f
            st.ghost?.alpha = 0f
            st.shape.auraAlpha = 0f
        }
    }

    private fun closeStage(st: Stage) {
        if (closing) return
        closing = true
        ui.removeCallbacks(endAlert)
        updateCompact()
        // jendela yang menutup menggambar aura yang sama dengan pil (gerak & warna sefase)
        st.shape.copyAuraFrom(pill)
        val (w, h) = compactSize()
        setCompactLp(w, h)
        // pil di bawah langsung siap di bentuk akhir (tertutup stage sampai morph selesai)
        pill.setShapeNow(w.toFloat(), h.toFloat(), compactR(h))
        pill.setTintNow(C.BLACK)
        val bmp = snapshot(compact, w, h)
        if (bmp != null) st.setGhost(bmp, 0f)
        st.glow.hide()

        val box: View = if (st.kind == S.PANEL) panelBox else alertBox
        val a0 = box.alpha
        st.shape.animate(w.toFloat(), h.toFloat(), compactR(h), C.BLACK, 340, 10f, { f ->
            st.glow.setVisible(st.shape.vW, st.shape.vH)
            val o = 1f - smooth(f / 0.38f)
            st.shape.auraAlpha = smooth((f - 0.35f) / 0.65f)
            box.alpha = a0 * o
            val s = 0.96f + 0.04f * o
            box.scaleX = s
            box.scaleY = s
            st.ghost?.alpha = smooth((f - 0.5f) / 0.45f)
        }) {
            removeStage(st)
            cur = null
            closing = false
            box.alpha = 1f
            box.scaleX = 1f
            box.scaleY = 1f
            updateCompact()
            val n = queue.poll()
            if (n != null) showAlert(n)
        }
    }

    // ------------------------------------------------------------ public API

    fun showCompact() {
        ui.removeCallbacks(endAlert)
        if (closing) return
        if (replying) endReplyMode()
        endChatType()
        if (state == S.COMPACT && cur == null && pend == null) {
            updateCompact()
            fitCompact()
            return
        }
        state = S.COMPACT
        current = null
        cancelPending()
        notifyVisibility()
        val st = cur
        if (st == null) {
            resetPillNow()
            return
        }
        closeStage(st)
    }

    fun enqueue(a: Alert) {
        pet.perk()
        when {
            state == S.PANEL -> return
            state == S.ALERT || closing || pend != null -> if (queue.size < 4) queue.add(a)
            else -> showAlert(a)
        }
    }

    private fun showAlert(a: Alert) {
        state = S.ALERT
        current = a
        aTitle.text = a.title
        aSub.text = a.sub
        if (a.icon != null) {
            aImg.visibility = VISIBLE
            aImg.setImageDrawable(a.icon)
            aGlyph.visibility = GONE
            aLine.visibility = GONE
            aIconBox.background = null
        } else {
            aImg.visibility = GONE
            val kind = glyphIcon(a.glyph)
            if (kind != null) {
                aLine.set(kind, a.color)
                aLine.visibility = VISIBLE
                aGlyph.visibility = GONE
            } else {
                aGlyph.text = a.glyph
                aGlyph.setTextColor(a.color)
                aGlyph.visibility = VISIBLE
                aLine.visibility = GONE
            }
            // lingkaran lembut berwarna aksen (tint), bukan blok warna pekat
            aIconBox.background = rounded(Color.argb(0x33, Color.red(a.color), Color.green(a.color), Color.blue(a.color)), svc.dpf(21))
        }
        aIconBox.animate().cancel()
        aIconBox.scaleX = 0.6f
        aIconBox.scaleY = 0.6f
        aIconBox.animate().scaleX(1f).scaleY(1f).setStartDelay(140).setDuration(380)
            .setInterpolator(OvershootInterpolator(2.2f)).start()
        aReplyBtn.visibility = if (a.reply != null) VISIBLE else GONE
        val needH = if (a.reply != null) svc.dp(ALERT_EXP_H) else 0
        val st = cur
        if (st != null && st.kind == S.ALERT && !closing) {
            if (st.winH >= needH) {
                // alert berikutnya: jendela sama, isi diganti dengan fade singkat
                alertBox.alpha = 0f
                alertBox.animate().alpha(1f).setDuration(180).start()
                ui.removeCallbacks(endAlert)
                ui.postDelayed(endAlert, a.ms)
            } else {
                // alert berikutnya butuh jendela lebih tinggi (untuk kolom balas)
                openStage(S.ALERT, st)
            }
            return
        }
        openStage(S.ALERT, null)
    }

    // ------------------------------------------------------------ balas notifikasi dari notch

    private fun imm(): InputMethodManager = svc.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

    private fun beginReply() {
        val st = cur ?: return
        val a = current ?: return
        if (a.reply == null || st.kind != S.ALERT || closing || replying || state != S.ALERT) return
        if (!host.canType() || st.winH < svc.dp(ALERT_EXP_H)) {
            // jendela overlay jenis ini tidak bisa menerima keyboard -> kolom balas lewat activity kecil
            ReplyBridge.title = a.title
            ReplyBridge.fn = a.reply
            ui.removeCallbacks(endAlert)
            queue.clear()
            current = null
            showCompact()
            try {
                val i = Intent(svc, ReplyActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                svc.startActivity(i)
            } catch (e: Exception) {
            }
            return
        }
        replying = true
        ui.removeCallbacks(endAlert)
        aInput.setText("")
        aInput.hint = "Reply to " + a.title
        aReplyRow.alpha = 0f
        aReplyRow.visibility = VISIBLE
        host.setFocusable(st, true)
        st.shape.animate(alertW().toFloat(), svc.dp(ALERT_EXP_H).toFloat(), svc.dpf(ALERT_R), C.BLACK, 360, 10f, { f ->
            aReplyRow.alpha = smooth((f - 0.3f) / 0.6f)
        }) {
            aReplyRow.alpha = 1f
        }
        aInput.postDelayed({
            if (replying) {
                aInput.requestFocus()
                try {
                    imm().showSoftInput(aInput, 0)
                } catch (e: Exception) {
                }
            }
        }, 140)
    }

    private fun sendReply() {
        val a = current ?: return
        val t = aInput.text.toString().trim()
        if (t.isEmpty()) return
        val ok = try {
            a.reply?.invoke(t) ?: false
        } catch (e: Exception) {
            false
        }
        val who = a.title
        showCompact()
        Bus.alert(
            if (ok) Alert("Reply sent", who, "✓", C.GREEN, ms = 2000L)
            else Alert("Couldn't send reply", who, "!", C.RED)
        )
    }

    private fun endReplyMode() {
        replying = false
        try {
            imm().hideSoftInputFromWindow(aInput.windowToken, 0)
        } catch (e: Exception) {
        }
        aInput.clearFocus()
        cur?.let { host.setFocusable(it, false) }
        aReplyRow.visibility = GONE
    }

    private fun styleTabs(animate: Boolean = false) {
        for (i in tabViews.indices) {
            val sel = i == tab
            tabViews[i].alpha = if (sel) 1f else 0.45f
            tabViews[i].background = if (sel) rounded(0x26FFFFFF, svc.dpf(100)) else null
        }
        scrollToTab(tab, animate)
    }

    /** Lebar tiap tab = lebar baris tab / 4 (atau dibagi rata kalau tab-nya <= 4). */
    private fun layoutTabs() {
        val n = minOf(tabIcons.size, VISIBLE_TABS)
        val cw = (panelW() - svc.dp(24) - svc.dp(42)) / n
        tabsScroll.step = if (tabIcons.size > VISIBLE_TABS) cw else 0
        for (cell in tabCells) {
            val lp = cell.layoutParams
            if (lp.width != cw) {
                lp.width = cw
                cell.layoutParams = lp
            }
        }
    }

    /** Geser baris tab seperlunya supaya tab [i] terlihat utuh. */
    private fun scrollToTab(i: Int, animate: Boolean) {
        tabsScroll.post {
            val cw = tabsScroll.step
            if (cw <= 0) return@post
            val vw = if (tabsScroll.width > 0) tabsScroll.width else cw * VISIBLE_TABS
            val left = i * cw
            val right = left + cw
            val x = tabsScroll.scrollX
            val to = when {
                left < x -> left
                right > x + vw -> right - vw
                else -> x
            }
            if (to != x) {
                if (animate) tabsScroll.smoothScrollTo(to, 0) else tabsScroll.scrollTo(to, 0)
            }
        }
    }

    // ------------------------------------------------------------ ketik di tab Chat

    private fun beginChatType() {
        val st = cur ?: return
        if (st.kind != S.PANEL || closing || state != S.PANEL || tab != CHAT_TAB || chat.typing) return
        if (!host.canType()) {
            // overlay Accessibility tidak bisa menerima keyboard -> ketik lewat activity kecil
            showCompact()
            try {
                val i = Intent(svc, ChatInputActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                svc.startActivity(i)
            } catch (e: Exception) {
            }
            return
        }
        chat.startTyping()
        host.setFocusable(st, true)
        chat.input.postDelayed({
            if (chat.typing) {
                chat.input.requestFocus()
                try {
                    imm().showSoftInput(chat.input, 0)
                } catch (e: Exception) {
                }
            }
        }, 140)
    }

    private fun endChatType() {
        if (!chat.typing) return
        try {
            imm().hideSoftInputFromWindow(chat.input.windowToken, 0)
        } catch (e: Exception) {
        }
        chat.stopTyping()
        cur?.let { host.setFocusable(it, false) }
    }

    private fun preparePanels() {
        layoutTabs()
        for (i in panels.indices) {
            panels[i].alpha = 1f
            panels[i].visibility = if (i == tab) VISIBLE else GONE
        }
        styleTabs()
        (panels[tab] as Refreshable).refresh()
    }

    fun showPanel(t: Int) {
        if (closing) return
        ui.removeCallbacks(endAlert)
        queue.clear()
        current = null
        val nt = t.coerceIn(0, panels.size - 1)
        if (state == S.PANEL && cur != null) {
            selectTab(nt)
            return
        }
        if (state == S.PANEL && pend != null) {
            // panel sedang disiapkan: cukup ganti tab awalnya
            tab = nt
            Lobo.prefs.lastTab = nt
            preparePanels()
            return
        }
        val from = if (state == S.ALERT) cur else null
        state = S.PANEL
        tab = nt
        Lobo.prefs.lastTab = nt
        preparePanels()
        openStage(S.PANEL, from)
    }

    private fun selectTab(t: Int) {
        if (t == tab) return
        endChatType()
        val st = cur
        val old = tab
        tab = t
        Lobo.prefs.lastTab = t
        styleTabs(true)
        val inV = panels[t]
        val outV = panels[old]
        for (i in panels.indices) {
            if (i != t && i != old) panels[i].visibility = GONE
        }
        (inV as Refreshable).refresh()
        inV.alpha = 0f
        inV.visibility = VISIBLE
        if (st == null) {
            outV.visibility = GONE
            inV.alpha = 1f
            notifyVisibility()
            return
        }
        // kalau animasi buka belum selesai, finalkan dulu isinya supaya tidak tersangkut transparan
        panelBox.alpha = 1f
        panelBox.scaleX = 1f
        panelBox.scaleY = 1f
        st.ghost?.alpha = 0f
        val outA = outV.alpha
        val g = glowFor(t)
        st.glow.flash(g[0], g[1])
        st.shape.animate(panelW().toFloat(), panelH(t).toFloat(), svc.dpf(28), wantedTint(), 340, 11f, { f ->
            outV.alpha = outA * (1f - smooth(f / 0.4f))
            inV.alpha = smooth((f - 0.2f) / 0.6f)
            st.glow.setVisible(st.shape.vW, st.shape.vH)
        }) {
            outV.visibility = GONE
            outV.alpha = 1f
            inV.alpha = 1f
        }
        notifyVisibility()
    }

    fun refreshData() {
        if (state == S.PANEL) (panels[tab] as Refreshable).refresh()
    }

    // ------------------------------------------------------------ system hooks

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        post {
            replying = false
            endChatType()
            abortStages()
            ui.removeCallbacks(endAlert)
            queue.clear()
            current = null
            state = S.COMPACT
            notifyVisibility()
            resetPillNow()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ui.post(uiTick)
    }

    override fun onDetachedFromWindow() {
        ui.removeCallbacks(uiTick)
        ui.removeCallbacks(endAlert)
        abortStages()
        Markets.stop()
        PrivSampler.stop()
        super.onDetachedFromWindow()
    }
}
