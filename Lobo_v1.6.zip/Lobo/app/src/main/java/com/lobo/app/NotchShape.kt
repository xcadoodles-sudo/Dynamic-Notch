package com.lobo.app

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.os.SystemClock
import android.view.Choreographer
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.Interpolator
import android.widget.FrameLayout
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * Pegas teredam kritis (tanpa overshoot): mulai halus, cepat di tengah, mendarat lembut.
 * w makin besar = makin cepat mendarat.
 */
class Spring(private val w: Float) : Interpolator {
    private val norm = 1f - (1f + w) * Math.exp(-w.toDouble()).toFloat()

    override fun getInterpolation(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return (1f - (1f + w * x) * Math.exp((-w * x).toDouble()).toFloat()) / norm
    }
}

/**
 * Bentuk notch. Dua lapis:
 *  - lapisan bawah menggambar siluet penuh (termasuk "telinga" cekung di sudut atas, seperti
 *    notch MacBook) dengan gradasi warna;
 *  - lapisan [content] di atasnya, di-clip ke badan notch (tanpa telinga), tempat semua isi ditaruh.
 *
 * Bentuk (lebar, tinggi, radius) dianimasikan lewat [animate]. Selama animasi tidak ada layout
 * ulang dan tidak ada perubahan ukuran jendela: yang berubah cuma outline dan siluet.
 */
class NotchShape(c: Context) : FrameLayout(c) {
    private companion object {
        // warna bawaan aura musik kalau cover album tidak ada (sama dengan bawaan EqView)
        private val AURA_A = 0xFF8B7BFF.toInt()
        private val AURA_B = 0xFF40C8E0.toInt()
    }

    val content = FrameLayout(c)

    var vW = 0f
        private set
    var vH = 0f
        private set
    var vR = 0f
        private set
    var tint = C.BLACK
        private set

    /** Menempel di tepi atas layar (atas datar + telinga). false = pil melayang. */
    var flat = true

    /** Radius telinga (px). 0 = tanpa telinga. */
    var ear = 0f

    private val bgView = object : View(c) {
        override fun onDraw(canvas: Canvas) {
            drawShape(canvas)
        }
    }

    /** Lapisan kaca di atas isi: kilau, tepi dalam, garis tepi terang. Tidak menangkap sentuhan. */
    private val gloss = object : View(c) {
        override fun onDraw(canvas: Canvas) {
            drawGloss(canvas)
        }
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val veil = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val path = Path()
    private val arc = RectF()
    private val gm = Matrix()
    private var shader: LinearGradient? = null

    private val choreo = Choreographer.getInstance()
    private val argb = ArgbEvaluator()
    private var running = false
    private var dur = 1f
    private var el = 0f
    private var last = 0L
    private var w0 = 0f
    private var h0 = 0f
    private var r0 = 0f
    private var w1 = 0f
    private var h1 = 0f
    private var r1 = 0f
    private var t0 = 0
    private var t1 = 0
    private var eW: Interpolator = Spring(9f)
    private var eH: Interpolator = Spring(10f)
    private var onProg: ((Float) -> Unit)? = null
    private var onDone: (() -> Unit)? = null
    private var tintAnim: ValueAnimator? = null

    // ---- aura idle: cahaya HANYA di dalam notch (tanpa halo / garis tepi).
    //      Diam  : biru -> indigo -> ungu naik dari dasar notch.
    //      Musik : tiga gumpalan cahaya warna cover album melayang pelan ke kiri/kanan,
    //              membesar-mengecil ikut denyut equalizer, warnanya berpindah mulus saat lagu ganti.
    private val innerM = Matrix()
    private val blobM = Matrix()
    private val innerShader = RadialGradient(
        0f, 0f, 1f,
        intArrayOf(0xB35B7CFF.toInt(), 0x667C4DFF.toInt(), 0x007C4DFF),
        floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
    )
    private val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = innerShader }
    private val blobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN) // cahaya saling menumpuk, bukan saling menutup
    }
    private var shA: RadialGradient? = null
    private var shB: RadialGradient? = null
    private var shC: RadialGradient? = null

    private var wantMusic = false
    private var mix = 0f          // 0 = tampilan diam, 1 = tampilan musik (dihaluskan)
    private var en = 0f           // energi equalizer yang sudah dihaluskan, 0..1
    private var lastAura = 0L
    private var fromA = AURA_A
    private var fromB = AURA_B
    private var toA = AURA_A
    private var toB = AURA_B
    private var curA = AURA_A
    private var curB = AURA_B
    private var colT = 1f

    /** Sumber denyut 0..1 (rata-rata tinggi bar equalizer). null = tidak berdenyut. */
    var energy: (() -> Float)? = null

    /** true = jangan menjadwalkan frame animasi sendiri (pil tertutup panel/alert, hemat baterai). */
    var paused = false
        set(v) {
            if (field == v) return
            field = v
            if (!v) bgView.invalidate()
        }

    /**
     * 0 = hitam pekat seperti pil di bezel, 1 = liquid glass penuh (tembus pandang + kilau + tepi terang).
     * Dinaikkan saat panel/alert terbuka dan diturunkan lagi saat menutup, supaya pil tetap menyatu dengan bezel.
     */
    var glass = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            bgView.invalidate()
            gloss.invalidate()
        }

    /**
     * true = titik pantul cahaya mengembara pelan dan mengikuti jari (panel/alert). Pil idle tetap diam
     * supaya tidak menggambar ulang terus (hemat baterai).
     */
    var liquid = false

    private var lightX = 0.17f
    private var lightT = 0.17f
    private var lightTouch = false
    private var lastLight = 0L

    /** Jari menyentuh/menggeser di [xPx] (koordinat view): titik pantul ikut ke sana. */
    fun touchLight(xPx: Float, active: Boolean) {
        if (vW > 0f) lightT = ((xPx - (width / 2f - vW / 2f)) / vW).coerceIn(0.02f, 0.98f)
        lightTouch = active
        gloss.invalidate()
    }

    /** Kilau yang menyapu kaca saat panel membuka. 0..1 = posisi sapuan, < 0 = mati. */
    var sheen = -1f
        set(v) {
            field = v
            gloss.invalidate()
        }

    /** 0 = polos hitam (dipakai alert/panel), 1 = aura penuh (pil idle). Dipudarkan saat morph. */
    var auraAlpha = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            bgView.invalidate()
        }

    val animating: Boolean get() = running

    init {
        addView(bgView, LayoutParams(MATCH, MATCH))
        addView(content, LayoutParams(MATCH, MATCH))
        addView(gloss, LayoutParams(MATCH, MATCH))
        content.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val cx = view.width / 2f
                val l = Math.round(cx - vW / 2f)
                val r = Math.round(cx + vW / 2f)
                val top = if (flat) -Math.round(vR) - 2 else 0
                outline.setRoundRect(l, top, r, Math.round(vH), vR)
            }
        }
        content.clipToOutline = true
        buildShader(C.BLACK)
    }

    // ------------------------------------------------------------ warna

    private fun buildShader(col: Int) {
        val dark = Color.rgb((Color.red(col) * 0.5f).toInt(), (Color.green(col) * 0.5f).toInt(), (Color.blue(col) * 0.5f).toInt())
        shader = LinearGradient(0f, 0f, 1f, 0f, col, dark, Shader.TileMode.CLAMP)
        paint.shader = shader
    }

    fun setTintNow(col: Int) {
        tint = col
        buildShader(col)
        bgView.invalidate()
    }

    /** Pindah warna halus (dipakai saat warna album berubah). Diabaikan selagi bentuk beranimasi. */
    fun animateTint(target: Int) {
        if (target == tint || running) return
        if (tintAnim?.isRunning == true) return
        val a = ValueAnimator.ofArgb(tint, target)
        a.duration = 350
        a.addUpdateListener { setTintNow(it.animatedValue as Int) }
        a.start()
        tintAnim = a
    }

    // ------------------------------------------------------------ gambar

    private fun drawShape(cv: Canvas) {
        if (vW <= 0f || vH <= 0f) return
        val cx = width / 2f
        val l = cx - vW / 2f
        val r = cx + vW / 2f
        val br = minOf(vR, vH / 2f, vW / 2f)
        path.reset()
        if (flat && ear > 0.5f) {
            val e = minOf(ear, vH - br)
            path.moveTo(l - e, 0f)
            path.lineTo(r + e, 0f)
            // telinga kanan: lengkung cekung dari tepi atas turun ke sisi badan
            arc.set(r, 0f, r + 2f * e, 2f * e)
            path.arcTo(arc, 270f, -90f)
            path.lineTo(r, vH - br)
            arc.set(r - 2f * br, vH - 2f * br, r, vH)
            path.arcTo(arc, 0f, 90f)
            path.lineTo(l + br, vH)
            arc.set(l, vH - 2f * br, l + 2f * br, vH)
            path.arcTo(arc, 90f, 90f)
            path.lineTo(l, e)
            // telinga kiri
            arc.set(l - 2f * e, 0f, l, 2f * e)
            path.arcTo(arc, 0f, -90f)
            path.close()
        } else {
            val top = if (flat) -br - 2f else 0f
            path.addRoundRect(l, top, r, vH, br, br, Path.Direction.CW)
        }
        gm.setScale(vW, 1f)
        gm.postTranslate(l, 0f)
        shader?.setLocalMatrix(gm)
        val a = auraAlpha
        // liquid glass: isi makin tembus pandang seiring [glass], plus kerudung putih tipis (efek susu)
        val op = Lobo.prefs.glassPct.coerceIn(20, 100) / 100f
        paint.alpha = (255f * (1f - glass + glass * op)).toInt().coerceIn(0, 255)
        cv.drawPath(path, paint)
        if (glass > 0.01f) {
            veil.alpha = (22f * glass).toInt()
            cv.drawPath(path, veil)
        }
        if (a > 0.01f) {
            val t = stepAura()
            // cahaya diam: naik dari dasar notch, memudar saat tampilan musik masuk
            val still = 1f - mix
            if (still > 0.01f) {
                innerM.setScale(vW * 0.62f, vH * 1.15f)
                innerM.postTranslate(cx, vH)
                innerShader.setLocalMatrix(innerM)
                innerPaint.alpha = (255f * a * still).toInt()
                cv.drawPath(path, innerPaint)
            }
            if (mix > 0.01f) drawBlobs(cv, cx, t, a * mix)
            if (!paused && (wantMusic || mix > 0.004f || colT < 1f)) bgView.postInvalidateOnAnimation()
        }
    }

    // ------------------------------------------------------------ kaca (liquid glass)

    private val gPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gPath = Path()
    private val gRect = RectF()
    private val gM = Matrix()
    private val glossSh = LinearGradient(0f, 0f, 0f, 1f, 0x44FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
    private val specSh = RadialGradient(
        0f, 0f, 1f, intArrayOf(0x38FFFFFF, 0x00FFFFFF), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
    )
    private val bevelSh = LinearGradient(
        0f, 0f, 0f, 1f, intArrayOf(0x4DFFFFFF, 0x12FFFFFF, 0x4AFFFFFF),
        floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
    )
    private val rimSh = LinearGradient(
        0f, 0f, 1f, 1f, intArrayOf(0xE6FFFFFF.toInt(), 0x26FFFFFF, 0x8CFFFFFF.toInt()),
        floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
    )
    private val sheenSh = LinearGradient(
        0f, 0f, 1f, 0f, intArrayOf(0x00FFFFFF, 0x55FFFFFF, 0x00FFFFFF),
        floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
    )
    private val irisSh = SweepGradient(
        0f, 0f,
        intArrayOf(
            0xDDFF9AD5.toInt(), 0xDDFFD59A.toInt(), 0xDDC4FF9A.toInt(),
            0xDD9AF3FF.toInt(), 0xDDB59AFF.toInt(), 0xDDFF9AD5.toInt()
        ),
        null
    )

    private fun drawGloss(cv: Canvas) {
        val g = glass
        if (g <= 0.01f || vW <= 0f || vH <= 0f) return
        val cx = width / 2f
        val l = cx - vW / 2f
        val r = cx + vW / 2f
        val br = minOf(vR, vH / 2f, vW / 2f)
        val top = if (flat) -br - 2f else 0f
        val d = resources.displayMetrics.density
        gRect.set(l, top, r, vH)
        gPath.reset()
        gPath.addRoundRect(gRect, br, br, Path.Direction.CW)
        val ga = (255f * g).toInt().coerceIn(0, 255)

        // titik pantul: mengembara pelan, atau mengikuti jari kalau sedang disentuh
        if (liquid) {
            val now = SystemClock.uptimeMillis()
            val dt = if (lastLight == 0L) 0.016f else ((now - lastLight).coerceIn(1L, 100L)) / 1000f
            lastLight = now
            if (!lightTouch) lightT = 0.5f + 0.34f * sin(now / 1000.0 * 2.0 * PI / 9.0).toFloat()
            lightX += (lightT - lightX) * (1f - exp(-7f * dt))
        }

        cv.save()
        cv.clipPath(gPath)

        // kilau licin di bagian atas
        gPaint.style = Paint.Style.FILL
        gM.setScale(1f, vH * 0.6f)
        glossSh.setLocalMatrix(gM)
        gPaint.shader = glossSh
        gPaint.alpha = ga
        cv.drawRect(l, 0f, r, vH * 0.6f, gPaint)

        // titik pantul cahaya di kiri atas
        gM.setScale(vW * 0.34f, vH * 0.95f)
        gM.postTranslate(l + vW * lightX, 0f)
        specSh.setLocalMatrix(gM)
        gPaint.shader = specSh
        gPaint.alpha = if (lightTouch) ga else (ga * 0.85f).toInt()
        cv.drawRect(l, 0f, r, vH, gPaint)

        // tepi dalam: cahaya tipis menyusuri sisi dalam kaca (kesan tebal kaca)
        gPaint.style = Paint.Style.STROKE
        gPaint.strokeWidth = minOf(d * 6f, vH * 0.3f)
        gM.setScale(1f, vH)
        bevelSh.setLocalMatrix(gM)
        gPaint.shader = bevelSh
        gPaint.alpha = ga
        cv.drawPath(gPath, gPaint)

        // sapuan kilau saat membuka
        val sh = sheen
        if (sh in 0f..1f) {
            val bw = vW * 0.38f
            val x = l - bw + (vW + 2f * bw) * sh
            gPaint.style = Paint.Style.FILL
            gM.setScale(bw, vH)
            gM.postSkew(-0.5f, 0f)
            gM.postTranslate(x, 0f)
            sheenSh.setLocalMatrix(gM)
            gPaint.shader = sheenSh
            gPaint.alpha = (ga * sin(PI * sh)).toInt().coerceIn(0, 255)
            cv.drawRect(l, 0f, r, vH, gPaint)
        }
        cv.restore()

        // dispersi cahaya di tepi (magenta ke kiri, cyan ke kanan) seperti bias kaca sungguhan
        gPaint.style = Paint.Style.STROKE
        gPaint.strokeWidth = d * 1.2f
        gPaint.shader = null
        gPaint.color = Color.argb((0x5A * g).toInt().coerceIn(0, 255), 0xFF, 0x5F, 0xD2)
        cv.save()
        cv.translate(-d * 0.8f, 0f)
        cv.drawPath(gPath, gPaint)
        cv.restore()
        gPaint.color = Color.argb((0x5A * g).toInt().coerceIn(0, 255), 0x40, 0xE0, 0xFF)
        cv.save()
        cv.translate(d * 0.8f, 0f)
        cv.drawPath(gPath, gPaint)
        cv.restore()

        // garis tepi terang (terang di sudut kiri atas & kanan bawah, redup di tengah)
        if (Themes.cur() == Themes.AURORA) {
            gM.setRotate((SystemClock.uptimeMillis() % 9000L) / 9000f * 360f)
            gM.postTranslate(cx, vH / 2f)
            irisSh.setLocalMatrix(gM)
            gPaint.shader = irisSh
            gPaint.alpha = ga
            cv.drawPath(gPath, gPaint)
            if (!paused) gloss.postInvalidateOnAnimation()
        } else {
            gM.setScale(vW, vH)
            gM.postTranslate(l, 0f)
            rimSh.setLocalMatrix(gM)
            gPaint.shader = rimSh
            gPaint.alpha = ga
            cv.drawPath(gPath, gPaint)
        }
        if (liquid && !paused) gloss.postInvalidateOnAnimation()
    }

    // ------------------------------------------------------------ aura musik

    /**
     * Nyalakan/matikan tampilan musik. [a] dan [b] = dua warna cover album; berpindah mulus
     * (bukan loncat) kalau lagu ganti. Aman dipanggil berulang dengan nilai sama.
     */
    fun setMusic(on: Boolean, a: Int, b: Int) {
        var changed = false
        if (a != toA || b != toB) {
            if (mix < 0.02f && !wantMusic) {
                // belum terlihat: langsung ganti warna tanpa transisi
                fromA = a
                fromB = b
                curA = a
                curB = b
                colT = 1f
                buildBlobs()
            } else {
                fromA = curA
                fromB = curB
                colT = 0f
            }
            toA = a
            toB = b
            changed = true
        }
        if (wantMusic != on) {
            wantMusic = on
            changed = true
        }
        if (changed) bgView.invalidate()
    }

    /** Salin keadaan aura supaya jendela baru menggambar frame yang persis sama dengan jendela lama. */
    fun copyAuraFrom(o: NotchShape) {
        wantMusic = o.wantMusic
        mix = o.mix
        en = o.en
        fromA = o.fromA
        fromB = o.fromB
        toA = o.toA
        toB = o.toB
        curA = o.curA
        curB = o.curB
        colT = o.colT
        energy = o.energy
        buildBlobs()
        bgView.invalidate()
    }

    private fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

    private fun lighten(c: Int, w: Float): Int = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * w).toInt(),
        (Color.green(c) + (255 - Color.green(c)) * w).toInt(),
        (Color.blue(c) + (255 - Color.blue(c)) * w).toInt()
    )

    private fun blobShader(c: Int): RadialGradient = RadialGradient(
        0f, 0f, 1f,
        intArrayOf(withAlpha(c, 0xA8), withAlpha(c, 0x55), withAlpha(c, 0x00)),
        floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
    )

    private fun buildBlobs() {
        shA = blobShader(curA)
        shB = blobShader(curB)
        shC = blobShader(lighten(argb.evaluate(0.5f, curA, curB) as Int, 0.12f))
    }

    /**
     * Majukan keadaan aura sebesar waktu sejak frame sebelumnya (tidak bergantung frame rate).
     * @return waktu (detik) untuk fase gerakan. Jam-nya global, jadi pil dan jendela panel/alert
     * selalu sefase tanpa perlu disinkronkan.
     */
    private fun stepAura(): Double {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastAura == 0L) 0.016f else ((now - lastAura).coerceIn(1L, 500L)) / 1000f
        lastAura = now

        val goal = if (wantMusic) 1f else 0f
        mix += (goal - mix) * (1f - exp(-3.4f * dt))
        if (abs(goal - mix) < 0.004f) mix = goal

        if (colT < 1f) {
            colT = min(1f, colT + dt / 0.9f)
            val e = colT * colT * (3f - 2f * colT)
            curA = argb.evaluate(e, fromA, toA) as Int
            curB = argb.evaluate(e, fromB, toB) as Int
            buildBlobs()
        } else if (shA == null) {
            buildBlobs()
        }

        // denyut: naik cepat, turun pelan (sama wataknya dengan bar equalizer)
        val target = if (wantMusic) (energy?.invoke() ?: 0f).coerceIn(0f, 1f) else 0f
        en += (target - en) * (1f - exp(-(if (target > en) 12f else 4f) * dt))
        return now / 1000.0
    }

    private fun drawBlobs(cv: Canvas, cx: Float, t: Double, amt: Float) {
        val w = vW
        val h = vH
        val e = en
        val tau = 2.0 * PI
        val pulse = 0.78f + 0.22f * e
        // A: warna utama, menyapu kiri-kanan
        blob(
            cv, shA,
            cx + w * 0.30f * sin(tau * t / 6.1).toFloat(),
            h * (1.04f + 0.06f * sin(tau * t / 4.3 + 1.0).toFloat()),
            w * (0.46f + 0.08f * e), h * (1.20f + 0.45f * e),
            amt * pulse
        )
        // B: warna kedua, arah & periode beda supaya dua warna saling melewati
        blob(
            cv, shB,
            cx - w * 0.30f * sin(tau * t / 7.4 + 0.9).toFloat(),
            h * (1.04f + 0.06f * sin(tau * t / 5.2 + 2.4).toFloat()),
            w * (0.46f + 0.08f * e), h * (1.20f + 0.45f * e),
            amt * pulse
        )
        // C: campuran keduanya, lebih kecil dan lebih terang, bergerak lebih cepat
        blob(
            cv, shC,
            cx + w * 0.16f * sin(tau * t / 3.7 + 2.0).toFloat(),
            h * (1.10f + 0.05f * sin(tau * t / 2.9).toFloat()),
            w * (0.22f + 0.07f * e), h * (0.85f + 0.40f * e),
            amt * (0.30f + 0.30f * e)
        )
    }

    private fun blob(cv: Canvas, sh: RadialGradient?, x: Float, y: Float, rx: Float, ry: Float, alpha: Float) {
        if (sh == null) return
        blobM.setScale(rx, ry)
        blobM.postTranslate(x, y)
        sh.setLocalMatrix(blobM)
        blobPaint.shader = sh
        blobPaint.alpha = (255f * alpha).toInt().coerceIn(0, 255)
        cv.drawPath(path, blobPaint)
    }

    private fun touch() {
        content.invalidateOutline()
        bgView.invalidate()
        gloss.invalidate()
    }

    // ------------------------------------------------------------ animasi

    fun setShapeNow(w: Float, h: Float, r: Float) {
        stopAnim()
        vW = w
        vH = h
        vR = r
        touch()
    }

    private fun stopAnim() {
        if (running) {
            choreo.removeFrameCallback(frameCb)
            running = false
        }
        onProg = null
        onDone = null
    }

    fun release() {
        stopAnim()
        tintAnim?.cancel()
    }

    /**
     * Morph ke bentuk baru mulai dari bentuk yang tampil sekarang (aman dipanggil ulang di tengah
     * animasi). [onProgress] menerima kemajuan 0..1 yang sudah di-ease; [onEnd] dipanggil sekali
     * di akhir (tidak dipanggil kalau animasi diganti animasi lain).
     */
    fun animate(
        w: Float, h: Float, r: Float, tintTo: Int, durMs: Long, omega: Float,
        onProgress: ((Float) -> Unit)? = null, onEnd: (() -> Unit)? = null
    ) {
        if (running) {
            choreo.removeFrameCallback(frameCb)
            running = false
        }
        tintAnim?.cancel()
        w0 = vW
        h0 = vH
        r0 = vR
        w1 = w
        h1 = h
        r1 = r
        t0 = tint
        t1 = tintTo
        eW = Spring(omega)
        eH = Spring(omega * 1.18f)
        dur = durMs.toFloat()
        el = 0f
        last = 0L
        onProg = onProgress
        onDone = onEnd
        running = true
        choreo.postFrameCallback(frameCb)
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            if (last == 0L) {
                last = frameTimeNanos
            } else {
                // dt dibatasi supaya frame tersendat tidak bikin animasi melompat
                el += ((frameTimeNanos - last) / 1_000_000f).coerceIn(0f, 32f)
                last = frameTimeNanos
            }
            val u = (el / dur).coerceAtMost(1f)
            val f = eW.getInterpolation(u)
            val fh = eH.getInterpolation(u)
            vW = w0 + (w1 - w0) * f
            vH = h0 + (h1 - h0) * fh
            vR = r0 + (r1 - r0) * f
            if (t1 != t0) {
                tint = argb.evaluate(f, t0, t1) as Int
                buildShader(tint)
            }
            touch()
            onProg?.invoke(f)
            if (u >= 1f) {
                running = false
                vW = w1
                vH = h1
                vR = r1
                if (t1 != t0) {
                    tint = t1
                    buildShader(t1)
                }
                touch()
                val d = onDone
                onDone = null
                onProg = null
                d?.invoke()
            } else {
                choreo.postFrameCallback(this)
            }
        }
    }

    override fun onDetachedFromWindow() {
        stopAnim()
        tintAnim?.cancel()
        super.onDetachedFromWindow()
    }
}
