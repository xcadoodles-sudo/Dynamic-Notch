package com.xcadoodle.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class LrcLine(val t: Long, val text: String)

/** Lirik dari LRCLIB (lrclib.net) – format LRC bertimestamp. */
object Lrc {
    private val ts = Regex("\\[(\\d+):(\\d+)(?:[.:](\\d+))?\\]")

    fun parse(src: String): List<LrcLine> {
        val out = ArrayList<LrcLine>()
        for (line in src.lines()) {
            val ms = ts.findAll(line).toList()
            if (ms.isEmpty()) continue
            val text = line.substring(ms.last().range.last + 1).trim()
            for (m in ms) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val msv = if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong()
                out.add(LrcLine(min * 60000L + sec * 1000L + msv, text))
            }
        }
        out.sortBy { it.t }
        return out
    }

    private fun http(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "Xcadoodle-Notch/1.0 (Android)")
        return try {
            if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
        } finally {
            c.disconnect()
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    /** Blocking – panggil dari thread background. */
    fun fetch(track: String, artist: String, durMs: Long): List<LrcLine>? {
        val tries = listOf(
            "https://lrclib.net/api/search?track_name=${enc(track)}&artist_name=${enc(artist)}",
            "https://lrclib.net/api/search?q=${enc("$track $artist")}"
        )
        for (u in tries) {
            try {
                val body = http(u) ?: continue
                val arr = JSONArray(body)
                var best: String? = null
                var bestD = Long.MAX_VALUE
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val s = o.optString("syncedLyrics", "")
                    if (s.isBlank() || s == "null") continue
                    val d = if (durMs > 0) Math.abs((o.optDouble("duration", 0.0) * 1000).toLong() - durMs) else 0L
                    if (d < bestD) {
                        bestD = d
                        best = s
                    }
                }
                if (best != null) {
                    val l = parse(best)
                    if (l.isNotEmpty()) return l
                }
            } catch (e: Exception) {
            }
        }
        return null
    }
}

/** Memantau sesi media aktif (Spotify, YouTube Music, dll) lewat MediaSessionManager. */
class MediaWatcher(private val ctx: Context, private val onChange: () -> Unit) {
    private val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val cn = ComponentName(ctx, XcadoodleNotificationListener::class.java)
    private val main = Handler(Looper.getMainLooper())
    private var ctl: MediaController? = null
    private var registered = false

    var granted = false
        private set
    var hasSession = false
        private set
    var title = ""
        private set
    var artist = ""
        private set
    var art: Bitmap? = null
        private set
    var duration = 0L
        private set
    var playing = false
        private set
    var lyrics: List<LrcLine>? = null
        private set
    var lyricsState = 0 // 0 kosong, 1 loading, 2 ada, 3 tidak ada
        private set
    var pkg = ""
        private set

    // ---- lagu terakhir (untuk mode standby di tab Music)
    val hasLast: Boolean get() = Xcadoodle.prefs.lastTitle.isNotBlank()
    val lastTitle: String get() = Xcadoodle.prefs.lastTitle
    val lastArtist: String get() = Xcadoodle.prefs.lastArtist

    /** App yang dipakai untuk logo / tombol buka app: sesi aktif, kalau tidak ada pakai lagu terakhir. */
    val appPkg: String get() = if (hasSession && pkg.isNotEmpty()) pkg else Xcadoodle.prefs.lastPkg

    private val artFile = File(ctx.filesDir, "last_art.png")
    private var lastArtBmp: Bitmap? = null
    private var lastArtLoaded = false
    private var savedArt: Bitmap? = null

    val lastArt: Bitmap?
        get() {
            if (!lastArtLoaded) {
                lastArtLoaded = true
                lastArtBmp = try {
                    BitmapFactory.decodeFile(artFile.path)
                } catch (e: Throwable) {
                    null
                }
            }
            return lastArtBmp
        }

    private var lyricKey = ""
    private var basePos = 0L
    private var baseTime = 0L
    private var speed = 1f

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            readMeta(metadata)
            onChange()
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            readState(state)
            if (state == null || state.state != PlaybackState.STATE_PLAYING) pick(safeSessions())
            onChange()
        }

        override fun onSessionDestroyed() {
            pick(safeSessions())
        }
    }

    private fun refreshGranted() {
        granted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }

    private fun safeSessions(): List<MediaController>? {
        return try {
            msm.getActiveSessions(cn)
        } catch (e: SecurityException) {
            null
        }
    }

    /** Aman dipanggil berulang; mendaftar begitu izin notification access diberikan. */
    fun ensure() {
        if (registered) return
        refreshGranted()
        if (!granted) return
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            registered = true
            pick(safeSessions())
        } catch (e: SecurityException) {
            granted = false
        }
    }

    fun start() {
        ensure()
    }

    fun stop() {
        try {
            msm.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
        }
        ctl?.unregisterCallback(cb)
        ctl = null
        registered = false
    }

    private fun pick(list: List<MediaController>?) {
        val cands = (list ?: emptyList()).filter { it.packageName != ctx.packageName }
        val chosen = cands.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: cands.firstOrNull()
        if (chosen != null && ctl != null && chosen.sessionToken == ctl!!.sessionToken) {
            onChange()
            return
        }
        ctl?.unregisterCallback(cb)
        ctl = chosen
        hasSession = chosen != null
        if (chosen == null) {
            title = ""
            artist = ""
            art = null
            playing = false
            lyrics = null
            lyricsState = 0
            lyricKey = ""
            pkg = ""
            onChange()
            return
        }
        pkg = chosen.packageName
        chosen.registerCallback(cb, main)
        readMeta(chosen.metadata)
        readState(chosen.playbackState)
        onChange()
    }

    private fun readMeta(m: MediaMetadata?) {
        if (m == null) return
        title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: m.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        art = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        duration = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
        saveLast()
        loadLyrics()
    }

    /** Simpan lagu terakhir (judul, artis, app, cover) supaya tab Music tetap bisa tampil saat standby. */
    private fun saveLast() {
        if (title.isBlank()) return
        val pr = Xcadoodle.prefs
        if (pr.lastTitle != title) pr.lastTitle = title
        if (pr.lastArtist != artist) pr.lastArtist = artist
        if (pkg.isNotEmpty() && pr.lastPkg != pkg) pr.lastPkg = pkg
        val a = art ?: return
        if (a === savedArt) return
        savedArt = a
        lastArtBmp = a
        lastArtLoaded = true
        thread {
            try {
                val s = 256
                val sc = if (a.width > s) Bitmap.createScaledBitmap(a, s, (a.height * s / a.width.coerceAtLeast(1)).coerceAtLeast(1), true) else a
                artFile.outputStream().use { sc.compress(Bitmap.CompressFormat.PNG, 90, it) }
            } catch (e: Throwable) {
            }
        }
    }

    private fun readState(s: PlaybackState?) {
        if (s == null) {
            playing = false
            return
        }
        playing = s.state == PlaybackState.STATE_PLAYING || s.state == PlaybackState.STATE_BUFFERING
        basePos = if (s.position < 0) 0L else s.position
        baseTime = s.lastPositionUpdateTime
        speed = s.playbackSpeed
    }

    private fun loadLyrics() {
        val key = "$title|$artist"
        if (key == lyricKey) return
        lyricKey = key
        lyrics = null
        if (title.isBlank()) {
            lyricsState = 0
            return
        }
        lyricsState = 1
        val t = title
        val a = artist
        val d = duration
        thread {
            val r = Lrc.fetch(t, a, d)
            main.post {
                if (lyricKey == key) {
                    lyrics = r
                    lyricsState = if (r != null) 2 else 3
                    onChange()
                }
            }
        }
    }

    fun position(): Long {
        if (!playing) return basePos
        val p = basePos + ((SystemClock.elapsedRealtime() - baseTime) * speed).toLong()
        return if (duration > 0) minOf(p, duration) else p
    }

    fun currentLyric(): String {
        val l = lyrics
        if (l == null) {
            return when (lyricsState) {
                1 -> "Loading lyrics"
                3 -> "Lyrics not available"
                else -> ""
            }
        }
        val p = position() + 250
        var cur = ""
        for (x in l) {
            if (x.t <= p) cur = x.text else break
        }
        return if (cur.isBlank()) "♪" else cur
    }

    /** [baris sekarang, berikutnya, berikutnya lagi] untuk tampilan 3 baris. */
    fun lyricWindow(): Array<String> {
        val l = lyrics
        if (l == null) {
            val st = when (lyricsState) {
                1 -> "Loading lyrics"
                3 -> "Lyrics not available"
                else -> ""
            }
            return arrayOf(st, "", "")
        }
        val p = position() + 250
        var idx = -1
        for (i in l.indices) {
            if (l[i].t <= p) idx = i else break
        }
        fun txt(i: Int): String {
            if (i < 0 || i >= l.size) return ""
            return if (l[i].text.isBlank()) "♪" else l[i].text
        }
        return arrayOf(if (idx < 0) "♪" else txt(idx), txt(idx + 1), txt(idx + 2))
    }

    /** Buka app pemutarnya (layar now-playing kalau ada, kalau tidak ya halaman utama app). */
    fun openApp() {
        val pi = ctl?.sessionActivity
        if (pi != null) {
            fireIntent(ctx, pi)
            return
        }
        launchApp(appPkg)
    }

    private fun launchApp(p: String) {
        if (p.isEmpty()) return
        try {
            val i = ctx.packageManager.getLaunchIntentForPackage(p) ?: return
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
        }
    }

    private fun mediaKey(code: Int) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        } catch (e: Exception) {
        }
    }

    /**
     * Putar lagu terakhir tanpa membuka app. Urutan: (1) sesi masih ada -> play; (2) tidak ada sesi ->
     * kirim tombol media PLAY (sistem membangunkan app pemutar terakhir, mis. Spotify); (3) kalau
     * 1,5 detik kemudian belum main, app dibuka sebentar lalu di-play lagi.
     */
    fun resumeLast() {
        val c = ctl
        if (c != null) {
            c.transportControls.play()
            return
        }
        val p = appPkg
        mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
        main.postDelayed({
            if (!hasSession || !playing) {
                launchApp(p)
                main.postDelayed({
                    val c2 = ctl
                    if (c2 != null) c2.transportControls.play() else mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
                }, 2200)
            }
        }, 1500)
    }

    fun toggle() {
        val t = ctl?.transportControls ?: return
        if (playing) t.pause() else t.play()
    }

    fun next() {
        ctl?.transportControls?.skipToNext()
    }

    fun prev() {
        ctl?.transportControls?.skipToPrevious()
    }

    fun seekFrac(f: Float) {
        if (duration > 0) ctl?.transportControls?.seekTo((f * duration).toLong())
    }
}
