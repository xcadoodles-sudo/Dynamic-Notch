package com.xcadoodle.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

enum class IconKind {
    // tab
    MUSIC, DEVICE, MARKETS, CALENDAR, SHELF, CHEVRON_UP,

    // alert
    BOLT, PLUG, BATTERY_LOW, BATTERY_FULL, HEADPHONES, WIFI, WIFI_OFF, BELL, ALERT,

    // balas notifikasi
    REPLY, SEND, CHECK
}

/** Glyph (emoji/teks) yang dipakai Alert -> ikon garis. null = tidak dikenal (pakai teksnya apa adanya). */
fun glyphIcon(g: String): IconKind? = when {
    g.contains("⚡") -> IconKind.BOLT
    g.contains("🔌") -> IconKind.PLUG
    g.contains("🪫") -> IconKind.BATTERY_LOW
    g.contains("🔋") -> IconKind.BATTERY_FULL
    g.contains("🎧") -> IconKind.HEADPHONES
    g.contains("📶") -> IconKind.WIFI
    g.contains("📵") -> IconKind.WIFI_OFF
    g.contains("🔔") -> IconKind.BELL
    g.contains("✓") -> IconKind.CHECK
    g == "!" -> IconKind.ALERT
    else -> null
}

/**
 * Ikon garis minimalis (grid 24x24, garis tipis, ujung bulat) untuk tab, tombol tutup, dan alert.
 * Digambar sendiri supaya tidak bergantung emoji/font perangkat dan warnanya konsisten.
 */
class LineIconView(
    c: Context,
    kind: IconKind,
    tint: Int = C.TEXT,
    private val sizeDp: Float = 19f,
    private val strokeDp: Float = 1.5f
) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = tint
    }
    private var path = build(kind)

    /** Ganti ikon/warna (dipakai alert yang view-nya dipakai ulang). */
    fun set(kind: IconKind, tint: Int) {
        path = build(kind)
        paint.color = tint
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val box = context.dpf(sizeDp)
        val k = box / 24f
        paint.strokeWidth = context.dpf(strokeDp) / k
        canvas.save()
        canvas.translate((width - box) / 2f, (height - box) / 2f)
        canvas.scale(k, k)
        canvas.drawPath(path, paint)
        canvas.restore()
    }

    private fun battery(p: Path, bars: Int) {
        p.addRoundRect(RectF(3f, 7f, 19f, 17f), 2.5f, 2.5f, Path.Direction.CW)
        p.moveTo(21.5f, 10.5f)
        p.lineTo(21.5f, 13.5f)
        for (i in 0 until bars) {
            val x = 6.5f + i * 3.2f
            p.moveTo(x, 10.5f)
            p.lineTo(x, 13.5f)
        }
    }

    private fun wifiArcs(p: Path) {
        p.moveTo(3f, 9.5f)
        p.cubicTo(8.2f, 4.8f, 15.8f, 4.8f, 21f, 9.5f)
        p.moveTo(6f, 13f)
        p.cubicTo(9.3f, 10.2f, 14.7f, 10.2f, 18f, 13f)
        p.moveTo(9f, 16.5f)
        p.cubicTo(10.8f, 15.2f, 13.2f, 15.2f, 15f, 16.5f)
        p.moveTo(12f, 19.8f)
        p.lineTo(12.02f, 19.8f)
    }

    private fun build(kind: IconKind): Path {
        val p = Path()
        when (kind) {
            IconKind.MUSIC -> {
                p.moveTo(9f, 18f)
                p.lineTo(9f, 5f)
                p.lineTo(19f, 3f)
                p.lineTo(19f, 16f)
                p.addCircle(6.5f, 18f, 2.5f, Path.Direction.CW)
                p.addCircle(16.5f, 16f, 2.5f, Path.Direction.CW)
            }
            IconKind.DEVICE -> {
                p.addRoundRect(RectF(6f, 6f, 18f, 18f), 2.5f, 2.5f, Path.Direction.CW)
                for (v in floatArrayOf(10f, 14f)) {
                    p.moveTo(v, 3f)
                    p.lineTo(v, 6f)
                    p.moveTo(v, 18f)
                    p.lineTo(v, 21f)
                    p.moveTo(3f, v)
                    p.lineTo(6f, v)
                    p.moveTo(18f, v)
                    p.lineTo(21f, v)
                }
            }
            IconKind.MARKETS -> {
                p.moveTo(3f, 17f)
                p.lineTo(9f, 11f)
                p.lineTo(13f, 15f)
                p.lineTo(21f, 7f)
                p.moveTo(15f, 7f)
                p.lineTo(21f, 7f)
                p.lineTo(21f, 13f)
            }
            IconKind.CALENDAR -> {
                p.addRoundRect(RectF(4f, 5f, 20f, 20f), 3f, 3f, Path.Direction.CW)
                p.moveTo(4f, 10f)
                p.lineTo(20f, 10f)
                p.moveTo(8.5f, 3f)
                p.lineTo(8.5f, 7f)
                p.moveTo(15.5f, 3f)
                p.lineTo(15.5f, 7f)
            }
            IconKind.SHELF -> {
                p.moveTo(4f, 13f)
                p.lineTo(4f, 17f)
                p.cubicTo(4f, 18.7f, 5.3f, 20f, 7f, 20f)
                p.lineTo(17f, 20f)
                p.cubicTo(18.7f, 20f, 20f, 18.7f, 20f, 17f)
                p.lineTo(20f, 13f)
                p.moveTo(12f, 4f)
                p.lineTo(12f, 14.5f)
                p.moveTo(8f, 10.5f)
                p.lineTo(12f, 14.5f)
                p.lineTo(16f, 10.5f)
            }
            IconKind.CHEVRON_UP -> {
                p.moveTo(7f, 14.5f)
                p.lineTo(12f, 9.5f)
                p.lineTo(17f, 14.5f)
            }
            IconKind.BOLT -> {
                p.moveTo(13f, 2.8f)
                p.lineTo(5.5f, 13f)
                p.lineTo(11.5f, 13f)
                p.lineTo(10.5f, 21.2f)
                p.lineTo(18.5f, 10.5f)
                p.lineTo(12.5f, 10.5f)
                p.close()
            }
            IconKind.PLUG -> {
                p.moveTo(9f, 3f)
                p.lineTo(9f, 8f)
                p.moveTo(15f, 3f)
                p.lineTo(15f, 8f)
                p.moveTo(6f, 8f)
                p.lineTo(18f, 8f)
                p.lineTo(18f, 12f)
                p.cubicTo(18f, 15.3f, 15.3f, 18f, 12f, 18f)
                p.cubicTo(8.7f, 18f, 6f, 15.3f, 6f, 12f)
                p.close()
                p.moveTo(12f, 18f)
                p.lineTo(12f, 21f)
            }
            IconKind.BATTERY_LOW -> battery(p, 1)
            IconKind.BATTERY_FULL -> battery(p, 4)
            IconKind.HEADPHONES -> {
                p.moveTo(4f, 15f)
                p.lineTo(4f, 12f)
                p.cubicTo(4f, 7.6f, 7.6f, 4f, 12f, 4f)
                p.cubicTo(16.4f, 4f, 20f, 7.6f, 20f, 12f)
                p.lineTo(20f, 15f)
                p.addRoundRect(RectF(3.5f, 14f, 7.5f, 20f), 1.8f, 1.8f, Path.Direction.CW)
                p.addRoundRect(RectF(16.5f, 14f, 20.5f, 20f), 1.8f, 1.8f, Path.Direction.CW)
            }
            IconKind.WIFI -> wifiArcs(p)
            IconKind.WIFI_OFF -> {
                wifiArcs(p)
                p.moveTo(4.5f, 4.5f)
                p.lineTo(19.5f, 19.5f)
            }
            IconKind.BELL -> {
                p.moveTo(5.5f, 17f)
                p.lineTo(7f, 15.5f)
                p.lineTo(7f, 11f)
                p.cubicTo(7f, 8.2f, 9.2f, 6f, 12f, 6f)
                p.cubicTo(14.8f, 6f, 17f, 8.2f, 17f, 11f)
                p.lineTo(17f, 15.5f)
                p.lineTo(18.5f, 17f)
                p.close()
                p.moveTo(12f, 3.5f)
                p.lineTo(12f, 6f)
                p.moveTo(10f, 20f)
                p.cubicTo(10.6f, 21.2f, 13.4f, 21.2f, 14f, 20f)
            }
            IconKind.REPLY -> {
                p.moveTo(10f, 6.5f)
                p.lineTo(4.5f, 12f)
                p.lineTo(10f, 17.5f)
                p.moveTo(4.5f, 12f)
                p.lineTo(14f, 12f)
                p.cubicTo(17.6f, 12f, 19.5f, 14f, 19.5f, 17.5f)
            }
            IconKind.SEND -> {
                p.moveTo(12f, 19f)
                p.lineTo(12f, 5.5f)
                p.moveTo(6.2f, 11f)
                p.lineTo(12f, 5.2f)
                p.lineTo(17.8f, 11f)
            }
            IconKind.CHECK -> {
                p.moveTo(5f, 12.5f)
                p.lineTo(10f, 17.5f)
                p.lineTo(19f, 7f)
            }
            IconKind.ALERT -> {
                p.moveTo(12f, 6.5f)
                p.lineTo(12f, 13f)
                p.moveTo(12f, 17f)
                p.lineTo(12.02f, 17f)
            }
        }
        return p
    }
}
