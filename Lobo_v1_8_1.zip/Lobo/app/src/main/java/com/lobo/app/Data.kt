package com.lobo.app

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.LocationManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

private fun httpGet(url: String): String? {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 6000
    c.readTimeout = 6000
    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) Lobo/1.1")
    c.setRequestProperty("Accept", "application/json")
    return try {
        if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
    } finally {
        c.disconnect()
    }
}

// ================================================================== MARKETS

/** [spot] opsional: patokan harga spot, mis. "SQ:XAU/USD" (Swissquote) atau "GA:XAU" (gold-api). Kosong = ditebak dari id. */
data class Sym(val id: String, val name: String, val yahoo: String, val alt: String? = null, val dec: Int = 2, val spot: String? = null)

class Quote(
    val price: Double,
    val prev: Double,
    val times: LongArray,
    val opens: DoubleArray,
    val highs: DoubleArray,
    val lows: DoubleArray,
    val closes: DoubleArray,
    val tf: String,
    /** Catatan sumber data, mis. "futures GC=F" kalau feed spot tidak tersedia. null = normal. */
    val note: String? = null
) {
    /** Geser seluruh seri sebesar [off], paksa harga = [newPrice], dan pin candle terakhir ke harga itu. */
    fun rebased(off: Double, newPrice: Double, newNote: String?): Quote {
        val n = closes.size
        val o = DoubleArray(n) { opens[it] + off }
        val h = DoubleArray(n) { highs[it] + off }
        val l = DoubleArray(n) { lows[it] + off }
        val c = DoubleArray(n) { closes[it] + off }
        if (n > 0) {
            c[n - 1] = newPrice
            if (newPrice > h[n - 1]) h[n - 1] = newPrice
            if (newPrice < l[n - 1]) l[n - 1] = newPrice
        }
        return Quote(newPrice, prev + off, times, o, h, l, c, tf, newNote)
    }

    val dayChange: Double get() = if (prev > 0) price - prev else 0.0
    val dayPct: Double get() = if (prev > 0) (price - prev) / prev * 100.0 else 0.0
}

class TF(val id: String, val label: String, val range: String, val interval: String)

fun fmtPrice(v: Double, dec: Int): String =
    if (v.isNaN()) "—" else String.format(Locale.US, "%,." + dec + "f", v)

fun fmtPct(v: Double): String = String.format(Locale.US, "%+.2f%%", v)

/**
 * Harga dari Yahoo Finance (endpoint chart, tanpa API key), di-poll selama tab Markets terbuka:
 * simbol terpilih tiap 3 detik, sisanya tiap 12 detik. Hampir realtime, bukan tick-by-tick.
 */
object Markets {
    val defaults = listOf(
        Sym("BTCUSD", "Bitcoin / US Dollar", "BTC-USD", null, 0),
        Sym("XAUUSD", "Gold Spot / US Dollar", "XAUUSD=X", "GC=F", 2, "SQ:XAU/USD"),
        Sym("ETHUSD", "Ethereum / US Dollar", "ETH-USD", null, 2),
        Sym("EURUSD", "Euro / US Dollar", "EURUSD=X", null, 5, "SQ:EUR/USD"),
        Sym("DXY", "US Dollar Index", "DX-Y.NYB", null, 3),
        Sym("USOIL", "WTI Crude Oil", "CL=F", null, 2),
        Sym("NDQ", "US 100 (Nasdaq)", "^NDX", null, 2),
        Sym("DJI", "Dow Jones Industrial", "^DJI", null, 2)
    )

    val quotes = ConcurrentHashMap<String, Quote>()
    @Volatile var version = 0
    @Volatile var failing = false

    @Volatile private var active = false
    private var th: Thread? = null

    fun symbols(): List<Sym> {
        val raw = Lobo.prefs.mkSymbols
        if (raw.isBlank()) return defaults
        return try {
            val a = JSONArray(raw)
            val out = ArrayList<Sym>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Sym(o.getString("id"), o.optString("name", o.getString("id")), o.getString("y"), o.optString("alt").ifBlank { null }, o.optInt("dec", 2), o.optString("spot").ifBlank { null }))
            }
            if (out.isEmpty()) defaults else out
        } catch (e: Exception) {
            defaults
        }
    }

    private fun save(l: List<Sym>) {
        val a = JSONArray()
        for (s in l) a.put(JSONObject().put("id", s.id).put("name", s.name).put("y", s.yahoo).put("alt", s.alt ?: "").put("dec", s.dec).put("spot", s.spot ?: ""))
        Lobo.prefs.mkSymbols = a.toString()
        version++
    }

    fun add(s: Sym) {
        val l = symbols().toMutableList()
        l.removeAll { it.id == s.id }
        l.add(s)
        save(l)
        Lobo.prefs.mkSelected = s.id
        kick()
    }

    fun remove(id: String) {
        val l = symbols().toMutableList()
        if (l.size <= 1) return
        l.removeAll { it.id == id }
        save(l)
        if (Lobo.prefs.mkSelected == id) Lobo.prefs.mkSelected = l[0].id
        kick()
    }

    fun selected(): Sym {
        val l = symbols()
        return l.firstOrNull { it.id == Lobo.prefs.mkSelected } ?: l[0]
    }

    fun select(id: String) {
        Lobo.prefs.mkSelected = id
        kick()
    }

    val tfs = listOf(
        TF("m5", "M5", "1d", "5m"),
        TF("m15", "M15", "5d", "15m"),
        TF("m30", "M30", "5d", "30m"),
        TF("h1", "H1", "1mo", "60m"),
        TF("d1", "D1", "6mo", "1d")
    )

    fun tf(): TF = tfs.firstOrNull { it.id == Lobo.prefs.mkRange } ?: tfs[0]

    fun setTf(id: String) {
        Lobo.prefs.mkRange = id
        kick()
    }

    /** Blocking. Dipakai juga oleh dialog tambah simbol untuk validasi. */
    fun fetch(yahoo: String, tf: TF): Quote? {
        return try {
            val url = "https://query1.finance.yahoo.com/v8/finance/chart/" + URLEncoder.encode(yahoo, "UTF-8") +
                "?range=" + tf.range + "&interval=" + tf.interval + "&includePrePost=false"
            val body = httpGet(url) ?: return null
            val r = JSONObject(body).getJSONObject("chart").getJSONArray("result").getJSONObject(0)
            val meta = r.getJSONObject("meta")
            val ts = r.optJSONArray("timestamp")
            val q = r.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0)
            val cl = q.optJSONArray("close")
            val op = q.optJSONArray("open")
            val hi = q.optJSONArray("high")
            val lo = q.optJSONArray("low")
            val t = ArrayList<Long>()
            val o = ArrayList<Double>()
            val h = ArrayList<Double>()
            val l = ArrayList<Double>()
            val c = ArrayList<Double>()
            if (ts != null && cl != null) {
                for (i in 0 until minOf(ts.length(), cl.length())) {
                    if (cl.isNull(i)) continue
                    val cv = cl.getDouble(i)
                    t.add(ts.getLong(i))
                    c.add(cv)
                    o.add(if (op != null && i < op.length() && !op.isNull(i)) op.getDouble(i) else cv)
                    h.add(if (hi != null && i < hi.length() && !hi.isNull(i)) hi.getDouble(i) else cv)
                    l.add(if (lo != null && i < lo.length() && !lo.isNull(i)) lo.getDouble(i) else cv)
                }
            }
            var price = meta.optDouble("regularMarketPrice", Double.NaN)
            if (price.isNaN() && c.isNotEmpty()) price = c[c.size - 1]
            if (price.isNaN()) return null
            var prev = meta.optDouble("chartPreviousClose", Double.NaN)
            if (prev.isNaN()) prev = meta.optDouble("previousClose", Double.NaN)
            if (prev.isNaN() && c.isNotEmpty()) prev = c[0]
            Quote(price, prev, t.toLongArray(), o.toDoubleArray(), h.toDoubleArray(), l.toDoubleArray(), c.toDoubleArray(), tf.id)
        } catch (e: Exception) {
            null
        }
    }

    // ---------------------------------------------------------------- patokan harga spot

    private val metals = setOf("XAU", "XAG", "XPT", "XPD")
    private val fxCodes = setOf(
        "USD", "EUR", "GBP", "JPY", "CHF", "AUD", "NZD", "CAD", "SEK", "NOK", "DKK", "TRY", "SGD",
        "HKD", "ZAR", "MXN", "PLN", "CZK", "HUF", "CNH", "THB"
    )

    /** "SQ:XAU/USD" / "GA:XAU" atau null kalau simbol ini bukan spot FX/logam. */
    private fun anchorFor(s: Sym): String? {
        s.spot?.let { return it }
        val id = s.id.uppercase(Locale.US)
        if (id.length != 6) return null
        val a = id.substring(0, 3)
        val b = id.substring(3)
        if ((a in metals || a in fxCodes) && b in fxCodes) return "SQ:$a/$b"
        return null
    }

    private fun fetchAnchor(spec: String): Double? {
        return try {
            when {
                spec.startsWith("SQ:") -> swissquote(spec.substring(3)) ?: goldApi(spec.substring(3).substringBefore('/'))
                spec.startsWith("GA:") -> goldApi(spec.substring(3))
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Feed bid/ask publik Swissquote (harga broker real-time, tanpa key). Ambil median mid semua profil. */
    private fun swissquote(pair: String): Double? {
        val body = httpGet("https://forex-data-feed.swissquote.com/public-quotes/bboquotes/instrument/$pair") ?: return null
        val arr = JSONArray(body)
        val mids = ArrayList<Double>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val sp = o.optJSONArray("spreadProfilePrices")
            if (sp != null) {
                for (j in 0 until sp.length()) {
                    val p = sp.optJSONObject(j) ?: continue
                    val bid = p.optDouble("bid", Double.NaN)
                    val ask = p.optDouble("ask", Double.NaN)
                    if (!bid.isNaN() && !ask.isNaN() && bid > 0 && ask > 0) mids.add((bid + ask) / 2.0)
                }
            } else {
                val bid = o.optDouble("bid", Double.NaN)
                val ask = o.optDouble("ask", Double.NaN)
                if (!bid.isNaN() && !ask.isNaN() && bid > 0 && ask > 0) mids.add((bid + ask) / 2.0)
            }
        }
        if (mids.isEmpty()) return null
        mids.sort()
        return mids[mids.size / 2]
    }

    /** gold-api.com: spot logam mulia (XAU/XAG/XPT/XPD) dalam USD, tanpa key. */
    private fun goldApi(sym: String): Double? {
        if (sym !in metals) return null
        val body = httpGet("https://api.gold-api.com/price/$sym") ?: return null
        val p = JSONObject(body).optDouble("price", Double.NaN)
        return if (p.isNaN() || p <= 0) null else p
    }

    /**
     * Candle dari Yahoo, tapi harga dipatok ke spot sungguhan kalau ada. Ini yang memperbaiki
     * selisih ~$20 pada XAUUSD: kalau XAUUSD=X kosong, kode lama jatuh ke GC=F (futures, selalu
     * lebih mahal dari spot). Sekarang seri futures digeser mengikuti spot, dan candle terakhir
     * selalu ikut harga live.
     */
    private fun fetchSym(s: Sym, tf: TF): Quote? {
        var q = fetch(s.yahoo, tf)
        var viaAlt = false
        if (q == null && s.alt != null) {
            q = fetch(s.alt, tf)
            viaAlt = q != null
        }
        if (q == null) return null
        val spec = anchorFor(s)
        if (spec != null) {
            val a = fetchAnchor(spec)
            if (a != null && q.price > 0 && Math.abs(a - q.price) / q.price < 0.03) {
                return q.rebased(a - q.price, a, null)
            }
        }
        val note = if (viaAlt && s.alt != null) "futures ${s.alt}, bukan spot" else null
        return q.rebased(0.0, q.price, note)
    }

    fun start() {
        if (active) return
        active = true
        th = thread(name = "lobo-markets") { loop() }
    }

    fun stop() {
        active = false
        th?.interrupt()
        th = null
    }

    fun kick() {
        th?.interrupt()
    }

    private fun loop() {
        var lastAll = 0L
        val day = tfs[0]
        while (active) {
            var ok = false
            try {
                val sel = selected()
                val tf = tf()
                val q = fetchSym(sel, tf)
                if (q != null) {
                    quotes[sel.id + "|" + tf.id] = q
                    if (tf.id == day.id) quotes[sel.id] = q
                    ok = true
                }
                val now = SystemClock.elapsedRealtime()
                if (now - lastAll > 12000 || quotes.size < 2) {
                    lastAll = now
                    for (s in symbols()) {
                        if (!active) break
                        if (s.id == sel.id && tf.id == day.id) continue
                        val d = fetchSym(s, day)
                        if (d != null) quotes[s.id] = d
                    }
                }
            } catch (e: Exception) {
            }
            failing = !ok
            Bus.changed()
            try {
                Thread.sleep(3000)
            } catch (e: InterruptedException) {
            }
        }
    }
}

// ================================================================== WEATHER

class Weather(
    val temp: Double,
    val code: Int,
    val isDay: Boolean,
    val place: String,
    val dayHi: DoubleArray,
    val dayLo: DoubleArray,
    val dayCode: IntArray,
    val dayName: Array<String>,
    val at: Long
) {
    companion object {
        fun emoji(code: Int, day: Boolean): String = when (code) {
            0 -> if (day) "☀️" else "🌙"
            1 -> if (day) "🌤️" else "🌙"
            2 -> "⛅"
            3 -> "☁️"
            45, 48 -> "🌫️"
            in 51..57 -> "🌦️"
            in 61..67 -> "🌧️"
            in 71..77 -> "❄️"
            in 80..82 -> "🌧️"
            85, 86 -> "❄️"
            95, 96, 99 -> "⛈️"
            else -> "☁️"
        }

        fun text(code: Int): String = when (code) {
            0 -> "Clear"
            1 -> "Mostly clear"
            2 -> "Partly cloudy"
            3 -> "Overcast"
            45, 48 -> "Fog"
            in 51..57 -> "Drizzle"
            in 61..67 -> "Rain"
            in 71..77 -> "Snow"
            in 80..82 -> "Showers"
            85, 86 -> "Snow showers"
            95 -> "Thunderstorm"
            96, 99 -> "Thunderstorm, hail"
            else -> "Cloudy"
        }

        fun parse(json: String, place: String, at: Long): Weather? {
            return try {
                val o = JSONObject(json)
                val cur = o.getJSONObject("current")
                val d = o.getJSONObject("daily")
                val hi = d.getJSONArray("temperature_2m_max")
                val lo = d.getJSONArray("temperature_2m_min")
                val dc = d.getJSONArray("weather_code")
                val dt = d.getJSONArray("time")
                val n = minOf(hi.length(), lo.length(), dc.length(), dt.length())
                val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US)
                val out = java.text.SimpleDateFormat("EEE", Locale.getDefault())
                Weather(
                    cur.getDouble("temperature_2m"),
                    cur.getInt("weather_code"),
                    cur.optInt("is_day", 1) == 1,
                    place,
                    DoubleArray(n) { hi.getDouble(it) },
                    DoubleArray(n) { lo.getDouble(it) },
                    IntArray(n) { dc.getInt(it) },
                    Array(n) { i -> fmt.parse(dt.getString(i))?.let { out.format(it) } ?: "" },
                    at
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}

object WeatherRepo {
    @Volatile var current: Weather? = null
    @Volatile private var busy = false
    private const val DEF_LAT = -5.1477
    private const val DEF_LON = 119.4327
    private const val DEF_NAME = "Makassar"

    fun loadCache() {
        if (current != null) return
        val raw = Lobo.prefs.wxCache
        if (raw.isBlank()) return
        try {
            val o = JSONObject(raw)
            current = Weather.parse(o.getString("json"), o.optString("place", DEF_NAME), o.optLong("at"))
        } catch (e: Exception) {
        }
    }

    private fun location(ctx: Context): Pair<Double, Double>? {
        if (ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: android.location.Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.time > best.time) best = l
            }
            if (best != null) Pair(best.latitude, best.longitude) else null
        } catch (e: Exception) {
            null
        }
    }

    /** Panggil dari main thread; jalan di background, hasil lewat Bus.changed(). */
    fun refresh(ctx: Context, force: Boolean = false) {
        loadCache()
        val c = current
        if (!force && c != null && System.currentTimeMillis() - c.at < 20 * 60_000L) return
        if (busy) return
        busy = true
        thread(name = "lobo-weather") {
            try {
                val loc = location(ctx)
                val lat = loc?.first ?: DEF_LAT
                val lon = loc?.second ?: DEF_LON
                var place = DEF_NAME
                if (loc != null) {
                    place = "Your location"
                    try {
                        if (Geocoder.isPresent()) {
                            @Suppress("DEPRECATION")
                            val a = Geocoder(ctx, Locale.getDefault()).getFromLocation(lat, lon, 1)
                            val n = a?.firstOrNull()?.let { it.locality ?: it.subAdminArea ?: it.adminArea }
                            if (!n.isNullOrBlank()) place = n
                        }
                    } catch (e: Exception) {
                    }
                }
                val url = "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon +
                    "&current=temperature_2m,weather_code,is_day" +
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=4"
                val body = httpGet(url)
                if (body != null) {
                    val now = System.currentTimeMillis()
                    val w = Weather.parse(body, place, now)
                    if (w != null) {
                        current = w
                        Lobo.prefs.wxCache = JSONObject().put("json", body).put("place", place).put("at", now).toString()
                    }
                }
            } catch (e: Exception) {
            } finally {
                busy = false
                Bus.changed()
            }
        }
    }
}

// ================================================================== DEVICE

class DevSnap(
    val cpu: Float,        // 0..100, -1 = tidak terbaca
    val cpuGhz: Float,     // -1 = tidak terbaca
    val cpuTemp: Float,    // °C, NaN = tidak terbaca
    val gpu: Float,
    val gpuTemp: Float,
    val memPct: Float,
    val memUsedGb: Float,
    val memTotalGb: Float,
    val batPct: Int,
    val batTemp: Float,
    val charging: Boolean,
    val thermal: String,
    val priv: Boolean,
    val gpuMhz: Float = -1f
)

/**
 * CPU/GPU/suhu dibaca dari sysfs. Android modern membatasi sebagian file itu untuk app biasa,
 * jadi nilai yang tidak bisa dibaca ditampilkan "—" (tanpa root/Shizuku tidak ada jalan lain).
 */
object DeviceStats {
    private var prevTotal = 0L
    private var prevIdle = 0L
    private var cpuFiles: List<Triple<File, File, File?>>? = null
    private var cpuZones: List<File>? = null
    private var gpuZones: List<File>? = null
    private var lastGpu = -1f
    private var lastGpuAt = 0L

    private fun readText(f: File): String? = try {
        f.readText().trim()
    } catch (e: Exception) {
        null
    }

    private fun readNum(f: File): Double? = readText(f)?.toDoubleOrNull()

    private fun procStat(): Float {
        try {
            val line = File("/proc/stat").bufferedReader().use { it.readLine() } ?: return -1f
            val p = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (p.size < 5) return -1f
            val idle = p[3] + p[4]
            val total = p.sum()
            val dT = total - prevTotal
            val dI = idle - prevIdle
            val first = prevTotal == 0L
            prevTotal = total
            prevIdle = idle
            if (first || dT <= 0) return -1f
            return ((dT - dI).toFloat() / dT * 100f).coerceIn(0f, 100f)
        } catch (e: Exception) {
            return -1f
        }
    }

    private fun initCpu() {
        if (cpuFiles != null) return
        val out = ArrayList<Triple<File, File, File?>>()
        for (i in 0 until 16) {
            val d = File("/sys/devices/system/cpu/cpu$i/cpufreq")
            val cur = File(d, "scaling_cur_freq")
            val max = File(d, "cpuinfo_max_freq")
            if (readNum(max) != null) {
                out.add(Triple(cur, max, File(d, "cpuinfo_min_freq")))
            }
        }
        cpuFiles = out
    }

    private fun freqLoad(): Pair<Float, Float> {
        initCpu()
        var sum = 0.0
        var n = 0
        var curMax = 0.0
        for ((cur, max, min) in cpuFiles!!) {
            val c = readNum(cur) ?: continue
            val mx = readNum(max) ?: continue
            val mn = (if (min != null) readNum(min) else null) ?: 0.0
            if (mx <= mn) continue
            sum += ((c - mn) / (mx - mn)).coerceIn(0.0, 1.0)
            n++
            if (c > curMax) curMax = c
        }
        if (n == 0) return Pair(-1f, -1f)
        return Pair((sum / n * 100).toFloat(), (curMax / 1_000_000.0).toFloat())
    }

    private fun initZones() {
        if (cpuZones != null) return
        val cpu = ArrayList<File>()
        val gpu = ArrayList<File>()
        try {
            val dirs = File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") } ?: emptyArray()
            for (d in dirs) {
                val t = readText(File(d, "type"))?.lowercase() ?: continue
                val temp = File(d, "temp")
                if (readNum(temp) == null) continue
                if (t.startsWith("gpu") || t.contains("kgsl") || t.contains("mali")) gpu.add(temp)
                else if (t.startsWith("cpu") || t.contains("mtktscpu") || t.contains("soc_thermal") || t.startsWith("big") || t.startsWith("little")) cpu.add(temp)
            }
        } catch (e: Exception) {
        }
        cpuZones = cpu
        gpuZones = gpu
    }

    private fun maxTemp(files: List<File>): Float {
        var best = Double.NaN
        for (f in files) {
            var v = readNum(f) ?: continue
            if (v > 1000) v /= 1000.0
            if (v < 10 || v > 130) continue
            if (best.isNaN() || v > best) best = v
        }
        return if (best.isNaN()) Float.NaN else best.toFloat()
    }

    private val gpuBusy = listOf(
        "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage",
        "/sys/class/kgsl/kgsl-3d0/gpubusy",
        "/sys/kernel/gpu/gpu_busy",
        "/sys/devices/platform/soc/3d00000.qcom,kgsl-3d0/kgsl/kgsl-3d0/gpu_busy_percentage"
    )

    private fun gpuLoad(): Float {
        for (p in gpuBusy) {
            val t = readText(File(p)) ?: continue
            val nums = Regex("[0-9.]+").findAll(t).mapNotNull { it.value.toDoubleOrNull() }.toList()
            if (nums.isEmpty()) continue
            if (nums.size >= 2 && nums[1] > 0) return (nums[0] / nums[1] * 100).toFloat().coerceIn(0f, 100f)
            if (nums.size == 1) return nums[0].toFloat().coerceIn(0f, 100f)
        }
        return -1f
    }

    fun sample(ctx: Context): DevSnap {
        initZones()
        var cpu = procStat()
        var ghz = -1f
        val fl = freqLoad()
        ghz = fl.second
        if (cpu < 0f) cpu = fl.first

        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem.toDouble()
        val used = total - mi.availMem.toDouble()
        val gb = 1024.0 * 1024.0 * 1024.0

        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        var pct = -1
        var bt = Float.NaN
        var chg = false
        if (b != null) {
            val lv = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (lv >= 0 && sc > 0) pct = lv * 100 / sc
            val t = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            if (t != Int.MIN_VALUE) bt = t / 10f
            chg = b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        }

        var th = ""
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
                th = when (pm.currentThermalStatus) {
                    PowerManager.THERMAL_STATUS_NONE -> "Normal"
                    PowerManager.THERMAL_STATUS_LIGHT -> "Warm"
                    PowerManager.THERMAL_STATUS_MODERATE -> "Hot"
                    else -> "Throttling"
                }
            } catch (e: Exception) {
            }
        }

        var gpuL = gpuLoad()
        var cpuT = maxTemp(cpuZones!!)
        var gpuT = maxTemp(gpuZones!!)
        var gpuMhz = -1f
        val nowMs = SystemClock.elapsedRealtime()
        val pd = PrivSampler.data?.takeIf { nowMs - it.at < 10_000 }
        if (pd != null) {
            if (pd.cpu >= 0f) cpu = pd.cpu
            if (pd.gpu >= 0f) gpuL = pd.gpu
            if (!pd.cpuT.isNaN()) cpuT = pd.cpuT
            if (!pd.gpuT.isNaN()) gpuT = pd.gpuT
            gpuMhz = pd.gpuMhz
        }
        // satu sampel kosong tidak boleh bikin GPU berkedip jadi "—": tahan nilai terakhir 12 dtk
        if (gpuL >= 0f) {
            lastGpu = gpuL
            lastGpuAt = nowMs
        } else if (lastGpu >= 0f && nowMs - lastGpuAt < 12_000) {
            gpuL = lastGpu
        }

        return DevSnap(
            cpu, ghz, cpuT, gpuL, gpuT,
            if (total > 0) (used / total * 100).toFloat() else 0f,
            (used / gb).toFloat(), (total / gb).toFloat(),
            pct, bt, chg, th, pd != null, gpuMhz
        )
    }
}
