package com.xcadoodle.app

import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.os.Build
import kotlin.concurrent.thread

/** Nama chipset + GPU untuk tab Device, mis. "Snapdragon 8 Gen 2 · Adreno 740". */
object Soc {
    private val table = listOf(
        Triple("SM8750", "Snapdragon 8 Elite", "Adreno 830"),
        Triple("SM8650", "Snapdragon 8 Gen 3", "Adreno 750"),
        Triple("SM8635", "Snapdragon 8s Gen 3", "Adreno 735"),
        Triple("SM8550", "Snapdragon 8 Gen 2", "Adreno 740"),
        Triple("SM8475", "Snapdragon 8+ Gen 1", "Adreno 730"),
        Triple("SM8450", "Snapdragon 8 Gen 1", "Adreno 730"),
        Triple("SM8350", "Snapdragon 888", "Adreno 660"),
        Triple("SM8250", "Snapdragon 865", "Adreno 650"),
        Triple("SM8150", "Snapdragon 855", "Adreno 640"),
        Triple("SM7675", "Snapdragon 7+ Gen 3", "Adreno 732"),
        Triple("SM7550", "Snapdragon 7 Gen 3", "Adreno 720"),
        Triple("SM7475", "Snapdragon 7+ Gen 2", "Adreno 725"),
        Triple("SM7450", "Snapdragon 7 Gen 1", "Adreno 644"),
        Triple("MT6991", "Dimensity 9400", "Immortalis-G925"),
        Triple("MT6989", "Dimensity 9300", "Immortalis-G720"),
        Triple("MT6985", "Dimensity 9200", "Immortalis-G715"),
        Triple("MT6983", "Dimensity 9000", "Mali-G710")
    )

    @Volatile private var chip = ""
    @Volatile private var gpu = ""
    private var started = false

    private fun ensure() {
        if (started) return
        started = true
        var model = ""
        var manu = ""
        if (Build.VERSION.SDK_INT >= 31) {
            model = (Build.SOC_MODEL ?: "").trim()
            manu = (Build.SOC_MANUFACTURER ?: "").trim()
        }
        val key = model.uppercase()
        val hit = table.firstOrNull { key.startsWith(it.first) }
        if (hit != null) {
            chip = hit.second
            gpu = hit.third
        } else {
            val bad = model.isEmpty() || model.equals("unknown", true)
            chip = if (!bad) listOf(manu, model).filter { it.isNotEmpty() && !it.equals("unknown", true) }.joinToString(" ")
            else (Build.HARDWARE ?: "").replaceFirstChar { it.uppercase() }
        }
        // GPU asli dibaca dari driver (lebih akurat dari tabel)
        thread {
            val r = queryRenderer() ?: return@thread
            val clean = r.replace("(TM)", "").replace(Regex("\\s+"), " ").trim()
            if (clean.isNotEmpty()) gpu = clean
        }
    }

    fun line(): String {
        ensure()
        return listOf(chip, gpu).filter { it.isNotBlank() }.joinToString(" · ")
    }

    private fun queryRenderer(): String? {
        var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
        var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
        var surf: EGLSurface = EGL14.EGL_NO_SURFACE
        try {
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val v = IntArray(2)
            if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) return null
            val cfgAttr = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_NONE
            )
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val n = IntArray(1)
            if (!EGL14.eglChooseConfig(dpy, cfgAttr, 0, cfgs, 0, 1, n, 0) || n[0] == 0) return null
            val ctxAttr = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
            ctx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, ctxAttr, 0)
            val sAttr = intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE)
            surf = EGL14.eglCreatePbufferSurface(dpy, cfgs[0], sAttr, 0)
            if (!EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) return null
            return GLES20.glGetString(GLES20.GL_RENDERER)
        } catch (e: Throwable) {
            return null
        } finally {
            try {
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, surf)
                if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx)
                EGL14.eglTerminate(dpy)
            } catch (e: Throwable) {
            }
        }
    }
}
