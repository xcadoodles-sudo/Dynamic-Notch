package com.xcadoodle.app

import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.Build
import java.io.File
import kotlin.concurrent.thread

/**
 * Nama chipset + GPU untuk tab Device (mis. "Snapdragon 8 Gen 2" + "Adreno 740").
 * Chipset dari Build.SOC_MODEL (kode seperti SM8550) lewat tabel; kalau tidak ada di tabel,
 * tampilkan kode aslinya. Nama GPU dibaca dari driver OpenGL (sekali, di thread terpisah),
 * dengan tabel sebagai cadangan.
 */
object ChipInfo {
    class Info(val chip: String, val gpu: String)

    private class Soc(val name: String, val gpu: String)

    private val table = mapOf(
        // Qualcomm
        "SM8750" to Soc("Snapdragon 8 Elite", "Adreno 830"),
        "SM8650" to Soc("Snapdragon 8 Gen 3", "Adreno 750"),
        "SM8635" to Soc("Snapdragon 8s Gen 3", "Adreno 735"),
        "SM8550" to Soc("Snapdragon 8 Gen 2", "Adreno 740"),
        "SM8475" to Soc("Snapdragon 8+ Gen 1", "Adreno 730"),
        "SM8450" to Soc("Snapdragon 8 Gen 1", "Adreno 730"),
        "SM8350" to Soc("Snapdragon 888", "Adreno 660"),
        "SM8250" to Soc("Snapdragon 865", "Adreno 650"),
        "SM8150" to Soc("Snapdragon 855", "Adreno 640"),
        "SM7675" to Soc("Snapdragon 7+ Gen 3", "Adreno 732"),
        "SM7550" to Soc("Snapdragon 7 Gen 3", "Adreno 720"),
        "SM7475" to Soc("Snapdragon 7+ Gen 2", "Adreno 725"),
        "SM7450" to Soc("Snapdragon 7 Gen 1", "Adreno 644"),
        "SM7435" to Soc("Snapdragon 7s Gen 2", "Adreno 710"),
        "SM7325" to Soc("Snapdragon 778G", "Adreno 642L"),
        "SM6375" to Soc("Snapdragon 695", "Adreno 619"),
        "SM6115" to Soc("Snapdragon 662", "Adreno 610"),
        // MediaTek
        "MT6991" to Soc("Dimensity 9400", "Immortalis-G925"),
        "MT6989" to Soc("Dimensity 9300", "Immortalis-G720"),
        "MT6985" to Soc("Dimensity 9200", "Immortalis-G715"),
        "MT6983" to Soc("Dimensity 9000", "Mali-G710"),
        "MT6897" to Soc("Dimensity 8300", "Mali-G615"),
        "MT6896" to Soc("Dimensity 8200", "Mali-G610"),
        "MT6895" to Soc("Dimensity 8100", "Mali-G610"),
        "MT6886" to Soc("Dimensity 7200", "Mali-G610"),
        // Samsung / Google
        "S5E9945" to Soc("Exynos 2400", "Xclipse 940"),
        "S5E9925" to Soc("Exynos 2200", "Xclipse 920"),
        "GS201" to Soc("Google Tensor G2", "Mali-G710"),
        "GS101" to Soc("Google Tensor", "Mali-G78")
    )

    @Volatile
    private var glName: String? = null
    private var glStarted = false

    private val base: Pair<String, String> by lazy {
        val model = socModel()
        val soc = table[model.uppercase().substringBefore('-').trim()]
        if (soc != null) Pair(soc.name, soc.gpu) else Pair(fallbackName(model), "")
    }

    fun get(): Info {
        startGl()
        return Info(base.first, glName ?: base.second)
    }

    private fun socModel(): String {
        if (Build.VERSION.SDK_INT >= 31) {
            val m = Build.SOC_MODEL
            if (!m.isNullOrBlank() && !m.equals("unknown", true)) return m
        }
        return ""
    }

    private fun fallbackName(model: String): String {
        if (model.isNotBlank()) {
            val maker = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MANUFACTURER else ""
            return if (maker.isNullOrBlank() || maker.equals("unknown", true)) model else "$maker $model"
        }
        try {
            for (l in File("/proc/cpuinfo").readLines()) {
                if (l.startsWith("Hardware")) {
                    val v = l.substringAfter(':').trim()
                    if (v.isNotEmpty()) return v
                }
            }
        } catch (e: Exception) {
        }
        val hw = Build.HARDWARE
        return if (hw.isNullOrBlank()) Build.MODEL else hw.replaceFirstChar { it.uppercase() }
    }

    @Synchronized
    private fun startGl() {
        if (glStarted) return
        glStarted = true
        thread(name = "gpu-name") {
            val r = queryRenderer() ?: return@thread
            val n = r.replace("(TM)", "").replace("(R)", "").replace(Regex("\\s+"), " ").trim()
            if (n.isNotEmpty() && !n.contains("llvmpipe", true) && !n.contains("emulator", true)) glName = n
        }
    }

    /** Nama GPU dari driver OpenGL ES lewat konteks pbuffer 1x1 (tanpa jendela). */
    private fun queryRenderer(): String? {
        try {
            val dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val ver = IntArray(2)
            if (!EGL14.eglInitialize(dpy, ver, 0, ver, 1)) return null
            val cfgAttr = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_NONE
            )
            val cfgs = arrayOfNulls<EGLConfig>(1)
            val n = IntArray(1)
            if (!EGL14.eglChooseConfig(dpy, cfgAttr, 0, cfgs, 0, 1, n, 0) || n[0] <= 0) return null
            val ctx = EGL14.eglCreateContext(
                dpy, cfgs[0], EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
            )
            val surf = EGL14.eglCreatePbufferSurface(
                dpy, cfgs[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0
            )
            var r: String? = null
            if (EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) {
                r = GLES20.glGetString(GLES20.GL_RENDERER)
            }
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(dpy, surf)
            EGL14.eglDestroyContext(dpy, ctx)
            return r
        } catch (e: Throwable) {
            return null
        }
    }
}
