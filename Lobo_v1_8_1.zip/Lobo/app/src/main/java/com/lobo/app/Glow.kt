package com.lobo.app

import android.animation.ArgbEvaluator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.view.View

/**
 * Cahaya ala matahari terbit di dasar panel: kilatan terang (flash) lalu mereda jadi gradasi tipis.
 * Warnanya beda tiap tab. Digambar relatif ke tepi bawah area yang sedang terlihat.
 */
class GlowView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var cA = 0
    private var cB = 0
    private val argb = ArgbEvaluator()

    // perpindahan warna halus (dipakai tab Markets: hijau <-> merah ikut naik/turunnya harga)
    private var fA = 0
    private var fB = 0
    private var toA = 0
    private var toB = 0
    private var ct = 1f
    private var ctT0 = 0L
    private var t0 = 0L
    private var from = 0f
    private var mode = 0 // 0 mati, 1 flash, 2 hilang
    private var visW = 0f
    private var visH = 0f

    private fun ease(x: Float): Float {
        val u = 1f - x.coerceIn(0f, 1f)
        return 1f - u * u * u
    }

    private fun level(t: Float): Float = when (mode) {
        1 -> {
            val u = t / 1.15f
            if (u < 0.22f) {
                from + (1f - from) * ease(u / 0.22f)
            } else {
                1f - 0.62f * ease((u - 0.22f) / 0.78f)
            }
        }
        2 -> from * (1f - (t / 0.22f).coerceIn(0f, 1f))
        else -> 0f
    }

    fun setVisible(w: Float, h: Float) {
        visW = w
        visH = h
        if (mode != 0) invalidate()
    }

    fun flash(a: Int, b: Int) {
        from = if (mode == 0) 0f else level((SystemClock.uptimeMillis() - t0) / 1000f).coerceIn(0f, 1f)
        cA = a
        cB = b
        toA = a
        toB = b
        ct = 1f
        t0 = SystemClock.uptimeMillis()
        mode = 1
        invalidate()
    }

    /** Ganti warna cahaya yang sedang tampil dengan transisi halus (tanpa kilatan ulang). */
    fun setColors(a: Int, b: Int) {
        if (a == toA && b == toB) return
        fA = cA
        fB = cB
        toA = a
        toB = b
        if (mode == 0) {
            cA = a
            cB = b
            ct = 1f
            return
        }
        ct = 0f
        ctT0 = SystemClock.uptimeMillis()
        invalidate()
    }

    fun hide() {
        if (mode == 0) return
        from = level((SystemClock.uptimeMillis() - t0) / 1000f).coerceIn(0f, 1f)
        t0 = SystemClock.uptimeMillis()
        mode = 2
        invalidate()
    }

    private fun al(c: Int, f: Float): Int = Color.argb((255 * f.coerceIn(0f, 1f)).toInt(), Color.red(c), Color.green(c), Color.blue(c))

    private fun mix(c: Int, w: Float): Int = Color.rgb(
        (Color.red(c) + (255 - Color.red(c)) * w).toInt(),
        (Color.green(c) + (255 - Color.green(c)) * w).toInt(),
        (Color.blue(c) + (255 - Color.blue(c)) * w).toInt()
    )

    override fun onDraw(cv: Canvas) {
        if (mode == 0 || visW <= 0f) return
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        val lv = level(t)
        if (mode == 2 && t >= 0.22f) {
            mode = 0
            return
        }
        if (ct < 1f) {
            ct = ((SystemClock.uptimeMillis() - ctT0) / 700f).coerceIn(0f, 1f)
            val e = ct * ct * (3f - 2f * ct)
            cA = argb.evaluate(e, fA, toA) as Int
            cB = argb.evaluate(e, fB, toB) as Int
        }
        // "matahari" naik dari bawah tepi, lalu diam
        val rise = if (mode == 1) ease(t / 0.95f) else 1f
        val cx = width / 2f
        val cy = visH + (1f - rise) * visH * 0.55f
        val r = visW * (0.42f + 0.22f * rise)
        val sy = (visH * (0.55f + 0.25f * rise)) / r
        p.shader = RadialGradient(
            cx, cy, r,
            intArrayOf(al(mix(cA, 0.65f), 0.95f * lv), al(cA, 0.85f * lv), al(cB, 0.38f * lv), al(cB, 0f)),
            floatArrayOf(0f, 0.2f, 0.58f, 1f),
            Shader.TileMode.CLAMP
        )
        cv.save()
        cv.scale(1f, sy, cx, cy)
        cv.drawRect(cx - r, cy - r, cx + r, cy + r, p)
        cv.restore()
        if ((mode == 1 && t < 1.2f) || mode == 2 || ct < 1f) postInvalidateOnAnimation()
    }
}
