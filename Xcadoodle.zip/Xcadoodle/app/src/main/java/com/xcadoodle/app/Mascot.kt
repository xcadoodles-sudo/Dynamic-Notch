package com.xcadoodle.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.Choreographer
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Parser path SVG mini: hanya M, L, C, Z (absolut), dipisah spasi. */
internal fun svgPath(d: String): Path {
    val p = Path()
    val t = d.trim().split(' ').filter { it.isNotEmpty() }
    var i = 0
    fun n(): Float = t[i++].toFloat()
    while (i < t.size) {
        when (t[i++]) {
            "M" -> p.moveTo(n(), n())
            "L" -> p.lineTo(n(), n())
            "C" -> p.cubicTo(n(), n(), n(), n(), n(), n())
            "Z" -> p.close()
        }
    }
    return p
}

/** Cermin horizontal path SVG mini (kotak 100 lebar): x -> 100 - x. */
private fun mirrorSvg(d: String): String {
    val sb = StringBuilder()
    var xTurn = true
    for (tok in d.trim().split(' ')) {
        if (tok.isEmpty()) continue
        if (tok.length == 1 && tok[0].isLetter()) {
            xTurn = true
            sb.append(tok)
        } else {
            sb.append(if (xTurn) (100f - tok.toFloat()).toString() else tok)
            xTurn = !xTurn
        }
        sb.append(' ')
    }
    return sb.toString()
}

/**
 * Bentuk maskot dalam kotak 100x100. Dibuat sekali, dipakai ulang tiap frame.
 * Gaya: kepala bulat gemuk, telinga runcing, mata oval menyala, outline neon ungu.
 */
private object Wolf {
    private const val EAR = "M 13.5 36 C 13.2 22 16 10 21.2 3.2 C 22.4 1.6 24.4 1.8 26 2.8 C 31 6 36 10.5 40 15.5 L 32 40 Z"
    private const val EAR_IN = "M 23.2 9.2 C 27 12 30.5 15.5 32.5 19 C 28 21 23.5 24 20.4 28.5 C 19.8 22 20.8 15 23.2 9.2 Z"
    private const val HEAD = "M 40 14.5 C 45 13 55 13 60 14.5 C 74 15 85 22 86.3 33 C 89.5 38 91 43 90.6 49 C 89.5 66 73 78.6 50 78.6 C 27 78.6 10.5 66 9.4 49 C 9 43 10.5 38 13.7 33 C 15 22 26 15 40 14.5 Z"
    private const val MASK = "M 50 45 C 46 36 40 30.5 33 31 C 25 31.8 21 39 21 46 C 18 49.5 16.5 53 17.5 57 C 22.5 68.5 36 75 50 75 C 64 75 77.5 68.5 82.5 57 C 83.5 53 82 49.5 79 46 C 79 39 75 31.8 67 31 C 60 30.5 54 36 50 45 Z"
    private const val NOSE = "M 44.5 57 C 46 55.3 54 55.3 55.5 57 C 55.5 60.2 52 63.5 50 63.5 C 48 63.5 44.5 60.2 44.5 57 Z"
    private const val HAPPY = "M 31 49.5 C 32.5 41.5 40.5 41.5 42 49.5"
    private const val SHUT = "M 31 45.5 C 32.5 51.5 40.5 51.5 42 45.5"

    private const val BODY = "M 25 99 C 23 82 33 68 50 68 C 67 68 77 82 75 99 Z"
    private const val TAIL = "M 66 97 C 79 99 91 90 93 76 C 93.6 72 95.6 70 97.4 71.4 C 100 82 94 99.5 76 100 Z"
    private const val TAIL_TIP = "M 93 76 C 93.6 72 95.6 70 97.4 71.4 C 98.2 74.6 97.8 78.5 96.6 82 C 95 80 94 78 93 76 Z"

    private const val LOAF = "M 9 99 C 5 80 22 62 50 62 C 78 62 95 80 91 99 Z"
    private const val CURL = "M 93 90 C 98 97 90 101 70 101 C 50 101 28 100 14 96 C 8 94 7 88 13 86 C 30 90 50 91 66 90 C 80 89 88 85 93 90 Z"
    private const val CURL_TIP = "M 13 86 C 7 88 8 94 14 96 C 19 97.4 24 98.4 28 99 C 24 95 20 90 13 86 Z"

    val earL = svgPath(EAR)
    val earR = svgPath(mirrorSvg(EAR))
    val earInL = svgPath(EAR_IN)
    val earInR = svgPath(mirrorSvg(EAR_IN))
    val head = svgPath(HEAD)
    val mask = svgPath(MASK)
    val nose = svgPath(NOSE)
    val happyL = svgPath(HAPPY)
    val happyR = svgPath(mirrorSvg(HAPPY))
    val shutL = svgPath(SHUT)
    val shutR = svgPath(mirrorSvg(SHUT))

    val body = svgPath(BODY)
    val tail = svgPath(TAIL)
    val tailTip = svgPath(TAIL_TIP)
    val tailBack = svgPath(mirrorSvg(TAIL))
    val tailTipBack = svgPath(mirrorSvg(TAIL_TIP))
    val paw = Path().apply { addRoundRect(RectF(-7f, -4.6f, 7f, 4.6f), 4.6f, 4.6f, Path.Direction.CW) }

    val loaf = svgPath(LOAF)
    val curl = svgPath(CURL)
    val curlTip = svgPath(CURL_TIP)

    // --- hiasan
    val heart = svgPath("M 0 6 C -9 0 -6 -7 0 -3 C 6 -7 9 0 0 6 Z")
    val zee = svgPath("M 0 0 L 8 0 L 0 9 L 8 9")
}

/**
 * Maskot Xcadoodle di sisi kiri pil notch.
 *
 *  SIT   : duduk menghadap depan, berkedip, melirik, telinga berkedut, ekor goyang, bernapas
 *  WALK  : jalan lenggak-lenggok ke kiri/kanan (badan bergoyang, telinga ikut berayun)
 *  DOZE  : mengantuk, kelopak turun, kepala terangguk-angguk
 *  SLEEP : meringkuk bulat tidur, ekor melingkar, napas pelan, "z z z" melayang
 *  WAKE  : bangun, melar (stretch), lalu duduk lagi
 *
 * Interaksi: [perk] (notifikasi masuk -> kaget & lompat), [poke] (disentuh -> bangun),
 * [pat] (tekan lama -> senang, ekor cepat, hati melayang).
 */
class PetView(c: Context) : View(c) {
    private enum class Mode { SIT, WALK, DOZE, SLEEP, WAKE }

    companion object {
        // Atur di sini kalau mau lebih cepat/lambat.
        private const val SLEEP_AFTER_MS = 20_000L // diam selama ini -> mulai mengantuk
        private const val DOZE_MS = 2_600L         // lama mengantuk sebelum benar-benar tidur
        private const val NAP_MS = 75_000L         // lama tidur sebelum bangun sendiri
        private const val WAKE_MS = 750L           // lama animasi bangun
        private const val WALK_DP_PER_SEC = 28f
        private const val STEP_RATE = 11f          // kecepatan ayunan langkah (rad/dtk)

        private val HEAD = 0xFF3B2E5A.toInt()
        private val INNER = 0xFF5B4E78.toInt()
        private val BODY = 0xFF2F2549.toInt()
        private val PAW = 0xFF5F5282.toInt()
        private val TIP = 0xFF6A5C8C.toInt()
        private val NOSE = 0xFF241A3A.toInt()
        private val DIM = 0xFF7C5CC4.toInt()       // outline redup untuk badan/ekor/kaki
        private val EYE = 0xFFFFFFFF.toInt()
        private val HEART = 0xFFB98BFF.toInt()
        private val ZZZ = 0xFFDDBFFF.toInt()
        private const val TWO_PI = 2.0 * PI
    }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val rect = RectF()
    private val maskShader = LinearGradient(0f, 30f, 0f, 76f, 0xFF4A3F69.toInt(), 0xFF6E6190.toInt(), Shader.TileMode.CLAMP)

    private var mode = Mode.SIT
    private var modeAt = 0L
    private var petX = 0f
    private var targetX = 0f
    private var face = 1
    private var phase = 0f
    private var gaze = 0f
    private var gazeTo = 0f
    private var lastT = 0L
    private var lastTouch = 0L
    private var nextAct = 0L
    private var nextBlink = 0L
    private var nextGaze = 0L
    private var blinkAt = -10_000L
    private var nextEar = 0L
    private var earAt = -10_000L
    private var popAt = -10_000L
    private var hopAt = -10_000L
    private var happyUntil = 0L
    private var skip = 0
    private var posted = false

    /** true = animasi berhenti (mis. saat panel/alert terbuka). Saat lanjut, maskot bangun. */
    var paused = false
        set(v) {
            if (field == v) return
            field = v
            if (!v) poke()
            sync()
        }

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!posted) return
            val t = frameTimeNanos / 1_000_000L
            val dt = if (lastT == 0L) 16L else (t - lastT).coerceIn(1L, 50L)
            lastT = t
            step(t, dt / 1000f)
            val busy = mode == Mode.WALK || mode == Mode.WAKE || t - popAt < 300L || t - hopAt < 700L || t < happyUntil ||
                abs(gazeTo - gaze) > 0.02f
            skip++
            if (busy || (skip and 1) == 0) invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun clock(): Long = SystemClock.uptimeMillis()

    private fun sprite(): Float = min(height * 0.80f, context.dpf(26))

    private fun range(): Float = max(0f, width - sprite())

    private fun sync() {
        val want = isAttachedToWindow && visibility == VISIBLE && windowVisibility == VISIBLE && !paused
        if (want && !posted) {
            posted = true
            lastT = 0L
            Choreographer.getInstance().postFrameCallback(frame)
        } else if (!want && posted) {
            posted = false
            Choreographer.getInstance().removeFrameCallback(frame)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val t = clock()
        lastTouch = t
        nextAct = t + 3_000L
        nextBlink = t + 1_500L
        nextEar = t + 5_000L
        nextGaze = t + 2_500L
        mode = Mode.SIT
        modeAt = t
        sync()
    }

    override fun onDetachedFromWindow() {
        posted = false
        Choreographer.getInstance().removeFrameCallback(frame)
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        sync()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        sync()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        petX = petX.coerceIn(0f, range())
    }

    // ------------------------------------------------------------ interaksi

    /** Disentuh / tombol ditekan: bangun kalau sedang tidur. */
    fun poke() {
        val t = clock()
        lastTouch = t
        if (mode == Mode.SLEEP || mode == Mode.DOZE) enter(Mode.WAKE, t)
    }

    /** Ada notifikasi/alert: kaget, melompat kecil, bangun kalau tidur. */
    fun perk() {
        val t = clock()
        lastTouch = t
        hopAt = t
        when (mode) {
            Mode.SLEEP, Mode.DOZE -> enter(Mode.WAKE, t)
            Mode.WALK -> enter(Mode.SIT, t)
            else -> {
            }
        }
        nextAct = t + 3_000L
    }

    /** Ditahan lama = dielus: senang, ekor cepat, hati melayang. */
    fun pat() {
        val t = clock()
        lastTouch = t
        hopAt = t
        happyUntil = t + 1_900L
        when (mode) {
            Mode.SLEEP, Mode.DOZE -> enter(Mode.WAKE, t)
            Mode.WALK -> enter(Mode.SIT, t)
            else -> {
            }
        }
        nextAct = t + 4_000L
    }

    // ------------------------------------------------------------ logika

    private fun enter(m: Mode, t: Long) {
        // saat jalan, arah lirik dihitung relatif arah jalan (gambar dicerminkan); ubah ke arah layar
        if ((m == Mode.WALK) != (mode == Mode.WALK)) gaze *= face
        gazeTo = if (m == Mode.WALK) 1f else 0f
        mode = m
        modeAt = t
        popAt = t
    }

    private fun startWalk(t: Long, r: Float) {
        val far = if (petX < r / 2f) r else 0f
        targetX = if (Random.nextFloat() < 0.4f) far else Random.nextFloat() * r
        if (abs(targetX - petX) < sprite() * 0.5f) targetX = far
        face = if (targetX >= petX) 1 else -1
        phase = 0f
        enter(Mode.WALK, t)
    }

    private fun step(t: Long, dt: Float) {
        val r = range()
        if (petX > r) petX = r
        gaze += (gazeTo - gaze) * min(1f, dt * 9f)
        when (mode) {
            Mode.SIT -> {
                if (t - lastTouch > SLEEP_AFTER_MS) {
                    enter(Mode.DOZE, t)
                    return
                }
                if (t >= nextAct) {
                    nextAct = t + 3_500L + Random.nextLong(6_500L)
                    if (r > sprite() * 0.6f && Random.nextFloat() < 0.75f) startWalk(t, r)
                }
                if (t >= nextBlink) {
                    blinkAt = t
                    nextBlink = t + 2_200L + Random.nextLong(3_800L)
                }
                if (t >= nextEar) {
                    earAt = t
                    nextEar = t + 6_000L + Random.nextLong(7_000L)
                }
                if (t >= nextGaze) {
                    gazeTo = when (Random.nextInt(4)) {
                        0 -> -0.8f
                        1 -> 0.8f
                        else -> 0f
                    }
                    nextGaze = t + 1_600L + Random.nextLong(3_200L)
                }
            }
            Mode.WALK -> {
                val stepPx = context.dpf(WALK_DP_PER_SEC) * dt
                val dx = targetX - petX
                if (abs(dx) <= stepPx) {
                    petX = targetX
                    enter(Mode.SIT, t)
                    nextAct = t + 2_500L + Random.nextLong(5_000L)
                } else {
                    petX += if (dx > 0f) stepPx else -stepPx
                    phase += dt * STEP_RATE
                }
            }
            Mode.DOZE -> if (t - modeAt > DOZE_MS) enter(Mode.SLEEP, t)
            Mode.SLEEP -> if (t - modeAt > NAP_MS) enter(Mode.WAKE, t)
            Mode.WAKE -> if (t - modeAt > WAKE_MS) {
                enter(Mode.SIT, t)
                lastTouch = t
                nextAct = t + 2_500L + Random.nextLong(3_000L)
            }
        }
    }

    // ------------------------------------------------------------ gambar

    private fun wave(t: Long, hz: Double): Float = sin(t / 1000.0 * TWO_PI * hz).toFloat()

    private fun glowCol(a: Int, k: Float): Int =
        Color.argb((a * k).toInt().coerceIn(0, 255), 0x9B, 0x5C, 0xFF)

    /** Outline neon (hanya setengah luarnya yang terlihat karena isi digambar menimpa). */
    private fun halo(cv: Canvas, p: Path, k: Float) {
        line.shader = null
        line.strokeWidth = 16f
        line.color = glowCol(0x26, k)
        cv.drawPath(p, line)
        line.strokeWidth = 10f
        line.color = glowCol(0x4A, k)
        cv.drawPath(p, line)
        line.strokeWidth = 5f
        line.color = Color.argb((110 + 145 * k).toInt().coerceIn(0, 255), 0xDD, 0xBF, 0xFF)
        cv.drawPath(p, line)
    }

    /** Badan/ekor/kaki: outline ungu redup + isi. */
    private fun part(cv: Canvas, p: Path, color: Int) {
        line.shader = null
        line.strokeWidth = 3.6f
        line.color = DIM
        cv.drawPath(p, line)
        fill.shader = null
        fill.color = color
        cv.drawPath(p, fill)
    }

    private fun solid(cv: Canvas, p: Path, color: Int) {
        fill.shader = null
        fill.color = color
        cv.drawPath(p, fill)
    }

    private fun paw(cv: Canvas, cx: Float, cy: Float, lift: Float) {
        cv.save()
        cv.translate(cx, cy - lift)
        part(cv, Wolf.paw, PAW)
        cv.restore()
    }

    private fun oval(cv: Canvas, cx: Float, cy: Float, rx: Float, ry: Float) {
        rect.set(cx - rx, cy - ry, cx + rx, cy + ry)
        cv.drawOval(rect, fill)
    }

    private fun eyeOval(cv: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, k: Float) {
        fill.shader = null
        fill.color = glowCol(0x30, k)
        oval(cv, cx, cy, rx + 3.6f, ry + 3.6f)
        fill.color = glowCol(0x66, k)
        oval(cv, cx, cy, rx + 1.8f, ry + 1.8f)
        fill.color = EYE
        oval(cv, cx, cy, rx, ry)
    }

    private fun arcs(cv: Canvas, l: Path, r: Path, dx: Float, k: Float) {
        cv.save()
        cv.translate(dx, 0f)
        line.shader = null
        line.strokeWidth = 7f
        line.color = glowCol(0x55, k)
        cv.drawPath(l, line)
        cv.drawPath(r, line)
        line.strokeWidth = 3.2f
        line.color = EYE
        cv.drawPath(l, line)
        cv.drawPath(r, line)
        cv.restore()
    }

    /** Wajah: topeng terang, mata menyala, hidung. [look] -1..1 menggeser fitur wajah (efek menoleh). */
    private fun face(cv: Canvas, look: Float, open: Float, happy: Boolean, k: Float) {
        cv.save()
        cv.translate(look * 3f, 0f)
        fill.shader = maskShader
        fill.color = Color.WHITE
        cv.drawPath(Wolf.mask, fill)
        fill.shader = null
        cv.restore()

        val ex = look * 4.4f
        if (happy) {
            arcs(cv, Wolf.happyL, Wolf.happyR, ex, k)
        } else if (open < 0.22f) {
            arcs(cv, Wolf.shutL, Wolf.shutR, ex, k)
        } else {
            val ry = 7.4f * open
            eyeOval(cv, 36.5f + ex, 46.5f, 5f, ry, k)
            eyeOval(cv, 63.5f + ex, 46.5f, 5f, ry, k)
        }

        cv.save()
        cv.translate(look * 5f, 0f)
        solid(cv, Wolf.nose, NOSE)
        cv.restore()
    }

    /** Kepala utuh: telinga (bisa digerakkan sendiri), muka. Sudut telinga dalam derajat. */
    private fun head(cv: Canvas, look: Float, earA: Float, earB: Float, open: Float, happy: Boolean, k: Float) {
        // 1) semua outline dulu, 2) isi menimpa -> outline hanya muncul di siluet luar
        cv.save()
        cv.rotate(earA, 26f, 26f)
        halo(cv, Wolf.earL, k)
        cv.restore()
        cv.save()
        cv.rotate(earB, 74f, 26f)
        halo(cv, Wolf.earR, k)
        cv.restore()
        halo(cv, Wolf.head, k)

        cv.save()
        cv.rotate(earA, 26f, 26f)
        solid(cv, Wolf.earL, HEAD)
        cv.restore()
        cv.save()
        cv.rotate(earB, 74f, 26f)
        solid(cv, Wolf.earR, HEAD)
        cv.restore()
        solid(cv, Wolf.head, HEAD)

        cv.save()
        cv.rotate(earA, 26f, 26f)
        solid(cv, Wolf.earInL, INNER)
        cv.restore()
        cv.save()
        cv.rotate(earB, 74f, 26f)
        solid(cv, Wolf.earInR, INNER)
        cv.restore()

        face(cv, look, open, happy, k)
    }

    override fun onDraw(cv: Canvas) {
        if (width <= 0 || height <= 0) return
        val t = clock()
        val s = sprite()
        val u = s / 100f
        val top = (height - s) / 2f + s * 0.04f

        // "pop" kecil tiap ganti pose + lompat + melar saat bangun
        val pp = ((t - popAt) / 240f).coerceIn(0f, 1f)
        val k = (1f - pp) * (1f - pp)
        var sx = 1f + 0.10f * k
        var sy = 1f - 0.14f * k
        var lid = 0f
        if (mode == Mode.WAKE) {
            val wp = ((t - modeAt).toFloat() / WAKE_MS).coerceIn(0f, 1f)
            val st = sin(wp * PI.toFloat())
            sx *= 1f + 0.10f * st
            sy *= 1f - 0.07f * st
            lid = 1f - wp
        }
        val hp = ((t - hopAt) / 650f).coerceIn(0f, 1f)
        val hop = if (hp < 1f) 4f * hp * (1f - hp) * 14f else 0f

        cv.save()
        cv.translate(petX, top)
        cv.scale(u, u)
        cv.translate(0f, -hop)
        cv.scale(sx, sy, 50f, 100f)
        when (mode) {
            Mode.SIT, Mode.WAKE -> drawSit(cv, t, 0f, lid)
            Mode.DOZE -> {
                val d = ((t - modeAt).toFloat() / DOZE_MS).coerceIn(0f, 1f)
                drawSit(cv, t, d, d)
                if (d > 0.45f) drawZ(cv, t, 78f, 20f, 1)
            }
            Mode.WALK -> {
                if (face < 0) cv.scale(-1f, 1f, 50f, 50f)
                drawWalk(cv, t)
            }
            Mode.SLEEP -> {
                if (face < 0) cv.scale(-1f, 1f, 50f, 50f)
                drawSleep(cv, t)
            }
        }
        cv.restore()
    }

    private fun blinkAmount(t: Long): Float {
        val bp = (t - blinkAt) / 180f
        return if (bp in 0f..1f) sin(bp * PI.toFloat()) else 0f
    }

    /** [nod] 0..1 kepala terangguk; [lid] 0..1 kelopak turun (mengantuk). */
    private fun drawSit(cv: Canvas, t: Long, nod: Float, lid: Float) {
        val happy = t < happyUntil
        val br = wave(t, 1.0 / 3.2)
        val wag = wave(t, if (happy) 4.5 else 1.1) * (if (happy) 20f else 8f)
        val k = 0.92f + 0.08f * wave(t, 0.4)

        // ekor
        cv.save()
        cv.rotate(wag, 70f, 97f)
        part(cv, Wolf.tail, BODY)
        solid(cv, Wolf.tailTip, TIP)
        cv.restore()

        // badan + kaki depan
        cv.save()
        cv.scale(1f, 1f + 0.014f * br, 50f, 99f)
        part(cv, Wolf.body, BODY)
        cv.restore()
        paw(cv, 38f, 95f, 0f)
        paw(cv, 62f, 95f, 0f)

        // kepala (mengangguk kalau mengantuk, miring halus waktu idle)
        val dip = nod * (3.5f + 2f * wave(t, 1.05))
        cv.save()
        cv.translate(0f, dip + 0.5f * br)
        cv.rotate(1.6f * wave(t, 0.23) + nod * 4f, 50f, 78f)

        val ep = (t - earAt) / 260f
        val twitch = if (ep in 0f..1f) -14f * sin(ep * PI.toFloat()) else 0f
        val open = (1f - blinkAmount(t)) * (1f - 0.72f * lid)
        head(cv, gaze, -nod * 4f, twitch + nod * 4f, open, happy, k)
        cv.restore()

        if (happy) drawHearts(cv, t)
    }

    /** Jalan lenggak-lenggok: badan bergoyang, kaki bergantian, telinga trailing, kepala menoleh ke arah jalan. */
    private fun drawWalk(cv: Canvas, t: Long) {
        val sw = phase
        val s = sin(sw)
        val flop = sin(sw * 2f)
        val bounce = abs(s) * 3.6f
        val open = 1f - blinkAmount(t)

        cv.save()
        cv.rotate(4f, 50f, 99f) // condong ke depan

        // badan + ekor (ekor di belakang, melambai)
        cv.save()
        cv.rotate(s * 3.5f, 50f, 99f)
        cv.save()
        cv.rotate(-6f + 15f * sin(sw * 0.5f + 1f), 32f, 97f)
        part(cv, Wolf.tailBack, BODY)
        solid(cv, Wolf.tailTipBack, TIP)
        cv.restore()
        part(cv, Wolf.body, BODY)
        cv.restore()

        // kaki: bergantian terangkat dan melangkah
        paw(cv, 37f + 3f * s, 95f, max(0f, s) * 6.5f)
        paw(cv, 63f - 3f * s, 95f, max(0f, -s) * 6.5f)

        // kepala memantul, menoleh ke depan
        cv.save()
        cv.translate(1.6f, -bounce)
        cv.rotate(-s * 2.4f, 50f, 72f)
        val ear = -9f + 6f * flop
        head(cv, gaze, ear, ear, open, false, 1f)
        cv.restore()

        cv.restore()
    }

    /** Tidur meringkuk bulat: kepala bersandar, telinga terkulai, ekor melingkar di depan, kaki dilipat. */
    private fun drawSleep(cv: Canvas, t: Long) {
        val br = wave(t, 1.0 / 3.8)
        val k = 0.5f + 0.08f * br

        cv.save()
        cv.scale(1f, 1f + 0.03f * br, 50f, 99f)
        part(cv, Wolf.loaf, BODY)

        cv.save()
        cv.translate(0f, 17f)
        cv.rotate(-6f, 50f, 60f)
        cv.scale(0.84f, 0.84f, 50f, 50f)
        head(cv, 0f, -13f, 13f, 0f, false, k)
        cv.restore()

        // ekor melingkar di depan, menutupi dagu & kaki yang dilipat
        part(cv, Wolf.curl, BODY)
        solid(cv, Wolf.curlTip, TIP)
        cv.restore()

        for (i in 0 until 3) drawZ(cv, t, 76f, 38f, i)
    }

    /** Huruf "z" melayang naik sambil memudar. */
    private fun drawZ(cv: Canvas, t: Long, bx: Float, by: Float, i: Int) {
        val q = ((t / 3200.0) + i / 3.0) % 1.0
        val qf = q.toFloat()
        val a = sin(qf * PI.toFloat())
        if (a <= 0.02f) return
        cv.save()
        cv.translate(bx + qf * 14f, by - qf * 34f)
        val sc = 0.5f + 0.7f * qf
        cv.scale(sc, sc)
        line.shader = null
        line.color = Color.argb((a * 230f).toInt(), Color.red(ZZZ), Color.green(ZZZ), Color.blue(ZZZ))
        line.strokeWidth = 2.4f
        cv.drawPath(Wolf.zee, line)
        cv.restore()
    }

    /** Hati melayang waktu dielus; muncul di sisi yang masih ada ruang. */
    private fun drawHearts(cv: Canvas, t: Long) {
        val s = sprite()
        val onRight = petX + s * 1.2f <= width
        val hx = if (onRight) 108f else -8f
        for (i in 0 until 3) {
            val q = (((t + i * 470L) % 1400L) / 1400f)
            val a = 1f - q
            cv.save()
            cv.translate(hx + (i - 1) * 3f, 70f - q * 55f)
            val sc = 0.7f + 0.4f * q
            cv.scale(sc, sc)
            fill.shader = null
            fill.color = Color.argb((a * 255f).toInt(), Color.red(HEART), Color.green(HEART), Color.blue(HEART))
            cv.drawPath(Wolf.heart, fill)
            cv.restore()
        }
    }
}
