package com.lobo.app

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

class MainActivity : Activity() {
    private val statuses = ArrayList<Pair<TextView, () -> Boolean>>()
    private lateinit var col: LinearLayout
    private lateinit var btnService: TextView
    private lateinit var shelfInfo: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(C.APP_BG)
        val wrap = FrameLayout(this)
        scroll.addView(wrap, FrameLayout.LayoutParams(MATCH, WRAP))
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(24), dp(28), dp(24), dp(48))
        val maxW = minOf(resources.displayMetrics.widthPixels, dp(720))
        wrap.addView(col, FrameLayout.LayoutParams(maxW, WRAP, Gravity.CENTER_HORIZONTAL))
        setContentView(scroll)

        col.addView(tv("Lobo", 34f, C.TEXT, true))
        col.addView(tv("A living notch for Android. Music, lyrics, device stats, live markets, calendar with weather, file shelf, notifications, clipboard, widgets, mixer, launcher and call controls.", 14f, C.SUB), llp(MATCH, WRAP, 0f, 0, 6, 0, 16))

        // ---------- notch on/off
        btnService = pill("", C.ACCENT, C.TEXT, 15f) { toggleService() }
        col.addView(btnService, llp(MATCH, WRAP, 0f, 0, 0, 0, 4))

        // ---------- izin
        val perms = section("Permissions")
        permRow(perms, "Display over other apps", "Required. Lets the notch float at the top of the screen.",
            { Settings.canDrawOverlays(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        permRow(perms, "Notification access", "Music controls, lyrics and app notifications in the notch.",
            { NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName) }) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        permRow(perms, "Post notifications", "Reminders and alerts as system notifications.",
            { Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED }) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        permRow(perms, "Bluetooth devices", "Show the device name when headphones connect.",
            { Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED }) {
            if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 2)
        }
        permRow(perms, "Location (optional)", "Weather for where you are. Without it Lobo uses Makassar.",
            { checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 3)
        }
        permRow(perms, "Shizuku (hardware monitor)", "Optional. Lets the Device tab read real CPU/GPU load and temperatures.",
            { Priv.granted() }) {
            if (!Priv.running()) {
                Toast.makeText(this, "Start Shizuku first", Toast.LENGTH_LONG).show()
                val li = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (li != null) startActivity(li)
            } else {
                Priv.request(4)
            }
        }
        permRow(perms, "Battery: no restrictions", "Keeps the notch alive in the background (HyperOS may kill it otherwise).",
            { (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName) }) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        permRow(perms, "Accessibility (recommended)", "Lets the notch sit flush on the top edge and receive taps over the status bar. Lobo does not read your screen.",
            { LoboAccessibilityService.instance != null || (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName) }) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        val xiaomi = pill("Open Xiaomi / HyperOS autostart settings", C.CARD2, C.TEXT, 13f) { openAutostart() }
        perms.addView(xiaomi, llp(MATCH, WRAP, 0f, 0, 6, 0, 10))

        // ---------- pengaturan
        val set = section("Settings")
        toggleRow(set, "Start with device", "Launch the notch automatically after boot.", { Lobo.prefs.startOnBoot }) { Lobo.prefs.startOnBoot = it }
        toggleRow(set, "Lobo Mascot", "Show the wolf in the idle notch. Long-press it to pet it.", { Lobo.prefs.pet }) { Lobo.prefs.pet = it }
        toggleRow(set, "Minimal notch", "A smaller idle pill with no extras.", { Lobo.prefs.minimal }) { Lobo.prefs.minimal = it }
        toggleRow(set, "App notifications", "Peek other apps' notifications in the notch.", { Lobo.prefs.notifAlerts }) { Lobo.prefs.notifAlerts = it }
        stepRow(set, "Notch width", "Idle notch width. Wider = more like a MacBook notch.", 80, 320, 8, { Lobo.prefs.notchW }) { Lobo.prefs.notchW = it }
        stepRow(set, "Notch height", "Idle notch thickness. ~33 lines up with the status bar chip.", 16, 48, 1, { Lobo.prefs.notchH }) { Lobo.prefs.notchH = it }
        offsetRow(set)
        percentRow(set, "Glass opacity", "Liquid glass notch & panel. Lower = more see-through, higher = easier to read over bright apps.", 30, 95, 5, { Lobo.prefs.glassPct }) { Lobo.prefs.glassPct = it }

        // ---------- shelf
        val sh = section("File shelf")
        shelfInfo = tv("", 13f, C.SUB)
        val zone = tv("Drop files here\n(split-screen with Files, then drag in)", 14f, C.SUB)
        zone.gravity = Gravity.CENTER
        zone.setPadding(dp(16), dp(28), dp(16), dp(28))
        zone.background = rounded(C.CARD2, dpf(14))
        zone.setOnDragListener { _, e -> onShelfDrag(zone, e) }
        sh.addView(zone, llp(MATCH, WRAP, 0f, 0, 10, 0, 8))
        sh.addView(shelfInfo, llp(WRAP, WRAP, 0f, 0, 0, 0, 10))
        val addBtn = pill("+ Add files…", C.ACCENT, C.TEXT, 13f) {
            val i = Intent(this, ShareReceiverActivity::class.java)
            i.action = "com.lobo.app.PICK"
            startActivity(i)
        }
        sh.addView(addBtn, llp(WRAP, WRAP, 0f, 0, 0, 0, 12))

        // ---------- about
        val ab = section("About")
        ab.addView(tv("Lobo 1.3.0 – living notch for Android.", 13f, C.TEXT), llp(WRAP, WRAP, 0f, 0, 10, 0, 4))
        ab.addView(tv("Lyrics provided by LRCLIB (lrclib.net).", 12f, C.SUB), llp(WRAP, WRAP, 0f, 0, 0, 0, 12))
    }

    private val shizukuListener = rikka.shizuku.Shizuku.OnRequestPermissionResultListener { _, _ ->
        runOnUiThread { refreshStatuses() }
    }

    override fun onStart() {
        super.onStart()
        try {
            rikka.shizuku.Shizuku.addRequestPermissionResultListener(shizukuListener)
        } catch (e: Throwable) {
        }
    }

    override fun onStop() {
        try {
            rikka.shizuku.Shizuku.removeRequestPermissionResultListener(shizukuListener)
        } catch (e: Throwable) {
        }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        refreshStatuses()
    }

    private fun refreshStatuses() {
        for ((v, ok) in statuses) {
            val g = ok()
            v.text = if (g) "✓ Granted" else "Grant"
            v.background = rounded(if (g) C.CARD2 else C.ACCENT, dpf(100))
        }
        btnService.text = if (NotchService.isRunning()) "Stop notch" else "Start notch"
        btnService.background = rounded(if (NotchService.isRunning()) C.CARD2 else C.ACCENT, dpf(100))
        shelfInfo.text = "${Lobo.shelf.items().size} item(s) on the shelf"
    }

    private fun toggleService() {
        if (NotchService.isRunning()) {
            NotchService.stop(this)
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow “Display over other apps” first", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return
            }
            NotchService.start(this)
        }
        btnService.postDelayed({ refreshStatuses() }, 500)
    }

    private fun openAutostart() {
        val tries = listOf(
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
            Intent("miui.intent.action.OP_AUTO_START").addCategory(Intent.CATEGORY_DEFAULT),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
        for (i in tries) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
            }
        }
    }

    // ---------- builder kecil
    private fun field(hint: String, value: String, secret: Boolean): EditText {
        val e = EditText(this)
        e.setText(value)
        e.hint = hint
        e.setHintTextColor(0x66FFFFFF)
        e.setTextColor(C.TEXT)
        e.textSize = 14f
        e.setSingleLine(true)
        e.background = rounded(C.CARD2, dpf(12))
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        e.inputType = if (secret) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        return e
    }

    private fun section(title: String): LinearLayout {
        val t = tv(title.uppercase(), 12f, C.SUB, true)
        t.letterSpacing = 0.08f
        col.addView(t, llp(WRAP, WRAP, 0f, 4, 24, 0, 8))
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = rounded(C.CARD, dpf(18))
        card.setPadding(dp(16), dp(6), dp(16), dp(6))
        col.addView(card, llp(MATCH, WRAP))
        return card
    }

    private fun textCol(title: String, desc: String): LinearLayout {
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        tc.addView(tv(title, 15f, C.TEXT, true))
        tc.addView(tv(desc, 12f, C.SUB), llp(WRAP, WRAP, 0f, 0, 2, 0, 0))
        return tc
    }

    private fun permRow(card: LinearLayout, title: String, desc: String, ok: () -> Boolean, act: () -> Unit) {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(12), 0, dp(12))
        r.addView(textCol(title, desc), llp(0, WRAP, 1f, 0, 0, 12, 0))
        val st = pill("", C.CARD2, C.TEXT, 12f) {
            try {
                act()
            } catch (e: Exception) {
            }
        }
        r.addView(st)
        card.addView(r)
        statuses.add(Pair(st, ok))
    }

    private fun toggleRow(card: LinearLayout, title: String, desc: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(12), 0, dp(12))
        r.addView(textCol(title, desc), llp(0, WRAP, 1f, 0, 0, 12, 0))
        val sw = Switch(this)
        sw.isChecked = get()
        sw.setOnCheckedChangeListener { _, v ->
            set(v)
            NotchService.instance?.refreshSettings()
        }
        r.addView(sw)
        card.addView(r)
    }

    private fun stepRow(card: LinearLayout, title: String, desc: String, min: Int, max: Int, step: Int, get: () -> Int, set: (Int) -> Unit) {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(12), 0, dp(12))
        r.addView(textCol(title, desc), llp(0, WRAP, 1f, 0, 0, 12, 0))
        val v = tv("${get()} dp", 15f, C.TEXT, true)
        v.gravity = Gravity.CENTER
        fun change(d: Int) {
            set((get() + d).coerceIn(min, max))
            v.text = "${get()} dp"
            NotchService.instance?.refreshSettings()
        }
        r.addView(pill("−", C.CARD2, C.TEXT, 16f) { change(-step) }, llp(dp(44), WRAP))
        r.addView(v, llp(dp(64), WRAP))
        r.addView(pill("+", C.CARD2, C.TEXT, 16f) { change(step) }, llp(dp(44), WRAP))
        card.addView(r)
    }

    private fun percentRow(card: LinearLayout, title: String, desc: String, min: Int, max: Int, step: Int, get: () -> Int, set: (Int) -> Unit) {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(12), 0, dp(12))
        r.addView(textCol(title, desc), llp(0, WRAP, 1f, 0, 0, 12, 0))
        val v = tv("${get()}%", 15f, C.TEXT, true)
        v.gravity = Gravity.CENTER
        fun change(d: Int) {
            set((get() + d).coerceIn(min, max))
            v.text = "${get()}%"
        }
        r.addView(pill("−", C.CARD2, C.TEXT, 16f) { change(-step) }, llp(dp(44), WRAP))
        r.addView(v, llp(dp(64), WRAP))
        r.addView(pill("+", C.CARD2, C.TEXT, 16f) { change(step) }, llp(dp(44), WRAP))
        card.addView(r)
    }

    private fun offsetRow(card: LinearLayout) {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(12), 0, dp(12))
        r.addView(textCol("Notch distance from top", "0 = flush with the top edge. Raise it if taps don't register without Accessibility."), llp(0, WRAP, 1f, 0, 0, 12, 0))
        val v = tv("${Lobo.prefs.topOffset} dp", 15f, C.TEXT, true)
        v.gravity = Gravity.CENTER
        fun change(d: Int) {
            Lobo.prefs.topOffset = (Lobo.prefs.topOffset + d).coerceIn(0, 80)
            v.text = "${Lobo.prefs.topOffset} dp"
            NotchService.instance?.refreshSettings()
        }
        r.addView(pill("−", C.CARD2, C.TEXT, 16f) { change(-2) }, llp(dp(44), WRAP))
        r.addView(v, llp(dp(64), WRAP))
        r.addView(pill("+", C.CARD2, C.TEXT, 16f) { change(2) }, llp(dp(44), WRAP))
        card.addView(r)
    }

    private fun onShelfDrag(zone: TextView, e: DragEvent): Boolean {
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED -> return true
            DragEvent.ACTION_DRAG_ENTERED -> zone.background = rounded(C.ACCENT, dpf(14))
            DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> zone.background = rounded(C.CARD2, dpf(14))
            DragEvent.ACTION_DROP -> {
                zone.background = rounded(C.CARD2, dpf(14))
                val clip = e.clipData
                if (clip != null) {
                    val perms = try {
                        requestDragAndDropPermissions(e)
                    } catch (ex: Exception) {
                        null
                    }
                    var n = 0
                    for (i in 0 until clip.itemCount) {
                        val item = clip.getItemAt(i)
                        val uri = item.uri
                        val txt = item.text?.toString()
                        if (uri != null) {
                            val sch = uri.scheme ?: ""
                            if (sch == "http" || sch == "https") {
                                Lobo.shelf.addLink(uri.toString())
                                n++
                            } else if (Lobo.shelf.addUri(uri)) n++
                        } else if (txt != null && (txt.startsWith("http://") || txt.startsWith("https://"))) {
                            Lobo.shelf.addLink(txt.trim())
                            n++
                        }
                    }
                    perms?.release()
                    Toast.makeText(this, if (n > 0) "Added $n item(s) to the shelf" else "Couldn't add that", Toast.LENGTH_SHORT).show()
                    Bus.changed()
                    refreshStatuses()
                }
            }
        }
        return true
    }
}
