package com.lobo.app

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout

/**
 * Cadangan: kalau jendela notch tidak bisa menerima keyboard (overlay Accessibility), kolom balas
 * dibuka sebagai activity transparan kecil di atas layar. Pengirimannya tetap lewat aksi Reply notifikasi.
 */
class ReplyActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val fn = ReplyBridge.fn
        if (fn == null) {
            finish()
            return
        }
        val input = EditText(this)
        fun send() {
            val t = input.text.toString().trim()
            if (t.isEmpty()) return
            val ok = try {
                fn(t)
            } catch (e: Exception) {
                false
            }
            ReplyBridge.fn = null
            Bus.alert(if (ok) Alert("Reply sent", ReplyBridge.title, "✓", C.GREEN, ms = 2000L) else Alert("Couldn't send reply", ReplyBridge.title, "!", C.RED))
            finish()
        }

        val root = FrameLayout(this)
        root.setBackgroundColor(0x66000000)
        root.setOnClickListener { finish() }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = rounded(0xFF0A0A0D.toInt(), dpf(28))
        card.setPadding(dp(18), dp(10), dp(10), dp(10))
        card.isClickable = true

        input.hint = "Reply to ${ReplyBridge.title}"
        input.setHintTextColor(0x66FFFFFF)
        input.setTextColor(C.TEXT)
        input.textSize = 15f
        input.background = null
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.maxLines = 3
        input.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_SEND) {
                send()
                true
            } else {
                false
            }
        }
        card.addView(input, llp(0, WRAP, 1f))
        val btn = LineIconView(this, IconKind.SEND, C.BLACK, 18f, 2f)
        btn.background = rounded(C.TEXT, dpf(20))
        btn.setOnClickListener { send() }
        card.addView(btn, llp(dp(40), dp(40), 0f, 8, 0, 0, 0))

        val sw = resources.displayMetrics.widthPixels
        val lp = FrameLayout.LayoutParams(minOf(sw - dp(24), dp(480)), WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        lp.topMargin = dp(12)
        root.addView(card, lp)
        setContentView(root)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        input.requestFocus()
    }

    override fun onDestroy() {
        ReplyBridge.fn = null
        super.onDestroy()
    }
}
