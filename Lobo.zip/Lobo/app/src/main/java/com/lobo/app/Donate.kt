package com.lobo.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import java.security.MessageDigest

/**
 * Pengaturan tab Donate ("Buy Lobo a meat").
 *
 * CUKUP ISI [URL] dengan link halaman donasi kamu (Trakteer / Saweria / Sociabuzz / Ko-fi, dst), lalu build ulang.
 * Selama [URL] kosong, tombolnya tampil "Segera hadir" dan tidak membuka apa-apa.
 */
object Donate {
    /** Contoh: "https://trakteer.id/namakamu" atau "https://saweria.co/namakamu". */
    val URL: String = "https://sociabuzz.com/lobo_ofc/tribe"

    /**
     * Sidik jari SHA-256 sertifikat tanda tangan RESMI Lobo (dari keystore rilis). APK yang ditandatangani kunci lain
     * (hasil bongkar-ulang / modifikasi orang) dianggap "bukan build resmi": tab Donate menonaktifkan tombolnya dan
     * memberi peringatan. Kosongkan nilainya kalau mau mematikan pengecekan ini.
     * Nilai ini harus sama dengan yang dicetak langkah "APK signature" di GitHub Actions.
     */
    private const val OFFICIAL_CERT_SHA256 = "AF:51:35:30:DD:BA:E6:32:3B:9F:D3:D2:6B:04:12:0A:93:E4:84:E6:F6:C0:E2:04:7E:C7:E2:79:4D:01:28:C6"

    private var verified: Boolean? = null

    /** true kalau APK ini ditandatangani kunci resmi Lobo. Dihitung sekali lalu disimpan. */
    fun isOfficial(c: Context): Boolean {
        verified?.let { return it }
        val ok = check(c)
        verified = ok
        return ok
    }

    @Suppress("DEPRECATION")
    private fun check(c: Context): Boolean {
        val want = OFFICIAL_CERT_SHA256.replace(":", "").lowercase()
        if (want.isEmpty()) return true // pengecekan dimatikan
        return try {
            val pm = c.packageManager
            val sigs = if (Build.VERSION.SDK_INT >= 28) {
                val si = pm.getPackageInfo(c.packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo
                    ?: return false
                si.apkContentsSigners
            } else {
                pm.getPackageInfo(c.packageName, PackageManager.GET_SIGNATURES).signatures ?: return false
            }
            if (sigs.isEmpty()) return false
            sigs.all { sig ->
                val h = MessageDigest.getInstance("SHA-256").digest(sig.toByteArray())
                h.joinToString("") { b -> "%02x".format(b) } == want
            }
        } catch (e: Exception) {
            false
        }
    }
}

/**
 * Panel "Buy Lobo a meat": logo serigala melayang pelan dengan potongan daging di sudutnya, ajakan singkat, dan tombol
 * ke halaman donasi. Animasi hanya jalan selama panel terlihat ([PanelLife]), jadi tidak makan CPU saat notch idle / mode hemat.
 */
class DonatePanel(private val c: Context) : FrameLayout(c), Refreshable, PanelLife {
    /** Diisi NotchView: tutup panel dulu, baru buka browser (sama seperti Launcher / Alerts). */
    var closeThen: ((() -> Unit) -> Unit)? = null

    private val logo = ImageView(c)
    private val meats = arrayOf("🍖", "🍗", "🥩")
    private var meatIdx = 0
    private val meat = c.tv(meats[0], 26f)
    private var bob: ObjectAnimator? = null
    private var wobble: ObjectAnimator? = null

    init {
        val official = Donate.isOfficial(c)
        val hasUrl = official && Donate.URL.isNotBlank()

        val card = LinearLayout(c)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = glass(C.GLASS, c.dpf(18))
        card.setPadding(c.dp(10), c.dp(6), c.dp(16), c.dp(6))

        // ---- kiri: logo Lobo + potongan daging
        val logoBox = FrameLayout(c)
        logo.setImageResource(R.drawable.ic_launcher_fg)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        logo.setOnClickListener { hop() }
        logoBox.addView(logo, LayoutParams(MATCH, MATCH))
        val ml = LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END)
        ml.setMargins(0, 0, c.dp(6), c.dp(8))
        meat.isClickable = false
        logoBox.addView(meat, ml)
        card.addView(logoBox, c.llp(c.dp(118), c.dp(118), 0f, 0, 0, 10, 0))

        // ---- kanan: judul, ajakan, tombol
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_VERTICAL

        col.addView(c.tv("Buy Lobo a meat", 20f, C.TEXT, true), c.llp(WRAP, WRAP, 0f, 0, 0, 0, 4))

        val desc = c.tv(
            if (official) {
                "Bantu Lobo mendarat di Play Store! Dukunganmu dipakai buat biaya rilis dan pengembangan Lobo. " +
                    "Punya saran atau nemu bug? Tulis di pesan donasinya, semuanya Lobo baca."
            } else {
                "⚠ Ini bukan build resmi Lobo, jadi tombol donasi dimatikan demi keamananmu. " +
                    "Pasang ulang Lobo dari sumber resmi."
            },
            12.5f, C.SUB
        )
        desc.maxLines = 3
        desc.ellipsize = TextUtils.TruncateAt.END
        desc.setLineSpacing(0f, 1.1f)
        col.addView(desc, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 10))

        val btns = LinearLayout(c)
        btns.gravity = Gravity.CENTER_VERTICAL
        val buy = c.pill(
            when {
                !official -> "Build tidak resmi"
                hasUrl -> "🍖  Traktir daging"
                else -> "Segera hadir"
            },
            if (hasUrl) MEAT_RED else C.GLASS2, C.TEXT, 13f
        ) { openDonate() }
        btns.addView(buy, c.llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        if (hasUrl) {
            btns.addView(c.pill("Salin link", C.GLASS2, C.TEXT, 12f) { copyLink() }, c.llp(WRAP, WRAP, 0f, 0, 0, 10, 0))
        }
        if (official) {
            val thanks = c.tv("Makasih, berapa pun itu ♥", 11.5f, C.SUB)
            thanks.maxLines = 2
            btns.addView(thanks, c.llp(0, WRAP, 1f))
        }
        col.addView(btns, c.llp(MATCH, WRAP))

        card.addView(col, c.llp(0, MATCH, 1f))
        addView(card, LayoutParams(MATCH, MATCH))
    }

    private fun openDonate() {
        if (!Donate.isOfficial(c)) {
            Toast.makeText(c, "Build tidak resmi: donasi dimatikan", Toast.LENGTH_SHORT).show()
            return
        }
        val url = Donate.URL.trim()
        if (url.isEmpty()) {
            Toast.makeText(c, "Link donasi belum diisi", Toast.LENGTH_SHORT).show()
            return
        }
        val go: () -> Unit = {
            try {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                c.startActivity(i)
            } catch (e: Exception) {
                Toast.makeText(c, "Tidak ada browser untuk membuka link", Toast.LENGTH_SHORT).show()
            }
        }
        val ct = closeThen
        if (ct != null) ct(go) else go()
    }

    private fun copyLink() {
        if (!Donate.isOfficial(c)) return
        try {
            val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Lobo", Donate.URL.trim()))
            Toast.makeText(c, "Link disalin", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
        }
    }

    /** Ketuk logo: Lobo melompat kecil dan dagingnya ganti (🍖 → 🍗 → 🥩). */
    private fun hop() {
        meatIdx = (meatIdx + 1) % meats.size
        meat.text = meats[meatIdx]
        logo.animate().cancel()
        logo.scaleX = 0.86f
        logo.scaleY = 0.86f
        logo.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(OvershootInterpolator(3f)).start()
    }

    private fun startAnim() {
        if (bob == null) {
            bob = ObjectAnimator.ofFloat(logo, View.TRANSLATION_Y, -c.dpf(3), c.dpf(3)).apply {
                duration = 1700
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                interpolator = AccelerateDecelerateInterpolator()
            }
        }
        if (wobble == null) {
            wobble = ObjectAnimator.ofFloat(meat, View.ROTATION, -12f, 12f).apply {
                duration = 900
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                interpolator = AccelerateDecelerateInterpolator()
            }
        }
        if (bob?.isStarted != true) bob?.start()
        if (wobble?.isStarted != true) wobble?.start()
    }

    private fun stopAnim() {
        bob?.cancel()
        wobble?.cancel()
        bob = null
        wobble = null
        logo.translationY = 0f
        meat.rotation = 0f
    }

    override fun onVisible(v: Boolean) {
        if (v) startAnim() else stopAnim()
    }

    override fun onDetachedFromWindow() {
        stopAnim()
        super.onDetachedFromWindow()
    }

    override fun refresh() {
        // statis: tidak ada data yang perlu diperbarui
    }

    private companion object {
        val MEAT_RED = 0xFFFF5A4D.toInt()
    }
}
