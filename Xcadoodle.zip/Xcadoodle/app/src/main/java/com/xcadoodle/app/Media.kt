package com.xcadoodle.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class LrcLine(val t: Long, val text: String)

/** Lirik dari LRCLIB (lrclib.net) – format LRC bertimestamp. */
object Lrc {
    private val ts = Regex("\\[(\\d+):(\\d+)(?:[.:](\\d+))?\\]")

    fun parse(src: String): List<LrcLine> {
        val out = ArrayList<LrcLine>()
        for (line in src.lines()) {
            val ms = ts.findAll(line).toList()
            if (ms.isEmpty()) continue
            val text = line.substring(ms.last().range.last + 1).trim()
            for (m in ms) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val msv = if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong()
                out.add(LrcLine(min * 60000L + sec * 1000L + msv, text))
            }
        }
        out.sortBy { it.t }
        return out
    }

    private fun http(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "Xcadoodle-Notch/1.0 (Android)")
        return try {
            if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
        } finally {
            c.disconnect()
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    /** Blocking – panggil dari thread background. */
    fun fetch(track: String, artist: String, durMs: Long): List<LrcLine>? {
        val tries = listOf(
            "https://lrclib.net/api/search?track_name=${enc(track)}&artist_name=${enc(artist)}",
            "https://lrclib.net/api/search?q=${enc("$track $artist")}"
        )
        for (u in tries) {
            try {
                val body = http(u) ?: continue
                val arr = JSONArray(body)
                var best: String? = null
                var bestD = Long.MAX_VALUE
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val s = o.optString("syncedLyrics", "")
                    if (s.isBlank() || s == "null") continue
                    val d = if (durMs > 0) Math.abs((o.optDouble("duration", 0.0) * 1000).toLong() - durMs) else 0L
                    if (d < bestD) {
                        bestD = d
                        best = s
                    }
                }
                if (best != null) {
                    val l = parse(best)
                    if (l.isNotEmpty()) return l
                }
            } catch (e: Exception) {
            }
        }
        return null
    }
}

/** Memantau sesi media aktif (Spotify, YouTube Music, dll) lewat MediaSessionManager. */
class MediaWatcher(private val ctx: Context, private val onChange: () -> Unit) {
    private val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val cn = ComponentName(ctx, XcadoodleNotificationListener::class.java)
    private val main = Handler(Looper.getMainLooper())
    private var ctl: MediaController? = null
    private var registered = false

    var granted = false
        private set
    var hasSession = false
        private set
    var title = ""
        private set
    var artist = ""
        private set
    var art: Bitmap? = null
        private set
    var duration = 0L
        private set
    var playing = false
        private set
    var lyrics: List<LrcLine>? = null
        private set
    var lyricsState = 0 // 0 kosong, 1 loading, 2 ada, 3 tidak ada
        private set

    // --- lagu terakhir: tetap tersedia walau sesi sudah hilang (mode standby di tab Music)
    var lastTitle = ""
        private set
    var lastArtist = ""
        private set
    var lastPkg = ""
        private set
    var lastArt: Bitmap? = null
        private set
    private var savedArt: Bitmap? = null
    private var resumeAt = -100_000L
    private val artFile = File(ctx.cacheDir, "last_art.jpg")

    val hasLast: Boolean get() = lastTitle.isNotBlank() && lastPkg.isNotBlank()

    /** true sebentar setelah tombol play ditekan di mode standby, sebelum app pemutarnya menjawab. */
    val resuming: Boolean get() = !hasSession && SystemClock.elapsedRealtime() - resumeAt < 4000L

    init {
        val p = Xcadoodle.prefs
        lastTitle = p.lastTitle
        lastArtist = p.lastArtist
        lastPkg = p.lastPkg
        if (lastTitle.isNotBlank()) {
            thread {
                val b = try {
                    BitmapFactory.decodeFile(artFile.absolutePath)
                } catch (e: Exception) {
                    null
                }
                main.post {
                    if (b != null && lastArt == null) {
                        lastArt = b
                        savedArt = b
                        onChange()
                    }
                }
            }
        }
    }

    private var lyricKey = ""
    private var basePos = 0L
    private var baseTime = 0L
    private var speed = 1f

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            readMeta(metadata)
            onChange()
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            readState(state)
            if (state == null || state.state != PlaybackState.STATE_PLAYING) pick(safeSessions())
            onChange()
        }

        override fun onSessionDestroyed() {
            pick(safeSessions())
        }
    }

    private fun refreshGranted() {
        granted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }

    private fun safeSessions(): List<MediaController>? {
        return try {
            msm.getActiveSessions(cn)
        } catch (e: SecurityException) {
            null
        }
    }

    /** Aman dipanggil berulang; mendaftar begitu izin notification access diberikan. */
    fun ensure() {
        if (registered) return
        refreshGranted()
        if (!granted) return
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            registered = true
            pick(safeSessions())
        } catch (e: SecurityException) {
            granted = false
        }
    }

    fun start() {
        ensure()
    }

    fun stop() {
        try {
            msm.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
        }
        ctl?.unregisterCallback(cb)
        ctl = null
        registered = false
    }

    private fun pick(list: List<MediaController>?) {
        val cands = (list ?: emptyList()).filter { it.packageName != ctx.packageName }
        val chosen = cands.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: cands.firstOrNull()
        if (chosen != null && ctl != null && chosen.sessionToken == ctl!!.sessionToken) {
            onChange()
            return
        }
        ctl?.unregisterCallback(cb)
        ctl = chosen
        hasSession = chosen != null
        if (chosen == null) {
            title = ""
            artist = ""
            art = null
            playing = false
            lyrics = null
            lyricsState = 0
            lyricKey = ""
            onChange()
            return
        }
        chosen.registerCallback(cb, main)
        readMeta(chosen.metadata)
        readState(chosen.playbackState)
        onChange()
    }

    private fun readMeta(m: MediaMetadata?) {
        if (m == null) return
        title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: m.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        art = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        duration = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
        remember()
        loadLyrics()
    }

    /** Simpan lagu yang sedang/terakhir diputar supaya bisa ditampilkan lagi saat standby. */
    private fun remember() {
        val pkg = ctl?.packageName ?: return
        if (title.isBlank()) return
        val changed = title != lastTitle || artist != lastArtist || pkg != lastPkg
        if (changed) {
            lastTitle = title
            lastArtist = artist
            lastPkg = pkg
            val p = Xcadoodle.prefs
            p.lastTitle = title
            p.lastArtist = artist
            p.lastPkg = pkg
        }
        val a = art
        if (a != null && a !== savedArt) {
            savedArt = a
            lastArt = a
            thread {
                try {
                    val sc = 320f / maxOf(a.width, a.height)
                    val out = if (sc < 1f) Bitmap.createScaledBitmap(a, (a.width * sc).toInt().coerceAtLeast(1), (a.height * sc).toInt().coerceAtLeast(1), true) else a
                    artFile.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                } catch (e: Exception) {
                }
            }
        } else if (a == null && changed) {
            savedArt = null
            lastArt = null
            artFile.delete()
        }
    }

    /** Paket app yang sedang memutar (atau yang terakhir memutar). */
    fun sourcePkg(): String = ctl?.packageName ?: lastPkg

    fun sourceIcon(): Drawable? {
        val p = sourcePkg()
        if (p.isBlank()) return null
        return try {
            ctx.packageManager.getApplicationIcon(p)
        } catch (e: Exception) {
            null
        }
    }

    fun sourceLabel(): String {
        val p = sourcePkg()
        if (p.isBlank()) return ""
        return try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString()
        } catch (e: Exception) {
            ""
        }
    }

    /** Buka app pemutar (Spotify dll). */
    fun openApp() {
        val p = sourcePkg()
        if (p.isBlank()) return
        val i = ctx.packageManager.getLaunchIntentForPackage(p)
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                ctx.startActivity(i)
                return
            } catch (e: Exception) {
            }
        }
        try {
            ctl?.sessionActivity?.send()
        } catch (e: Exception) {
        }
    }

    /**
     * Mode standby: putar lagu terakhir tanpa membuka app. Memakai tombol media PLAY yang sama dengan
     * tombol headset, jadi sistem membangunkan pemutar terakhir (Spotify) di latar belakang.
     */
    fun resume() {
        if (!hasLast) return
        resumeAt = SystemClock.elapsedRealtime()
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY))
        } catch (e: Exception) {
        }
        // cadangan: kalau belum ada sesi setelah 2,5 dtk, kirim tombol PLAY langsung ke app terakhir
        main.postDelayed({
            if (!hasSession && lastPkg.isNotBlank()) {
                for (act in intArrayOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP)) {
                    val i = Intent(Intent.ACTION_MEDIA_BUTTON)
                    i.setPackage(lastPkg)
                    i.putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(act, KeyEvent.KEYCODE_MEDIA_PLAY))
                    try {
                        ctx.sendBroadcast(i)
                    } catch (e: Exception) {
                    }
                }
            }
        }, 2500L)
        onChange()
    }

    private fun readState(s: PlaybackState?) {
        if (s == null) {
            playing = false
            return
        }
        playing = s.state == PlaybackState.STATE_PLAYING || s.state == PlaybackState.STATE_BUFFERING
        basePos = if (s.position < 0) 0L else s.position
        baseTime = s.lastPositionUpdateTime
        speed = s.playbackSpeed
    }

    private fun loadLyrics() {
        val key = "$title|$artist"
        if (key == lyricKey) return
        lyricKey = key
        lyrics = null
        if (title.isBlank()) {
            lyricsState = 0
            return
        }
        lyricsState = 1
        val t = title
        val a = artist
        val d = duration
        thread {
            val r = Lrc.fetch(t, a, d)
            main.post {
                if (lyricKey == key) {
                    lyrics = r
                    lyricsState = if (r != null) 2 else 3
                    onChange()
                }
            }
        }
    }

    fun position(): Long {
        if (!playing) return basePos
        val p = basePos + ((SystemClock.elapsedRealtime() - baseTime) * speed).toLong()
        return if (duration > 0) minOf(p, duration) else p
    }

    fun currentLyric(): String {
        val l = lyrics
        if (l == null) {
            return when (lyricsState) {
                1 -> "Loading lyrics"
                3 -> "Lyrics not available"
                else -> ""
            }
        }
        val p = position() + 250
        var cur = ""
        for (x in l) {
            if (x.t <= p) cur = x.text else break
        }
        return if (cur.isBlank()) "♪" else cur
    }

    /** [baris sekarang, berikutnya, berikutnya lagi] untuk tampilan 3 baris. */
    fun lyricWindow(): Array<String> {
        val l = lyrics
        if (l == null) {
            val st = when (lyricsState) {
                1 -> "Loading lyrics"
                3 -> "Lyrics not available"
                else -> ""
            }
            return arrayOf(st, "", "")
        }
        val p = position() + 250
        var idx = -1
        for (i in l.indices) {
            if (l[i].t <= p) idx = i else break
        }
        fun txt(i: Int): String {
            if (i < 0 || i >= l.size) return ""
            return if (l[i].text.isBlank()) "♪" else l[i].text
        }
        return arrayOf(if (idx < 0) "♪" else txt(idx), txt(idx + 1), txt(idx + 2))
    }

    fun toggle() {
        val t = ctl?.transportControls ?: return
        if (playing) t.pause() else t.play()
    }

    fun next() {
        ctl?.transportControls?.skipToNext()
    }

    fun prev() {
        ctl?.transportControls?.skipToPrevious()
    }

    fun seekFrac(f: Float) {
        if (duration > 0) ctl?.transportControls?.seekTo((f * duration).toLong())
    }
}
