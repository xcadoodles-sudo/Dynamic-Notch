# Xcadoodle untuk Android

"Living notch" yang menempel di tepi atas layar, dengan maskot serigala kecil.
Dibuat untuk Xiaomi Pad 6S Pro. Kotlin murni, tanpa Compose, dependensi cuma `androidx.core` + Shizuku.

## Cara build
- **Android Studio**: buka folder `Xcadoodle`, tunggu Gradle sync, Run / Build APK.
- **GitHub Actions**: upload folder ini ke repo, workflow ada di `.github/workflows/build.yml`.
  Hasil APK ada di Artifacts (`Xcadoodle-debug-apk`).

Pertama kali buka app, beri izin dari atas ke bawah (Display over other apps, Notification access,
Accessibility, dst), lalu tekan **Start notch**.

> Nama paket sekarang `com.xcadoodle.app`, jadi ini terpasang sebagai aplikasi BARU (bukan update dari Nusa).
> Uninstall Nusa lama, lalu beri izin ulang sekali.

## Maskot serigala
Kepala bulat gemuk dengan mata menyala dan outline neon ungu. Tinggal di sisi kiri pil saat tidak ada musik.

| Kondisi | Yang dilakukan |
|---|---|
| Idle | duduk, berkedip, melirik kiri/kanan, telinga berkedut, ekor goyang, bernapas |
| Tiap beberapa detik | jalan lenggak-lenggok ke kiri/kanan sepanjang pil: badan bergoyang, kaki bergantian, telinga berayun, wajah menoleh ke arah jalan |
| Diam ~20 detik | mengantuk (kelopak turun, kepala angguk-angguk), lalu meringkuk tidur dengan ekor melingkar dan "z z z" |
| Disentuh / panel dibuka | bangun, melar, duduk lagi |
| Notifikasi masuk | kaget dan melompat kecil |
| Tekan lama | dielus: mata senang, ekor cepat, hati melayang |

Waktu tidur, lama tidur, kecepatan jalan, dan kecepatan langkah ada di konstanta bagian atas `PetView` (`Mascot.kt`).
Ikon tab, tombol tutup, dan ikon alert digambar di `Icons.kt` (garis tipis minimalis, tanpa emoji).

## Alert / notifikasi
Pil alert berbentuk kapsul penuh: ikon garis di dalam lingkaran bertint lembut (warna sesuai jenis alert), judul medium + keterangan redup, isi di tengah. Notifikasi app lain menampilkan ikon app dalam kotak membulat. Ikon pop kecil saat alert muncul.

Ikon aplikasi (launcher) memakai kepala maskot dengan latar gelap, dan ada versi monochrome untuk themed icon Android 13+.

## Equalizer
- Bar bergerak dari gelombang sinus bertumpuk, jadi halus (tidak loncat acak). Naik cepat, turun pelan.
- Warna gradasi dari dua warna utama cover album yang sedang diputar; berubah mulus saat lagu ganti.
- Berhenti menggambar sendiri saat musik pause (hemat baterai).

## Warna di dalam notch (idle)
- Tidak ada lagi halo/garis tepi bercahaya di sekeliling notch, cuma warna di dalamnya.
- Saat tidak ada musik: cahaya biru -> indigo -> ungu diam dari dasar notch.
- Saat musik main: tiga gumpalan cahaya warna cover album melayang pelan kiri-kanan (dua warna saling melewati),
  membesar-mengecil ikut denyut equalizer. Masuk/keluar dan ganti lagu bertransisi mulus.
  Gerakannya di `NotchShape.drawBlobs`, kecepatan = periode detik di situ. Berhenti menggambar sendiri saat notch tertutup panel/alert.

## Gradasi tab Markets
Cahaya di dasar panel Music memakai dua warna cover album yang sedang diputar (oranye -> pink kalau tidak ada cover).

Cahaya di dasar panel Markets mengikuti arah harga simbol yang dipilih (angka perubahan yang sama dengan yang tampil):
naik = hijau, turun = merah, belum ada data = abu-biru. Ganti simbol/timeframe atau harga melewati titik awal -> warna berpindah halus.

## Fitur lain
Music (lirik LRCLIB), Device (CPU/GPU/RAM/suhu, lebih lengkap dengan Shizuku), Markets (chart ala TradingView),
Calendar + cuaca, Shelf (drop/share file). Alert untuk baterai, jaringan, Bluetooth, dan notifikasi app lain.
Ukuran notch (lebar, tebal, jarak dari atas) bisa disetel di pengaturan app.
