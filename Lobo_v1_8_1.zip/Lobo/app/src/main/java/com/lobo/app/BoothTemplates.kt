package com.lobo.app

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// ------------------------------------------------------------------ alat gambar kecil

private const val PAPER_BG = 0xFFF6F3EC.toInt()

private fun solid(col: Int): Paint {
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = col
    return p
}

private fun strokeP(col: Int, w: Float): Paint {
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.style = Paint.Style.STROKE
    p.color = col
    p.strokeWidth = w
    p.strokeCap = Paint.Cap.ROUND
    p.strokeJoin = Paint.Join.ROUND
    return p
}

private fun textP(col: Int, size: Float, tf: Typeface, spacing: Float, align: Paint.Align = Paint.Align.CENTER): Paint {
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.color = col
    p.textSize = size
    p.typeface = tf
    p.letterSpacing = spacing
    p.textAlign = align
    return p
}

private fun withAlpha(col: Int, a: Int): Int = (a shl 24) or (col and 0x00FFFFFF)

private fun dateStr(): String = SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date())

private fun tHeart(cv: Canvas, x: Float, y: Float, r: Float, col: Int) {
    val path = Path()
    path.moveTo(x, y + r * 0.9f)
    path.cubicTo(x - r * 1.6f, y - r * 0.1f, x - r * 0.9f, y - r * 1.3f, x, y - r * 0.45f)
    path.cubicTo(x + r * 0.9f, y - r * 1.3f, x + r * 1.6f, y - r * 0.1f, x, y + r * 0.9f)
    path.close()
    cv.drawPath(path, solid(col))
}

private fun tStar(cv: Canvas, x: Float, y: Float, r: Float, col: Int) {
    val path = Path()
    val tau = (2.0 * PI).toFloat()
    for (i in 0 until 10) {
        val rr = if (i % 2 == 0) r else r * 0.45f
        val a = i * (tau / 10f) - tau / 4f
        val px = x + cos(a) * rr
        val py = y + sin(a) * rr
        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
    }
    path.close()
    cv.drawPath(path, solid(col))
}

private fun tSparkle(cv: Canvas, x: Float, y: Float, r: Float, col: Int) {
    val k = r * 0.26f
    val path = Path()
    path.moveTo(x, y - r)
    path.quadTo(x + k, y - k, x + r, y)
    path.quadTo(x + k, y + k, x, y + r)
    path.quadTo(x - k, y + k, x - r, y)
    path.quadTo(x - k, y - k, x, y - r)
    path.close()
    cv.drawPath(path, solid(col))
}

/** Potong sumber supaya rasio pas dengan kotak tujuan. biasY 0..1: 0 = rapatkan ke atas (menjaga dahi/kepala). */
private fun srcFor(b: Bitmap, aspect: Float, biasY: Float): Rect {
    val bw = b.width
    val bh = b.height
    return if (bw.toFloat() / bh > aspect) {
        val nw = (bh * aspect).toInt()
        val x = (bw - nw) / 2
        Rect(x, 0, x + nw, bh)
    } else {
        val nh = (bw / aspect).toInt()
        val y = ((bh - nh) * biasY).toInt()
        Rect(0, y, bw, y + nh)
    }
}

/** Foto dengan sudut membulat (anti-alias lewat shader, bukan clip). */
private fun drawPhoto(cv: Canvas, b: Bitmap, dst: RectF, radius: Float) {
    val src = srcFor(b, dst.width() / dst.height(), 0.3f)
    val sh = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    val m = Matrix()
    m.setRectToRect(RectF(src), dst, Matrix.ScaleToFit.FILL)
    sh.setLocalMatrix(m)
    val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    p.shader = sh
    cv.drawRoundRect(dst, radius, radius, p)
}

// ------------------------------------------------------------------ kerangka template

/**
 * Satu template = tampilan bingkai untuk 4-Up (grid 2x2) dan Strip (4 foto vertikal). Semua ukuran dalam piksel hasil.
 * Urutan gambar: bg -> (frame -> foto -> over) per foto -> foot.
 */
private abstract class Tpl {
    open val mx: Float = 40f      // strip: margin kiri/kanan
    open val my: Float = 40f      // strip: margin atas
    open val gap: Float = 40f     // strip: jarak antar foto
    open val footS: Float = 160f  // strip: tinggi footer
    open val gmx: Float = 40f     // grid: margin kiri/kanan
    open val gmy: Float = 40f     // grid: margin atas
    open val ggap: Float = 40f    // grid: jarak antar foto
    open val footG: Float = 120f  // grid: tinggi footer (0 = tanpa footer)
    open val radius: Float = 0f

    abstract fun bg(cv: Canvas, w: Float, h: Float, vertical: Boolean)
    open fun frame(cv: Canvas, r: RectF, i: Int) {}
    open fun over(cv: Canvas, r: RectF, i: Int) {}
    abstract fun foot(cv: Canvas, w: Float, top: Float, h: Float, vertical: Boolean)
}

/** Kertas krem polos (tampilan asli). */
private class ClassicTpl : Tpl() {
    override val gmx: Float = 26f
    override val gmy: Float = 26f
    override val ggap: Float = 26f
    override val footG: Float = 0f

    override fun bg(cv: Canvas, w: Float, h: Float, vertical: Boolean) {
        cv.drawColor(PAPER_BG)
    }

    override fun foot(cv: Canvas, w: Float, top: Float, h: Float, vertical: Boolean) {
        val tp = textP(0xFF9B968C.toInt(), 38f, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0.18f)
        cv.drawText("LOBO PHOTO BOOTH", w / 2f, top + 66f, tp)
        tp.textSize = 28f
        tp.letterSpacing = 0.05f
        cv.drawText(dateStr(), w / 2f, top + 114f, tp)
    }
}

/** Rol film hitam dengan lubang sprocket, nomor frame, dan cap "LOBO 400". */
private class FilmTpl : Tpl() {
    override val mx: Float = 100f
    override val my: Float = 46f
    override val gap: Float = 40f
    override val footS: Float = 150f
    override val gmx: Float = 44f
    override val gmy: Float = 104f
    override val ggap: Float = 40f
    override val footG: Float = 170f
    override val radius: Float = 6f

    private val amber: Int = 0xFFFFB02E.toInt()
    private val cream: Int = 0xFFEFE8D8.toInt()
    private val mono: Typeface = Typeface.create("monospace", Typeface.BOLD)

    override fun bg(cv: Canvas, w: Float, h: Float, vertical: Boolean) {
        cv.drawColor(0xFF111111.toInt())
        val hole = solid(cream)
        val edge = strokeP(withAlpha(amber, 110), 2f)
        val rr = RectF()
        if (vertical) {
            for (side in 0 until 2) {
                val x = if (side == 0) 50f else w - 50f
                var y = 22f
                while (y + 44f < h - 14f) {
                    rr.set(x - 15f, y, x + 15f, y + 44f)
                    cv.drawRoundRect(rr, 8f, 8f, hole)
                    y += 72f
                }
            }
            cv.drawLine(88f, 0f, 88f, h, edge)
            cv.drawLine(w - 88f, 0f, w - 88f, h, edge)
        } else {
            for (side in 0 until 2) {
                val y = if (side == 0) 24f else h - 54f
                var x = 26f
                while (x + 44f < w - 14f) {
                    rr.set(x, y, x + 44f, y + 30f)
                    cv.drawRoundRect(rr, 8f, 8f, hole)
                    x += 72f
                }
            }
            cv.drawLine(0f, 70f, w, 70f, edge)
            cv.drawLine(0f, h - 70f, w, h - 70f, edge)
        }
    }

    override fun frame(cv: Canvas, r: RectF, i: Int) {
        val pl = RectF(r.left - 7f, r.top - 7f, r.right + 7f, r.bottom + 7f)
        cv.drawRoundRect(pl, 10f, 10f, solid(0xFF1F1F1F.toInt()))
    }

    override fun over(cv: Canvas, r: RectF, i: Int) {
        val tp = textP(amber, 20f, mono, 0.05f, Paint.Align.LEFT)
        cv.drawText((i + 1).toString() + "A", r.left + 2f, r.top - 14f, tp)
        val tri = Path()
        tri.moveTo(r.right - 16f, r.top - 29f)
        tri.lineTo(r.right - 16f, r.top - 13f)
        tri.lineTo(r.right, r.top - 21f)
        tri.close()
        cv.drawPath(tri, solid(amber))
    }

    override fun foot(cv: Canvas, w: Float, top: Float, h: Float, vertical: Boolean) {
        cv.drawText("LOBO 400", w / 2f, top + 54f, textP(amber, 38f, mono, 0.22f))
        cv.drawText(dateStr().uppercase(Locale.getDefault()), w / 2f, top + 92f, textP(cream, 24f, mono, 0.12f))
    }
}

/** Synthwave: ungu malam, bintang, bingkai neon cyan/magenta, matahari retro + grid. */
private class NeonTpl : Tpl() {
    override val mx: Float = 60f
    override val my: Float = 60f
    override val gap: Float = 54f
    override val footS: Float = 300f
    override val gmx: Float = 60f
    override val gmy: Float = 60f
    override val ggap: Float = 54f
    override val footG: Float = 270f
    override val radius: Float = 24f

    private val cyan: Int = 0xFF19F2FF.toInt()
    private val pink: Int = 0xFFFF3DDC.toInt()
    private var bgPaint: Paint? = null

    override fun bg(cv: Canvas, w: Float, h: Float, vertical: Boolean) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(0xFF0B0120.toInt(), 0xFF1D0A45.toInt(), 0xFF41095F.toInt()),
            floatArrayOf(0f, 0.6f, 1f),
            Shader.TileMode.CLAMP
        )
        cv.drawRect(0f, 0f, w, h, p)
        bgPaint = p
        val rnd = Random(11L)
        val sp = solid(0xFFFFFFFF.toInt())
        for (k in 0 until 70) {
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h * 0.88f
            sp.alpha = 90 + rnd.nextInt(150)
            cv.drawCircle(x, y, 1.2f + rnd.nextFloat() * 2.2f, sp)
        }
    }

    private fun tone(i: Int): Int = if (i % 2 == 0) cyan else pink

    override fun frame(cv: Canvas, r: RectF, i: Int) {
        val col = tone(i)
        val widths = floatArrayOf(34f, 24f, 15f, 8f)
        val alphas = intArrayOf(26, 46, 80, 140)
        for (k in 0 until 4) {
            cv.drawRoundRect(r, radius, radius, strokeP(withAlpha(col, alphas[k]), widths[k]))
        }
    }

    override fun over(cv: Canvas, r: RectF, i: Int) {
        cv.drawRoundRect(r, radius, radius, strokeP(tone(i), 6f))
        cv.drawRoundRect(r, radius, radius, strokeP(0xCCFFFFFF.toInt(), 1.8f))
    }

    private fun glowText(cv: Canvas, s: String, x: Float, y: Float, size: Float, col: Int) {
        val tf = Typeface.create("sans-serif-medium", Typeface.BOLD)
        val g = textP(withAlpha(col, 60), size, tf, 0.16f)
        g.style = Paint.Style.STROKE
        g.strokeWidth = 12f
        cv.drawText(s, x, y, g)
        g.strokeWidth = 6f
        g.color = withAlpha(col, 120)
        cv.drawText(s, x, y, g)
        cv.drawText(s, x, y, textP(0xFFFFFFFF.toInt(), size, tf, 0.16f))
    }

    override fun foot(cv: Canvas, w: Float, top: Float, h: Float, vertical: Boolean) {
        val bgP: Paint = bgPaint ?: return
        val cx = w / 2f
        val hor = top + h * 0.45f
        val bottom = top + h
        val rad = min(84f, h * 0.30f)

        // matahari: setengah lingkaran bergradasi, dipotong garis-garis berwarna latar
        val sunP = Paint(Paint.ANTI_ALIAS_FLAG)
        sunP.shader = LinearGradient(0f, hor - rad, 0f, hor, 0xFFFFE259.toInt(), 0xFFFF2E9A.toInt(), Shader.TileMode.CLAMP)
        val clip = Path()
        clip.addRect(0f, hor - rad - 6f, w, hor, Path.Direction.CW)
        cv.save()
        cv.clipPath(clip)
        cv.drawCircle(cx, hor, rad, sunP)
        for (k in 0 until 5) {
            val bh = 3f + k * 2.2f
            val yb = hor - rad * 0.62f + k * rad * 0.15f
            cv.drawRect(cx - rad, yb, cx + rad, yb + bh, bgP)
        }
        cv.restore()

        // lantai grid
        cv.save()
        cv.clipRect(0f, hor, w, bottom)
        val gl = strokeP(withAlpha(pink, 170), 2.2f)
        var k = 1
        while (k <= 7) {
            val f = k / 7f
            val y = hor + (bottom - hor) * f * f
            cv.drawLine(0f, y, w, y, gl)
            k++
        }
        for (j in -8..8) {
            cv.drawLine(cx, hor, cx + j * w / 6f, bottom, gl)
        }
        cv.restore()
        cv.drawLine(0f, hor, w, hor, strokeP(cyan, 3f))

        val ty = hor + (bottom - hor) * 0.52f
        val pill = RectF(cx - 330f, ty - 48f, cx + 330f, ty + 82f)
        cv.drawRoundRect(pill, 40f, 40f, solid(0xB30B0120.toInt()))
        glowText(cv, "LOBO PHOTO BOOTH", cx, ty, 40f, cyan)
        glowText(cv, dateStr(), cx, ty + 52f, 26f, pink)
    }
}

/** Pastel manis: gradasi pink-peach, polkadot, bingkai putih bertape, stiker hati/bintang, tulisan "xoxo". */
private class PastelTpl : Tpl() {
    override val mx: Float = 64f
    override val my: Float = 72f
    override val gap: Float = 64f
    override val footS: Float = 250f
    override val gmx: Float = 64f
    override val gmy: Float = 72f
    override val ggap: Float = 64f
    override val footG: Float = 230f
    override val radius: Float = 26f

    private val script: Typeface = Typeface.create("cursive", Typeface.BOLD)
    private val tapes: IntArray = intArrayOf(0xCCB8F0D8.toInt(), 0xCCD9C8FF.toInt(), 0xCCFFF0A8.toInt(), 0xCCFFC8B0.toInt())

    override fun bg(cv: Canvas, w: Float, h: Float, vertical: Boolean) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, w, h, 0xFFFFCFE4.toInt(), 0xFFFFF0DA.toInt(), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p)
        val dp = solid(0x66FFFFFF)
        var row = 0
        var y = 30f
        while (y < h) {
            var x = if (row % 2 == 0) 30f else 69f
            while (x < w) {
                cv.drawCircle(x, y, 12f, dp)
                x += 78f
            }
            y += 60f
            row++
        }
    }

    override fun frame(cv: Canvas, r: RectF, i: Int) {
        val sh = RectF(r.left - 16f, r.top - 4f, r.right + 16f, r.bottom + 28f)
        cv.drawRoundRect(sh, radius + 16f, radius + 16f, solid(0x30B04A7A))
        val fr = RectF(r.left - 16f, r.top - 16f, r.right + 16f, r.bottom + 16f)
        cv.drawRoundRect(fr, radius + 16f, radius + 16f, solid(0xFFFFFFFF.toInt()))
    }

    override fun over(cv: Canvas, r: RectF, i: Int) {
        cv.save()
        cv.rotate(if (i % 2 == 0) -5f else 4f, r.centerX(), r.top - 14f)
        val tr = RectF(r.centerX() - 70f, r.top - 36f, r.centerX() + 70f, r.top + 6f)
        cv.drawRect(tr, solid(tapes[i % tapes.size]))
        cv.restore()
        if (i % 2 == 0) {
            tHeart(cv, r.right - 4f, r.bottom - 2f, 26f, 0xFFFF7BAE.toInt())
            tSparkle(cv, r.left + 18f, r.bottom - 22f, 16f, 0xFFFFFFFF.toInt())
        } else {
            tStar(cv, r.left + 4f, r.bottom - 4f, 26f, 0xFFFFD84D.toInt())
            tHeart(cv, r.right - 20f, r.bottom - 22f, 14f, 0xFFFFFFFF.toInt())
        }
    }

    override fun foot(cv: Canvas, w: Float, top: Float, h: Float, vertical: Boolean) {
        val cx = w / 2f
        cv.drawText("xoxo", cx, top + h * 0.52f, textP(0xFFFF5F9E.toInt(), 92f, script, 0.02f))
        tHeart(cv, cx - 210f, top + h * 0.40f, 20f, 0xFFFF9CC4.toInt())
        tHeart(cv, cx + 210f, top + h * 0.40f, 20f, 0xFFFFB3D2.toInt())
        tStar(cv, cx - 150f, top + h * 0.20f, 14f, 0xFFFFD84D.toInt())
        tStar(cv, cx + 150f, top + h * 0.20f, 14f, 0xFFFFD84D.toInt())
        val t2 = textP(0xFFB8678F.toInt(), 30f, Typeface.create("sans-serif-medium", Typeface.NORMAL), 0.14f)
        cv.drawText("LOBO PHOTO BOOTH", cx, top + h * 0.76f, t2)
        t2.textSize = 26f
        t2.letterSpacing = 0.06f
        cv.drawText(dateStr(), cx, top + h * 0.76f + 40f, t2)
    }
}

// ------------------------------------------------------------------ komposisi

object BoothTpl {
    val names: List<String> = listOf("Classic", "Film", "Neon", "Pastel")

    private val all: List<Tpl> = listOf(ClassicTpl(), FilmTpl(), NeonTpl(), PastelTpl())

    private fun pick(idx: Int): Tpl = all[idx.coerceIn(0, all.size - 1)]

    /** 4 foto vertikal. Foto lanskap dipotong 4:3, foto potret dipotong persegi (menjaga bagian atas kepala). */
    fun strip(l: List<Bitmap>, idx: Int): Bitmap {
        val t = pick(idx)
        val ta = if (l[0].width >= l[0].height) 4f / 3f else 1f
        val fw = 720f
        val fh = fw / ta
        val tilesBottom = t.my + 4f * fh + 3f * t.gap
        val w = fw + 2f * t.mx
        val h = tilesBottom + t.footS
        val out = Bitmap.createBitmap(w.toInt(), h.toInt(), Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        t.bg(cv, w, h, true)
        for (i in 0 until 4) {
            val y = t.my + i * (fh + t.gap)
            val r = RectF(t.mx, y, t.mx + fw, y + fh)
            t.frame(cv, r, i)
            drawPhoto(cv, l[i], r, t.radius)
            t.over(cv, r, i)
        }
        t.foot(cv, w, tilesBottom, t.footS, true)
        return out
    }

    /** Grid 2x2 dengan rasio asli foto (dibatasi 3:4 .. 4:3). */
    fun grid(l: List<Bitmap>, idx: Int): Bitmap {
        val t = pick(idx)
        val ar = (l[0].width.toFloat() / l[0].height).coerceIn(0.75f, 4f / 3f)
        val cw = if (ar >= 1f) 720f else 600f
        val ch = cw / ar
        val tilesBottom = t.gmy + 2f * ch + t.ggap
        val w = 2f * t.gmx + 2f * cw + t.ggap
        val h = tilesBottom + t.footG
        val out = Bitmap.createBitmap(w.toInt(), h.toInt(), Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        t.bg(cv, w, h, false)
        for (i in 0 until 4) {
            val x = t.gmx + (i % 2) * (cw + t.ggap)
            val y = t.gmy + (i / 2) * (ch + t.ggap)
            val r = RectF(x, y, x + cw, y + ch)
            t.frame(cv, r, i)
            drawPhoto(cv, l[i], r, t.radius)
            t.over(cv, r, i)
        }
        if (t.footG > 0f) t.foot(cv, w, tilesBottom, t.footG, false)
        return out
    }
}
