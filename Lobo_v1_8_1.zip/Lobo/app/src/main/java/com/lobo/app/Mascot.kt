package com.lobo.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.Choreographer
import android.view.View
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Parser path SVG mini: hanya M, L, C, Z (absolut), dipisah spasi. */
internal fun svgPath(d: String): Path {
    val p = Path()
    val t = d.trim().split(' ').filter { it.isNotEmpty() }
    var i = 0
    fun n(): Float = t[i++].toFloat()
    while (i < t.size) {
        when (t[i++]) {
            "M" -> p.moveTo(n(), n())
            "L" -> p.lineTo(n(), n())
            "C" -> p.cubicTo(n(), n(), n(), n(), n(), n())
            "Z" -> p.close()
        }
    }
    return p
}

/** Cermin horizontal path SVG mini (kotak 100 lebar): x -> 100 - x. */
private fun mirrorSvg(d: String): String {
    val sb = StringBuilder()
    var xTurn = true
    for (tok in d.trim().split(' ')) {
        if (tok.isEmpty()) continue
        if (tok.length == 1 && tok[0].isLetter()) {
            xTurn = true
            sb.append(tok)
        } else {
            sb.append(if (xTurn) (100f - tok.toFloat()).toString() else tok)
            xTurn = !xTurn
        }
        sb.append(' ')
    }
    return sb.toString()
}

/**
 * Suasana hati / animasi maskot. Tiap mood punya wajah (mata + mulut), warna aura, gerak badan, dan lencana kecil sendiri.
 * Dipakai oleh [PetView.react] dan galeri di setelan app.
 */
enum class PetMood(val label: String) {
    IDLE("idle"), WORKING("working"), THINKING("thinking"), SEARCHING("searching"), APPROVAL("approval"), QUESTION("question"),
    ERROR("error"), FINISHED("finished"), RATELIMIT("rate limit"), SLEEPING("sleeping"), DIZZY("dizzy"), GREETING("greeting"),
    LOVE("love"), SURPRISED("surprised"), PROUD("proud"), SIGH("sigh"), YAWN("yawn"), ANNOYED("annoyed"),
    UPLOAD("upload"), AMUSED("amusing"), SLAP("slap"), DANCE("dance")
}

/** Aksesoris yang bisa dipakai maskot. */
enum class PetAcc(val id: String, val label: String) {
    NONE("none", "none"), BEANIE("beanie", "beanie"), SANTA("santa", "santa hat"), PARTY("party", "party hat"),
    CROWN("crown", "crown"), WITCH("witch", "witch hat"), SHADES("shades", "sunglasses"), GLASSES("glasses", "glasses"),
    SCARF("scarf", "scarf"), PUMPKIN("pumpkin", "pumpkin"), BOW("bow", "bow")
}

object PetStyle {
    const val AUTO = "auto"

    /** "auto" = ikut musim/hari besar; selain itu id aksesoris (lihat [PetAcc.id]). */
    fun resolve(id: String): PetAcc {
        if (id == AUTO) return seasonal()
        for (a in PetAcc.values()) if (a.id == id) return a
        return PetAcc.NONE
    }

    /** 15 Okt - 1 Nov: topi penyihir. Nov - 14 Des: syal. 15-26 Des: topi santa. 27 Des - 3 Jan: topi pesta. 10-14 Feb: pita. */
    fun seasonal(): PetAcc {
        val c = Calendar.getInstance()
        val m = c.get(Calendar.MONTH)
        val d = c.get(Calendar.DAY_OF_MONTH)
        return when {
            (m == Calendar.OCTOBER && d >= 15) || (m == Calendar.NOVEMBER && d == 1) -> PetAcc.WITCH
            m == Calendar.NOVEMBER || (m == Calendar.DECEMBER && d < 15) -> PetAcc.SCARF
            m == Calendar.DECEMBER && d <= 26 -> PetAcc.SANTA
            m == Calendar.DECEMBER || (m == Calendar.JANUARY && d <= 3) -> PetAcc.PARTY
            m == Calendar.FEBRUARY && d in 10..14 -> PetAcc.BOW
            else -> PetAcc.NONE
        }
    }
}

/** Jenis mata & mulut (file-private supaya fungsi di companion boleh mengembalikannya). */
private enum class PetEyes { OPEN, UP, DOWN, HALF, DASH, SPIRAL, HEART, WIDE, ASYM }

private enum class PetMouth { SMILE, FLAT, FROWN, O, WIDE, WAVY, SMIRK }

/**
 * Bentuk maskot dalam kotak 100x100. Dibuat sekali, dipakai ulang tiap frame.
 * Gaya: kepala bulat gemuk berjumbai, telinga runcing, mata oval menyala, outline neon ungu.
 * Badan (v1.8): gemuk, dada terang, paha, kaki dengan jari, jumbai leher, ekor lebat berujung terang.
 */
private object Wolf {
    // ---------- kepala (tetap)
    private const val EAR = "M 13.5 36 C 13.2 22 16 10 21.2 3.2 C 22.4 1.6 24.4 1.8 26 2.8 C 31 6 36 10.5 40 15.5 L 32 40 Z"
    private const val EAR_IN = "M 23.2 9.2 C 27 12 30.5 15.5 32.5 19 C 28 21 23.5 24 20.4 28.5 C 19.8 22 20.8 15 23.2 9.2 Z"
    private const val HEAD = "M 40 14.5 C 45 13 55 13 60 14.5 C 74 15 85 22 86.3 33 C 89.5 38 91 43 90.6 49 C 89.5 66 73 78.6 50 78.6 C 27 78.6 10.5 66 9.4 49 C 9 43 10.5 38 13.7 33 C 15 22 26 15 40 14.5 Z"
    private const val MASK = "M 50 45 C 46 36 40 30.5 33 31 C 25 31.8 21 39 21 46 C 18 49.5 16.5 53 17.5 57 C 22.5 68.5 36 75 50 75 C 64 75 77.5 68.5 82.5 57 C 83.5 53 82 49.5 79 46 C 79 39 75 31.8 67 31 C 60 30.5 54 36 50 45 Z"
    private const val NOSE = "M 44.5 57 C 46 55.3 54 55.3 55.5 57 C 55.5 60.2 52 63.5 50 63.5 C 48 63.5 44.5 60.2 44.5 57 Z"
    private const val HAPPY = "M 31 49.5 C 32.5 41.5 40.5 41.5 42 49.5"
    private const val SHUT = "M 31 45.5 C 32.5 51.5 40.5 51.5 42 45.5"
    // pipi berbulu (jumbai di sisi kepala)
    private const val CHEEK = "M 12 50 L 5.5 53 L 12.5 57 L 7.5 62 L 15.5 63.5 L 20 68 C 17 62 14.5 56 12 50 Z"
    // ---------- badan baru: gemuk, dada terang, paha, kaki, jumbai leher
    private const val BODY = "M 21 100 C 16 85 22 70 35 65.5 C 42 63.5 58 63.5 65 65.5 C 78 70 84 85 79 100 Z"
    private const val CHEST = "M 50 67 C 43 67 38.5 73 38.5 82 C 38.5 91 43.5 98.5 50 98.5 C 56.5 98.5 61.5 91 61.5 82 C 61.5 73 57 67 50 67 Z"
    private const val HAUNCH = "M 21 100 C 18.5 91 22 82.5 30 81.5 C 36.5 81 40.5 88 40 100 Z"
    private const val LEG = "M 32.5 79 C 32.5 75.5 41 75.5 41 79 L 41.5 96 C 41.7 100 32.1 100 32.3 96 Z"
    private const val TOES = "M 35.1 97 L 35.1 99.4 M 38.3 97 L 38.3 99.4"
    private const val RUFF = "M 22 72 L 27 82 L 32 75.5 L 37.5 85 L 43 78 L 50 87 L 57 78 L 62.5 85 L 68 75.5 L 73 82 L 78 72 C 70 66 30 66 22 72 Z"
    private const val TAIL = "M 66 97 C 80 100 92 91 93.4 75 C 93.9 70 96.4 68.4 98.2 70.2 C 100 83 95 100.6 76 100.8 Z"
    private const val TAIL_TIP = "M 93.4 75 C 93.9 70 96.4 68.4 98.2 70.2 C 99 73.5 98.8 78 97.5 82.5 C 95.5 80.5 94.3 78 93.4 75 Z"
    private const val LOAF = "M 9 99 C 5 80 22 62 50 62 C 78 62 95 80 91 99 Z"
    private const val CURL = "M 93 90 C 98 97 90 101 70 101 C 50 101 28 100 14 96 C 8 94 7 88 13 86 C 30 90 50 91 66 90 C 80 89 88 85 93 90 Z"
    private const val CURL_TIP = "M 13 86 C 7 88 8 94 14 96 C 19 97.4 24 98.4 28 99 C 24 95 20 90 13 86 Z"

    val earL = svgPath(EAR)
    val earR = svgPath(mirrorSvg(EAR))
    val earInL = svgPath(EAR_IN)
    val earInR = svgPath(mirrorSvg(EAR_IN))
    val head = svgPath(HEAD)
    val mask = svgPath(MASK)
    val nose = svgPath(NOSE)
    val happyL = svgPath(HAPPY)
    val happyR = svgPath(mirrorSvg(HAPPY))
    val shutL = svgPath(SHUT)
    val shutR = svgPath(mirrorSvg(SHUT))
    val cheekL = svgPath(CHEEK)
    val cheekR = svgPath(mirrorSvg(CHEEK))

    val body = svgPath(BODY)
    val chest = svgPath(CHEST)
    val haunchL = svgPath(HAUNCH)
    val haunchR = svgPath(mirrorSvg(HAUNCH))
    val legL = svgPath(LEG)
    val legR = svgPath(mirrorSvg(LEG))
    val toesL = svgPath(TOES)
    val toesR = svgPath(mirrorSvg(TOES))
    val ruff = svgPath(RUFF)
    val tail = svgPath(TAIL)
    val tailTip = svgPath(TAIL_TIP)
    val tailBack = svgPath(mirrorSvg(TAIL))
    val tailTipBack = svgPath(mirrorSvg(TAIL_TIP))

    val loaf = svgPath(LOAF)
    val curl = svgPath(CURL)
    val curlTip = svgPath(CURL_TIP)

    // --- wajah
    val dashL = svgPath("M 31 46.5 L 42 46.5")
    val dashR = svgPath("M 58 46.5 L 69 46.5")
    val mSmile = svgPath("M 45.5 65.5 C 46.5 68.5 50 68.5 50 65 C 50 68.5 53.5 68.5 54.5 65.5")
    val mFlat = svgPath("M 46.5 66.8 L 53.5 66.8")
    val mFrown = svgPath("M 45.5 69 C 47 65.5 53 65.5 54.5 69")
    val mWavy = svgPath("M 45.5 66.5 C 47 65 48.5 65 50 66.5 C 51.5 68 53 68 54.5 66.5")
    val mSmirk = svgPath("M 46 66.5 C 49 67.5 52.5 67.5 55.5 64.5")
    val half = Path().apply {
        moveTo(-5.2f, 0f)
        lineTo(5.2f, 0f)
        cubicTo(5.2f, 7.4f, -5.2f, 7.4f, -5.2f, 0f)
        close()
    }
    val spiral = Path().apply {
        moveTo(0f, 0f)
        var a = 0f
        while (a < 18.8f) {
            a += 0.3f
            val r = 0.34f * a
            lineTo(r * cos(a), r * sin(a))
        }
    }

    // --- hiasan
    val heart = svgPath("M 0 6 C -9 0 -6 -7 0 -3 C 6 -7 9 0 0 6 Z")
    val zee = svgPath("M 0 0 L 8 0 L 0 9 L 8 9")
    val spark = svgPath("M 0 -5 C 0.8 -1.2 1.2 -0.8 5 0 C 1.2 0.8 0.8 1.2 0 5 C -0.8 1.2 -1.2 0.8 -5 0 C -1.2 -0.8 -0.8 -1.2 0 -5 Z")
    val drop = svgPath("M 0 -5 C 3 -1 4 1.5 0 4.2 C -4 1.5 -3 -1 0 -5 Z")
}

/**
 * Maskot Lobo di sisi kiri pil notch.
 *
 *  SIT   : duduk menghadap depan, berkedip, melirik, telinga berkedut, ekor goyang, bernapas
 *  WALK  : jalan lenggak-lenggok ke kiri/kanan (badan bergoyang, telinga ikut berayun)
 *  DOZE  : mengantuk, kelopak turun, kepala terangguk-angguk
 *  SLEEP : meringkuk bulat tidur, ekor melingkar, napas pelan, "z z z" melayang
 *  WAKE  : bangun, melar (stretch), lalu duduk lagi
 *
 * Di atas mode itu ada [PetMood] (22 ekspresi/animasi: working, thinking, error, dance, dst) yang dipicu lewat [react],
 * dan aksesoris ([accessory]) yang ikut kepala/badan.
 *
 * Interaksi: [perk] (notifikasi masuk -> kaget & lompat), [poke] (disentuh -> bangun; 2x cepat = slap, 5x = pusing),
 * [pat] (tekan lama -> jatuh cinta, ekor cepat, hati melayang).
 */
class PetView(c: Context) : View(c) {
    private enum class Mode { SIT, WALK, DOZE, SLEEP, WAKE }

    companion object {
        // Atur di sini kalau mau lebih cepat/lambat.
        private const val SLEEP_AFTER_MS = 20_000L // diam selama ini -> mulai mengantuk
        private const val DOZE_MS = 2_600L         // lama mengantuk sebelum benar-benar tidur
        private const val NAP_MS = 75_000L         // lama tidur sebelum bangun sendiri
        private const val WAKE_MS = 750L           // lama animasi bangun
        private const val WALK_DP_PER_SEC = 28f
        private const val STEP_RATE = 11f          // kecepatan ayunan langkah (rad/dtk)
        private const val PENDING_MAX_AGE_MS = 30_000L
        private const val YAWN_MS = 2_400L         // menguap sebelum benar-benar mengantuk
        private const val IDLE_MOOD_MIN_MS = 6_000L // jeda antar ekspresi acak saat idle (+ acak sampai IDLE_MOOD_VAR_MS)
        private const val IDLE_MOOD_VAR_MS = 6_000L
        private const val IDLE_MOOD_FIRST_MS = 4_000L // ekspresi pertama setelah bangun / baru muncul (+ acak)
        private val IDLE_MOODS = arrayOf(PetMood.AMUSED, PetMood.PROUD, PetMood.GREETING, PetMood.SIGH, PetMood.QUESTION)

        private val HEAD = 0xFF3B2E5A.toInt()
        private val HEAD_LIT = 0xFF5A4B85.toInt()
        private val INNER = 0xFF5B4E78.toInt()
        private val BODY = 0xFF2F2549.toInt()
        private val BODY_TOP = 0xFF3A2D5C.toInt()
        private val BODY_BOT = 0xFF261D40.toInt()
        private val CHEST_TOP = 0xFF9486BA.toInt()
        private val CHEST_BOT = 0xFF6B5D90.toInt()
        private val HAUNCH = 0xFF42356A.toInt()
        private val CHEEK = 0xFF4A3D70.toInt()
        private val RUFF = 0xFF6A5C8C.toInt()
        private val PAW = 0xFF5F5282.toInt()
        private val TOE = 0xFF3F3466.toInt()
        private val TIP = 0xFF6A5C8C.toInt()
        private val NOSE = 0xFF241A3A.toInt()
        private val DIM = 0xFF7C5CC4.toInt()       // outline redup untuk badan/ekor/kaki
        private val HALO = 0xFFDDBFFF.toInt()
        private val EYE = 0xFFFFFFFF.toInt()
        private val EYE_GLOW = 0xFF9B5CFF.toInt()
        private val HEART = 0xFFB98BFF.toInt()
        private val HEART_EYE = 0xFFFF86B6.toInt()
        private val ZZZ = 0xFFDDBFFF.toInt()
        private val BADGE_BG = 0xFF14121C.toInt()
        private const val TWO_PI = 2.0 * PI
        private const val PIF = 3.1415927f
        private const val TWO_PIF = 6.2831855f

        /** Warna aura/tint per mood. 0 = tanpa tint. */
        private fun tintOf(m: PetMood): Int = when (m) {
            PetMood.WORKING -> 0xFF4C9BFF.toInt()
            PetMood.THINKING -> 0xFF9B6BFF.toInt()
            PetMood.SEARCHING -> 0xFF6C7CFF.toInt()
            PetMood.APPROVAL -> 0xFFFFB84C.toInt()
            PetMood.QUESTION -> 0xFF38D6E0.toInt()
            PetMood.ERROR -> 0xFFFF5470.toInt()
            PetMood.FINISHED -> 0xFF3DDC97.toInt()
            PetMood.RATELIMIT -> 0xFFFFA070.toInt()
            PetMood.DIZZY -> 0xFFFF6FB5.toInt()
            PetMood.GREETING -> 0xFFFFC9A0.toInt()
            PetMood.LOVE -> 0xFFFF6FA5.toInt()
            PetMood.PROUD -> 0xFFFFD27A.toInt()
            PetMood.ANNOYED -> 0xFFFF7A7A.toInt()
            PetMood.UPLOAD -> 0xFF2BD4A8.toInt()
            PetMood.SLAP -> 0xFFFF7A7A.toInt()
            PetMood.DANCE -> 0xFFE85FA8.toInt()
            else -> 0
        }

        private fun eyesOf(m: PetMood): PetEyes = when (m) {
            PetMood.APPROVAL, PetMood.SURPRISED -> PetEyes.WIDE
            PetMood.QUESTION -> PetEyes.ASYM
            PetMood.ERROR, PetMood.SLAP -> PetEyes.DASH
            PetMood.FINISHED, PetMood.YAWN -> PetEyes.DOWN
            PetMood.RATELIMIT, PetMood.SIGH, PetMood.ANNOYED -> PetEyes.HALF
            PetMood.DIZZY -> PetEyes.SPIRAL
            PetMood.LOVE -> PetEyes.HEART
            PetMood.GREETING, PetMood.PROUD, PetMood.AMUSED, PetMood.DANCE -> PetEyes.UP
            else -> PetEyes.OPEN
        }

        private fun mouthOf(m: PetMood): PetMouth = when (m) {
            PetMood.WORKING, PetMood.SEARCHING, PetMood.APPROVAL, PetMood.RATELIMIT, PetMood.ANNOYED -> PetMouth.FLAT
            PetMood.ERROR -> PetMouth.FROWN
            PetMood.SURPRISED -> PetMouth.O
            PetMood.YAWN, PetMood.UPLOAD, PetMood.DANCE -> PetMouth.WIDE
            PetMood.THINKING, PetMood.QUESTION, PetMood.DIZZY, PetMood.SIGH, PetMood.SLAP -> PetMouth.WAVY
            PetMood.AMUSED -> PetMouth.SMIRK
            else -> PetMouth.SMILE
        }

        private fun blushOf(m: PetMood): Boolean =
            m == PetMood.LOVE || m == PetMood.GREETING || m == PetMood.PROUD || m == PetMood.DANCE ||
                m == PetMood.FINISHED || m == PetMood.SLAP

        private fun joyOf(m: PetMood): Boolean =
            m == PetMood.LOVE || m == PetMood.GREETING || m == PetMood.DANCE || m == PetMood.FINISHED || m == PetMood.PROUD
    }

    /** Aksesoris yang dipakai (di-set oleh NotchView dari setelan, atau galeri). */
    var accessory: PetAcc = PetAcc.NONE
        set(v) {
            if (field == v) return
            field = v
            invalidate()
        }

    /** Mode galeri: tidak jalan/tidur sendiri, mood bertahan sampai diganti. */
    var demo = false

    /** Ukuran maksimum maskot (dp). Galeri memakai ukuran besar. */
    var maxDp = 26

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        textSize = 11f
    }
    private val rect = RectF()
    private val maskShader = LinearGradient(0f, 30f, 0f, 76f, 0xFF4A3F69.toInt(), 0xFF6E6190.toInt(), Shader.TileMode.CLAMP)
    private val headShader = RadialGradient(36f, 28f, 70f, HEAD_LIT, HEAD, Shader.TileMode.CLAMP)
    private val bodyShader = LinearGradient(0f, 64f, 0f, 100f, BODY_TOP, BODY_BOT, Shader.TileMode.CLAMP)
    private val chestShader = LinearGradient(0f, 66f, 0f, 98f, CHEST_TOP, CHEST_BOT, Shader.TileMode.CLAMP)
    private var auraShader: Shader? = null

    private var mode = Mode.SIT
    private var modeAt = 0L
    private var petX = 0f
    private var targetX = 0f
    private var face = 1
    private var phase = 0f
    private var gaze = 0f
    private var gazeTo = 0f
    private var lastT = 0L
    private var lastTouch = 0L
    private var nextAct = 0L
    private var nextBlink = 0L
    private var nextGaze = 0L
    private var blinkAt = -10_000L
    private var nextEar = 0L
    private var earAt = -10_000L
    private var popAt = -10_000L
    private var hopAt = -10_000L
    private var skip = 0
    private var posted = false

    // mood
    private var mood = PetMood.IDLE
    private var moodAt = 0L
    private var moodUntil = 0L
    private var tint = 0xFF9B5CFF.toInt()
    private var tintA = 0f
    private var pending: PetMood? = null
    private var pendingMs = 0L
    private var pendingAt = 0L
    private var combo = 0
    private var comboAt = -10_000L

    /** Ekspresi spontan saat idle (amused, proud, greeting, sigh, question + menguap sebelum tidur). Ikut setelan Mascot reactions. */
    var idleMoods = true
    private var nextIdleMood = 0L
    private var yawnTouch = -1L
    private var lastIdleMood: PetMood? = null

    // hasil animasi mood per frame (diisi [anim])
    private var aDx = 0f
    private var aDy = 0f
    private var aRot = 0f
    private var aSx = 1f
    private var aSy = 1f
    private var hRot = 0f
    private var hDx = 0f
    private var hDy = 0f
    private var lL = 0f
    private var lR = 0f
    private var wavePaw = 0f
    private var tMul = 1f
    private var eDrop = 0f
    private var lookOv = false
    private var lookX = 0f
    private var lookY = 0f
    private var mouthOpen = 0.6f

    /** true = animasi berhenti (mis. saat panel/alert terbuka). Saat lanjut, maskot bangun. */
    var paused = false
        set(v) {
            if (field == v) return
            field = v
            if (!v) {
                poke()
                val p = pending
                if (p != null) {
                    pending = null
                    if (clock() - pendingAt < PENDING_MAX_AGE_MS) react(p, pendingMs)
                }
            }
            sync()
        }

    private val frame: Choreographer.FrameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!posted) return
            val t = frameTimeNanos / 1_000_000L
            val dt = if (lastT == 0L) 16L else (t - lastT).coerceIn(1L, 50L)
            lastT = t
            step(t, dt / 1000f)
            val fast = mode == Mode.WALK || mode == Mode.WAKE || t - popAt < 300L || t - hopAt < 700L ||
                abs(gazeTo - gaze) > 0.02f
            val lively = mood != PetMood.IDLE || tintA > 0.01f
            invalidate()
            // jalan/melompat ~60 fps, mood ~50 fps, duduk/tidur ~25 fps; jeda ini menghindari bangun di tiap vsync (layar 120/144 Hz)
            postDelayed(nextFrame, if (fast) 8L else if (lively) 16L else 36L)
        }
    }

    private val nextFrame: Runnable = Runnable {
        if (posted) Choreographer.getInstance().postFrameCallback(frame)
    }

    private fun clock(): Long = SystemClock.uptimeMillis()

    private fun sprite(): Float = min(height * 0.80f, context.dpf(maxDp))

    private fun range(): Float = max(0f, width - sprite())

    private fun sync() {
        val want = isAttachedToWindow && visibility == VISIBLE && windowVisibility == VISIBLE && !paused
        if (want && !posted) {
            posted = true
            lastT = 0L
            Choreographer.getInstance().postFrameCallback(frame)
        } else if (!want && posted) {
            posted = false
            removeCallbacks(nextFrame)
            Choreographer.getInstance().removeFrameCallback(frame)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val t = clock()
        lastTouch = t
        nextAct = t + 3_000L
        nextBlink = t + 1_500L
        nextEar = t + 5_000L
        nextGaze = t + 2_500L
        nextIdleMood = t + IDLE_MOOD_FIRST_MS + Random.nextLong(IDLE_MOOD_VAR_MS)
        mode = Mode.SIT
        modeAt = t
        sync()
    }

    override fun onDetachedFromWindow() {
        posted = false
        removeCallbacks(nextFrame)
        Choreographer.getInstance().removeFrameCallback(frame)
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        sync()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        sync()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        petX = if (demo) range() / 2f else petX.coerceIn(0f, range())
    }

    // ------------------------------------------------------------ interaksi

    /** Disentuh / tombol ditekan: bangun kalau sedang tidur. Ketuk 2x cepat = slap, 5x cepat = pusing. */
    fun poke() {
        val t = clock()
        lastTouch = t
        if (mode == Mode.SLEEP || mode == Mode.DOZE) {
            enter(Mode.WAKE, t)
            combo = 0
            return
        }
        combo = if (t - comboAt < 450L) combo + 1 else 1
        comboAt = t
        if (combo >= 5) {
            combo = 0
            react(PetMood.DIZZY, 2_800L)
        } else if (combo == 2) {
            react(PetMood.SLAP, 1_000L)
        }
    }

    /** Ada notifikasi/alert: kaget, melompat kecil, bangun kalau tidur. */
    fun perk() {
        val t = clock()
        lastTouch = t
        hopAt = t
        when (mode) {
            Mode.SLEEP, Mode.DOZE -> enter(Mode.WAKE, t)
            Mode.WALK -> enter(Mode.SIT, t)
            else -> {
            }
        }
        nextAct = t + 3_000L
    }

    /** Ditahan lama = dielus: jatuh cinta, ekor cepat, hati melayang. */
    fun pat() {
        hopAt = clock()
        react(PetMood.LOVE, 1_900L)
    }

    /**
     * Mainkan mood [m] selama [ms] (0 = terus sampai diganti). Maskot langsung duduk dan memainkannya.
     * [PetMood.SLEEPING] = meringkuk tidur (hanya sampai disentuh).
     */
    fun react(m: PetMood, ms: Long = 2_600L) {
        val t = clock()
        lastTouch = t
        if (m == PetMood.SLEEPING) {
            setMood(PetMood.IDLE, t, 0L)
            enter(Mode.SLEEP, t)
            return
        }
        if (mode != Mode.SIT) enter(Mode.SIT, t)
        popAt = t
        setMood(m, t, if (ms <= 0L) Long.MAX_VALUE else t + ms)
        nextAct = t + 4_000L
    }

    /** Sama seperti [react], tapi baru dimainkan begitu maskot kembali terlihat (mis. setelah alert/panel menutup). */
    fun reactLater(m: PetMood, ms: Long = 2_800L) {
        pending = m
        pendingMs = ms
        pendingAt = clock()
    }

    /** Musik main (tanpa cover) -> menari. Dilepas begitu musik berhenti. */
    fun setDancing(on: Boolean) {
        if (on) {
            if (mood == PetMood.IDLE) react(PetMood.DANCE, 0L)
        } else if (mood == PetMood.DANCE && moodUntil == Long.MAX_VALUE) {
            setMood(PetMood.IDLE, clock(), 0L)
        }
    }

    /** Ekspresi spontan saat idle. Tidak dihitung sebagai sentuhan, jadi hitung mundur tidur tetap jalan. */
    private fun idleMood(m: PetMood, ms: Long, t: Long) {
        if (m != PetMood.YAWN) popAt = t
        setMood(m, t, t + ms)
        nextAct = t + ms + 1_500L
    }

    private fun setMood(m: PetMood, t: Long, until: Long) {
        mood = m
        moodAt = t
        moodUntil = until
        val c = tintOf(m)
        if (c != 0 && c != tint) {
            tint = c
            auraShader = null
        }
        invalidate()
    }

    // ------------------------------------------------------------ logika

    private fun enter(m: Mode, t: Long) {
        // saat jalan, arah lirik dihitung relatif arah jalan (gambar dicerminkan); ubah ke arah layar
        if ((m == Mode.WALK) != (mode == Mode.WALK)) gaze *= face
        gazeTo = if (m == Mode.WALK) 1f else 0f
        mode = m
        modeAt = t
        popAt = t
    }

    private fun startWalk(t: Long, r: Float) {
        val far = if (petX < r / 2f) r else 0f
        targetX = if (Random.nextFloat() < 0.4f) far else Random.nextFloat() * r
        if (abs(targetX - petX) < sprite() * 0.5f) targetX = far
        face = if (targetX >= petX) 1 else -1
        phase = 0f
        enter(Mode.WALK, t)
    }

    private fun step(t: Long, dt: Float) {
        val r = range()
        if (petX > r) petX = r
        gaze += (gazeTo - gaze) * min(1f, dt * 9f)
        if (mood != PetMood.IDLE && t > moodUntil) {
            setMood(PetMood.IDLE, t, 0L)
            popAt = t
        }
        val goal = if (mood != PetMood.IDLE && tintOf(mood) != 0) 1f else 0f
        tintA += (goal - tintA) * min(1f, dt * 6f)
        when (mode) {
            Mode.SIT -> {
                if (demo) lastTouch = t
                val calm = mood == PetMood.IDLE
                val idleFor = t - lastTouch
                // menguap dulu sebelum mengantuk (sekali per masa diam)
                if (calm && !demo && idleMoods && yawnTouch != lastTouch && idleFor > SLEEP_AFTER_MS - YAWN_MS) {
                    yawnTouch = lastTouch
                    idleMood(PetMood.YAWN, YAWN_MS, t)
                    return
                }
                if (calm && idleFor > SLEEP_AFTER_MS) {
                    enter(Mode.DOZE, t)
                    return
                }
                // ekspresi acak biar idle tidak monoton
                if (calm && !demo && idleMoods && t >= nextIdleMood) {
                    nextIdleMood = t + IDLE_MOOD_MIN_MS + Random.nextLong(IDLE_MOOD_VAR_MS)
                    if (idleFor < SLEEP_AFTER_MS - YAWN_MS - 3_000L) {
                        var m = IDLE_MOODS[Random.nextInt(IDLE_MOODS.size)]
                        if (m == lastIdleMood) m = IDLE_MOODS[(IDLE_MOODS.indexOf(m) + 1) % IDLE_MOODS.size]
                        lastIdleMood = m
                        idleMood(m, 2_600L, t)
                        return
                    }
                }
                if (calm && !demo && t >= nextAct) {
                    nextAct = t + 3_500L + Random.nextLong(6_500L)
                    if (r > sprite() * 0.6f && Random.nextFloat() < 0.75f) startWalk(t, r)
                }
                if (t >= nextBlink) {
                    blinkAt = t
                    nextBlink = t + 2_200L + Random.nextLong(3_800L)
                }
                if (t >= nextEar) {
                    earAt = t
                    nextEar = t + 6_000L + Random.nextLong(7_000L)
                }
                if (t >= nextGaze) {
                    gazeTo = when (Random.nextInt(4)) {
                        0 -> -0.8f
                        1 -> 0.8f
                        else -> 0f
                    }
                    nextGaze = t + 1_600L + Random.nextLong(3_200L)
                }
            }
            Mode.WALK -> {
                val stepPx = context.dpf(WALK_DP_PER_SEC) * dt
                val dx = targetX - petX
                if (abs(dx) <= stepPx) {
                    petX = targetX
                    enter(Mode.SIT, t)
                    nextAct = t + 2_500L + Random.nextLong(5_000L)
                } else {
                    petX += if (dx > 0f) stepPx else -stepPx
                    phase += dt * STEP_RATE
                }
            }
            Mode.DOZE -> if (t - modeAt > DOZE_MS) enter(Mode.SLEEP, t)
            Mode.SLEEP -> if (!demo && t - modeAt > NAP_MS) enter(Mode.WAKE, t)
            Mode.WAKE -> if (t - modeAt > WAKE_MS) {
                enter(Mode.SIT, t)
                lastTouch = t
                nextAct = t + 2_500L + Random.nextLong(3_000L)
                nextIdleMood = t + IDLE_MOOD_FIRST_MS + Random.nextLong(IDLE_MOOD_VAR_MS)
            }
        }
    }

    // ------------------------------------------------------------ animasi mood

    /** Hitung gerak badan/kepala/kaki untuk mood sekarang. [active] false = semua netral (mis. saat jalan/tidur). */
    private fun anim(t: Long, active: Boolean) {
        aDx = 0f
        aDy = 0f
        aRot = 0f
        aSx = 1f
        aSy = 1f
        hRot = 0f
        hDx = 0f
        hDy = 0f
        lL = 0f
        lR = 0f
        wavePaw = 0f
        tMul = 1f
        eDrop = 0f
        lookOv = false
        lookX = 0f
        lookY = 0f
        mouthOpen = 0.6f
        if (!active || mood == PetMood.IDLE) return
        val mt = (t - moodAt) / 1000f
        when (mood) {
            PetMood.WORKING -> {
                val s = sin(mt * 16f)
                lL = max(0f, s) * 4.5f
                lR = max(0f, -s) * 4.5f
                hDy = 1.8f
                hRot = 1.6f * sin(mt * 2.4f)
                aSy = 1f - 0.012f * abs(s)
                lookOv = true
                lookY = 1.8f
            }
            PetMood.THINKING -> {
                hRot = 9f + 2f * sin(mt * 1.3f)
                hDx = -1.5f
                aRot = 1.5f
                lookOv = true
                lookX = 0.7f
                lookY = -2.6f
            }
            PetMood.SEARCHING -> {
                hRot = 6f * sin(mt * 2.1f)
                hDx = 2f * sin(mt * 2.1f)
                lookOv = true
                lookX = sin(mt * 3.2f)
            }
            PetMood.APPROVAL -> {
                aSy = 1f + 0.025f * sin(mt * 7f)
                hDy = -1f
            }
            PetMood.QUESTION -> {
                hRot = 13f + 4f * sin(mt * 3f)
                lookOv = true
                lookX = -0.5f
            }
            PetMood.ERROR -> {
                val amp = 2.4f * max(0f, 1f - mt * 0.8f) + 0.5f
                aDx = amp * sin(mt * 38f)
                hRot = amp * 1.2f * sin(mt * 38f + 1f)
                eDrop = 12f
            }
            PetMood.FINISHED -> {
                val e = exp(-mt * 1.5f)
                aDy = -15f * max(0f, sin(mt * 7.5f)) * e
                hRot = 4f * sin(mt * 2f)
            }
            PetMood.RATELIMIT -> {
                hDy = 3f + 0.8f * sin(mt * 1.6f)
                hRot = -5f
                aSy = 0.97f
                eDrop = 14f
                lookOv = true
                lookY = 1.8f
            }
            PetMood.DIZZY -> {
                val w = mt * 5.2f
                hRot = 11f * sin(w)
                hDx = 2.6f * sin(w + 1.57f)
                aRot = 3.5f * sin(w)
            }
            PetMood.GREETING -> {
                val hp = min(1f, mt / 0.5f)
                aDy = if (mt < 0.5f) -10f * sin(hp * PIF) else 0f
                wavePaw = 1f
                hRot = 4f * sin(mt * 4f)
            }
            PetMood.LOVE -> {
                aDy = -2.2f * abs(sin(mt * 5f))
                hRot = 5f * sin(mt * 3f)
            }
            PetMood.SURPRISED -> {
                val p = min(1f, mt / 0.35f)
                aDy = -15f * sin(p * PIF)
                aSx = 1f - 0.05f * sin(p * PIF)
                aSy = 1f + 0.08f * sin(p * PIF)
                eDrop = -6f
            }
            PetMood.PROUD -> {
                aSx = 1.03f
                aSy = 1.045f
                hDy = -1.8f
                hRot = -3f
            }
            PetMood.SIGH -> {
                val p = min(1f, mt / 0.9f)
                hDy = 3f * sin(p * PIF / 2f)
                aSy = 1f - 0.03f * sin(p * PIF / 2f)
                hRot = -3f * p
                eDrop = 14f * p
                lookOv = true
                lookY = 1.8f
            }
            PetMood.YAWN -> {
                val p = (mt / 2.4f).coerceIn(0f, 1f)
                val s = sin(p * PIF)
                hRot = -6f * s
                aSy = 1f + 0.07f * s
                aSx = 1f - 0.03f * s
                hDy = -2f * s
                mouthOpen = s
            }
            PetMood.ANNOYED -> {
                hRot = -3f
                hDy = 1f
                tMul = if (sin(mt * 2.2f) > 0.6f) 3f else 0.6f
                eDrop = 10f
            }
            PetMood.UPLOAD -> {
                val c = (mt * 0.9f) % 1f
                val chew = if (c in 0.62f..0.9f) sin((c - 0.62f) / 0.28f * PIF) else 0f
                aSy = 1f - 0.08f * chew
                aSx = 1f + 0.05f * chew
                hDy = 0.8f * chew
                lookOv = true
                lookY = -2.8f
                mouthOpen = 0.9f - 0.5f * chew
            }
            PetMood.AMUSED -> {
                hRot = 6f + 2f * sin(mt * 1.5f)
                hDx = 1f
            }
            PetMood.SLAP -> {
                val p = min(1f, mt / 0.9f)
                val d = exp(-p * 4.5f)
                hRot = -26f * d * cos(p * 15f)
                aDx = -3.5f * d * cos(p * 15f)
                aSx = 1f + 0.08f * d
                aSy = 1f - 0.08f * d
            }
            PetMood.DANCE -> {
                val b = sin(mt * 12.566f)
                aRot = 7f * b
                aDx = 3f * b
                aDy = -3.5f * abs(b)
                hRot = -9f * b
                lL = max(0f, b) * 5f
                lR = max(0f, -b) * 5f
                tMul = 1.2f
                eDrop = 8f * b
                mouthOpen = 0.5f
            }
            else -> {
            }
        }
    }

    // ------------------------------------------------------------ gambar

    private fun wave(t: Long, hz: Double): Float = sin(t / 1000.0 * TWO_PI * hz).toFloat()

    private fun mix(a: Int, b: Int, f: Float): Int {
        val g = f.coerceIn(0f, 1f)
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * g).toInt()
        val gg = (Color.green(a) + (Color.green(b) - Color.green(a)) * g).toInt()
        val bb = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * g).toInt()
        return Color.rgb(r, gg, bb)
    }

    private fun dimCol(): Int = if (tintA > 0.02f) mix(DIM, tint, tintA * 0.8f) else DIM

    private fun glowCol(a: Int, k: Float): Int {
        val c = if (tintA > 0.02f) mix(EYE_GLOW, tint, tintA * 0.9f) else EYE_GLOW
        return Color.argb((a * k).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))
    }

    /** Outline tipis yang tegas, tanpa pendar (hanya setengah luarnya yang terlihat karena isi digambar menimpa). */
    private fun halo(cv: Canvas, p: Path, k: Float) {
        line.shader = null
        line.strokeWidth = 4f
        val base = if (tintA > 0.02f) mix(HALO, tint, tintA * 0.85f) else HALO
        line.color = Color.argb((110 + 145 * k).toInt().coerceIn(0, 255), Color.red(base), Color.green(base), Color.blue(base))
        cv.drawPath(p, line)
    }

    private fun outline(cv: Canvas, p: Path, w: Float) {
        line.shader = null
        line.strokeWidth = w
        line.color = dimCol()
        cv.drawPath(p, line)
    }

    /** Ekor: outline ungu redup + isi. */
    private fun part(cv: Canvas, p: Path, color: Int) {
        outline(cv, p, 3.6f)
        solid(cv, p, color)
    }

    private fun solid(cv: Canvas, p: Path, color: Int) {
        fill.shader = null
        fill.color = color
        cv.drawPath(p, fill)
    }

    private fun grad(cv: Canvas, p: Path, sh: Shader) {
        fill.shader = sh
        fill.color = Color.WHITE
        cv.drawPath(p, fill)
        fill.shader = null
    }

    /** Lapisan warna tint mood di atas bentuk (tanpa alokasi). */
    private fun wash(cv: Canvas, p: Path, a: Float) {
        if (tintA < 0.02f) return
        fill.shader = null
        fill.color = Color.argb((255f * a * tintA).toInt().coerceIn(0, 255), Color.red(tint), Color.green(tint), Color.blue(tint))
        cv.drawPath(p, fill)
    }

    private fun circle(cv: Canvas, x: Float, y: Float, r: Float, color: Int) {
        fill.shader = null
        fill.color = color
        cv.drawCircle(x, y, r, fill)
    }

    private fun oval(cv: Canvas, cx: Float, cy: Float, rx: Float, ry: Float) {
        rect.set(cx - rx, cy - ry, cx + rx, cy + ry)
        cv.drawOval(rect, fill)
    }

    private fun stroke(cv: Canvas, p: Path, color: Int, w: Float) {
        line.shader = null
        line.strokeWidth = w
        line.color = color
        cv.drawPath(p, line)
    }

    private fun aura(cv: Canvas) {
        if (tintA < 0.02f) return
        var sh = auraShader
        if (sh == null) {
            sh = RadialGradient(50f, 58f, 56f, tint, tint and 0x00FFFFFF, Shader.TileMode.CLAMP)
            auraShader = sh
        }
        fill.color = Color.WHITE
        fill.alpha = (120f * tintA).toInt().coerceIn(0, 255)
        fill.shader = sh
        cv.drawCircle(50f, 58f, 56f, fill)
        fill.shader = null
        fill.alpha = 255
    }

    private fun leg(cv: Canvas, right: Boolean, dx: Float, lift: Float, rot: Float) {
        cv.save()
        cv.translate(dx, -lift)
        if (rot != 0f) cv.rotate(rot, if (right) 63.5f else 36.5f, 78f)
        outline(cv, if (right) Wolf.legR else Wolf.legL, 3.0f)
        solid(cv, if (right) Wolf.legR else Wolf.legL, PAW)
        stroke(cv, if (right) Wolf.toesR else Wolf.toesL, TOE, 1.2f)
        cv.restore()
    }

    /** Badan gemuk: paha, dada terang, dua kaki depan berjari, jumbai leher, dan syal kalau dipakai. */
    private fun drawBody(cv: Canvas, br: Float, dxL: Float, dxR: Float, liftL: Float, liftR: Float, rotR: Float) {
        cv.save()
        cv.scale(1f, 1f + 0.014f * br, 50f, 99f)
        outline(cv, Wolf.body, 3.6f)
        outline(cv, Wolf.haunchL, 3f)
        outline(cv, Wolf.haunchR, 3f)
        grad(cv, Wolf.body, bodyShader)
        wash(cv, Wolf.body, 0.22f)
        solid(cv, Wolf.haunchL, HAUNCH)
        solid(cv, Wolf.haunchR, HAUNCH)
        grad(cv, Wolf.chest, chestShader)
        wash(cv, Wolf.chest, 0.16f)
        cv.restore()

        leg(cv, false, dxL, liftL, 0f)
        leg(cv, true, dxR, liftR, rotR)

        cv.save()
        cv.scale(1f, 1f + 0.014f * br, 50f, 99f)
        solid(cv, Wolf.ruff, RUFF)
        if (accessory == PetAcc.SCARF) AccArt.drawScarfBody(cv)
        cv.restore()
    }

    private fun eyeOval(cv: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, k: Float) {
        fill.shader = null
        fill.color = glowCol(0x30, k)
        oval(cv, cx, cy, rx + 3.6f, ry + 3.6f)
        fill.color = glowCol(0x66, k)
        oval(cv, cx, cy, rx + 1.8f, ry + 1.8f)
        fill.color = EYE
        oval(cv, cx, cy, rx, ry)
    }

    private fun halfEye(cv: Canvas, cx: Float, cy: Float, k: Float) {
        cv.save()
        cv.translate(cx, cy - 2.5f)
        fill.shader = null
        fill.color = glowCol(0x30, k)
        cv.save()
        cv.scale(1.5f, 1.5f)
        cv.drawPath(Wolf.half, fill)
        cv.restore()
        fill.color = glowCol(0x66, k)
        cv.save()
        cv.scale(1.25f, 1.25f)
        cv.drawPath(Wolf.half, fill)
        cv.restore()
        fill.color = EYE
        cv.drawPath(Wolf.half, fill)
        cv.restore()
    }

    private fun spiralEye(cv: Canvas, cx: Float, cy: Float, rot: Float, k: Float) {
        cv.save()
        cv.translate(cx, cy)
        cv.rotate(rot)
        line.shader = null
        line.strokeWidth = 5.6f
        line.color = glowCol(0x44, k)
        cv.drawPath(Wolf.spiral, line)
        line.strokeWidth = 2f
        line.color = EYE
        cv.drawPath(Wolf.spiral, line)
        cv.restore()
    }

    private fun heartEye(cv: Canvas, cx: Float, cy: Float, sc: Float) {
        cv.save()
        cv.translate(cx, cy + 0.5f)
        cv.scale(sc, sc)
        fill.shader = null
        fill.color = Color.argb(70, 255, 134, 182)
        cv.save()
        cv.scale(1.35f, 1.35f)
        cv.drawPath(Wolf.heart, fill)
        cv.restore()
        fill.color = HEART_EYE
        cv.drawPath(Wolf.heart, fill)
        cv.restore()
    }

    private fun arcs(cv: Canvas, l: Path, r: Path, dx: Float, dy: Float, k: Float) {
        cv.save()
        cv.translate(dx, dy)
        line.shader = null
        line.strokeWidth = 7f
        line.color = glowCol(0x55, k)
        cv.drawPath(l, line)
        cv.drawPath(r, line)
        line.strokeWidth = 3.2f
        line.color = EYE
        cv.drawPath(l, line)
        cv.drawPath(r, line)
        cv.restore()
    }

    private fun mouth(cv: Canvas) {
        when (mouthOf(mood)) {
            PetMouth.SMILE -> stroke(cv, Wolf.mSmile, NOSE, 1.6f)
            PetMouth.FLAT -> stroke(cv, Wolf.mFlat, NOSE, 1.7f)
            PetMouth.FROWN -> stroke(cv, Wolf.mFrown, NOSE, 1.7f)
            PetMouth.WAVY -> stroke(cv, Wolf.mWavy, NOSE, 1.6f)
            PetMouth.SMIRK -> stroke(cv, Wolf.mSmirk, NOSE, 1.7f)
            PetMouth.O -> {
                fill.shader = null
                fill.color = NOSE
                oval(cv, 50f, 67.6f, 2.5f, 3.1f)
            }
            PetMouth.WIDE -> {
                val oy = 4.6f * mouthOpen.coerceIn(0.15f, 1f)
                fill.shader = null
                fill.color = NOSE
                oval(cv, 50f, 66f + oy, 4.6f, oy)
                fill.color = 0xFFFF86A0.toInt()
                oval(cv, 50f, 66f + oy * 1.55f, 2.7f, oy * 0.45f)
            }
        }
    }

    /** Wajah: topeng terang, mata menyala, hidung, mulut. [look] -1..1 menggeser fitur wajah (efek menoleh). */
    private fun face(cv: Canvas, look: Float, ly: Float, open: Float, k: Float) {
        cv.save()
        cv.translate(look * 3f, 0f)
        fill.shader = maskShader
        fill.color = Color.WHITE
        cv.drawPath(Wolf.mask, fill)
        fill.shader = null
        wash(cv, Wolf.mask, 0.18f)
        cv.restore()

        val ex = look * 4.4f
        val ey = 46.5f + ly
        if (blushOf(mood)) {
            fill.shader = null
            fill.color = Color.argb(85, 255, 143, 184)
            oval(cv, 26.5f + ex * 0.5f, 57f, 4.8f, 2.7f)
            oval(cv, 73.5f + ex * 0.5f, 57f, 4.8f, 2.7f)
        }
        val t = clock()
        when (eyesOf(mood)) {
            PetEyes.OPEN, PetEyes.WIDE, PetEyes.ASYM -> {
                if (open < 0.22f) {
                    arcs(cv, Wolf.shutL, Wolf.shutR, ex, ly, k)
                } else {
                    val isWorking = mood == PetMood.WORKING
                    val ry = (if (isWorking) 6.2f else 7.4f) * open
                    when (eyesOf(mood)) {
                        PetEyes.WIDE -> {
                            eyeOval(cv, 36.5f + ex, ey, 5.8f, 8.8f * open, k)
                            eyeOval(cv, 63.5f + ex, ey, 5.8f, 8.8f * open, k)
                        }
                        PetEyes.ASYM -> {
                            eyeOval(cv, 36.5f + ex, ey, 5.4f, 8.4f * open, k)
                            eyeOval(cv, 63.5f + ex, ey + 1.2f, 4.2f, 5.6f * open, k)
                        }
                        else -> {
                            eyeOval(cv, 36.5f + ex, ey, 5f, ry, k)
                            eyeOval(cv, 63.5f + ex, ey, 5f, ry, k)
                        }
                    }
                }
            }
            PetEyes.UP -> arcs(cv, Wolf.happyL, Wolf.happyR, ex, ly, k)
            PetEyes.DOWN -> arcs(cv, Wolf.shutL, Wolf.shutR, ex, ly, k)
            PetEyes.DASH -> arcs(cv, Wolf.dashL, Wolf.dashR, ex, ly, k)
            PetEyes.HALF -> {
                halfEye(cv, 36.5f + ex, ey, k)
                halfEye(cv, 63.5f + ex, ey, k)
                if (mood == PetMood.ANNOYED) {
                    line.shader = null
                    line.strokeWidth = 2.6f
                    line.color = 0xCCFFFFFF.toInt()
                    cv.drawLine(30.5f + ex, 38.5f, 42.5f + ex, 42.5f, line)
                    cv.drawLine(69.5f + ex, 38.5f, 57.5f + ex, 42.5f, line)
                }
            }
            PetEyes.SPIRAL -> {
                val rot = (t % 1400L) / 1400f * 360f
                spiralEye(cv, 36.5f + ex, ey, rot, k)
                spiralEye(cv, 63.5f + ex, ey, -rot, k)
            }
            PetEyes.HEART -> {
                val sc = 0.82f + 0.07f * sin(t * 0.012f)
                heartEye(cv, 36.5f + ex, ey, sc)
                heartEye(cv, 63.5f + ex, ey, sc)
            }
        }

        cv.save()
        cv.translate(look * 5f, 0f)
        solid(cv, Wolf.nose, NOSE)
        mouth(cv)
        cv.restore()
    }

    private fun hatEars(): Boolean = when (accessory) {
        PetAcc.BEANIE, PetAcc.SANTA, PetAcc.PARTY, PetAcc.WITCH, PetAcc.CROWN, PetAcc.PUMPKIN -> true
        else -> false
    }

    /** Kepala utuh: telinga (bisa digerakkan sendiri), muka, aksesoris. Sudut telinga dalam derajat. */
    private fun head(cv: Canvas, look: Float, ly: Float, earA: Float, earB: Float, open: Float, k: Float) {
        val spread = if (hatEars()) 8f else 0f
        val a = earA - spread - eDrop
        val b = earB + spread + eDrop
        // 1) semua outline dulu, 2) isi menimpa -> outline hanya muncul di siluet luar
        cv.save()
        cv.rotate(a, 26f, 26f)
        halo(cv, Wolf.earL, k)
        cv.restore()
        cv.save()
        cv.rotate(b, 74f, 26f)
        halo(cv, Wolf.earR, k)
        cv.restore()
        halo(cv, Wolf.head, k)

        cv.save()
        cv.rotate(a, 26f, 26f)
        solid(cv, Wolf.earL, HEAD)
        wash(cv, Wolf.earL, 0.3f)
        cv.restore()
        cv.save()
        cv.rotate(b, 74f, 26f)
        solid(cv, Wolf.earR, HEAD)
        wash(cv, Wolf.earR, 0.3f)
        cv.restore()
        grad(cv, Wolf.head, headShader)
        wash(cv, Wolf.head, 0.3f)

        cv.save()
        cv.rotate(a, 26f, 26f)
        solid(cv, Wolf.earInL, INNER)
        cv.restore()
        cv.save()
        cv.rotate(b, 74f, 26f)
        solid(cv, Wolf.earInR, INNER)
        cv.restore()

        solid(cv, Wolf.cheekL, CHEEK)
        solid(cv, Wolf.cheekR, CHEEK)
        face(cv, look, ly, open, k)
        drawAccessory(cv)
    }

    /** Aksesoris kepala bergaya semi-3D: lihat [AccArt]. */
    private fun drawAccessory(cv: Canvas) {
        if (accessory != PetAcc.NONE && accessory != PetAcc.SCARF) AccArt.drawHat(cv, accessory)
    }

    // ------------------------------------------------------------ lencana & hiasan mood

    private fun spark(cv: Canvas, x: Float, y: Float, s: Float, color: Int, a: Int) {
        if (s <= 0.02f || a <= 4) return
        cv.save()
        cv.translate(x, y)
        cv.scale(s, s)
        fill.shader = null
        fill.color = Color.argb(a.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
        cv.drawPath(Wolf.spark, fill)
        cv.restore()
    }

    private fun note(cv: Canvas, x: Float, y: Float, s: Float, a: Int) {
        if (a <= 4) return
        val col = Color.argb(a.coerceIn(0, 255), 255, 143, 224)
        cv.save()
        cv.translate(x, y)
        cv.scale(s, s)
        fill.shader = null
        fill.color = col
        rect.set(-2.6f, -1.8f, 2.6f, 1.8f)
        cv.save()
        cv.rotate(-20f)
        cv.drawOval(rect, fill)
        cv.restore()
        line.shader = null
        line.strokeWidth = 1.5f
        line.color = col
        cv.drawLine(2.2f, -0.5f, 2.2f, -10f, line)
        cv.drawLine(2.2f, -10f, 6f, -7.5f, line)
        cv.restore()
    }

    private fun bubble(cv: Canvas, t: Long, periodMs: Float) {
        rect.set(2f, 3f, 22f, 15.5f)
        fill.shader = null
        fill.color = BADGE_BG
        cv.drawRoundRect(rect, 6.3f, 6.3f, fill)
        line.shader = null
        line.strokeWidth = 1.8f
        line.color = tint
        cv.drawRoundRect(rect, 6.3f, 6.3f, line)
        for (i in 0 until 3) {
            val ph = ((t / periodMs) + i * 0.33f) % 1f
            val a = 80 + (175f * (0.5f + 0.5f * sin(ph * TWO_PIF))).toInt()
            fill.color = Color.argb(a.coerceIn(0, 255), 255, 255, 255)
            cv.drawCircle(7.6f + i * 4.4f, 9.2f, 1.6f, fill)
        }
    }

    private fun roundBadge(cv: Canvas) {
        fill.shader = null
        fill.color = BADGE_BG
        cv.drawCircle(11f, 11f, 8.2f, fill)
        line.shader = null
        line.strokeWidth = 1.8f
        line.color = tint
        cv.drawCircle(11f, 11f, 8.2f, line)
    }

    private fun dotBadge(cv: Canvas, t: Long) {
        val pulse = 0.5f + 0.5f * sin(t * 0.008f)
        circle(cv, 10f, 10f, 6.6f + 1.2f * pulse, BADGE_BG)
        circle(cv, 10f, 10f, 4.2f + 0.7f * pulse, tint)
    }

    private fun badge(cv: Canvas, t: Long) {
        if (mood == PetMood.IDLE) return
        val mt = (t - moodAt) / 1000f
        when (mood) {
            PetMood.WORKING -> bubble(cv, t, 700f)
            PetMood.THINKING -> bubble(cv, t, 1500f)
            PetMood.SEARCHING -> {
                roundBadge(cv)
                cv.save()
                cv.translate(1.2f * sin(mt * 3f), 0f)
                line.shader = null
                line.strokeWidth = 1.7f
                line.color = EYE
                cv.drawCircle(10f, 10f, 3.2f, line)
                cv.drawLine(12.4f, 12.4f, 15.2f, 15.2f, line)
                cv.restore()
            }
            PetMood.APPROVAL, PetMood.ERROR -> dotBadge(cv, t)
            PetMood.QUESTION -> {
                roundBadge(cv)
                txt.color = EYE
                cv.drawText("?", 11f, 14.9f, txt)
            }
            PetMood.RATELIMIT -> {
                val q = (mt * 0.7f) % 1f
                cv.save()
                cv.translate(86f, 26f + q * 14f)
                fill.shader = null
                fill.color = Color.argb(((1f - q) * 255f).toInt().coerceIn(0, 255), 140, 205, 255)
                cv.drawPath(Wolf.drop, fill)
                cv.restore()
            }
            PetMood.FINISHED -> {
                for (i in 0 until 4) {
                    val q = ((t / 900f) + i * 0.27f) % 1f
                    val a = sin(q * PIF)
                    val x = if (i % 2 == 0) 10f + i * 4f else 90f - i * 3f
                    val y = if (i < 2) 12f + i * 18f else 22f + i * 10f
                    spark(cv, x, y, 0.5f + 1.0f * a, 0xFFE9FFF4.toInt(), (a * 255f).toInt())
                }
            }
            PetMood.GREETING -> {
                for (i in 0 until 6) {
                    val ang = t / 900f + i * (TWO_PIF / 6f)
                    val x = 50f + 54f * cos(ang)
                    val y = 46f + 36f * sin(ang)
                    val a = 0.5f + 0.5f * sin(t / 300f + i)
                    spark(cv, x, y, 0.55f + 0.35f * a, 0xFFFFE6C4.toInt(), (140f + 100f * a).toInt())
                }
            }
            PetMood.LOVE -> drawHearts(cv, t)
            PetMood.DIZZY -> {
                for (i in 0 until 3) {
                    val ang = t / 420f + i * (TWO_PIF / 3f)
                    val x = 50f + 28f * cos(ang)
                    val y = 10f + 5f * sin(ang)
                    val front = 0.7f + 0.3f * sin(ang)
                    spark(cv, x, y, 0.85f * front, 0xFFFFE27A.toInt(), (190f * front + 60f).toInt())
                }
            }
            PetMood.SURPRISED -> {
                val a = (1f - (mt / 1.0f)).coerceIn(0f, 1f)
                line.shader = null
                line.strokeWidth = 2.4f
                line.color = Color.argb((a * 255f).toInt(), 255, 255, 255)
                cv.drawLine(38f, 8f, 34f, 1f, line)
                cv.drawLine(50f, 5f, 50f, -3f, line)
                cv.drawLine(62f, 8f, 66f, 1f, line)
            }
            PetMood.PROUD -> {
                val a = 0.5f + 0.5f * sin(t / 260f)
                spark(cv, 82f, 14f, 0.8f + 0.7f * a, 0xFFFFE9A8.toInt(), (150f + 100f * a).toInt())
            }
            PetMood.SIGH -> {
                for (i in 0 until 3) {
                    val q = ((mt * 0.6f) + i * 0.3f) % 1f
                    val a = (1f - q) * 0.7f
                    circle(cv, 60f + q * 14f, 69f + q * 6f, 2f + q * 4f, Color.argb((a * 255f).toInt().coerceIn(0, 255), 235, 235, 245))
                }
            }
            PetMood.ANNOYED -> {
                val a = 0.6f + 0.4f * sin(mt * 9f)
                spark(cv, 82f, 20f, 1.0f + 0.25f * a, 0xFFFF5A5A.toInt(), 255)
            }
            PetMood.UPLOAD -> drawDoc(cv, mt)
            PetMood.SLAP -> {
                val d = exp(-(mt / 0.9f) * 3f)
                spark(cv, 20f, 52f, 1.6f * d, 0xFFFF5A5A.toInt(), (255f * d).toInt())
                spark(cv, 10f, 38f, 0.9f * d, 0xFFFFE27A.toInt(), (255f * d).toInt())
                spark(cv, 90f, 30f, 0.8f * d, 0xFFFFE27A.toInt(), (255f * d).toInt())
            }
            PetMood.DANCE -> {
                for (i in 0 until 2) {
                    val q = ((t / 1500f) + i * 0.5f) % 1f
                    val x = if (i == 0) 6f - q * 6f else 94f + q * 6f
                    note(cv, x, 42f - q * 40f, 0.9f, (sin(q * PIF) * 255f).toInt())
                }
            }
            else -> {
            }
        }
    }

    /** Dokumen terbang dari pojok kanan-atas menuju mulut, mengecil sambil masuk. */
    private fun drawDoc(cv: Canvas, mt: Float) {
        val c = (mt * 0.9f) % 1f
        if (c > 0.62f) return
        val p = c / 0.62f
        val x = 86f + (52f - 86f) * p
        val y = -2f + (64f - -2f) * p - 10f * sin(p * PIF)
        cv.save()
        cv.translate(x, y)
        cv.rotate(14f - 28f * p)
        val sc = 1f - 0.7f * p
        cv.scale(sc, sc)
        rect.set(-4.2f, -5.4f, 4.2f, 5.4f)
        fill.shader = null
        fill.color = 0xFFFAFAFF.toInt()
        cv.drawRoundRect(rect, 1.4f, 1.4f, fill)
        line.shader = null
        line.strokeWidth = 1f
        line.color = 0xFF9A93B8.toInt()
        cv.drawLine(-2.3f, -2.2f, 2.3f, -2.2f, line)
        cv.drawLine(-2.3f, 0.4f, 2.3f, 0.4f, line)
        cv.drawLine(-2.3f, 3f, 0.6f, 3f, line)
        cv.restore()
    }

    override fun onDraw(cv: Canvas) {
        if (width <= 0 || height <= 0) return
        val t = clock()
        val s = sprite()
        val u = s / 100f
        val top = (height - s) / 2f + s * 0.04f
        anim(t, mode == Mode.SIT)

        // "pop" kecil tiap ganti pose + lompat + melar saat bangun
        val pp = ((t - popAt) / 240f).coerceIn(0f, 1f)
        val k = (1f - pp) * (1f - pp)
        var sx = 1f + 0.10f * k
        var sy = 1f - 0.14f * k
        var lid = 0f
        if (mode == Mode.WAKE) {
            val wp = ((t - modeAt).toFloat() / WAKE_MS).coerceIn(0f, 1f)
            val st = sin(wp * PI.toFloat())
            sx *= 1f + 0.10f * st
            sy *= 1f - 0.07f * st
            lid = 1f - wp
        }
        val hp = ((t - hopAt) / 650f).coerceIn(0f, 1f)
        val hop = if (hp < 1f) 4f * hp * (1f - hp) * 14f else 0f
        // topi tinggi: kecilkan sedikit supaya ujungnya tidak terpotong tepi atas
        val fit = if (accessory == PetAcc.WITCH || accessory == PetAcc.PARTY) 0.9f else 1f

        cv.save()
        cv.translate(petX, top)
        cv.scale(u, u)
        if (fit != 1f) cv.scale(fit, fit, 50f, 100f)
        cv.translate(aDx, -hop + aDy)
        cv.rotate(aRot, 50f, 99f)
        cv.scale(sx * aSx, sy * aSy, 50f, 100f)
        when (mode) {
            Mode.SIT, Mode.WAKE -> drawSit(cv, t, 0f, lid)
            Mode.DOZE -> {
                val d = ((t - modeAt).toFloat() / DOZE_MS).coerceIn(0f, 1f)
                drawSit(cv, t, d, d)
                if (d > 0.45f) drawZ(cv, t, 78f, 20f, 1)
            }
            Mode.WALK -> {
                if (face < 0) cv.scale(-1f, 1f, 50f, 50f)
                drawWalk(cv, t)
            }
            Mode.SLEEP -> {
                if (face < 0) cv.scale(-1f, 1f, 50f, 50f)
                drawSleep(cv, t)
            }
        }
        cv.restore()
    }

    private fun blinkAmount(t: Long): Float {
        val bp = (t - blinkAt) / 180f
        return if (bp in 0f..1f) sin(bp * PI.toFloat()) else 0f
    }

    /** [nod] 0..1 kepala terangguk; [lid] 0..1 kelopak turun (mengantuk). */
    private fun drawSit(cv: Canvas, t: Long, nod: Float, lid: Float) {
        val joy = joyOf(mood)
        val br = wave(t, 1.0 / 3.2)
        val wag = wave(t, if (joy) 4.5 else 1.1) * (if (joy) 20f else 8f) * tMul
        val k = 0.92f + 0.08f * wave(t, 0.4)

        aura(cv)

        // ekor
        cv.save()
        cv.rotate(wag, 70f, 97f)
        part(cv, Wolf.tail, BODY)
        wash(cv, Wolf.tail, 0.2f)
        solid(cv, Wolf.tailTip, TIP)
        cv.restore()

        // badan + kaki depan (kaki kanan melambai waktu menyapa)
        val rotR = if (wavePaw > 0f) -(42f + 20f * sin((t - moodAt) / 1000f * 13f)) else 0f
        drawBody(cv, br, 0f, 0f, lL, lR, rotR)

        // kepala (mengangguk kalau mengantuk, miring halus waktu idle)
        val dip = nod * (3.5f + 2f * wave(t, 1.05))
        cv.save()
        cv.translate(hDx, dip + 0.5f * br + hDy)
        cv.rotate(1.6f * wave(t, 0.23) + nod * 4f + hRot, 50f, 78f)

        val ep = (t - earAt) / 260f
        val twitch = if (ep in 0f..1f) -14f * sin(ep * PIF) else 0f
        val open = (1f - blinkAmount(t)) * (1f - 0.72f * lid)
        val lx = if (lookOv) lookX else gaze
        head(cv, lx, lookY, -nod * 4f, twitch + nod * 4f, open, k)
        cv.restore()

        badge(cv, t)
    }

    /** Jalan lenggak-lenggok: badan bergoyang, kaki bergantian, telinga trailing, kepala menoleh ke arah jalan. */
    private fun drawWalk(cv: Canvas, t: Long) {
        val sw = phase
        val s = sin(sw)
        val flop = sin(sw * 2f)
        val bounce = abs(s) * 3.6f
        val open = 1f - blinkAmount(t)

        cv.save()
        cv.rotate(4f, 50f, 99f) // condong ke depan

        // badan + ekor (ekor di belakang, melambai)
        cv.save()
        cv.rotate(s * 3.5f, 50f, 99f)
        cv.save()
        cv.rotate(-6f + 15f * sin(sw * 0.5f + 1f), 32f, 97f)
        part(cv, Wolf.tailBack, BODY)
        solid(cv, Wolf.tailTipBack, TIP)
        cv.restore()
        drawBody(cv, 0f, 3f * s, -3f * s, max(0f, s) * 6.5f, max(0f, -s) * 6.5f, 0f)
        cv.restore()

        // kepala memantul, menoleh ke depan
        cv.save()
        cv.translate(1.6f, -bounce)
        cv.rotate(-s * 2.4f, 50f, 72f)
        val ear = -9f + 6f * flop
        head(cv, gaze, 0f, ear, ear, open, 1f)
        cv.restore()

        cv.restore()
    }

    /** Tidur meringkuk bulat: kepala bersandar, telinga terkulai, ekor melingkar di depan, kaki dilipat. */
    private fun drawSleep(cv: Canvas, t: Long) {
        val br = wave(t, 1.0 / 3.8)
        val k = 0.5f + 0.08f * br

        cv.save()
        cv.scale(1f, 1f + 0.03f * br, 50f, 99f)
        part(cv, Wolf.loaf, BODY)

        cv.save()
        cv.translate(0f, 17f)
        cv.rotate(-6f, 50f, 60f)
        cv.scale(0.84f, 0.84f, 50f, 50f)
        head(cv, 0f, 0f, -13f, 13f, 0f, k)
        cv.restore()

        // ekor melingkar di depan, menutupi dagu & kaki yang dilipat
        part(cv, Wolf.curl, BODY)
        solid(cv, Wolf.curlTip, TIP)
        cv.restore()

        for (i in 0 until 3) drawZ(cv, t, 76f, 38f, i)
    }

    /** Huruf "z" melayang naik sambil memudar. */
    private fun drawZ(cv: Canvas, t: Long, bx: Float, by: Float, i: Int) {
        val q = ((t / 3200.0) + i / 3.0) % 1.0
        val qf = q.toFloat()
        val a = sin(qf * PI.toFloat())
        if (a <= 0.02f) return
        cv.save()
        cv.translate(bx + qf * 14f, by - qf * 34f)
        val sc = 0.5f + 0.7f * qf
        cv.scale(sc, sc)
        line.shader = null
        line.color = Color.argb((a * 230f).toInt(), Color.red(ZZZ), Color.green(ZZZ), Color.blue(ZZZ))
        line.strokeWidth = 2.4f
        cv.drawPath(Wolf.zee, line)
        cv.restore()
    }

    /** Hati melayang waktu dielus; muncul di sisi yang masih ada ruang. */
    private fun drawHearts(cv: Canvas, t: Long) {
        val s = sprite()
        val onRight = petX + s * 1.2f <= width
        val hx = if (onRight) 108f else -8f
        for (i in 0 until 3) {
            val q = (((t + i * 470L) % 1400L) / 1400f)
            val a = 1f - q
            cv.save()
            cv.translate(hx + (i - 1) * 3f, 70f - q * 55f)
            val sc = 0.7f + 0.4f * q
            cv.scale(sc, sc)
            fill.shader = null
            fill.color = Color.argb((a * 255f).toInt(), Color.red(HEART), Color.green(HEART), Color.blue(HEART))
            cv.drawPath(Wolf.heart, fill)
            cv.restore()
        }
    }
}
