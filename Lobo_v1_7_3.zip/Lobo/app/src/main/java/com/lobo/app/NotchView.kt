package com.lobo.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Jembatan ke WindowManager milik service (tipe jendela, posisi, add/remove). */
interface OverlayHost {
    fun params(w: Int, h: Int): WindowManager.LayoutParams
    fun add(v: View, lp: WindowManager.LayoutParams): Boolean
    fun remove(v: View)

    /** Izinkan/larang jendela menerima fokus keyboard (dibutuhkan untuk balas notifikasi). */
    fun setFocusable(v: View, focusable: Boolean)

    /** false = tipe jendela ini tidak bisa menampilkan keyboard (pakai ReplyActivity). */
    fun canType(): Boolean
}

/**
 * Notch yang menempel di tepi atas layar (atas datar + telinga cekung, bawah melengkung).
 * COMPACT : pil (maskot / album art di kiri, equalizer di kanan)
 * ALERT   : melebar sebentar untuk notifikasi
 * PANEL   : ketuk pil -> 5 tab (Music, System, Info, Inbox, Tools) tanpa geser; tab yang punya beberapa isi
 *            menampilkan pilihannya sebagai chip di baris yang sama. Semua tampilan berbahan liquid glass.
 *
 * Arsitektur animasi (kenapa tidak goyang lagi):
 *  - Jendela TIDAK PERNAH di-resize selagi terlihat. Pil punya jendela kecil tetap. Untuk ALERT/PANEL
 *    dibuat jendela baru berukuran tetap (sebesar bentuk maksimumnya). Frame pertamanya menggambar
 *    bentuk yang persis sama dengan pil, jadi pergantian jendela tidak terlihat; baru setelah itu
 *    bentuknya dimorph (outline + siluet saja, tanpa layout ulang).
 *  - Saat menutup, bentuk dimorph kembali ke pil, lalu jendela tambahan dibuang.
 *  - Isi lama (pil/alert) tampil sebagai "ghost" (bitmap) yang memudar selama morph.
 */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class NotchView(private val svc: Context, private val media: MediaWatcher, private val host: OverlayHost) : FrameLayout(svc) {
    enum class S { COMPACT, ALERT, PANEL }

    companion object {
        private const val TABS_H = 38
        private const val BODY_PAD_V = 16 // 4 atas + 12 bawah
        private const val PANEL_W = 620
        private const val ALERT_H = 76
        private const val ALERT_EXP_H = 138
        private const val ALERT_R = 28
        private const val HALO_PAD = 14
        private const val EAR_DP = 10
        // Music, Device, Markets, Calendar, Shelf, Notifications, Clipboard, Widgets, Mixer, Launcher, Calls, Booth
        private val TAB_H = intArrayOf(196, 196, 290, 290, 290, 290, 290, 290, 196, 290, 196, 300)
        const val TAB_WIDGETS = 7
        private const val CELL_W = 44 // lebar satu ikon tab (dp)
        private const val CELL_H = 30
        private const val IDLE_GLASS = 0.85f // pil idle juga kaca (hampir penuh)
    }

    private val ui = Handler(Looper.getMainLooper())
    private val choreo = Choreographer.getInstance()
    var state = S.COMPACT
        private set

    private var flat = Lobo.prefs.topOffset == 0
    private val earPx: Float get() = if (flat) svc.dpf(EAR_DP) else 0f

    /** Ukuran jendela pil (tetap). Dipakai service saat memasang jendela. */
    val winW: Int = evenW(maxOf(svc.dp(Lobo.prefs.notchW), svc.dp(120)) + 2 * earPx.toInt() + svc.dp(24))
    val winH: Int = svc.dp(Lobo.prefs.notchH) + svc.dp(2) + svc.dp(HALO_PAD)

    private val pill = NotchShape(svc)
    private var cur: Stage? = null      // jendela tambahan yang sedang tampil
    private var pend: Stage? = null     // jendela tambahan yang sedang disiapkan (belum tergambar)
    private var closing = false

    private val tabGlow = arrayOf(
        intArrayOf(0xFFFF9A3D.toInt(), 0xFFFF3D7F.toInt()), // music: sunrise oranye -> pink
        intArrayOf(0xFF3DDCFF.toInt(), 0xFF3D6BFF.toInt()), // device: cyan -> biru
        intArrayOf(0xFF35E08A.toInt(), 0xFF12A39A.toInt()), // markets: (dipakai lewat glowFor, ikut tren harga)
        intArrayOf(0xFFB06BFF.toInt(), 0xFFFF5FB5.toInt()), // calendar: ungu -> magenta
        intArrayOf(0xFFFFD04D.toInt(), 0xFFFF8A3D.toInt()), // shelf: kuning -> oranye
        intArrayOf(0xFF4D8DFF.toInt(), 0xFF7A5CFF.toInt()), // notifications: biru -> indigo
        intArrayOf(0xFF2DD4BF.toInt(), 0xFF3B82F6.toInt()), // clipboard: teal -> biru
        intArrayOf(0xFFFFA24D.toInt(), 0xFFFF5F8A.toInt()), // widgets: oranye -> pink
        intArrayOf(0xFF8B7BFF.toInt(), 0xFF3D6BFF.toInt()), // mixer: ungu -> biru
        intArrayOf(0xFF9AA7C7.toInt(), 0xFF5B6B9A.toInt()), // launcher: abu-biru
        intArrayOf(0xFF35E08A.toInt(), 0xFF12A39A.toInt()), // calls: hijau -> teal
        intArrayOf(0xFFFF5F8A.toInt(), 0xFFFFA24D.toInt())  // booth: pink -> oranye
    )

    // tab Markets: gradasi ikut arah harga simbol yang dipilih
    private val glowUp = intArrayOf(0xFF35E08A.toInt(), 0xFF12A39A.toInt())   // naik: hijau -> teal
    private val glowDown = intArrayOf(0xFFFF4D5A.toInt(), 0xFFC21E56.toInt()) // turun: merah -> crimson
    private val glowIdle = intArrayOf(0xFF8A96B8.toInt(), 0xFF4B5A86.toInt()) // belum ada data: abu-biru

    // tab Music: gradasi dari dua warna cover album (di-cache per bitmap), bawaan oranye -> pink kalau tidak ada cover
    private var glowArt: Bitmap? = null
    private var glowArtCols: IntArray? = null

    private fun albumGlow(): IntArray? {
        val art = media.art
        if (!media.hasSession || art == null) return null
        if (art !== glowArt) {
            glowArt = art
            glowArtCols = ArtPalette.of(art)
        }
        return glowArtCols
    }

    private fun glowFor(t: Int): IntArray {
        if (Themes.cur() != 0) return Themes.glow[Themes.cur()]
        if (t == 0) return albumGlow() ?: tabGlow[0]
        if (t != 2) return tabGlow[t]
        return when (markets.trend) {
            1 -> glowUp
            -1 -> glowDown
            else -> glowIdle
        }
    }

    private var tintArt: Bitmap? = null
    private var tintCache = C.BLACK

    private val compact = LinearLayout(svc)
    private val alertBox = LinearLayout(svc)
    private val panelBox = LinearLayout(svc)

    // --- compact
    private val pet = PetView(svc)
    private val miniArt = ImageView(svc)
    private val gap = View(svc)
    private val eq = EqView(svc)
    private var lastMiniArt: Bitmap? = null

    // --- alert
    private val aIconBox = FrameLayout(svc)
    private val aGlyph = svc.tv("", 17f, C.TEXT, true)
    private val aLine = LineIconView(svc, IconKind.BELL, C.TEXT, 20f, 1.6f)
    private val aImg = ImageView(svc)
    private val aTitle = svc.tv("", 15f, C.TEXT, false)
    private val aSub = svc.tv("", 13f, 0xBFFFFFFF.toInt())
    private val aTop = LinearLayout(svc)
    private val aReplyBtn = LineIconView(svc, IconKind.REPLY, C.TEXT, 18f, 1.7f)
    private val aReplyRow = LinearLayout(svc)
    private val aInput = EditText(svc)
    private val aSend = LineIconView(svc, IconKind.SEND, C.BLACK, 18f, 2f)
    private var replying = false
    private var current: Alert? = null
    private val queue = java.util.ArrayDeque<Alert>()

    // --- panel
    private val tabsRow = LinearLayout(svc)
    private val tabHi = View(svc)           // sorotan kaca di bawah tab aktif (meluncur antar tab)
    private val chipsRow = LinearLayout(svc) // pilihan isi untuk tab yang punya lebih dari satu panel
    private var chipGroup = -1
    private val body = FrameLayout(svc)
    private val music = MusicPanel(svc, media)
    private val device = DevicePanel(svc)
    private val markets = MarketsPanel(svc)
    private val calendar = CalendarPanel(svc)
    private val shelf = ShelfPanel(svc)
    private val notifs = NotifPanel(svc)
    private val clip = ClipPanel(svc)
    private val widgets = WidgetsPanel(svc)
    private val mixer = MixerPanel(svc)
    private val launcher = LauncherPanel(svc)
    private val calls = CallsPanel(svc)
    private val booth = BoothPanel(svc)
    private val panels: List<View> = listOf(music, device, markets, calendar, shelf, notifs, clip, widgets, mixer, launcher, calls, booth)

    // 11 panel dirangkum jadi 5 tab. Nomor panel (0..10) tidak berubah, jadi alert / service yang memanggil
    // showPanel(n) tetap jalan.
    //   Music   : Music
    //   System  : Device, Mixer, Calls
    //   Info    : Calendar, Widgets, Markets
    //   Inbox   : Notifications, Clipboard
    //   Tools   : Shelf, Launcher, Booth
    private val groups = arrayOf(intArrayOf(0), intArrayOf(1, 8, 10), intArrayOf(3, 7, 2), intArrayOf(5, 6), intArrayOf(4, 9, 11))
    private val groupIcons = listOf(IconKind.MUSIC, IconKind.DEVICE, IconKind.CALENDAR, IconKind.BELL, IconKind.SHELF)
    private val panelNames = arrayOf(
        "Music", "Device", "Markets", "Calendar", "Shelf", "Alerts", "Clipboard", "Widgets", "Mixer", "Launcher", "Calls", "Booth"
    )
    private val groupPanel = IntArray(groups.size) { groups[it][0] } // panel terakhir dibuka di tiap tab
    private val tabViews = ArrayList<View>()
    private var tab = 0

    // warna dasar kaca netral (gelap kebiruan); mode Dark memakai dasar yang lebih pekat
    private val glassBase: Int get() = if (Look.dark) 0xFF0A0B10.toInt() else 0xFF10131A.toInt()
    private lateinit var modeBtn: LineIconView

    private fun darken(c: Int, f: Float): Int =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    private fun groupOf(p: Int): Int {
        for (i in groups.indices) if (groups[i].contains(p)) return i
        return 0
    }

    private val endAlert = Runnable {
        current = null
        val n = queue.poll()
        if (n != null) showAlert(n) else showCompact()
    }

    private val uiTick = object : Runnable {
        override fun run() {
            pet.paused = state != S.COMPACT
            when (state) {
                S.COMPACT -> if (!closing) {
                    updateCompact()
                    if (cur == null && pend == null && !pill.animating) fitCompact()
                }
                S.PANEL -> {
                    val st = cur
                    if (st != null && !st.shape.animating) {
                        (panels[tab] as Refreshable).refresh()
                        st.shape.animateTint(wantedTint())
                        if (tab == 0 && st.kind == S.PANEL) {
                            // lagu ganti saat tab Music terbuka -> gradasi ikut pindah warna
                            val g = glowFor(0)
                            st.glow.setColors(g[0], g[1])
                        }
                    }
                }
                S.ALERT -> {
                }
            }
            // pil idle tidak perlu dicek tiap 0,5 detik (musik/alert memanggil refreshData sendiri): hemat CPU
            ui.postDelayed(this, if (state == S.COMPACT) 1000L else 500L)
        }
    }

    // ------------------------------------------------------------ jendela tambahan

    /** Satu jendela tambahan (ALERT atau PANEL), ukuran tetap selama hidupnya. */
    private inner class Stage(val kind: S) : FrameLayout(svc) {
        val shape = NotchShape(svc)
        val glow = GlowView(svc)
        var ghost: ImageView? = null
        var winH = 0

        init {
            shape.flat = flat
            shape.liquid = true
            shape.ear = earPx
            addView(shape, LayoutParams(MATCH, MATCH))
            shape.content.addView(glow, LayoutParams(MATCH, MATCH))
        }

        fun setGhost(b: Bitmap, alpha: Float) {
            ghost?.let { shape.content.removeView(it) }
            val iv = ImageView(svc)
            iv.setImageBitmap(b)
            iv.alpha = alpha
            shape.content.addView(iv, LayoutParams(b.width, b.height, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
            ghost = iv
        }

        fun attach(v: View, w: Int, h: Int) {
            (v.parent as? ViewGroup)?.removeView(v)
            v.pivotX = w / 2f
            v.pivotY = 0f
            shape.content.addView(v, LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        }

        fun release() {
            shape.release()
            for (v in arrayOf<View>(alertBox, panelBox)) {
                if (v.parent === shape.content) shape.content.removeView(v)
            }
        }

        /** Panggil [cb] setelah jendela ini benar-benar tergambar (frame pertama + 1-2 frame). */
        fun whenDrawn(cb: () -> Unit) {
            var fired = false
            val fire = Runnable {
                if (!fired) {
                    fired = true
                    cb()
                }
            }
            viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
                override fun onPreDraw(): Boolean {
                    if (viewTreeObserver.isAlive) viewTreeObserver.removeOnPreDrawListener(this)
                    choreo.postFrameCallback { choreo.postFrameCallback { fire.run() } }
                    return true
                }
            })
            postDelayed(fire, 160) // pengaman kalau PreDraw tidak pernah datang
        }

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> shape.touchLight(ev.x, true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> shape.touchLight(ev.x, false)
            }
            if (stageGate(this, ev)) return true
            return super.dispatchTouchEvent(ev)
        }
    }

    /** true = sentuhan sudah ditangani/ditelan. */
    private fun stageGate(st: Stage, ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_OUTSIDE) {
            if (st === cur && !closing && (state == S.PANEL || (state == S.ALERT && replying))) showCompact()
            return true
        }
        if (closing) return true
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            val cx = st.width / 2f
            val half = st.shape.vW / 2f + st.shape.ear
            val inside = ev.x >= cx - half && ev.x <= cx + half && ev.y <= st.shape.vH
            if (!inside) {
                // ketukan di area transparan (di luar bentuk) dianggap ketukan di luar panel
                if (st === cur && (state == S.PANEL || (state == S.ALERT && replying))) showCompact()
                return true
            }
        }
        return false
    }

    init {
        pill.flat = flat
        pill.ear = earPx
        pill.glass = IDLE_GLASS
        pill.auraAlpha = 1f
        pill.energy = { eq.energy }

        // harga naik/turun berubah -> gradasi tab Markets berpindah warna dengan halus
        markets.onTrend = {
            val st = cur
            if (st != null && st.kind == S.PANEL && tab == 2) {
                val g = glowFor(2)
                st.glow.setColors(g[0], g[1])
            }
        }

        // ---------- compact: kiri maskot/art, kanan equalizer, tengah kosong (seperti notch MacBook)
        compact.orientation = LinearLayout.HORIZONTAL
        compact.gravity = Gravity.CENTER_VERTICAL
        compact.setPadding(svc.dp(12), 0, svc.dp(12), 0)
        compact.addView(pet, LinearLayout.LayoutParams(svc.dp(24), MATCH, 1f))
        pet.setOnClickListener {
            pet.poke()
            compact.performClick()
        }
        pet.setOnLongClickListener {
            pet.pat()
            true
        }
        miniArt.scaleType = ImageView.ScaleType.CENTER_CROP
        miniArt.roundClip(svc.dpf(6))
        compact.addView(miniArt, LinearLayout.LayoutParams(svc.dp(20), svc.dp(20)))
        compact.addView(gap, LinearLayout.LayoutParams(svc.dp(36), 1, 1f))
        compact.addView(eq, LinearLayout.LayoutParams(svc.dp(18), svc.dp(14)))
        compact.setOnClickListener {
            if (state == S.COMPACT && cur == null && pend == null && !closing) {
                showPanel(if (media.hasSession && media.playing) 0 else Lobo.prefs.lastTab.coerceIn(0, panels.size - 1))
            }
        }

        // ---------- alert: baris atas (ikon app + judul + isi + tombol balas), baris bawah (kolom balas)
        alertBox.orientation = LinearLayout.VERTICAL
        aTop.orientation = LinearLayout.HORIZONTAL
        aTop.gravity = Gravity.CENTER_VERTICAL
        aTop.setPadding(svc.dp(18), 0, svc.dp(14), 0)
        aTitle.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        aSub.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        aSub.setLineSpacing(0f, 1.06f)
        aGlyph.gravity = Gravity.CENTER
        aIconBox.addView(aGlyph, LayoutParams(MATCH, MATCH))
        aIconBox.addView(aLine, LayoutParams(MATCH, MATCH))
        aImg.scaleType = ImageView.ScaleType.FIT_CENTER
        aImg.roundClip(svc.dpf(11))
        aIconBox.addView(aImg, LayoutParams(MATCH, MATCH))
        aTop.addView(aIconBox, svc.llp(svc.dp(42), svc.dp(42)))
        val tcol = LinearLayout(svc)
        tcol.orientation = LinearLayout.VERTICAL
        tcol.gravity = Gravity.CENTER_VERTICAL
        aTitle.maxLines = 1
        aTitle.ellipsize = TextUtils.TruncateAt.END
        aSub.maxLines = 2
        aSub.ellipsize = TextUtils.TruncateAt.END
        tcol.addView(aTitle)
        tcol.addView(aSub, svc.llp(WRAP, WRAP, 0f, 0, 3, 0, 0))
        aTop.addView(tcol, svc.llp(0, WRAP, 1f, 14, 0, 6, 0))
        aReplyBtn.background = rounded(0x26FFFFFF, svc.dpf(100))
        aReplyBtn.visibility = GONE
        aReplyBtn.setOnClickListener { beginReply() }
        aTop.addView(aReplyBtn, svc.llp(svc.dp(44), svc.dp(36)))
        aTop.setOnClickListener {
            val a = current
            ui.removeCallbacks(endAlert)
            queue.clear()
            current = null
            a?.onClick?.invoke()
            if (a != null && a.tab >= 0) showPanel(a.tab) else showCompact()
        }
        alertBox.addView(aTop, svc.llp(MATCH, svc.dp(ALERT_H)))

        aReplyRow.orientation = LinearLayout.HORIZONTAL
        aReplyRow.gravity = Gravity.CENTER_VERTICAL
        aReplyRow.setPadding(svc.dp(14), 0, svc.dp(12), svc.dp(4))
        aReplyRow.visibility = GONE
        aInput.setTextColor(C.TEXT)
        aInput.setHintTextColor(0x66FFFFFF)
        aInput.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14.5f)
        aInput.background = rounded(0x22FFFFFF, svc.dpf(22))
        aInput.setPadding(svc.dp(16), 0, svc.dp(16), 0)
        aInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        aInput.imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        aInput.setSingleLine(true)
        aInput.setOnEditorActionListener { _, act, _ ->
            if (act == EditorInfo.IME_ACTION_SEND) {
                sendReply()
                true
            } else {
                false
            }
        }
        aReplyRow.addView(aInput, svc.llp(0, svc.dp(44), 1f))
        aSend.background = rounded(C.TEXT, svc.dpf(22))
        aSend.setOnClickListener { sendReply() }
        aReplyRow.addView(aSend, svc.llp(svc.dp(44), svc.dp(44), 0f, 8, 0, 0, 0))
        alertBox.addView(aReplyRow, svc.llp(MATCH, svc.dp(ALERT_EXP_H - ALERT_H)))

        // ---------- panel: strip ikon tab di atas, isi di bawah
        panelBox.orientation = LinearLayout.VERTICAL
        // 5 tab ikon dalam satu kapsul kaca (semua terlihat, tidak perlu geser). Sorotan kaca meluncur ke tab aktif.
        // Di sebelahnya muncul chip pilihan isi (mis. System: Device | Mixer | Calls). Di kanan tetap: palet, setelan, tutup.
        tabsRow.orientation = LinearLayout.HORIZONTAL
        tabsRow.gravity = Gravity.CENTER_VERTICAL
        for (i in groups.indices) {
            val t = LineIconView(svc, groupIcons[i], C.TEXT, 16f, 1.4f)
            tabViews.add(t)
            val cell = FrameLayout(svc)
            cell.setOnClickListener { selectTab(groupPanel[i]) }
            cell.addView(t, FrameLayout.LayoutParams(MATCH, MATCH))
            tabsRow.addView(cell, LinearLayout.LayoutParams(svc.dp(CELL_W), svc.dp(CELL_H)))
        }
        val capsule = FrameLayout(svc)
        capsule.background = glass(C.GLASS, svc.dpf(100))
        capsule.setPadding(svc.dp(2), svc.dp(2), svc.dp(2), svc.dp(2))
        tabHi.background = glass(C.GLASS_SEL, svc.dpf(100))
        capsule.addView(tabHi, FrameLayout.LayoutParams(svc.dp(CELL_W), svc.dp(CELL_H)))
        capsule.addView(tabsRow, FrameLayout.LayoutParams(WRAP, WRAP))
        chipsRow.orientation = LinearLayout.HORIZONTAL
        chipsRow.gravity = Gravity.CENTER_VERTICAL
        val tabsBar = LinearLayout(svc)
        tabsBar.orientation = LinearLayout.HORIZONTAL
        tabsBar.gravity = Gravity.CENTER_VERTICAL
        tabsBar.setPadding(svc.dp(14), 0, svc.dp(10), 0)
        tabsBar.addView(capsule, svc.llp(WRAP, svc.dp(CELL_H + 4)))
        tabsBar.addView(chipsRow, svc.llp(0, MATCH, 1f, 10, 0, 6, 0))
        // saklar mode: tetes = Liquid Glass, bulan = Dark (gradasi tetap ada di dua-duanya)
        modeBtn = LineIconView(svc, if (Look.dark) IconKind.MOON else IconKind.DROP, 0xB3FFFFFF.toInt(), 15f, 1.35f)
        modeBtn.setOnClickListener {
            Look.set(!Look.dark)
            applyMode()
        }
        tabsBar.addView(modeBtn, svc.llp(svc.dp(32), svc.dp(30)))
        val palette = LineIconView(svc, IconKind.PALETTE, 0xB3FFFFFF.toInt(), 15f, 1.35f)
        palette.setOnClickListener {
            Lobo.prefs.theme = (Themes.cur() + 1) % Themes.names.size
            applyTheme()
        }
        tabsBar.addView(palette, svc.llp(svc.dp(32), svc.dp(30)))
        val gear = LineIconView(svc, IconKind.GEAR, 0xB3FFFFFF.toInt(), 15f, 1.35f)
        gear.setOnClickListener {
            showCompact()
            try {
                val i = Intent(svc, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                svc.startActivity(i)
            } catch (e: Exception) {
            }
        }
        tabsBar.addView(gear, svc.llp(svc.dp(32), svc.dp(30)))
        val close = LineIconView(svc, IconKind.CHEVRON_UP, 0xB3FFFFFF.toInt(), 17f, 1.5f)
        close.setOnClickListener { showCompact() }
        tabsBar.addView(close, svc.llp(svc.dp(32), svc.dp(30)))
        panelBox.addView(tabsBar, svc.llp(MATCH, svc.dp(TABS_H)))
        // aksi yang membuka app lain: tutup panel dulu, baru jalankan
        val closer: (() -> Unit) -> Unit = { fn ->
            showCompact()
            ui.postDelayed({ fn() }, 420)
        }
        notifs.closeThen = closer
        launcher.closeThen = closer
        booth.closeThen = closer
        body.setPadding(svc.dp(18), svc.dp(4), svc.dp(18), svc.dp(12))
        for (i in panels.indices) {
            // tinggi isi tiap panel tetap (sesuai tabnya) -> tidak ada relayout saat pindah tab
            val ph = svc.dp(TAB_H[i] - TABS_H - BODY_PAD_V)
            panels[i].visibility = GONE
            body.addView(panels[i], LayoutParams(MATCH, ph, Gravity.TOP))
        }
        panelBox.addView(body, svc.llp(MATCH, 0, 1f))

        val (w, h) = compactSize()
        pill.setShapeNow(w.toFloat(), h.toFloat(), compactR(h))
        pill.content.addView(compact, LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        addView(pill, LayoutParams(MATCH, MATCH))
        updateCompact()
    }

    // ------------------------------------------------------------ util

    private fun screenW(): Int {
        return if (Build.VERSION.SDK_INT >= 30) {
            (svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager).currentWindowMetrics.bounds.width()
        } else {
            resources.displayMetrics.widthPixels
        }
    }

    /** Lebar jendela dibuat berparitas sama dengan layar supaya semua jendela persis sepusat. */
    private fun evenW(w: Int): Int = if ((screenW() - w) % 2 != 0) w + 1 else w

    private fun tintFrom(art: Bitmap): Int {
        if (art === tintArt) return tintCache
        var out = C.BLACK
        try {
            val px = Bitmap.createScaledBitmap(art, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(px, hsv)
            hsv[1] = (hsv[1] * 1.15f).coerceAtMost(0.85f)
            hsv[2] = 0.36f
            out = Color.HSVToColor(hsv)
        } catch (e: Exception) {
        }
        tintArt = art
        tintCache = out
        return out
    }

    private fun wantedTint(): Int {
        // mode Dark: warna tema / cover album tetap jadi gradasi, tapi digelapkan supaya panel pekat
        val k = if (Look.dark) 0.5f else 1f
        if (Themes.cur() != 0) return darken(Themes.tint[Themes.cur()], k)
        if (state == S.PANEL && tab == 0 && media.hasSession) {
            val art = media.art
            if (art != null) return darken(tintFrom(art), k)
        }
        return glassBase
    }

    private fun smooth(x: Float): Float {
        val u = x.coerceIn(0f, 1f)
        return u * u * (3f - 2f * u)
    }

    /** Foto isi sebuah view (untuk ghost). fw/fh > 0 memaksa layout ke ukuran itu dulu. */
    private fun snapshot(v: View, fw: Int = 0, fh: Int = 0): Bitmap? {
        try {
            var w = v.width
            var h = v.height
            if (fw > 0 && fh > 0) {
                v.measure(
                    View.MeasureSpec.makeMeasureSpec(fw, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(fh, View.MeasureSpec.EXACTLY)
                )
                v.layout(0, 0, fw, fh)
                w = fw
                h = fh
            }
            if (w <= 0 || h <= 0) return null
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            v.draw(Canvas(b))
            return b
        } catch (e: Throwable) {
            return null
        }
    }

    private fun notifyVisibility() {
        for (i in panels.indices) (panels[i] as? PanelLife)?.onVisible(state == S.PANEL && tab == i)
    }

    // ------------------------------------------------------------ compact

    private fun updateCompact() {
        val pr = Lobo.prefs
        val minimal = pr.minimal
        val musicOn = media.hasSession && media.playing
        val art = media.art
        val showArt = musicOn && art != null && !minimal
        val showPet = !minimal && pr.pet && !showArt
        pet.visibility = if (showPet) VISIBLE else GONE
        gap.visibility = if (showPet) GONE else VISIBLE
        miniArt.visibility = if (showArt) VISIBLE else GONE
        if (showArt && lastMiniArt !== art) {
            lastMiniArt = art
            miniArt.setImageBitmap(art)
        }
        val showEq = musicOn && !minimal
        eq.visibility = if (showEq) VISIBLE else GONE
        eq.setArt(art)
        eq.active = media.playing
        // gradasi di dalam notch bergerak selama musik main, warnanya dari cover album
        pill.setMusic(showEq, eq.colA, eq.colB)
        syncPillPaused()
    }

    /** Pil yang tertutup panel/alert tidak perlu menggambar animasi (hemat baterai). */
    private fun syncPillPaused() {
        pill.paused = cur != null && !closing
    }

    private fun compactSize(): Pair<Int, Int> {
        compact.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        val minimal = Lobo.prefs.minimal
        val bw = svc.dp(Lobo.prefs.notchW)
        val bh = svc.dp(Lobo.prefs.notchH)
        val minW = if (minimal) (bw * 0.75f).toInt() else bw
        val h = if (minimal) (bh * 0.8f).toInt() else bh
        val maxW = winW - 2 * earPx.toInt() - svc.dp(8)
        return Pair(minOf(maxOf(minW, compact.measuredWidth + svc.dp(8)), maxW), minOf(h, winH))
    }

    /** Menempel di tepi: sudut bawah agak kotak. Melayang: pil bulat penuh. */
    private fun compactR(h: Int): Float = if (flat) h * 0.42f else h / 2f

    private fun setCompactLp(w: Int, h: Int) {
        compact.layoutParams = LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
    }

    /** Pil menyesuaikan isi (musik mulai/berhenti): hanya bentuk yang beranimasi, jendela tetap. */
    private fun fitCompact() {
        val (w, h) = compactSize()
        if (Math.abs(pill.vW - w) > svc.dp(2) || Math.abs(pill.vH - h) > 1f) {
            // isi dilebarkan dulu ke ukuran terbesar supaya tidak terpotong selama morph
            setCompactLp(maxOf(w, Math.ceil(pill.vW.toDouble()).toInt()), h)
            pill.animate(w.toFloat(), h.toFloat(), compactR(h), C.BLACK, 280, 12f, null) {
                setCompactLp(w, h)
            }
        }
    }

    private fun resetPillNow() {
        updateCompact()
        val (w, h) = compactSize()
        setCompactLp(w, h)
        pill.setShapeNow(w.toFloat(), h.toFloat(), compactR(h))
        pill.setTintNow(C.BLACK)
        pill.auraAlpha = 1f
        pill.alpha = 1f
    }

    // ------------------------------------------------------------ buka/tutup jendela tambahan

    private fun alertW(): Int = minOf((screenW() * 0.9f).toInt(), svc.dp(400))

    private fun panelW(): Int = minOf(screenW() - svc.dp(24), svc.dp(PANEL_W))

    private fun panelH(t: Int): Int = svc.dp(TAB_H[t])

    private fun stageW(contentW: Int): Int = evenW(contentW + 2 * earPx.toInt() + svc.dp(4))

    private fun removeStage(st: Stage) {
        st.release()
        host.remove(st)
    }

    private fun cancelPending() {
        val p = pend ?: return
        pend = null
        removeStage(p)
    }

    private fun abortStages() {
        cancelPending()
        cur?.let { removeStage(it) }
        cur = null
        closing = false
        pill.release()
        pill.alpha = 1f
    }

    /**
     * Siapkan jendela baru untuk [kind], bentuk awalnya = bentuk yang sedang tampil
     * (pil, atau stage lama kalau [from] != null). Animasi baru jalan setelah jendela tergambar.
     */
    private fun openStage(kind: S, from: Stage?) {
        cancelPending()
        val sw: Int
        val sh: Int
        if (kind == S.PANEL) {
            sw = stageW(panelW())
            sh = svc.dp(TAB_H.max())
        } else {
            sw = stageW(alertW())
            sh = if (current?.reply != null) svc.dp(ALERT_EXP_H) else svc.dp(ALERT_H)
        }
        val st = Stage(kind)
        st.winH = sh
        val src = from?.shape ?: pill
        st.shape.setShapeNow(src.vW, src.vH, src.vR)
        st.shape.setTintNow(src.tint)
        st.shape.copyAuraFrom(src)
        st.shape.auraAlpha = src.auraAlpha
        st.shape.glass = src.glass

        // isi lama jadi ghost (tampak identik dengan yang ada di jendela lama)
        val ghostBmp = if (from != null) snapshot(alertBox) else snapshot(compact)
        if (ghostBmp != null) st.setGhost(ghostBmp, 1f)

        // isi baru (transparan dulu, dimunculkan oleh animasi)
        if (kind == S.PANEL) {
            panelBox.alpha = 0f
            panelBox.scaleX = 0.94f
            panelBox.scaleY = 0.94f
            panelBox.visibility = VISIBLE
            st.attach(panelBox, panelW(), sh)
        } else {
            alertBox.alpha = 0f
            alertBox.scaleX = 0.94f
            alertBox.scaleY = 0.94f
            alertBox.visibility = VISIBLE
            aReplyRow.visibility = GONE
            st.attach(alertBox, alertW(), sh)
        }

        pend = st
        st.whenDrawn { onStageReady(st, from) }
        if (!host.add(st, host.params(sw, sh))) {
            pend = null
            st.release()
            state = S.COMPACT
            resetPillNow()
        }
    }

    private fun onStageReady(st: Stage, from: Stage?) {
        if (pend !== st) return
        pend = null
        cur = st
        syncPillPaused()
        pill.alpha = 0f
        if (from != null) removeStage(from)
        if (st.kind == S.PANEL) animateOpenPanel(st) else animateOpenAlert(st)
    }

    private fun animateOpenPanel(st: Stage) {
        notifyVisibility()
        val g = glowFor(tab)
        val g0 = st.shape.glass // alert -> panel: kaca sudah menyala, jangan dimulai ulang dari 0
        st.glow.flash(g[0], g[1])
        st.shape.animate(panelW().toFloat(), panelH(tab).toFloat(), svc.dpf(28), wantedTint(), 480, 9f, { f ->
            st.glow.setVisible(st.shape.vW, st.shape.vH)
            st.ghost?.alpha = 1f - smooth(f / 0.3f)
            st.shape.auraAlpha = 1f - smooth(f / 0.5f)
            st.shape.glass = maxOf(g0, smooth(f / 0.55f))
            st.shape.sheen = ((f - 0.06f) / 0.94f).coerceIn(0f, 1f)
            val a = smooth((f - 0.22f) / 0.5f)
            panelBox.alpha = a
            val s = 0.94f + 0.06f * a
            panelBox.scaleX = s
            panelBox.scaleY = s
        }) {
            panelBox.alpha = 1f
            panelBox.scaleX = 1f
            panelBox.scaleY = 1f
            st.ghost?.alpha = 0f
            st.shape.auraAlpha = 0f
            st.shape.glass = 1f
            st.shape.sheen = -1f
        }
    }

    private fun animateOpenAlert(st: Stage) {
        ui.removeCallbacks(endAlert)
        ui.postDelayed(endAlert, current?.ms ?: 3500L)
        val g0 = st.shape.glass
        st.shape.animate(alertW().toFloat(), svc.dp(ALERT_H).toFloat(), svc.dpf(ALERT_R), glassBase, 420, 9.5f, { f ->
            st.ghost?.alpha = 1f - smooth(f / 0.3f)
            st.shape.auraAlpha = 1f - smooth(f / 0.5f)
            st.shape.glass = maxOf(g0, smooth(f / 0.55f))
            st.shape.sheen = ((f - 0.06f) / 0.94f).coerceIn(0f, 1f)
            val a = smooth((f - 0.2f) / 0.55f)
            alertBox.alpha = a
            val s = 0.94f + 0.06f * a
            alertBox.scaleX = s
            alertBox.scaleY = s
        }) {
            alertBox.alpha = 1f
            alertBox.scaleX = 1f
            alertBox.scaleY = 1f
            st.ghost?.alpha = 0f
            st.shape.auraAlpha = 0f
            st.shape.glass = 1f
            st.shape.sheen = -1f
        }
    }

    private fun closeStage(st: Stage) {
        if (closing) return
        closing = true
        ui.removeCallbacks(endAlert)
        updateCompact()
        // jendela yang menutup menggambar aura yang sama dengan pil (gerak & warna sefase)
        st.shape.copyAuraFrom(pill)
        val (w, h) = compactSize()
        setCompactLp(w, h)
        // pil di bawah langsung siap di bentuk akhir (tertutup stage sampai morph selesai)
        pill.setShapeNow(w.toFloat(), h.toFloat(), compactR(h))
        pill.setTintNow(C.BLACK)
        val bmp = snapshot(compact, w, h)
        if (bmp != null) st.setGhost(bmp, 0f)
        st.glow.hide()

        val box: View = if (st.kind == S.PANEL) panelBox else alertBox
        val a0 = box.alpha
        val g0 = st.shape.glass
        val gEnd = pill.glass
        st.shape.sheen = -1f
        st.shape.animate(w.toFloat(), h.toFloat(), compactR(h), C.BLACK, 340, 10f, { f ->
            st.glow.setVisible(st.shape.vW, st.shape.vH)
            val o = 1f - smooth(f / 0.38f)
            st.shape.auraAlpha = smooth((f - 0.35f) / 0.65f)
            // kaca kembali pekat sebelum sampai ke bezel; pil di bawahnya baru ditampakkan saat sudah identik
            st.shape.glass = gEnd + (g0 - gEnd) * (1f - smooth(f / 0.85f))
            if (f > 0.9f && pill.alpha < 1f) pill.alpha = 1f
            box.alpha = a0 * o
            val s = 0.96f + 0.04f * o
            box.scaleX = s
            box.scaleY = s
            st.ghost?.alpha = smooth((f - 0.5f) / 0.45f)
        }) {
            pill.alpha = 1f
            removeStage(st)
            cur = null
            closing = false
            box.alpha = 1f
            box.scaleX = 1f
            box.scaleY = 1f
            updateCompact()
            val n = queue.poll()
            if (n != null) showAlert(n)
        }
    }

    // ------------------------------------------------------------ public API

    fun showCompact() {
        ui.removeCallbacks(endAlert)
        if (closing) return
        if (replying) endReplyMode()
        if (state == S.COMPACT && cur == null && pend == null) {
            updateCompact()
            fitCompact()
            return
        }
        state = S.COMPACT
        current = null
        cancelPending()
        notifyVisibility()
        val st = cur
        if (st == null) {
            resetPillNow()
            return
        }
        closeStage(st)
    }

    fun enqueue(a: Alert) {
        pet.perk()
        when {
            state == S.PANEL -> return
            state == S.ALERT || closing || pend != null -> if (queue.size < 4) queue.add(a)
            else -> showAlert(a)
        }
    }

    private fun showAlert(a: Alert) {
        state = S.ALERT
        current = a
        aTitle.text = a.title
        aSub.text = a.sub
        if (a.icon != null) {
            aImg.visibility = VISIBLE
            aImg.setImageDrawable(a.icon)
            aGlyph.visibility = GONE
            aLine.visibility = GONE
            aIconBox.background = null
        } else {
            aImg.visibility = GONE
            val kind = glyphIcon(a.glyph)
            if (kind != null) {
                aLine.set(kind, a.color)
                aLine.visibility = VISIBLE
                aGlyph.visibility = GONE
            } else {
                aGlyph.text = a.glyph
                aGlyph.setTextColor(a.color)
                aGlyph.visibility = VISIBLE
                aLine.visibility = GONE
            }
            // lingkaran lembut berwarna aksen (tint), bukan blok warna pekat
            aIconBox.background = rounded(Color.argb(0x33, Color.red(a.color), Color.green(a.color), Color.blue(a.color)), svc.dpf(21))
        }
        aIconBox.animate().cancel()
        aIconBox.scaleX = 0.6f
        aIconBox.scaleY = 0.6f
        aIconBox.animate().scaleX(1f).scaleY(1f).setStartDelay(140).setDuration(380)
            .setInterpolator(OvershootInterpolator(2.2f)).start()
        aReplyBtn.visibility = if (a.reply != null) VISIBLE else GONE
        val needH = if (a.reply != null) svc.dp(ALERT_EXP_H) else 0
        val st = cur
        if (st != null && st.kind == S.ALERT && !closing) {
            if (st.winH >= needH) {
                // alert berikutnya: jendela sama, isi diganti dengan fade singkat
                alertBox.alpha = 0f
                alertBox.animate().alpha(1f).setDuration(180).start()
                ui.removeCallbacks(endAlert)
                ui.postDelayed(endAlert, a.ms)
            } else {
                // alert berikutnya butuh jendela lebih tinggi (untuk kolom balas)
                openStage(S.ALERT, st)
            }
            return
        }
        openStage(S.ALERT, null)
    }

    // ------------------------------------------------------------ balas notifikasi dari notch

    private fun imm(): InputMethodManager = svc.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

    private fun beginReply() {
        val st = cur ?: return
        val a = current ?: return
        if (a.reply == null || st.kind != S.ALERT || closing || replying || state != S.ALERT) return
        if (!host.canType() || st.winH < svc.dp(ALERT_EXP_H)) {
            // jendela overlay jenis ini tidak bisa menerima keyboard -> kolom balas lewat activity kecil
            ReplyBridge.title = a.title
            ReplyBridge.fn = a.reply
            ui.removeCallbacks(endAlert)
            queue.clear()
            current = null
            showCompact()
            try {
                val i = Intent(svc, ReplyActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                svc.startActivity(i)
            } catch (e: Exception) {
            }
            return
        }
        replying = true
        ui.removeCallbacks(endAlert)
        aInput.setText("")
        aInput.hint = "Reply to " + a.title
        aReplyRow.alpha = 0f
        aReplyRow.visibility = VISIBLE
        host.setFocusable(st, true)
        st.shape.animate(alertW().toFloat(), svc.dp(ALERT_EXP_H).toFloat(), svc.dpf(ALERT_R), glassBase, 360, 10f, { f ->
            aReplyRow.alpha = smooth((f - 0.3f) / 0.6f)
        }) {
            aReplyRow.alpha = 1f
        }
        aInput.postDelayed({
            if (replying) {
                aInput.requestFocus()
                try {
                    imm().showSoftInput(aInput, 0)
                } catch (e: Exception) {
                }
            }
        }, 140)
    }

    private fun sendReply() {
        val a = current ?: return
        val t = aInput.text.toString().trim()
        if (t.isEmpty()) return
        val ok = try {
            a.reply?.invoke(t) ?: false
        } catch (e: Exception) {
            false
        }
        val who = a.title
        showCompact()
        Bus.alert(
            if (ok) Alert("Reply sent", who, "✓", C.GREEN, ms = 2000L)
            else Alert("Couldn't send reply", who, "!", C.RED)
        )
    }

    private fun endReplyMode() {
        replying = false
        try {
            imm().hideSoftInputFromWindow(aInput.windowToken, 0)
        } catch (e: Exception) {
        }
        aInput.clearFocus()
        cur?.let { host.setFocusable(it, false) }
        aReplyRow.visibility = GONE
    }

    private fun styleTabs(animate: Boolean = false) {
        val g = groupOf(tab)
        groupPanel[g] = tab
        for (i in tabViews.indices) tabViews[i].alpha = if (i == g) 1f else 0.68f
        val x = (g * svc.dp(CELL_W)).toFloat()
        tabHi.animate().cancel()
        if (animate) {
            tabHi.animate().translationX(x).setDuration(280).setInterpolator(DecelerateInterpolator(2.2f)).start()
        } else {
            tabHi.translationX = x
        }
        if (chipGroup != g) buildChips(g)
        styleChips()
    }

    /** Chip pilihan isi untuk tab [g] (kosong kalau tab itu cuma punya satu panel). */
    private fun buildChips(g: Int) {
        chipGroup = g
        chipsRow.removeAllViews()
        val ids = groups[g]
        if (ids.size < 2) return
        for (p in ids) {
            val t = svc.tv(panelNames[p], 12f, C.TEXT, false)
            t.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            t.gravity = Gravity.CENTER
            t.setPadding(svc.dp(11), svc.dp(6), svc.dp(11), svc.dp(6))
            t.tag = p
            t.setOnClickListener { selectTab(p) }
            chipsRow.addView(t, svc.llp(WRAP, WRAP, 0f, 0, 0, 4, 0))
        }
    }

    private fun styleChips() {
        for (i in 0 until chipsRow.childCount) {
            val c = chipsRow.getChildAt(i)
            val sel = (c.tag as? Int) == tab
            c.background = if (sel) glass(C.GLASS_SEL, svc.dpf(100)) else null
            c.alpha = if (sel) 1f else 0.72f
        }
    }

    /** Ganti tema kaca (Crystal / Rosé / Peach / Ocean / Forest / Aurora): tint kaca dan cahaya dasar ikut berubah. */
    private fun applyTheme() {
        val st = cur ?: return
        if (st.kind != S.PANEL) return
        st.shape.animateTint(wantedTint())
        val g = glowFor(tab)
        st.glow.setColors(g[0], g[1])
    }

    /** Ganti mode Liquid Glass <-> Dark: bentuk, kartu, chip, dan warna dasar ikut berganti; gradasi cahaya tetap. */
    private fun applyMode() {
        modeBtn.set(if (Look.dark) IconKind.MOON else IconKind.DROP, 0xB3FFFFFF.toInt())
        pill.refreshLook()
        val st = cur
        if (st != null) {
            st.shape.refreshLook()
            if (st.kind == S.PANEL) {
                st.shape.animateTint(wantedTint())
                val g = glowFor(tab)
                st.glow.flash(g[0], g[1])
            }
            st.invalidateAll()
        }
        panelBox.invalidateAll()
        alertBox.invalidateAll()
        styleTabs()
        styleChips()
    }

    private fun preparePanels() {
        for (i in panels.indices) {
            panels[i].alpha = 1f
            panels[i].visibility = if (i == tab) VISIBLE else GONE
        }
        styleTabs()
        (panels[tab] as Refreshable).refresh()
    }

    fun showPanel(t: Int) {
        if (closing) return
        ui.removeCallbacks(endAlert)
        queue.clear()
        current = null
        val nt = t.coerceIn(0, panels.size - 1)
        if (state == S.PANEL && cur != null) {
            selectTab(nt)
            return
        }
        if (state == S.PANEL && pend != null) {
            // panel sedang disiapkan: cukup ganti tab awalnya
            tab = nt
            Lobo.prefs.lastTab = nt
            preparePanels()
            return
        }
        val from = if (state == S.ALERT) cur else null
        state = S.PANEL
        tab = nt
        Lobo.prefs.lastTab = nt
        preparePanels()
        openStage(S.PANEL, from)
    }

    private fun selectTab(t: Int) {
        if (t == tab) return
        val st = cur
        val old = tab
        tab = t
        Lobo.prefs.lastTab = t
        styleTabs(true)
        val inV = panels[t]
        val outV = panels[old]
        for (i in panels.indices) {
            if (i != t && i != old) panels[i].visibility = GONE
        }
        (inV as Refreshable).refresh()
        inV.alpha = 0f
        inV.visibility = VISIBLE
        if (st == null) {
            outV.visibility = GONE
            inV.alpha = 1f
            notifyVisibility()
            return
        }
        // kalau animasi buka belum selesai, finalkan dulu isinya supaya tidak tersangkut transparan
        panelBox.alpha = 1f
        panelBox.scaleX = 1f
        panelBox.scaleY = 1f
        st.ghost?.alpha = 0f
        val outA = outV.alpha
        val g = glowFor(t)
        st.glow.flash(g[0], g[1])
        st.shape.animate(panelW().toFloat(), panelH(t).toFloat(), svc.dpf(28), wantedTint(), 340, 11f, { f ->
            outV.alpha = outA * (1f - smooth(f / 0.4f))
            inV.alpha = smooth((f - 0.2f) / 0.6f)
            st.glow.setVisible(st.shape.vW, st.shape.vH)
        }) {
            outV.visibility = GONE
            outV.alpha = 1f
            inV.alpha = 1f
        }
        notifyVisibility()
    }

    fun refreshData() {
        if (state == S.PANEL) (panels[tab] as Refreshable).refresh()
    }

    // ------------------------------------------------------------ system hooks

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        post {
            replying = false
            abortStages()
            ui.removeCallbacks(endAlert)
            queue.clear()
            current = null
            state = S.COMPACT
            notifyVisibility()
            resetPillNow()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ui.post(uiTick)
    }

    override fun onDetachedFromWindow() {
        ui.removeCallbacks(uiTick)
        ui.removeCallbacks(endAlert)
        abortStages()
        Markets.stop()
        PrivSampler.stop()
        super.onDetachedFromWindow()
    }
}
