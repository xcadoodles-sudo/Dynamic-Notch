package com.lobo.app

import android.graphics.Bitmap
import android.graphics.HardwareRenderer
import android.graphics.PixelFormat
import android.graphics.RenderEffect
import android.graphics.RenderNode
import android.graphics.RuntimeShader
import android.hardware.HardwareBuffer
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.View
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Efek Photo Booth bergaya "3D" (cembung, cekung, pusaran, bola kaca, liquid glass, anaglyph 3D, terowongan, dst).
 *
 * Semuanya shader AGSL (Android 13+) yang dijalankan GPU:
 *  - preview: [Live] memasang shader sebagai RenderEffect di TextureView (tanpa callback per-frame, tetap ringan);
 *  - foto hasil: [render] menjalankan shader YANG SAMA ke bitmap lewat RenderNode + HardwareRenderer,
 *    jadi foto persis seperti preview.
 *
 * Semua ukuran di shader relatif terhadap sisi pendek gambar (`unit()`), jadi preview kecil dan foto beresolusi
 * penuh terlihat sama. Di bawah Android 13 efek ini tidak aktif (efek warna ColorMatrix tetap jalan).
 */
object BoothShaders {
    private const val TAG = "LoboFx"

    val supported: Boolean get() = Build.VERSION.SDK_INT >= 33

    private const val HEAD = """
uniform shader content;
uniform float2 res;
uniform float2 ctr;
uniform float time;

float unit() { return min(res.x, res.y); }
half4 tap(float2 p) { return content.eval(clamp(p, float2(0.5), res - 0.5)); }
float3 rgbAt(float2 p) { return float3(tap(p).rgb); }
float luma(float3 c) { return dot(c, float3(0.299, 0.587, 0.114)); }
half4 outc(float3 c) { return half4(half3(clamp(c, 0.0, 1.0)), 1.0); }
float edgeAt(float2 p, float s) {
  float gx = luma(rgbAt(p + float2(s, 0.0))) - luma(rgbAt(p - float2(s, 0.0)));
  float gy = luma(rgbAt(p + float2(0.0, s))) - luma(rgbAt(p - float2(0.0, s)));
  return length(float2(gx, gy));
}
"""

    // ---------------------------------------------------------------- cembung (lensa pembesar, ada kilau)
    const val BULGE = """
half4 main(float2 p) {
  float2 q = p - ctr;
  float R = 0.42 * unit();
  float k = length(q) / R;
  if (k >= 1.0) return tap(p);
  float t = 1.0 - k * k;
  float s = 1.0 - 0.58 * t * t;
  float3 c = rgbAt(ctr + q * s);
  float hl = max(0.0, 1.0 - length(q / R - float2(-0.30, -0.34)) * 2.0);
  c = c * (1.0 + 0.10 * t) + hl * hl * 0.20 * t;
  return outc(c);
}
"""

    // ---------------------------------------------------------------- cekung (dicubit ke dalam, ada bayangan)
    const val DENT = """
half4 main(float2 p) {
  float2 q = p - ctr;
  float R = 0.46 * unit();
  float k = length(q) / R;
  if (k >= 1.0) return tap(p);
  float t = 1.0 - k * k;
  float s = 1.0 + 1.15 * t * t;
  float3 c = rgbAt(ctr + q * s) * (1.0 - 0.16 * t);
  return outc(c);
}
"""

    // ---------------------------------------------------------------- pusaran
    const val TWIRL = """
half4 main(float2 p) {
  float2 q = p - ctr;
  float R = 0.50 * unit();
  float k = length(q) / R;
  if (k >= 1.0) return tap(p);
  float t = 1.0 - k;
  float a = 3.6 * t * t;
  float cs = cos(a);
  float sn = sin(a);
  float2 r = float2(cs * q.x - sn * q.y, sn * q.x + cs * q.y);
  return tap(ctr + r);
}
"""

    // ---------------------------------------------------------------- bola kaca 3D (refraksi + kilau + tepi Fresnel)
    const val ORB = """
half4 main(float2 p) {
  float2 q = p - ctr;
  float R = 0.40 * unit();
  float k = length(q) / R;
  float3 base = rgbAt(p);
  if (k >= 1.0) {
    float sh = 1.0 - 0.30 * (1.0 - smoothstep(1.0, 1.2, k));
    return outc(base * sh);
  }
  float z = sqrt(1.0 - k * k);
  float s = mix(0.50, 1.50, k * k);
  float3 c = float3(
    rgbAt(ctr + q * (s * (1.0 + 0.025 * k))).r,
    rgbAt(ctr + q * s).g,
    rgbAt(ctr + q * (s * (1.0 - 0.025 * k))).b);
  float3 n = float3(q / R, z);
  float3 l = normalize(float3(-0.45, -0.55, 0.70));
  float3 h = normalize(l + float3(0.0, 0.0, 1.0));
  float diff = max(dot(n, l), 0.0);
  float spec = pow(max(dot(n, h), 0.0), 60.0);
  float fres = pow(1.0 - z, 3.0);
  c = c * (0.78 + 0.35 * diff) + spec * 0.9 + fres * 0.35 * float3(0.80, 0.90, 1.00);
  float a = 1.0 - smoothstep(0.985, 1.0, k);
  return outc(mix(base * 0.72, c, a));
}
"""

    // ---------------------------------------------------------------- liquid glass (lensa kaca ala macOS terbaru)
    const val GLASS = """
half4 main(float2 p) {
  float2 q = p - ctr;
  float R = 0.34 * unit();
  float k = length(q) / R;
  float3 base = rgbAt(p);
  if (k >= 1.0) {
    float sh = 1.0 - 0.24 * (1.0 - smoothstep(1.0, 1.25, k));
    return outc(base * sh);
  }
  float k3 = k * k * k;
  float s = 0.80 + 0.55 * pow(k, 5.0);
  float3 c = float3(
    rgbAt(ctr + q * (s * (1.0 + 0.035 * k3))).r,
    rgbAt(ctr + q * s).g,
    rgbAt(ctr + q * (s * (1.0 - 0.035 * k3))).b);
  c = mix(c, float3(1.0), 0.07);
  float2 dir = q / max(length(q), 0.0001);
  float ld = dot(dir, normalize(float2(-0.6, -0.8)));
  float rim = smoothstep(0.84, 1.0, k);
  c += rim * (0.22 + 0.50 * max(ld, 0.0));
  c *= 1.0 - rim * 0.20 * max(-ld, 0.0);
  float line = smoothstep(0.970, 0.992, k) * (1.0 - smoothstep(0.992, 1.0, k));
  c += line * 0.45;
  float2 g = q / R - float2(-0.38, -0.45);
  c += 0.10 * max(0.0, 1.0 - length(g) * 2.4);
  return outc(c);
}
"""

    // ---------------------------------------------------------------- anaglyph 3D (kacamata merah-biru)
    const val ANAGLYPH = """
half4 main(float2 p) {
  float u = unit();
  float3 c0 = rgbAt(p);
  float r = length(p - ctr) / u;
  float depth = clamp(0.55 * luma(c0) + 0.45 * (1.0 - r / 0.75), 0.0, 1.0);
  float off = u * 0.024 * (depth - 0.12);
  float3 a = rgbAt(p + float2(off, 0.0));
  float3 b = rgbAt(p - float2(off, 0.0));
  float3 o = float3(a.r, b.g, b.b) * 1.06;
  return outc(o);
}
"""

    // ---------------------------------------------------------------- cermin (sumbu = titik yang digeser)
    const val MIRROR = """
half4 main(float2 p) {
  float2 q = p;
  if (p.x > ctr.x) q.x = 2.0 * ctr.x - p.x;
  float3 c = rgbAt(q);
  float seam = 1.0 - smoothstep(0.0, unit() * 0.004, abs(p.x - ctr.x));
  return outc(c + seam * 0.25);
}
"""

    // ---------------------------------------------------------------- kaleidoskop (berputar pelan)
    const val KALEIDO = """
half4 main(float2 p) {
  float2 q = p - ctr;
  float r = length(q);
  float seg = 6.2831853 / 6.0;
  float a = atan(q.y, q.x) + time * 0.20;
  a = abs(mod(a, seg) - seg * 0.5) + 0.9;
  float2 s = ctr + 0.85 * r * float2(cos(a), sin(a));
  return tap(s);
}
"""

    // ---------------------------------------------------------------- terowongan cahaya (bergerak)
    const val TUNNEL = """
half4 main(float2 p) {
  float u = unit();
  float2 q = p - ctr;
  float r = max(length(q) / u, 0.002);
  float a = atan(q.y, q.x);
  float v = fract(log2(r / 0.07) - time * 0.35);
  float rad = 0.07 * exp2(v) * 2.6;
  float3 c = rgbAt(ctr + float2(cos(a), sin(a)) * rad * u);
  float depth = smoothstep(0.0, 0.14, r);
  return outc(c * mix(0.30, 1.0, depth));
}
"""

    // ---------------------------------------------------------------- tarik (wajah memanjang)
    const val STRETCH = """
half4 main(float2 p) {
  float u = unit();
  float2 d = (p - ctr) / u;
  float g = exp(-dot(d, d) / (2.0 * 0.22 * 0.22));
  float2 q = p - ctr;
  float2 s = float2(q.x * (1.0 + 0.30 * g), q.y * (1.0 - 0.60 * g));
  return tap(ctr + s);
}
"""

    // ---------------------------------------------------------------- kamera termal
    const val THERMAL = """
half4 main(float2 p) {
  float l = clamp((luma(rgbAt(p)) - 0.04) * 1.15, 0.0, 1.0);
  float3 c = mix(float3(0.00, 0.00, 0.25), float3(0.45, 0.00, 0.70), smoothstep(0.00, 0.25, l));
  c = mix(c, float3(0.95, 0.10, 0.15), smoothstep(0.25, 0.50, l));
  c = mix(c, float3(1.00, 0.75, 0.05), smoothstep(0.50, 0.75, l));
  c = mix(c, float3(1.00, 1.00, 0.85), smoothstep(0.75, 1.00, l));
  return outc(c);
}
"""

    // ---------------------------------------------------------------- hologram (warna pelangi tipis film)
    const val HOLO = """
half4 main(float2 p) {
  float3 c = rgbAt(p);
  float l = luma(c);
  float2 uv = p / res;
  float h = l * 1.6 + uv.x * 0.9 - uv.y * 0.5 + time * 0.12;
  float3 irid = 0.5 + 0.5 * cos(6.2831853 * (h + float3(0.0, 0.33, 0.67)));
  float band = smoothstep(0.55, 1.0, 0.5 + 0.5 * sin(6.2831853 * (uv.x * 0.8 + uv.y * 0.6 - time * 0.18)));
  float3 o = mix(c, c * 0.55 + irid * 0.65, 0.60) + band * 0.12;
  return outc(o);
}
"""

    // ---------------------------------------------------------------- komik (posterisasi + garis tinta + halftone)
    const val COMIC = """
half4 main(float2 p) {
  float u = unit();
  float s = max(1.0, u * 0.004);
  float e = edgeAt(p, s);
  float3 c = rgbAt(p);
  float l = luma(c);
  c = mix(float3(l), c, 1.5);
  c = floor(c * 4.0 + 0.5) / 4.0;
  float cell = max(5.0, u * 0.014);
  float2 f = fract(p / cell) - 0.5;
  float tone = clamp((0.55 - l) * 1.7, 0.0, 1.0);
  float ink = 1.0 - smoothstep(0.5 * sqrt(tone) - 0.06, 0.5 * sqrt(tone), length(f));
  c *= 1.0 - 0.45 * ink * step(0.02, tone);
  float line = smoothstep(0.10, 0.22, e);
  return outc(mix(c, float3(0.0), line));
}
"""

    // ---------------------------------------------------------------- sketsa pensil
    const val SKETCH = """
half4 main(float2 p) {
  float u = unit();
  float s = max(1.0, u * 0.003);
  float e = edgeAt(p, s) + 0.5 * edgeAt(p, s * 2.5);
  float3 c = rgbAt(p);
  float l = luma(c);
  float ink = clamp(e * 4.5, 0.0, 1.0);
  float hatch = step(0.5, fract((p.x + p.y) / max(4.0, u * 0.011)));
  float dark = 1.0 - smoothstep(0.15, 0.55, l);
  float3 paper = float3(0.96, 0.94, 0.89);
  float3 o = paper * (1.0 - ink * 0.85) * (1.0 - 0.25 * dark * hatch);
  o *= mix(float3(1.0), c * 1.4, 0.20);
  return outc(o);
}
"""

    // ---------------------------------------------------------------- neon (garis tepi bercahaya)
    const val NEON = """
half4 main(float2 p) {
  float u = unit();
  float s = max(1.0, u * 0.004);
  float e = clamp((edgeAt(p, s) + 0.6 * edgeAt(p, s * 3.0)) * 5.0, 0.0, 1.0);
  float3 c = rgbAt(p);
  float2 uv = p / res;
  float3 g = 0.5 + 0.5 * cos(6.2831853 * (luma(c) + uv.x * 0.5 + time * 0.10 + float3(0.0, 0.33, 0.67)));
  return outc(c * 0.18 + g * e * 1.35);
}
"""

    // ---------------------------------------------------------------- preview (RenderEffect di TextureView)

    /** Memasang / memperbarui shader di sebuah View. Hanya dibuat saat [supported]. */
    class Live(private val view: View) {
        private var sh: RuntimeShader? = null
        private var code: String? = null
        private var broken: String? = null

        /** [body] = isi shader (salah satu konstanta di atas) atau null untuk mencopot efek. cx/cy 0..1 = titik pusat. */
        fun apply(body: String?, cx: Float, cy: Float, t: Float) {
            if (!supported) return
            try {
                if (body == null) {
                    if (code != null) view.setRenderEffect(null)
                    sh = null
                    code = null
                    return
                }
                if (broken == body) return
                val w = view.width.toFloat()
                val h = view.height.toFloat()
                if (w <= 0f || h <= 0f) return
                var s = sh
                if (s == null || code != body) {
                    s = RuntimeShader(HEAD + body)
                    sh = s
                    code = body
                }
                s.setFloatUniform("res", w, h)
                s.setFloatUniform("ctr", cx * w, cy * h)
                s.setFloatUniform("time", t)
                view.setRenderEffect(RenderEffect.createRuntimeShaderEffect(s, "content"))
            } catch (e: Throwable) {
                Log.w(TAG, "shader preview gagal", e)
                broken = body
                sh = null
                code = null
                try {
                    view.setRenderEffect(null)
                } catch (e2: Throwable) {
                }
            }
        }
    }

    // ---------------------------------------------------------------- foto hasil (shader yang sama, ke bitmap)

    /**
     * Jalankan shader ke [src] (bitmap tegak + cermin, ukuran penuh) dan kembalikan bitmap baru ARGB_8888.
     * Mengembalikan null kalau GPU / API tidak mendukung; pemanggil lalu memakai [src] apa adanya.
     * [src] TIDAK di-recycle di sini.
     */
    fun render(src: Bitmap, body: String, cx: Float, cy: Float, t: Float): Bitmap? {
        if (!supported) return null
        var reader: ImageReader? = null
        var node: RenderNode? = null
        var hr: HardwareRenderer? = null
        var ht: HandlerThread? = null
        try {
            val w = src.width
            val h = src.height
            val s = RuntimeShader(HEAD + body)
            s.setFloatUniform("res", w.toFloat(), h.toFloat())
            s.setFloatUniform("ctr", cx * w, cy * h)
            s.setFloatUniform("time", t)

            val r = ImageReader.newInstance(
                w, h, PixelFormat.RGBA_8888, 2,
                HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE or HardwareBuffer.USAGE_GPU_COLOR_OUTPUT
            )
            reader = r
            val latch = CountDownLatch(1)
            val th = HandlerThread("lobo-fx")
            th.start()
            ht = th
            r.setOnImageAvailableListener({ latch.countDown() }, Handler(th.looper))

            val n = RenderNode("lobo-fx")
            node = n
            n.setPosition(0, 0, w, h)
            n.setRenderEffect(RenderEffect.createRuntimeShaderEffect(s, "content"))
            val rc = n.beginRecording(w, h)
            rc.drawBitmap(src, 0f, 0f, null)
            n.endRecording()

            val rend = HardwareRenderer()
            hr = rend
            rend.setSurface(r.surface)
            rend.setContentRoot(n)
            rend.createRenderRequest().syncAndDraw()
            if (!latch.await(2000L, TimeUnit.MILLISECONDS)) return null

            val img = r.acquireLatestImage() ?: return null
            var out: Bitmap? = null
            try {
                val hb = img.hardwareBuffer
                if (hb != null) {
                    val hw = Bitmap.wrapHardwareBuffer(hb, null)
                    out = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hw?.recycle()
                    hb.close()
                }
            } finally {
                img.close()
            }
            return out
        } catch (e: Throwable) {
            Log.w(TAG, "shader foto gagal", e)
            return null
        } finally {
            try {
                hr?.destroy()
            } catch (e: Throwable) {
            }
            try {
                node?.discardDisplayList()
            } catch (e: Throwable) {
            }
            try {
                reader?.close()
            } catch (e: Throwable) {
            }
            try {
                ht?.quitSafely()
            } catch (e: Throwable) {
            }
        }
    }
}
