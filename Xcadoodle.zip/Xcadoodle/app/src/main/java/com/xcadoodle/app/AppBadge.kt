package com.xcadoodle.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.Drawable
import android.view.View

/**
 * Logo kecil app pemutar musik. Spotify digambar sendiri (lingkaran hijau + tiga gelombang),
 * app lain memakai ikon aslinya.
 */
class AppBadgeView(c: Context) : View(c) {
    private var spotify = false
    private var icon: Drawable? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wave = Path()

    fun setPkg(pkg: String) {
        spotify = pkg == "com.spotify.music" || pkg.startsWith("com.spotify.")
        icon = if (spotify || pkg.isEmpty()) null else try {
            context.packageManager.getApplicationIcon(pkg)
        } catch (e: Exception) {
            null
        }
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        if (!spotify) {
            val ic = icon ?: return
            val ring = context.dpf(1.5f)
            p.style = Paint.Style.FILL
            p.color = 0xFF000000.toInt()
            cv.drawCircle(w / 2f, h / 2f, w / 2f, p)
            ic.setBounds(ring.toInt(), ring.toInt(), (w - ring).toInt(), (h - ring).toInt())
            ic.draw(cv)
            return
        }
        val ring = context.dpf(1.6f)
        p.style = Paint.Style.FILL
        p.color = 0xFF000000.toInt()
        cv.drawCircle(w / 2f, h / 2f, w / 2f, p)
        p.color = 0xFF1DB954.toInt()
        cv.drawCircle(w / 2f, h / 2f, w / 2f - ring, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.color = 0xFF0B0B0B.toInt()
        fun arc(x0: Float, y0: Float, cy: Float, x1: Float, y1: Float, sw: Float) {
            wave.reset()
            wave.moveTo(x0 * w, y0 * h)
            wave.quadTo(0.5f * w, cy * h, x1 * w, y1 * h)
            p.strokeWidth = sw * w
            cv.drawPath(wave, p)
        }
        arc(0.25f, 0.375f, 0.285f, 0.76f, 0.43f, 0.095f)
        arc(0.28f, 0.52f, 0.455f, 0.72f, 0.58f, 0.078f)
        arc(0.31f, 0.655f, 0.60f, 0.68f, 0.715f, 0.062f)
    }
}
