# R8 untuk Lobo.
# Shizuku dipanggil lewat refleksi (Priv.kt: Shizuku::class.java.getDeclaredMethod("newProcess", ...)),
# jadi nama kelas & method-nya TIDAK boleh diacak atau dibuang.
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-dontwarn rikka.**
-dontwarn moe.shizuku.**

# Stack trace tetap bisa dibaca kalau ada crash
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
