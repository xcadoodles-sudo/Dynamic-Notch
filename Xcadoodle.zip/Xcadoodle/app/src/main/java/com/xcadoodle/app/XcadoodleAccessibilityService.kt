package com.xcadoodle.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Tidak membaca apa pun dari layar. Fungsinya cuma menyediakan jendela overlay jenis
 * TYPE_ACCESSIBILITY_OVERLAY, yang boleh menempel di tepi atas dan menerima sentuhan
 * di atas status bar.
 */
class XcadoodleAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: XcadoodleAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        NotchService.instance?.rebuildOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    }

    override fun onInterrupt() {
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        NotchService.instance?.rebuildOverlay()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
