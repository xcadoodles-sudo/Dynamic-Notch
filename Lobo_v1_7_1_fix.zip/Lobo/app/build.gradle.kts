plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lobo.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.lobo.app"
        minSdk = 26
        targetSdk = 34
        // versionCode = menit sejak 1970 -> SELALU naik di tiap build, walau repo dibuat ulang / dipindah ke
        // repo private (nomor run GitHub akan mulai dari 1 lagi dan Android menolak "downgrade").
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "1.7.1"
    }

    // Kunci tanda tangan TETAP (ikut di repo). Tanpa ini tiap build GitHub memakai debug key acak,
    // dan Android menolak update di atas versi sebelumnya (harus uninstall + izin ulang).
    signingConfigs {
        create("lobo") {
            storeFile = file("lobo-release-key.jks")
            storePassword = "lobo-notch"
            keyAlias = "lobo"
            keyPassword = "lobo-notch"
        }
    }

    buildTypes {
        debug {
            // build non-debuggable: tanpa agen debug, lebih ringan di RAM/CPU (tetap pakai kunci tanda tangan tetap)
            isDebuggable = false
            signingConfig = signingConfigs.getByName("lobo")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("lobo")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
