package com.lobo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.content.ContextCompat

object Notifier {
    private var nid = 100
    fun post(ctx: Context, title: String, text: String) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(ctx, NotchService.CH_ALERT)
                .setSmallIcon(R.drawable.ic_stat_lobo)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(nid++, n)
        } catch (e: Exception) {
        }
    }
}

class NotchService : Service() {
    companion object {
        const val ACTION_STOP = "com.lobo.app.STOP"
        private const val CH_SERVICE = "lobo_service"
        const val CH_ALERT = "lobo_alerts"
        @Volatile
        var instance: NotchService? = null

        fun isRunning(): Boolean = instance != null

        fun start(c: Context) {
            val i = Intent(c, NotchService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, NotchService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var media: MediaWatcher
    private var view: NotchView? = null
    private var overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private val h = Handler(Looper.getMainLooper())
    private var startedAt = 0L

    private var lastPlugged = -1
    private var lowFired = false
    private var critFired = false
    private var fullFired = false
    private var netState = ""
    private var lastBt = ""
    private var lastBtAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        startedAt = SystemClock.elapsedRealtime()
        createChannels()
        goForeground()
        if (!Settings.canDrawOverlays(this) && LoboAccessibilityService.instance == null) {
            stopSelf()
            return
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        media = MediaWatcher(this) {
            view?.refreshData()
        }
        media.start()
        addOverlay()
        ClipWatcher.start(this)
        Bus.sink = { a -> view?.enqueue(a) }
        Bus.dataChanged = { view?.refreshData() }
        registerSystemListeners()
    }

    override fun onDestroy() {
        ClipWatcher.stop()
        Bus.sink = null
        Bus.dataChanged = null
        try {
            unregisterReceiver(batteryRx)
        } catch (e: Exception) {
        }
        try {
            unregisterReceiver(btRx)
        } catch (e: Exception) {
        }
        try {
            (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(netCb)
        } catch (e: Exception) {
        }
        if (this::media.isInitialized) media.stop()
        try {
            view?.let { wm.removeViewImmediate(it) }
        } catch (e: Exception) {
        }
        view = null
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------- foreground + overlay

    private fun createChannels() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "Lobo notch", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Lobo reminders", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun goForeground() {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, NotchService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat_lobo)
            .setContentTitle("Lobo is running")
            .setContentText("Your living notch is active")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    /**
     * Semua jendela notch (pil tetap + jendela panel/alert yang dibuat sesuai kebutuhan) dibuat lewat
     * sini supaya tipe, posisi, dan flag-nya seragam. FLAG_HARDWARE_ACCELERATED penting: tanpa itu
     * jendela overlay yang ditambahkan lewat WindowManager digambar CPU dan animasinya patah-patah.
     */
    private val overlayHost = object : OverlayHost {
        override fun params(w: Int, h: Int): WindowManager.LayoutParams {
            val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
            val p = WindowManager.LayoutParams(w, h, overlayType, flags, PixelFormat.TRANSLUCENT)
            p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            p.y = dp(Lobo.prefs.topOffset)
            p.title = "LoboNotch"
            p.windowAnimations = android.R.style.Animation
            if (Build.VERSION.SDK_INT >= 28) {
                p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            return p
        }

        override fun add(v: View, lp: WindowManager.LayoutParams): Boolean {
            return try {
                wm.addView(v, lp)
                true
            } catch (e: Exception) {
                false
            }
        }

        override fun remove(v: View) {
            try {
                wm.removeViewImmediate(v)
            } catch (e: Exception) {
            }
        }

        override fun setFocusable(v: View, focusable: Boolean) {
            try {
                val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
                if (focusable) {
                    lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                    lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING or
                        WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
                } else {
                    lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                }
                wm.updateViewLayout(v, lp)
            } catch (e: Exception) {
            }
        }

        override fun canType(): Boolean = overlayType != WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
    }

    private fun addOverlay() {
        val acc = LoboAccessibilityService.instance
        val hostCtx: Context = acc ?: this
        wm = hostCtx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        overlayType = if (acc != null) {
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        }
        val v = NotchView(hostCtx, media, overlayHost)
        if (overlayHost.add(v, overlayHost.params(v.winW, v.winH))) view = v
    }

    /** Dipanggil saat izin Accessibility dinyalakan/dimatikan: pasang ulang jendela notch. */
    fun rebuildOverlay() {
        try {
            view?.let { wm.removeViewImmediate(it) }
        } catch (e: Exception) {
        }
        view = null
        if (Settings.canDrawOverlays(this) || LoboAccessibilityService.instance != null) addOverlay()
    }

    /** Buka panel di tab tertentu (dipakai activity kecil setelah selesai, mis. tambah to-do). */
    fun openTab(t: Int) {
        view?.showPanel(t)
    }

    /** Dipanggil MainActivity kalau pengaturan (maskot, minimal, ukuran, offset) berubah. */
    fun refreshSettings() {
        rebuildOverlay()
    }

    // ---------------------------------------------------------- baterai, jaringan, bluetooth

    private fun registerSystemListeners() {
        ContextCompat.registerReceiver(this, batteryRx, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        val bf = IntentFilter()
        bf.addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
        bf.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        ContextCompat.registerReceiver(this, btRx, bf, ContextCompat.RECEIVER_NOT_EXPORTED)
        try {
            (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).registerDefaultNetworkCallback(netCb, h)
        } catch (e: Exception) {
        }
    }

    private val batteryRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level < 0 || scale <= 0) return
            val pct = level * 100 / scale
            val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            if (lastPlugged == -1) {
                lastPlugged = if (plugged) 1 else 0
            } else if (plugged && lastPlugged == 0) {
                lastPlugged = 1
                Bus.alert(Alert("Charger connected", "Charging · $pct%", "⚡", C.GREEN))
            } else if (!plugged && lastPlugged == 1) {
                lastPlugged = 0
                Bus.alert(Alert("Charger unplugged", "$pct% remaining", "🔌", C.ORANGE))
            }
            if (!plugged) {
                fullFired = false
                if (pct <= 10) {
                    if (!critFired) {
                        critFired = true
                        lowFired = true
                        Bus.alert(Alert("Battery critical", "Plug in now · $pct% remaining", "🪫", C.RED, ms = 5000))
                    }
                } else if (pct <= 20) {
                    critFired = false
                    if (!lowFired) {
                        lowFired = true
                        Bus.alert(Alert("Low battery", "Plug in soon · $pct% remaining", "🪫", C.ORANGE, ms = 4500))
                    }
                } else {
                    lowFired = false
                    critFired = false
                }
            } else {
                lowFired = false
                critFired = false
                if (pct >= 100 && !fullFired) {
                    fullFired = true
                    Bus.alert(Alert("Fully charged", "You can unplug", "🔋", C.GREEN))
                }
            }
        }
    }

    private val btRx = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            val d: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
                i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
            } else {
                i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
            }
            val name = (try {
                d?.name
            } catch (e: SecurityException) {
                null
            }) ?: "Bluetooth device"
            val connected = i.action == BluetoothDevice.ACTION_ACL_CONNECTED
            val key = name + connected
            val now = SystemClock.elapsedRealtime()
            if (key == lastBt && now - lastBtAt < 5000) return
            lastBt = key
            lastBtAt = now
            if (connected) {
                Bus.alert(Alert("Connected", name, "🎧", C.BLUE))
            } else {
                Bus.alert(Alert("Disconnected", name, "🎧", C.SUB))
            }
        }
    }

    private val netCb = object : ConnectivityManager.NetworkCallback() {
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            val ok = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            val how = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Network"
            }
            setNet(if (ok) "online" else "limited", how)
        }

        override fun onLost(network: Network) {
            setNet("offline", "")
        }
    }

    private fun setNet(st: String, how: String) {
        if (st == netState) return
        val first = netState == ""
        netState = st
        if (first || SystemClock.elapsedRealtime() - startedAt < 3000) return
        when (st) {
            "online" -> Bus.alert(Alert("Connected", how, "📶", C.GREEN))
            "limited" -> Bus.alert(Alert("No internet access", how, "📵", C.ORANGE))
            else -> Bus.alert(Alert("Disconnected", "No network", "📵", C.RED))
        }
    }
}
