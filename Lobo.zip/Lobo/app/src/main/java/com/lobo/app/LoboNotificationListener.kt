package com.lobo.app

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Dua fungsi: (1) syarat agar MediaSessionManager boleh membaca sesi musik,
 * (2) meneruskan notifikasi app lain ke notch — bisa dibuka (ketuk) dan, kalau app-nya
 * menyediakan aksi balas (WhatsApp, Telegram, SMS, dll), bisa dibalas langsung dari notch.
 */
class LoboNotificationListener : NotificationListenerService() {

    /** Cari aksi "Reply" bawaan notifikasi (yang punya kolom teks bebas). */
    private fun findReply(n: Notification): Notification.Action? {
        val acts = n.actions ?: return null
        var best: Notification.Action? = null
        for (a in acts) {
            if (a.actionIntent == null) continue
            val ris = a.remoteInputs ?: continue
            if (ris.none { it.allowFreeFormInput }) continue
            if (Build.VERSION.SDK_INT >= 28 && a.semanticAction == Notification.Action.SEMANTIC_ACTION_REPLY) return a
            if (best == null) best = a
        }
        return best
    }

    private fun sendReply(ctx: Context, a: Notification.Action, text: String, key: String): Boolean {
        return try {
            val inputs = a.remoteInputs ?: return false
            val intent = Intent()
            val b = Bundle()
            for (ri in inputs) b.putCharSequence(ri.resultKey, text)
            RemoteInput.addResultsToIntent(inputs, intent, b)
            ReplyGuard.mute(key)
            a.actionIntent.send(ctx, 0, intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (!NotchService.isRunning() || !Lobo.prefs.notifAlerts) return
        if (sbn.packageName == packageName) return
        if (sbn.isOngoing) return
        if (ReplyGuard.muted(sbn.key)) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val cat = n.category
        if (cat == Notification.CATEGORY_TRANSPORT || cat == Notification.CATEGORY_PROGRESS || cat == Notification.CATEGORY_SERVICE) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim() ?: ""
        if (title.isBlank() && text.isBlank()) return
        val pm = packageManager
        val label = try {
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        val icon = try {
            pm.getApplicationIcon(sbn.packageName)
        } catch (e: Exception) {
            null
        }
        val pi = n.contentIntent
        val ctx = applicationContext
        val act = findReply(n)
        val key = sbn.key
        val replyFn: ((String) -> Boolean)? = if (act != null) {
            { t -> sendReply(ctx, act, t, key) }
        } else {
            null
        }
        Bus.alert(
            Alert(
                if (title.isBlank()) label else title,
                if (text.isBlank()) label else text,
                "🔔", C.BLUE, icon,
                if (replyFn != null) 7000L else 4500L,
                onClick = { fireIntent(ctx, pi) },
                reply = replyFn
            )
        )
    }
}
