package com.lobo.app

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.DateFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ DEVICE (minimalis)

class DevicePanel(private val c: Context) : FrameLayout(c), Refreshable, PanelLife {
    private class Card(val value: TextView, val bar: ProgressLine, val sub: TextView)

    private val cpu: Card
    private val gpu: Card
    private val ram: Card
    private val bat: Card
    private val tThermal = c.tv("", 12f, C.SUB)
    private val tChip = c.tv("", 12f, C.SUB)
    private var last = 0L

    private fun card(label: String, row: LinearLayout, first: Boolean): Card {
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_VERTICAL
        col.background = glass(C.GLASS, c.dpf(18))
        col.setPadding(c.dp(14), c.dp(12), c.dp(14), c.dp(12))
        col.addView(c.tv(label, 12f, C.SUB, true))
        val v = c.tv("—", 30f, C.TEXT, true)
        col.addView(v, c.llp(WRAP, WRAP, 0f, 0, 6, 0, 8))
        val b = ProgressLine(c)
        col.addView(b, c.llp(MATCH, c.dp(10), 0f, 0, 0, 0, 8))
        val s = c.tv("", 12f, C.SUB)
        s.maxLines = 1
        s.ellipsize = TextUtils.TruncateAt.END
        col.addView(s)
        row.addView(col, c.llp(0, MATCH, 1f, if (first) 0 else 8, 0, 0, 0))
        return Card(v, b, s)
    }

    init {
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(c)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(c.tv("Device", 15f, C.TEXT, true))
        tChip.maxLines = 1
        tChip.ellipsize = TextUtils.TruncateAt.END
        head.addView(tChip, c.llp(WRAP, WRAP, 0f, 10, 1, 0, 0))
        head.addView(View(c), c.llp(0, 1, 1f))
        head.addView(tThermal)
        col.addView(head, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        val row = LinearLayout(c)
        cpu = card("CPU", row, true)
        gpu = card("GPU", row, false)
        ram = card("MEMORY", row, false)
        bat = card("BATTERY", row, false)
        col.addView(row, c.llp(MATCH, 0, 1f))
        addView(col, LayoutParams(MATCH, MATCH))
    }

    override fun onVisible(v: Boolean) {
        if (v) PrivSampler.start() else PrivSampler.stop()
    }

    private fun barColor(p: Float): Int = if (p >= 92f) C.RED else if (p >= 80f) C.ORANGE else C.TEXT

    private fun parts(vararg p: String?): String {
        val l = p.filterNotNull()
        return if (l.isEmpty()) "n/a" else l.joinToString(" · ")
    }

    private fun temp(t: Float): String? = if (t.isNaN()) null else "%.0f°C".format(t)

    override fun refresh() {
        val now = SystemClock.elapsedRealtime()
        if (now - last < 900) return
        last = now
        val s = DeviceStats.sample(c)
        tChip.text = Soc.line()

        cpu.value.text = if (s.cpu < 0f) "—" else "%.0f%%".format(s.cpu)
        cpu.bar.fillColor = barColor(s.cpu)
        cpu.bar.frac = if (s.cpu < 0f) 0f else s.cpu / 100f
        cpu.sub.text = parts(temp(s.cpuTemp), if (s.cpuGhz > 0f) "%.1f GHz".format(s.cpuGhz) else null)

        gpu.value.text = if (s.gpu < 0f) "—" else "%.0f%%".format(s.gpu)
        gpu.bar.fillColor = barColor(s.gpu)
        gpu.bar.frac = if (s.gpu < 0f) 0f else s.gpu / 100f
        gpu.sub.text = parts(temp(s.gpuTemp), if (s.gpuMhz > 0f) "%.0f MHz".format(s.gpuMhz) else null)

        ram.value.text = "%.0f%%".format(s.memPct)
        ram.bar.fillColor = barColor(s.memPct)
        ram.bar.frac = s.memPct / 100f
        ram.sub.text = "%.1f / %.0f GB".format(s.memUsedGb, s.memTotalGb)

        bat.value.text = if (s.batPct < 0) "—" else "${s.batPct}%"
        bat.bar.fillColor = if (s.charging) C.GREEN else if (s.batPct in 0..15) C.RED else C.TEXT
        bat.bar.frac = if (s.batPct < 0) 0f else s.batPct / 100f
        bat.sub.text = parts(if (s.charging) "Charging" else null, temp(s.batTemp))

        val tl = ArrayList<String>()
        if (s.priv) tl.add("Shizuku")
        if (s.thermal.isNotEmpty()) tl.add("Thermal ${s.thermal}")
        tThermal.text = tl.joinToString(" · ")
    }
}

// ------------------------------------------------------------------ MARKETS

class MarketsPanel(private val c: Context) : FrameLayout(c), Refreshable, PanelLife {
    private class Row(val sym: Sym, val root: LinearLayout, val price: TextView, val chg: TextView)

    private val list = LinearLayout(c)
    private val rows = ArrayList<Row>()
    private var ver = -1
    private val tName = c.tv("", 13f, C.TEXT, true)
    private val tDesc = c.tv("", 12f, C.SUB)
    private val tPrice = c.tv("—", 28f, C.TEXT, true)
    private val tChg = c.tv("", 13f, C.SUB, true)
    private val chart = ChartView(c)
    private val chips = ArrayList<Pair<String, TextView>>()
    private val tModeBtn = c.tv("▮", 13f, C.TEXT, true)

    /**
     * Arah harga simbol yang sedang dipilih (sesuai angka perubahan yang tampil di panel):
     * 1 = naik/tetap, -1 = turun, 0 = belum ada data. NotchView memakainya untuk warna gradasi tab ini.
     */
    var trend = 0
        private set

    /** Dipanggil kalau [trend] berubah (ganti simbol, ganti timeframe, atau harga melewati titik awal). */
    var onTrend: (() -> Unit)? = null

    private fun setTrend(t: Int) {
        if (t == trend) return
        trend = t
        onTrend?.invoke()
    }

    init {
        val root = LinearLayout(c)

        // ---- kiri: watchlist
        val left = LinearLayout(c)
        left.orientation = LinearLayout.VERTICAL
        val lh = LinearLayout(c)
        lh.gravity = Gravity.CENTER_VERTICAL
        lh.addView(c.tv("Watchlist", 13f, C.SUB, true))
        lh.addView(View(c), c.llp(0, 1, 1f))
        val add = c.tv("＋", 16f, C.TEXT, true)
        add.setPadding(c.dp(10), c.dp(2), c.dp(6), c.dp(2))
        add.setOnClickListener { openEdit(null) }
        lh.addView(add)
        left.addView(lh, c.llp(MATCH, WRAP, 0f, 4, 0, 0, 4))
        val sv = ScrollView(c)
        sv.isVerticalScrollBarEnabled = false
        list.orientation = LinearLayout.VERTICAL
        sv.addView(list, LayoutParams(MATCH, WRAP))
        left.addView(sv, c.llp(MATCH, 0, 1f))
        root.addView(left, c.llp(c.dp(190), MATCH, 0f, 0, 0, 14, 0))

        // ---- kanan: harga + chart
        val right = LinearLayout(c)
        right.orientation = LinearLayout.VERTICAL
        val top = LinearLayout(c)
        top.gravity = Gravity.CENTER_VERTICAL
        val names = LinearLayout(c)
        names.orientation = LinearLayout.VERTICAL
        tDesc.maxLines = 1
        tDesc.ellipsize = TextUtils.TruncateAt.END
        names.addView(tName)
        names.addView(tDesc, c.llp(WRAP, WRAP, 0f, 0, 1, 0, 0))
        top.addView(names, c.llp(0, WRAP, 1f))
        for (tf in Markets.tfs) {
            val t = c.tv(tf.label, 12f, C.TEXT, true)
            t.setPadding(c.dp(8), c.dp(5), c.dp(8), c.dp(5))
            t.setOnClickListener {
                Markets.setTf(tf.id)
                refresh()
            }
            chips.add(Pair(tf.id, t))
            top.addView(t, c.llp(WRAP, WRAP, 0f, 1, 0, 0, 0))
        }
        tModeBtn.setPadding(c.dp(10), c.dp(5), c.dp(4), c.dp(5))
        tModeBtn.setOnClickListener {
            Lobo.prefs.mkCandles = !Lobo.prefs.mkCandles
            refresh()
        }
        top.addView(tModeBtn)
        right.addView(top, c.llp(MATCH, WRAP))
        val pr = LinearLayout(c)
        pr.gravity = Gravity.BOTTOM
        pr.addView(tPrice)
        tChg.setPadding(c.dp(10), 0, 0, c.dp(4))
        pr.addView(tChg)
        right.addView(pr, c.llp(MATCH, WRAP, 0f, 0, 2, 0, 4))
        right.addView(chart, c.llp(MATCH, 0, 1f))
        root.addView(right, c.llp(0, MATCH, 1f))
        addView(root, LayoutParams(MATCH, MATCH))
    }

    override fun onVisible(v: Boolean) {
        if (v) Markets.start() else Markets.stop()
    }

    private fun openEdit(remove: String?) {
        val i = Intent(c, SymbolEditActivity::class.java)
        if (remove != null) i.putExtra("remove", remove)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }

    private fun rebuild(syms: List<Sym>) {
        ver = Markets.version
        rows.clear()
        list.removeAllViews()
        for (s in syms) {
            val r = LinearLayout(c)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(c.dp(10), c.dp(7), c.dp(10), c.dp(7))
            val id = c.tv(s.id, 13f, C.TEXT, true)
            r.addView(id, c.llp(0, WRAP, 1f))
            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.END
            val p = c.tv("—", 13f, C.TEXT, true)
            val g = c.tv("", 12f, C.SUB, true)
            col.addView(p)
            col.addView(g)
            r.addView(col)
            r.setOnClickListener {
                Markets.select(s.id)
                refresh()
            }
            r.setOnLongClickListener {
                openEdit(s.id)
                true
            }
            list.addView(r, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 2))
            rows.add(Row(s, r, p, g))
        }
    }

    private fun upDown(v: Double): Int = if (v >= 0) C.GREEN else C.RED

    override fun refresh() {
        val syms = Markets.symbols()
        if (ver != Markets.version || rows.size != syms.size) rebuild(syms)
        val sel = Markets.selected()
        for (r in rows) {
            val q = Markets.quotes[r.sym.id]
            if (q != null) {
                r.price.text = fmtPrice(q.price, r.sym.dec)
                r.chg.text = fmtPct(q.dayPct)
                r.chg.setTextColor(upDown(q.dayPct))
            }
            r.root.background = if (r.sym.id == sel.id) glass(C.GLASS_SEL, c.dpf(12)) else null
        }

        val tf = Markets.tf()
        for ((key, t) in chips) {
            val on = key == tf.id
            t.background = if (on) glass(C.GLASS_SEL, c.dpf(100)) else null
            t.alpha = if (on) 1f else 0.5f
        }
        val candles = Lobo.prefs.mkCandles
        tModeBtn.text = if (candles) "▮" else "〰"
        tName.text = sel.id
        tDesc.text = if (Markets.failing && Markets.quotes[sel.id] == null) "Can't reach the market feed" else sel.name

        val q = Markets.quotes[sel.id + "|" + tf.id] ?: if (tf.id == Markets.tfs[0].id) Markets.quotes[sel.id] else null
        if (q?.note != null) tDesc.text = sel.name + " · " + q.note
        if (q == null) {
            tPrice.text = "—"
            tChg.text = ""
            setTrend(0)
            return
        }
        val base = if (tf.id == Markets.tfs[0].id) q.prev else if (q.closes.isNotEmpty()) q.closes[0] else q.prev
        val ch = if (base > 0) q.price - base else 0.0
        val pct = if (base > 0) ch / base * 100.0 else 0.0
        tPrice.text = fmtPrice(q.price, sel.dec)
        tChg.text = String.format(Locale.US, "%+.${minOf(sel.dec, 2)}f  %s", ch, fmtPct(pct))
        tChg.setTextColor(upDown(ch))
        setTrend(if (ch >= 0) 1 else -1)
        chart.setData(q, base, ch >= 0, sel.dec, tf.id != "d1", candles)
    }
}

// ------------------------------------------------------------------ CALENDAR + WEATHER

class CalendarPanel(private val c: Context) : FrameLayout(c), Refreshable, PanelLife {
    private val tDow = c.tv("", 12f, C.ACCENT, true)
    private val tDay = c.tv("", 44f, C.TEXT, true)
    private val tMonthSmall = c.tv("", 12f, C.SUB)
    private val tIcon = c.tv("", 28f)
    private val tTemp = c.tv("--°", 26f, C.TEXT, true)
    private val tCond = c.tv("Loading weather…", 12f, C.TEXT)
    private val tHiLo = c.tv("", 12f, C.SUB)
    private val forecast = LinearLayout(c)
    private val tTitle = c.tv("", 14f, C.TEXT, true)
    private val cells = ArrayList<TextView>()
    private val wdLabels = ArrayList<TextView>()

    private var vy = 0
    private var vm = 0
    private var sig = ""
    private var wxSig = ""

    init {
        val now = Calendar.getInstance()
        vy = now.get(Calendar.YEAR)
        vm = now.get(Calendar.MONTH)

        val root = LinearLayout(c)

        // ---- kiri: tanggal + cuaca
        val left = LinearLayout(c)
        left.orientation = LinearLayout.VERTICAL
        left.addView(tDow)
        left.addView(tDay, c.llp(WRAP, WRAP, 0f, 0, 2, 0, 0))
        left.addView(tMonthSmall, c.llp(WRAP, WRAP, 0f, 0, 2, 0, 10))
        val wr = LinearLayout(c)
        wr.gravity = Gravity.CENTER_VERTICAL
        wr.addView(tIcon, c.llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        wr.addView(tTemp)
        left.addView(wr)
        tCond.maxLines = 1
        tCond.ellipsize = TextUtils.TruncateAt.END
        tHiLo.maxLines = 1
        tHiLo.ellipsize = TextUtils.TruncateAt.END
        left.addView(tCond, c.llp(MATCH, WRAP, 0f, 0, 4, 0, 0))
        left.addView(tHiLo, c.llp(MATCH, WRAP, 0f, 0, 1, 0, 8))
        forecast.gravity = Gravity.CENTER_VERTICAL
        left.addView(forecast, c.llp(MATCH, WRAP))
        root.addView(left, c.llp(c.dp(190), MATCH, 0f, 0, 0, 16, 0))

        // ---- kanan: kalender bulanan
        val right = LinearLayout(c)
        right.orientation = LinearLayout.VERTICAL
        val hd = LinearLayout(c)
        hd.gravity = Gravity.CENTER_VERTICAL
        val prev = c.tv("‹", 22f, C.TEXT, true)
        prev.gravity = Gravity.CENTER
        prev.setOnClickListener { shift(-1) }
        val next = c.tv("›", 22f, C.TEXT, true)
        next.gravity = Gravity.CENTER
        next.setOnClickListener { shift(1) }
        tTitle.gravity = Gravity.CENTER
        tTitle.setOnClickListener {
            val n = Calendar.getInstance()
            vy = n.get(Calendar.YEAR)
            vm = n.get(Calendar.MONTH)
            refresh()
        }
        hd.addView(prev, c.llp(c.dp(44), c.dp(28)))
        hd.addView(tTitle, c.llp(0, WRAP, 1f))
        hd.addView(next, c.llp(c.dp(44), c.dp(28)))
        right.addView(hd, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 2))

        val wd = LinearLayout(c)
        for (j in 0 until 7) {
            val t = c.tv("", 11f, C.SUB, true)
            t.gravity = Gravity.CENTER
            wdLabels.add(t)
            wd.addView(t, c.llp(0, WRAP, 1f))
        }
        right.addView(wd, c.llp(MATCH, WRAP, 0f, 0, 2, 0, 4))

        val grid = LinearLayout(c)
        grid.orientation = LinearLayout.VERTICAL
        for (r in 0 until 6) {
            val row = LinearLayout(c)
            for (k in 0 until 7) {
                val cell = FrameLayout(c)
                val t = c.tv("", 12f, C.TEXT, true)
                t.gravity = Gravity.CENTER
                cell.addView(t, LayoutParams(c.dp(26), c.dp(26), Gravity.CENTER))
                cells.add(t)
                row.addView(cell, c.llp(0, MATCH, 1f))
            }
            grid.addView(row, c.llp(MATCH, 0, 1f))
        }
        right.addView(grid, c.llp(MATCH, 0, 1f))
        root.addView(right, c.llp(0, MATCH, 1f))
        addView(root, LayoutParams(MATCH, MATCH))
    }

    private fun shift(d: Int) {
        vm += d
        if (vm < 0) {
            vm = 11
            vy--
        } else if (vm > 11) {
            vm = 0
            vy++
        }
        refresh()
    }

    override fun onVisible(v: Boolean) {
        if (v) {
            WeatherRepo.refresh(c)
            val n = Calendar.getInstance()
            vy = n.get(Calendar.YEAR)
            vm = n.get(Calendar.MONTH)
            sig = ""
            refresh()
        }
    }

    private fun updateWeather() {
        WeatherRepo.loadCache()
        val w = WeatherRepo.current
        val s = if (w == null) "none" else "${w.at}"
        if (s == wxSig) return
        wxSig = s
        forecast.removeAllViews()
        if (w == null) {
            tIcon.text = ""
            tTemp.text = "--°"
            tCond.text = "Loading weather…"
            tHiLo.text = ""
            return
        }
        tIcon.text = Weather.emoji(w.code, w.isDay)
        tTemp.text = "%.0f°".format(w.temp)
        tCond.text = Weather.text(w.code)
        val hi = if (w.dayHi.isNotEmpty()) "%.0f°".format(w.dayHi[0]) else "--"
        val lo = if (w.dayLo.isNotEmpty()) "%.0f°".format(w.dayLo[0]) else "--"
        tHiLo.text = "H $hi  L $lo · ${w.place}"
        for (i in 1 until minOf(4, w.dayHi.size)) {
            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            val d = c.tv(w.dayName[i], 11f, C.SUB, true)
            val e = c.tv(Weather.emoji(w.dayCode[i], true), 16f)
            val t = c.tv("%.0f°/%.0f°".format(w.dayHi[i], w.dayLo[i]), 11f, C.TEXT)
            col.addView(d)
            col.addView(e, c.llp(WRAP, WRAP, 0f, 0, 2, 0, 2))
            col.addView(t)
            forecast.addView(col, c.llp(0, WRAP, 1f))
        }
    }

    override fun refresh() {
        val now = Calendar.getInstance()
        val today = now.get(Calendar.YEAR) * 10000 + now.get(Calendar.MONTH) * 100 + now.get(Calendar.DAY_OF_MONTH)
        val loc = Locale.getDefault()
        val s = "$vy-$vm-$today"
        if (s != sig) {
            sig = s
            tDow.text = SimpleDateFormat("EEEE", loc).format(Date()).uppercase(loc)
            tDay.text = now.get(Calendar.DAY_OF_MONTH).toString()
            tMonthSmall.text = SimpleDateFormat("MMMM yyyy", loc).format(Date())

            val cal = Calendar.getInstance()
            cal.clear()
            cal.set(vy, vm, 1)
            tTitle.text = SimpleDateFormat("MMMM yyyy", loc).format(cal.time)
            val first = cal.firstDayOfWeek
            val offset = (cal.get(Calendar.DAY_OF_WEEK) - first + 7) % 7
            val dim = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            val pc = Calendar.getInstance()
            pc.clear()
            pc.set(vy, vm, 1)
            pc.add(Calendar.MONTH, -1)
            val pdim = pc.getActualMaximum(Calendar.DAY_OF_MONTH)

            val names = DateFormatSymbols.getInstance(loc).shortWeekdays
            for (j in 0 until 7) {
                val wdIdx = ((first - 1 + j) % 7) + 1
                wdLabels[j].text = names[wdIdx].take(3).uppercase(loc)
            }
            for (i in 0 until 42) {
                val t = cells[i]
                val n = i - offset + 1
                val inMonth = n in 1..dim
                val num = if (n < 1) pdim + n else if (n > dim) n - dim else n
                t.text = num.toString()
                val isToday = inMonth && vy == now.get(Calendar.YEAR) && vm == now.get(Calendar.MONTH) && n == now.get(Calendar.DAY_OF_MONTH)
                t.setTextColor(if (isToday) C.TEXT else if (inMonth) C.TEXT else 0x44FFFFFF)
                t.background = if (isToday) rounded(C.ACCENT, c.dpf(100)) else null
            }
        }
        updateWeather()
    }
}
