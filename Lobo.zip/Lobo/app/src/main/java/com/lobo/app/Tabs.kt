package com.lobo.app

import android.content.Context
import android.view.MotionEvent
import android.widget.HorizontalScrollView

/**
 * Baris tab yang bisa digeser. Posisi selalu menempel ke kelipatan lebar satu tab ([step]), jadi
 * yang terlihat selalu tab utuh (mis. 4 dari 6). Geser pelan = menempel ke tab terdekat,
 * lempar = maju satu-dua tab.
 */
class SnapScroll(c: Context) : HorizontalScrollView(c) {
    /** Lebar satu tab dalam px. 0 = geser bebas. */
    var step = 0
    private var flung = false

    private fun snapTo(x: Float) {
        val child = getChildAt(0) ?: return
        val max = maxOf(0, child.width - width)
        val s = step
        val target = if (s <= 0) x.toInt() else Math.round(x / s) * s
        smoothScrollTo(target.coerceIn(0, max), 0)
    }

    override fun fling(velocityX: Int) {
        if (step <= 0) {
            super.fling(velocityX)
            return
        }
        flung = true
        snapTo(scrollX + velocityX * 0.22f)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) flung = false
        val r = super.onTouchEvent(ev)
        if (step > 0 && !flung && (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL)) {
            snapTo(scrollX.toFloat())
        }
        return r
    }
}
