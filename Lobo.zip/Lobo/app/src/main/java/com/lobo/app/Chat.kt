package com.lobo.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class ChatMsg(val role: String, var text: String, var error: Boolean = false)

/**
 * Chat dengan Claude lewat Anthropic Messages API (streaming). Hidup di luar panel, jadi jawaban
 * tetap berjalan kalau panel ditutup; kalau tidak ada panel Chat yang terbuka saat jawaban selesai,
 * notch menampilkan alert. Riwayat disimpan di file privat app (chat.json).
 *
 * Semua perubahan state terjadi di main thread; thread jaringan hanya mem-post hasilnya.
 */
object Chat {
    private const val API = "https://api.anthropic.com/v1/messages"
    private const val KEEP = 24
    private const val SYSTEM = "You are Claude, chatting inside a small floating notch panel on an Android tablet. " +
        "Keep answers short and direct, usually under 120 words. Use plain text: no markdown headings, tables " +
        "or bold markers, and no code fences unless the user asks for code. Reply in the language the user writes in."

    private val main = Handler(Looper.getMainLooper())
    val msgs = ArrayList<ChatMsg>()

    var busy = false
        private set

    /** Dipasang panel Chat selama terlihat. null = tidak ada yang melihat. */
    var listener: (() -> Unit)? = null

    private var loaded = false
    private var gen = 0
    @Volatile private var conn: HttpURLConnection? = null

    private fun file() = File(Lobo.app.filesDir, "chat.json")

    fun hasKey(): Boolean = Lobo.prefs.claudeKey.isNotBlank()

    fun load() {
        if (loaded) return
        loaded = true
        try {
            val f = file()
            if (!f.exists()) return
            val a = JSONArray(f.readText())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                msgs.add(ChatMsg(o.getString("r"), o.getString("t"), o.optBoolean("e", false)))
            }
        } catch (e: Exception) {
            msgs.clear()
        }
    }

    private fun save() {
        try {
            val a = JSONArray()
            for (m in msgs.takeLast(60)) a.put(JSONObject().put("r", m.role).put("t", m.text).put("e", m.error))
            file().writeText(a.toString())
        } catch (e: Exception) {
        }
    }

    private fun changed() {
        listener?.invoke()
    }

    fun clear() {
        load()
        cancelInternal()
        msgs.clear()
        save()
        changed()
    }

    /** Hentikan jawaban yang sedang mengalir (tombol stop). */
    fun cancel() {
        if (!busy) return
        cancelInternal()
        val last = msgs.lastOrNull()
        if (last != null && last.role == "assistant" && last.text.isBlank()) msgs.removeAt(msgs.size - 1)
        save()
        changed()
    }

    private fun cancelInternal() {
        gen++ // hasil dari thread lama diabaikan
        busy = false
        val c = conn
        conn = null
        if (c != null) thread { try { c.disconnect() } catch (e: Exception) { } }
    }

    fun send(text: String) {
        load()
        val t = text.trim()
        if (t.isEmpty() || busy) return
        msgs.add(ChatMsg("user", t))
        val key = Lobo.prefs.claudeKey.trim()
        if (key.isEmpty()) {
            msgs.add(ChatMsg("assistant", "Add your Anthropic API key first: open the Lobo app and fill in the Claude chat section.", true))
            save()
            changed()
            return
        }
        val reply = ChatMsg("assistant", "")
        val body = buildBody(Lobo.prefs.claudeModel.trim().ifEmpty { "claude-sonnet-5-5" }) // sebelum balasan kosong ditambahkan
        msgs.add(reply)
        busy = true
        val my = ++gen
        changed()
        thread(name = "lobo-chat") { stream(my, key, body, reply) }
    }

    private fun buildBody(model: String): String {
        val src = msgs.filter { !it.error && it.text.isNotBlank() }.takeLast(KEEP)
        val out = ArrayList<ChatMsg>()
        for (m in src) {
            val l = out.lastOrNull()
            if (l != null && l.role == m.role) out[out.size - 1] = ChatMsg(l.role, l.text + "\n\n" + m.text) else out.add(ChatMsg(m.role, m.text))
        }
        while (out.isNotEmpty() && out[0].role != "user") out.removeAt(0)
        val arr = JSONArray()
        for (m in out) arr.put(JSONObject().put("role", m.role).put("content", m.text))
        return JSONObject()
            .put("model", model)
            .put("max_tokens", 1024)
            .put("stream", true)
            .put("system", SYSTEM)
            .put("messages", arr)
            .toString()
    }

    private fun stream(my: Int, key: String, body: String, reply: ChatMsg) {
        var err: String? = null
        var c: HttpURLConnection? = null
        try {
            c = URL(API).openConnection() as HttpURLConnection
            conn = c
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.setRequestProperty("accept", "text/event-stream")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code != 200) {
                val raw = try {
                    (c.errorStream ?: c.inputStream).bufferedReader().readText()
                } catch (e: Exception) {
                    ""
                }
                err = apiError(code, raw)
            } else {
                c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
                    while (true) {
                        val line = r.readLine() ?: break
                        if (my != gen) break
                        if (!line.startsWith("data:")) continue
                        val d = line.substring(5).trim()
                        if (d.isEmpty()) continue
                        val j = try {
                            JSONObject(d)
                        } catch (e: Exception) {
                            continue
                        }
                        val type = j.optString("type")
                        if (type == "content_block_delta") {
                            val dl = j.optJSONObject("delta")
                            if (dl != null && dl.optString("type") == "text_delta") emit(my, reply, dl.optString("text"))
                        } else if (type == "error") {
                            err = j.optJSONObject("error")?.optString("message")?.ifBlank { null } ?: "Claude stopped responding."
                            break
                        } else if (type == "message_stop") {
                            break
                        }
                    }
                }
            }
        } catch (e: Exception) {
            if (my == gen) err = "Can't reach Claude. Check your connection."
        } finally {
            try {
                c?.disconnect()
            } catch (e: Exception) {
            }
        }
        val e2 = err
        main.post { finish(my, reply, e2) }
    }

    private fun emit(my: Int, reply: ChatMsg, s: String) {
        if (s.isEmpty()) return
        main.post {
            if (my == gen) {
                reply.text += s
                changed()
            }
        }
    }

    private fun finish(my: Int, reply: ChatMsg, err: String?) {
        if (my != gen) return
        busy = false
        conn = null
        if (err != null) {
            if (reply.text.isBlank()) {
                reply.text = err
                reply.error = true
            } else {
                reply.text += "\n\n[$err]"
            }
        } else if (reply.text.isBlank()) {
            reply.text = "(Claude sent an empty reply)"
            reply.error = true
        }
        save()
        changed()
        if (listener == null) {
            // tidak ada panel Chat yang terbuka: kabari lewat notch, ketuk = buka tab Chat
            if (reply.error) {
                Bus.alert(Alert("Claude", reply.text, "!", C.RED, ms = 4500L, tab = NotchView.CHAT_TAB))
            } else {
                Bus.alert(Alert("Claude replied", preview(reply.text), "💬", 0xFFE07B53.toInt(), ms = 5000L, tab = NotchView.CHAT_TAB))
            }
        }
    }

    private fun preview(s: String): String {
        val one = s.replace(Regex("\\s+"), " ").trim()
        return if (one.length > 110) one.substring(0, 107) + "…" else one
    }

    private fun apiError(code: Int, raw: String): String {
        val m = try {
            JSONObject(raw).optJSONObject("error")?.optString("message")?.ifBlank { null }
        } catch (e: Exception) {
            null
        }
        return when (code) {
            401 -> "Invalid API key. Check it in the Lobo app (Claude chat section)."
            403 -> "This API key isn't allowed to use that model."
            404 -> "Model not found. Check the model name in the Lobo app."
            429 -> "Rate limited. Try again in a moment."
            529 -> "Claude is overloaded right now. Try again shortly."
            else -> m ?: "Claude API error ($code)."
        }
    }
}

/**
 * Tab Chat: riwayat percakapan (bisa digulir), kolom ketik di bawah.
 * Mengetik: kalau jendela notch bisa menerima keyboard, kolom ketik tampil langsung di panel;
 * kalau tidak (overlay Accessibility), NotchView membuka ChatInputActivity sebagai gantinya.
 * Tekan lama balon jawaban = salin.
 */
class ChatPanel(private val c: Context) : FrameLayout(c), Refreshable, PanelLife {
    companion object {
        private val ERR = 0xFFFF8A80.toInt()
        private val ANSWER = 0xFFEDEDF2.toInt()
    }

    private val list = LinearLayout(c)
    private val sv = ScrollView(c)
    private val empty = c.tv("", 13f, C.SUB)
    private val tNew = c.tv("New chat", 11f, C.TEXT, true)
    private val fake = c.tv("", 14f, C.TEXT)
    val input = EditText(c)
    private val btn = FrameLayout(c)
    private val icSend = LineIconView(c, IconKind.SEND, C.BLACK, 18f, 2f)
    private val icStop = c.tv("■", 13f, C.BLACK, true)
    private val bubbles = ArrayList<TextView>()

    var typing = false
        private set

    /** Pengguna mengetuk kolom ketik. NotchView memutuskan cara membuka keyboard. */
    var onRequestType: (() -> Unit)? = null

    init {
        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL

        // judul + tombol percakapan baru
        val head = LinearLayout(c)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(c.tv("Claude", 13f, C.SUB, true))
        head.addView(View(c), c.llp(0, 1, 1f))
        tNew.setPadding(c.dp(10), c.dp(4), c.dp(10), c.dp(4))
        tNew.alpha = 0.6f
        tNew.setOnClickListener { Chat.clear() }
        head.addView(tNew)
        root.addView(head, c.llp(MATCH, WRAP, 0f, 2, 0, 0, 4))

        // riwayat
        val mid = FrameLayout(c)
        list.orientation = LinearLayout.VERTICAL
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        mid.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        empty.gravity = Gravity.CENTER
        empty.setPadding(c.dp(24), 0, c.dp(24), 0)
        mid.addView(empty, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(mid, c.llp(MATCH, 0, 1f))

        // kolom ketik: "kolom palsu" (tombol) saat tidak mengetik, EditText asli saat mengetik
        val row = LinearLayout(c)
        row.gravity = Gravity.CENTER_VERTICAL
        fake.gravity = Gravity.CENTER_VERTICAL
        fake.setPadding(c.dp(16), 0, c.dp(16), 0)
        fake.maxLines = 1
        fake.ellipsize = TextUtils.TruncateAt.END
        fake.background = rounded(0x22FFFFFF, c.dpf(20))
        fake.setOnClickListener { onRequestType?.invoke() }
        row.addView(fake, c.llp(0, c.dp(40), 1f))

        input.setTextColor(C.TEXT)
        input.setHintTextColor(0x66FFFFFF)
        input.hint = "Ask Claude…"
        input.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f)
        input.background = rounded(0x22FFFFFF, c.dpf(20))
        input.setPadding(c.dp(16), 0, c.dp(16), 0)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        input.imeOptions = EditorInfo.IME_ACTION_SEND or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        input.setSingleLine(true)
        input.visibility = View.GONE
        input.setOnEditorActionListener { _, act, _ ->
            if (act == EditorInfo.IME_ACTION_SEND) {
                submit()
                true
            } else {
                false
            }
        }
        row.addView(input, c.llp(0, c.dp(40), 1f))

        btn.background = rounded(C.TEXT, c.dpf(20))
        btn.addView(icSend, FrameLayout.LayoutParams(MATCH, MATCH))
        btn.addView(icStop, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        btn.setOnClickListener {
            when {
                Chat.busy -> Chat.cancel()
                typing -> submit()
                else -> onRequestType?.invoke()
            }
        }
        row.addView(btn, c.llp(c.dp(40), c.dp(40), 0f, 8, 0, 0, 0))
        root.addView(row, c.llp(MATCH, WRAP, 0f, 0, 6, 0, 0))

        addView(root, LayoutParams(MATCH, MATCH))
    }

    // ------------------------------------------------------------ ketik

    fun startTyping() {
        typing = true
        fake.visibility = View.GONE
        input.visibility = View.VISIBLE
    }

    fun stopTyping() {
        typing = false
        input.clearFocus()
        input.visibility = View.GONE
        fake.visibility = View.VISIBLE
        updateFake()
    }

    private fun submit() {
        val t = input.text.toString().trim()
        if (t.isEmpty() || Chat.busy) return
        input.setText("")
        Chat.send(t)
    }

    private fun updateFake() {
        val d = input.text.toString()
        val blank = d.isBlank()
        fake.text = if (blank) "Ask Claude…" else d
        fake.setTextColor(if (blank) 0x66FFFFFF else C.TEXT)
    }

    // ------------------------------------------------------------ gambar

    private fun colorFor(m: ChatMsg): Int = if (m.error) ERR else if (m.role == "user") C.TEXT else ANSWER

    private fun addBubble(m: ChatMsg): TextView {
        val t = c.tv(m.text, 13.5f, colorFor(m))
        t.setLineSpacing(0f, 1.1f)
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        if (m.role == "user") {
            lp.gravity = Gravity.END
            lp.leftMargin = c.dp(56)
            lp.topMargin = c.dp(4)
            lp.bottomMargin = c.dp(4)
            t.setPadding(c.dp(12), c.dp(7), c.dp(12), c.dp(7))
            t.background = rounded(0x33FFFFFF, c.dpf(14))
        } else {
            lp.gravity = Gravity.START
            lp.rightMargin = c.dp(28)
            lp.topMargin = c.dp(4)
            lp.bottomMargin = c.dp(4)
            t.setPadding(c.dp(2), c.dp(2), c.dp(2), c.dp(2))
            t.setOnLongClickListener {
                try {
                    val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Claude", m.text))
                    Toast.makeText(c, "Copied", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                }
                true
            }
        }
        list.addView(t, lp)
        return t
    }

    private fun syncBtn() {
        icSend.visibility = if (Chat.busy) View.GONE else View.VISIBLE
        icStop.visibility = if (Chat.busy) View.VISIBLE else View.GONE
    }

    private fun render() {
        Chat.load()
        val ms = Chat.msgs
        val atEnd = sv.scrollY + sv.height >= list.height - c.dp(48)
        var structural = false
        if (bubbles.size != ms.size) {
            structural = true
            list.removeAllViews()
            bubbles.clear()
            for (m in ms) bubbles.add(addBubble(m))
        } else if (ms.isNotEmpty()) {
            val m = ms.last()
            val b = bubbles.last()
            if (b.text.toString() != m.text) b.text = m.text
            b.setTextColor(colorFor(m))
        }
        empty.visibility = if (ms.isEmpty()) View.VISIBLE else View.GONE
        empty.text = if (Chat.hasKey()) "Ask Claude anything.\nTap the bar below to type."
        else "Add your Anthropic API key in the Lobo app\n(Claude chat section) to start."
        tNew.visibility = if (ms.isEmpty()) View.INVISIBLE else View.VISIBLE
        syncBtn()
        if (!typing) updateFake()
        if (atEnd || structural) sv.post { sv.fullScroll(View.FOCUS_DOWN) }
    }

    override fun refresh() {
        render()
    }

    override fun onVisible(v: Boolean) {
        if (v) {
            Chat.listener = { render() }
            render()
        } else {
            Chat.listener = null
        }
    }
}
