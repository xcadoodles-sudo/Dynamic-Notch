# Lobo untuk Android

"Living notch" yang menempel di tepi atas layar, dengan maskot serigala kecil.
Dibuat untuk Xiaomi Pad 6S Pro. Kotlin murni, tanpa Compose, dependensi cuma `androidx.core` + Shizuku.

## Cara build
- **Android Studio**: buka folder `Lobo`, tunggu Gradle sync, Run / Build APK.
- **GitHub Actions**: upload folder ini ke repo, workflow ada di `.github/workflows/build.yml`.
  Hasil APK ada di Artifacts (`Lobo-debug-apk`).

Pertama kali buka app, beri izin dari atas ke bawah (Display over other apps, Notification access,
Accessibility, dst), lalu tekan **Start notch**.

> Nama paket sekarang `com.lobo.app`, jadi ini terpasang sebagai aplikasi BARU (bukan update dari Xcadoodle/Nusa).
> Uninstall yang lama, lalu beri izin ulang sekali.

## Maskot serigala
Kepala bulat gemuk dengan outline ungu tipis (tanpa pendar di kepala) dan mata yang tetap menyala. Tinggal di sisi kiri pil saat tidak ada musik.

| Kondisi | Yang dilakukan |
|---|---|
| Idle | duduk, berkedip, melirik kiri/kanan, telinga berkedut, ekor goyang, bernapas |
| Tiap beberapa detik | jalan lenggak-lenggok ke kiri/kanan sepanjang pil: badan bergoyang, kaki bergantian, telinga berayun, wajah menoleh ke arah jalan |
| Diam ~20 detik | mengantuk (kelopak turun, kepala angguk-angguk), lalu meringkuk tidur dengan ekor melingkar dan "z z z" |
| Disentuh / panel dibuka | bangun, melar, duduk lagi |
| Notifikasi masuk | kaget dan melompat kecil |
| Tekan lama | dielus: mata senang, ekor cepat, hati melayang |

Waktu tidur, lama tidur, kecepatan jalan, dan kecepatan langkah ada di konstanta bagian atas `PetView` (`Mascot.kt`).
Ikon tab, tombol tutup, dan ikon alert digambar di `Icons.kt` (garis tipis minimalis, tanpa emoji).

## Alert / notifikasi
Pil alert berbentuk kapsul penuh: ikon garis di dalam lingkaran bertint lembut (warna sesuai jenis alert), judul medium + keterangan redup, isi di tengah. Notifikasi app lain menampilkan ikon app dalam kotak membulat. Ikon pop kecil saat alert muncul.

Ikon aplikasi (launcher) memakai kepala maskot dengan latar gelap, dan ada versi monochrome untuk themed icon Android 13+.

## Equalizer
- Bar bergerak dari gelombang sinus bertumpuk, jadi halus (tidak loncat acak). Naik cepat, turun pelan.
- Warna gradasi dari dua warna utama cover album yang sedang diputar; berubah mulus saat lagu ganti.
- Berhenti menggambar sendiri saat musik pause (hemat baterai).

## Warna di dalam notch (idle)
- Tidak ada lagi halo/garis tepi bercahaya di sekeliling notch, cuma warna di dalamnya.
- Saat tidak ada musik: kaca polos (liquid glass), tanpa warna/gradasi.
- Saat musik main: tiga gumpalan cahaya warna cover album melayang pelan kiri-kanan (dua warna saling melewati),
  membesar-mengecil ikut denyut equalizer. Masuk/keluar dan ganti lagu bertransisi mulus.
  Gerakannya di `NotchShape.drawBlobs`, kecepatan = periode detik di situ. Berhenti menggambar sendiri saat notch tertutup panel/alert.

## Gradasi tab Markets
Cahaya di dasar panel Music memakai dua warna cover album yang sedang diputar (oranye -> pink kalau tidak ada cover).

Cahaya di dasar panel Markets mengikuti arah harga simbol yang dipilih (angka perubahan yang sama dengan yang tampil):
naik = hijau, turun = merah, belum ada data = abu-biru. Ganti simbol/timeframe atau harga melewati titik awal -> warna berpindah halus.

## Tab di panel (v1.5, dirombak: 5 tab, tanpa geser)
Dulu ada 11 tab yang harus digeser. Sekarang cuma **5 tab ikon dalam satu kapsul kaca**, semuanya langsung kelihatan.
Tab yang punya beberapa isi menampilkan pilihannya sebagai **chip** di baris yang sama, jadi paling banyak 2 ketukan ke fitur mana pun.

| Tab | Pilihan (chip) |
|---|---|
| Music | Music (lirik, kontrol, cover) |
| System | Device, Mixer, Calls |
| Info | Calendar, Widgets, Markets |
| Inbox | Alerts (notifikasi), Clipboard |
| Tools | Shelf, Launcher, Booth |

Tab mengingat chip terakhir yang dibuka. Di kanan baris tetap ada palet tema, setelan, dan tombol tutup.
Isi tiap panel (Notifications, Clipboard, Widgets, Mixer, Launcher, Calls, dst) tidak berubah; nomor panel 0..10 di kode juga sama,
jadi `showPanel(n)` dari alert/service tetap jalan. Pengelompokan ada di `groups` (`NotchView.kt`).

| Panel | Isi |
|---|---|
| Notifications | Daftar notifikasi aktif (ikon app, judul, isi, waktu). Ketuk = buka app-nya, ✕ = buang, Clear all = bersihkan semua. Butuh Notification access. |
| Clipboard | Riwayat 20 salinan terakhir. Ketuk = salin balik. Android 10+ hanya mengizinkan app yang sedang fokus membaca clipboard, jadi tekan **+ Paste** untuk menyimpan isi clipboard sekarang. |
| Widgets | Jam + tanggal, cuaca, to-do (ketuk = centang, tekan lama = hapus, + = tambah), baterai perangkat. |
| Mixer | Slider volume Media, Ring, Alarm, Alerts (seret langsung). |
| Launcher | Screenshot, Recents, Lock (lewat izin Accessibility) + 12 slot app. |
| Calls | Tombol mute mikrofon, timer panggilan, speakerphone, perangkat output. |

## Mode tampilan: Liquid Glass / Dark (v1.7)
Ikon **tetes** (Glass) / **bulan** (Dark) di baris tab panel mengganti mode; bisa juga di setelan app (**Appearance**). Pilihan tersimpan.

- **Glass**: tembus pandang + kilau + tepi terang (seperti sebelumnya).
- **Dark**: panel, alert, dan pil idle pekat (tanpa tembus pandang, kilau, pantulan, dispersi), kartu/chip matte dengan garis tepi tipis.
- **Gradasi tetap ada** di dua mode: cahaya di dasar panel, gumpalan warna cover album di pil, dan tint tema (Rosé, Ocean, dst) tetap muncul; di Dark tint-nya hanya digelapkan. Aurora tetap punya tepi pelangi.
- Setelan **Glass opacity** hanya berpengaruh di mode Glass.
- Logika: objek `Look` (`Models.kt`), dibaca saat menggambar (`GlassDrawable` di `Ui.kt`, `NotchShape.kt`).

## Photo Booth (v1.7)
Tab **Tools -> Booth** (tombol *Open Booth* + strip foto terakhir; ketuk = buka, tekan lama = hapus). Layar penuh, kode di `Booth.kt`, murni Camera2 tanpa dependensi baru.

- Preview cermin kamera depan (ala Photo Booth di Mac), tombol balik kamera depan/belakang.
- **Efek** (ColorMatrix, live): Normal, Mono, Noir, Sepia, Fade, Vivid, Pop, Warm, Cool, Neon, X-Ray. Efek distorsi (bulge dst) di Mac tidak ada.
- **Mode**: Photo, **4-Up** (grid 2x2), **Strip** (4 foto vertikal ala photo strip).
- Timer 3 detik / 5 detik / mati, hitung mundur 3-2-1 besar, kilat layar + suara rana.
- Hasil tersimpan otomatis di galeri `Pictures/Lobo Photo Booth` (+ salinan privat 12 terakhir), ada tombol Share.
- Butuh izin Kamera (baris baru di setelan app, atau diminta saat pertama dibuka).

Notch idle, panel, dan alert semuanya berbahan kaca (bukan hitam pekat). Pil idle kacanya hampir penuh supaya tetap rapi di bezel;
saat melebar jadi panel kacanya penuh, lalu kembali ke kaca idle saat menutup.

- Isi tembus pandang bertint + kerudung putih tipis (efek susu).
- Kilau licin di bagian atas, titik pantul di kiri atas, cahaya tipis di sisi dalam tepi (kesan tebal kaca).
- Garis tepi terang (terang di kiri-atas & kanan-bawah, redup di tengah) dengan dispersi warna tipis (magenta/cyan) di tepi, dan sapuan kilau saat panel membuka.
- Titik pantul cahaya mengembara pelan di dalam kaca dan **mengikuti jari** saat panel/alert disentuh.
- Teks kecil diberi bayangan tipis dan warna sekunder dibuat lebih terang supaya tetap terbaca di atas kaca.
- Kartu, tombol, dan chip di dalam panel juga kaca (`glass()` / `GlassDrawable` di `Ui.kt`).
- Seberapa tembus pandang bisa disetel: setelan app **Glass opacity** (30–95%, bawaan 70%). Naikkan kalau teks susah dibaca di atas app yang terang.

> Catatan jujur: ini kaca "palsu" (tembus pandang + kilau + tepi), **bukan blur** isi layar di belakangnya. Android tidak mengizinkan
> overlay mem-blur layar di belakang dengan bentuk notch yang berubah-ubah tanpa mengubah ukuran jendela, dan itu yang bikin animasi geter dulu.

## Tema
Ikon palet di kanan baris tab mengganti tema: **Crystal** (bawaan, tint ikut cover album), **Rosé**, **Peach**, **Ocean**, **Forest**, **Aurora**.
Semuanya kaca; beda di tint kaca dan warna cahaya di dasar panel. Aurora menambah garis tepi pelangi yang berputar pelan,
terinspirasi kaca beriridesen di video referensi. Daftar warna ada di `Themes` (`Stores.kt`).

## Fitur lain
Music (lirik LRCLIB), Device (CPU/GPU/RAM/suhu, lebih lengkap dengan Shizuku), Markets (chart ala TradingView),
Calendar + cuaca, Shelf (drop/share file). Alert untuk baterai, jaringan, Bluetooth, dan notifikasi app lain.
Ukuran notch (lebar, tebal, jarak dari atas) bisa disetel di pengaturan app.

## Update tanpa uninstall
Android hanya mau meng-update kalau paket sama, **tanda tangan sama**, dan `versionCode` lebih besar.

- Tanda tangan: semua build memakai `app/lobo-release-key.jks` (atau secret `LOBO_KEYSTORE_B64`, lihat bawah). **Jangan ganti file ini**, kalau ganti, harus uninstall lagi sekali.
- `versionCode`: dihitung dari waktu build (menit sejak 1970), jadi selalu naik, juga kalau repo dibuat ulang.
- Build lama (sebelum v1.6) memakai kunci acak, jadi PEMASANGAN PERTAMA dengan kunci ini masih harus uninstall sekali. Setelah itu tinggal pasang di atas.

## Repo private
Repo private tidak mengubah apa pun di Actions (APK tetap muncul di Artifacts, kamu download lewat akun GitHub-mu).

1. **Termudah**: Settings repo -> General -> paling bawah *Danger Zone* -> *Change visibility* -> *Make private*. File `.jks` tetap di repo, aman karena cuma kamu yang bisa lihat.
2. **Kunci di luar repo** (kalau mau `.jks` tidak ikut di-upload):
   - Di HP/PC: ubah `.jks` jadi teks base64 (Linux/Mac: `base64 -w0 lobo-release-key.jks`; Termux: sama).
   - Repo -> Settings -> Secrets and variables -> Actions -> New repository secret, nama `LOBO_KEYSTORE_B64`, isi dengan teks tadi.
   - Hapus `Lobo/app/lobo-release-key.jks` dari repo. Workflow akan membuatnya lagi dari secret saat build.
   - Harus kunci YANG SAMA dengan yang sudah terpasang di HP.
