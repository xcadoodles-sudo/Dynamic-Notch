package com.lobo.app

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.display.DisplayManager
import android.media.MediaActionSound
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ penyimpanan foto

/**
 * Foto Photo Booth disimpan dua kali: salinan privat di filesDir/LoboBooth (untuk strip di panel notch + berbagi lewat
 * FileProvider) dan salinan di galeri (Pictures/Lobo Photo Booth). Salinan privat dibatasi [MAX] terakhir.
 */
object BoothStore {
    private const val MAX = 12

    val dir: File
        get() {
            val d = File(Lobo.app.filesDir, "LoboBooth")
            d.mkdirs()
            return d
        }

    fun items(): List<File> =
        (dir.listFiles()?.filter { it.isFile && it.extension.equals("jpg", true) } ?: emptyList()).sortedByDescending { it.lastModified() }

    fun uriFor(f: File): Uri = FileProvider.getUriForFile(Lobo.app, Lobo.app.packageName + ".files", f)

    fun save(ctx: Context, bmp: Bitmap): File? {
        val name = "LoboBooth_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val f = File(dir, name)
        try {
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 94, it) }
        } catch (e: Exception) {
            f.delete()
            return null
        }
        exportToGallery(ctx, f, name)
        items().drop(MAX).forEach { it.delete() }
        return f
    }

    private fun exportToGallery(ctx: Context, f: File, name: String) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.Images.Media.DISPLAY_NAME, name)
                v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Lobo Photo Booth")
                v.put(MediaStore.Images.Media.IS_PENDING, 1)
                val r = ctx.contentResolver
                val uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
                r.openOutputStream(uri)?.use { o -> f.inputStream().use { i -> i.copyTo(o) } }
                val done = ContentValues()
                done.put(MediaStore.Images.Media.IS_PENDING, 0)
                r.update(uri, done, null, null)
            } else {
                @Suppress("DEPRECATION")
                val pics = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val d = File(pics, "Lobo Photo Booth")
                d.mkdirs()
                val out = File(d, name)
                f.copyTo(out, true)
                MediaScannerConnection.scanFile(ctx, arrayOf(out.absolutePath), arrayOf("image/jpeg"), null)
            }
        } catch (e: Exception) {
            // salinan galeri gagal (izin ditolak, penyimpanan penuh): salinan privat tetap ada
        }
    }
}

// ------------------------------------------------------------------ efek warna (ColorMatrix)

private fun fxMat(vararg v: Float): ColorMatrix = ColorMatrix(v)

private fun fxSat(s: Float): ColorMatrix {
    val m = ColorMatrix()
    m.setSaturation(s)
    return m
}

private fun fxCat(a: ColorMatrix, b: ColorMatrix): ColorMatrix {
    val r = ColorMatrix(a)
    r.postConcat(b)
    return r
}

private fun fxContrast(c: Float, bright: Float = 0f): ColorMatrix {
    val t = (0.5f - 0.5f * c) * 255f + bright
    return fxMat(
        c, 0f, 0f, 0f, t,
        0f, c, 0f, 0f, t,
        0f, 0f, c, 0f, t,
        0f, 0f, 0f, 1f, 0f
    )
}

private class BoothFx(val name: String, val matrix: ColorMatrix?) {
    fun paint(): Paint? {
        val m = matrix ?: return null
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.colorFilter = ColorMatrixColorFilter(m)
        return p
    }
}

private val BOOTH_FX: List<BoothFx> = listOf(
    BoothFx("Normal", null),
    BoothFx("Mono", fxSat(0f)),
    BoothFx("Noir", fxCat(fxSat(0f), fxContrast(1.4f, -6f))),
    BoothFx(
        "Sepia", fxMat(
            0.393f, 0.769f, 0.189f, 0f, 0f,
            0.349f, 0.686f, 0.168f, 0f, 0f,
            0.272f, 0.534f, 0.131f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )
    ),
    BoothFx("Fade", fxCat(fxSat(0.55f), fxContrast(0.82f, 14f))),
    BoothFx("Vivid", fxCat(fxSat(1.7f), fxContrast(1.1f))),
    BoothFx("Pop", fxCat(fxSat(2.4f), fxContrast(1.3f))),
    BoothFx(
        "Warm", fxMat(
            1.16f, 0f, 0f, 0f, 10f,
            0f, 1.02f, 0f, 0f, 4f,
            0f, 0f, 0.84f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )
    ),
    BoothFx(
        "Cool", fxMat(
            0.88f, 0f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f, 6f,
            0f, 0f, 1.18f, 0f, 12f,
            0f, 0f, 0f, 1f, 0f
        )
    ),
    BoothFx(
        "Neon", fxMat(
            0.284f, 0.558f, 0.108f, 0f, 0f,
            0.105f, 0.205f, 0.040f, 0f, 0f,
            0.344f, 0.675f, 0.131f, 0f, 8f,
            0f, 0f, 0f, 1f, 0f
        )
    ),
    BoothFx(
        "X-Ray", fxCat(
            fxCat(
                fxSat(0f), fxMat(
                    -1f, 0f, 0f, 0f, 255f,
                    0f, -1f, 0f, 0f, 255f,
                    0f, 0f, -1f, 0f, 255f,
                    0f, 0f, 0f, 1f, 0f
                )
            ),
            fxMat(
                0.55f, 0f, 0f, 0f, 0f,
                0f, 0.85f, 0f, 0f, 8f,
                0f, 0f, 1.15f, 0f, 22f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )
)


// ------------------------------------------------------------------ komposisi 4-Up / Strip

private const val PAPER = 0xFFF6F3EC.toInt()

private fun boothGrid(l: List<Bitmap>): Bitmap {
    val w0 = l[0].width
    val h0 = l[0].height
    val sc = minOf(1f, 900f / maxOf(w0, h0))
    val cw = (w0 * sc).toInt()
    val ch = (h0 * sc).toInt()
    val gap = maxOf(8, (cw * 0.035f).toInt())
    val out = Bitmap.createBitmap(cw * 2 + gap * 3, ch * 2 + gap * 3, Bitmap.Config.ARGB_8888)
    val cv = Canvas(out)
    cv.drawColor(PAPER)
    val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    for (i in 0 until 4) {
        val x = gap + (i % 2) * (cw + gap)
        val y = gap + (i / 2) * (ch + gap)
        cv.drawBitmap(l[i], null, Rect(x, y, x + cw, y + ch), p)
    }
    return out
}

private fun boothStrip(l: List<Bitmap>): Bitmap {
    val fw = 720
    val fh = 540
    val m = 40
    val foot = 160
    val out = Bitmap.createBitmap(fw + 2 * m, 4 * m + 4 * fh + foot, Bitmap.Config.ARGB_8888)
    val cv = Canvas(out)
    cv.drawColor(PAPER)
    val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    val tr = fw.toFloat() / fh
    for (i in 0 until 4) {
        val b = l[i]
        val bw = b.width
        val bh = b.height
        val src = if (bw.toFloat() / bh > tr) {
            val nw = (bh * tr).toInt()
            Rect((bw - nw) / 2, 0, (bw - nw) / 2 + nw, bh)
        } else {
            val nh = (bw / tr).toInt()
            Rect(0, (bh - nh) / 2, bw, (bh - nh) / 2 + nh)
        }
        val y = m + i * (fh + m)
        cv.drawBitmap(b, src, Rect(m, y, m + fw, y + fh), p)
    }
    val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    tp.color = 0xFF9B968C.toInt()
    tp.textAlign = Paint.Align.CENTER
    tp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    tp.textSize = 38f
    tp.letterSpacing = 0.18f
    val cx = out.width / 2f
    val base = (4 * m + 4 * fh).toFloat() + 66f
    cv.drawText("LOBO PHOTO BOOTH", cx, base, tp)
    tp.textSize = 28f
    tp.letterSpacing = 0.05f
    cv.drawText(SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date()), cx, base + 48f, tp)
    return out
}

// ------------------------------------------------------------------ view bantu

/** TextureView yang menjaga rasio gambar (muat di dalam ruang yang ada), sudut membulat. */
private class AspectTextureView(c: Context, private val radius: Float) : TextureView(c) {
    private var aw = 0
    private var ah = 0

    init {
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        clipToOutline = true
    }

    fun setAspect(w: Int, h: Int) {
        if (w == aw && h == ah) return
        aw = w
        ah = h
        requestLayout()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        invalidateOutline()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val maxW = MeasureSpec.getSize(wSpec)
        val maxH = MeasureSpec.getSize(hSpec)
        if (aw <= 0 || ah <= 0) {
            setMeasuredDimension(maxW, maxH)
            return
        }
        var w = maxW
        var h = (w.toLong() * ah / aw).toInt()
        if (h > maxH) {
            h = maxH
            w = (h.toLong() * aw / ah).toInt()
        }
        setMeasuredDimension(w, h)
    }
}

/** FrameLayout dengan sudut membulat yang ikut ukuran (untuk panggung preview). */
private class RoundFrame(c: Context, private val radius: Float) : FrameLayout(c) {
    init {
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        clipToOutline = true
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        invalidateOutline()
    }
}

// ------------------------------------------------------------------ Photo Booth di dalam notch

/**
 * Photo Booth ala macOS yang hidup sepenuhnya di panel notch (tab Tools -> Booth): preview cermin, deretan efek,
 * hitung mundur, mode Photo / 4-Up / Strip. Tidak membuka app/Activity lain. Kamera HANYA menyala selama panel
 * ini terlihat; begitu tab pindah / panel ditutup, kamera, sound, dan bitmap dilepas (hemat RAM, CPU, baterai).
 * Murni Camera2 + TextureView di thread utama (preview tanpa callback per-frame), tanpa dependensi tambahan.
 */
class BoothPanel(private val c: Context) : FrameLayout(c), Refreshable, PanelLife, TextureView.SurfaceTextureListener {
    /** Diisi NotchView: tutup panel dulu, baru jalankan aksi (buka galeri / bagikan). */
    var closeThen: ((() -> Unit) -> Unit)? = null

    private val ui = Handler(Looper.getMainLooper())
    private val seq = Handler(Looper.getMainLooper()) // semua jadwal urutan jepret (hitung mundur, foto berikutnya)
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var previewSize: Size? = null
    private var sensorOrient = 90
    private var afContinuous = false
    private var fps: Range<Int>? = null
    private var front = true          // yang diminta
    private var facingFront = true    // yang benar-benar terbuka
    private var showing = false
    private var opening = false
    private var tries = 0
    private var sound: MediaActionSound? = null

    private val tex = AspectTextureView(c, c.dpf(14))
    private val stage = RoundFrame(c, c.dpf(16))
    private val status = c.tv("", 12f, C.TEXT, true)
    private val countNum = c.tv("", 90f, C.TEXT, true)
    private val flash = View(c)
    private val resultLayer = FrameLayout(c)
    private val resultImg = ImageView(c)
    private val msgLayer = LinearLayout(c)
    private val msgText = c.tv("", 12.5f, C.TEXT)
    private val msgBtn = TextView(c)
    private val thumb = ImageView(c)
    private val timerChip: TextView
    private val fxChips = ArrayList<TextView>()
    private val modeChips = ArrayList<TextView>()
    private val ctrl = ArrayList<View>()
    private lateinit var shutter: FrameLayout

    private var msgKind = 0           // 0 tidak ada, 1 izin, 2 galat
    private var fx = 0
    private var mode = 0              // 0 Photo, 1 4-Up, 2 Strip
    private var timerIdx = 0
    private val timers = intArrayOf(3, 5, 0)
    private var busy = false
    private val shots = ArrayList<Bitmap>()
    private var resultBmp: Bitmap? = null
    private var resultFile: File? = null
    private var thumbSig = ""

    companion object {
        const val PANEL = 11
    }

    init {
        // ----- panggung preview (kiri)
        stage.background = rounded(0x33000000, c.dpf(16))
        tex.surfaceTextureListener = this
        tex.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> configureTransform(r - l, b - t) }
        stage.addView(tex, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))

        status.setPadding(c.dp(10), c.dp(4), c.dp(10), c.dp(4))
        status.background = rounded(0x99000000.toInt(), c.dpf(100))
        status.visibility = View.GONE
        val slp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        slp.topMargin = c.dp(8)
        stage.addView(status, slp)

        countNum.gravity = Gravity.CENTER
        countNum.setShadowLayer(c.dpf(14), 0f, c.dpf(2), 0xAA000000.toInt())
        countNum.visibility = View.GONE
        stage.addView(countNum, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        flash.setBackgroundColor(0xFFFFFFFF.toInt())
        flash.alpha = 0f
        stage.addView(flash, FrameLayout.LayoutParams(MATCH, MATCH))

        // hasil jepretan (sebentar, lalu hilang sendiri)
        resultLayer.setBackgroundColor(0xE6000000.toInt())
        resultLayer.visibility = View.GONE
        resultLayer.setOnClickListener { closeResult() }
        resultImg.scaleType = ImageView.ScaleType.FIT_CENTER
        val rlp = FrameLayout.LayoutParams(MATCH, MATCH)
        rlp.bottomMargin = c.dp(34)
        resultLayer.addView(resultImg, rlp)
        val rb = LinearLayout(c)
        rb.gravity = Gravity.CENTER
        rb.addView(chip("Share") { shareResult() }, c.llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        rb.addView(chip("Done") { closeResult() })
        resultLayer.addView(rb, FrameLayout.LayoutParams(MATCH, c.dp(34), Gravity.BOTTOM))
        stage.addView(resultLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        // pesan (izin kamera / galat)
        msgLayer.orientation = LinearLayout.VERTICAL
        msgLayer.gravity = Gravity.CENTER
        msgLayer.setBackgroundColor(0xCC000000.toInt())
        msgLayer.visibility = View.GONE
        msgLayer.isClickable = true
        msgText.gravity = Gravity.CENTER
        msgLayer.addView(msgText, c.llp(WRAP, WRAP, 0f, 12, 0, 12, 8))
        msgBtn.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12f)
        msgBtn.typeface = Typeface.DEFAULT_BOLD
        msgBtn.setTextColor(C.BLACK)
        msgBtn.gravity = Gravity.CENTER
        msgBtn.setPadding(c.dp(14), c.dp(6), c.dp(14), c.dp(6))
        msgBtn.background = rounded(0xFFFFFFFF.toInt(), c.dpf(100))
        msgLayer.addView(msgBtn, c.llp(WRAP, WRAP))
        stage.addView(msgLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        // ----- baris kontrol di bawah preview: mode, timer, balik kamera, foto terakhir
        val ctrlRow = LinearLayout(c)
        ctrlRow.gravity = Gravity.CENTER_VERTICAL
        val names = arrayOf("Photo", "4-Up", "Strip")
        for (i in names.indices) {
            val ch = chip(names[i]) { selectMode(i) }
            modeChips.add(ch)
            ctrl.add(ch)
            ctrlRow.addView(ch, c.llp(WRAP, WRAP, 0f, 0, 0, 4, 0))
        }
        styleChip(modeChips[0], true)
        ctrlRow.addView(View(c), c.llp(0, 1, 1f))
        timerChip = chip("") {
            timerIdx = (timerIdx + 1) % timers.size
            updateTimerChip()
        }
        updateTimerChip()
        ctrl.add(timerChip)
        ctrlRow.addView(timerChip, c.llp(WRAP, WRAP, 0f, 0, 0, 2, 0))
        val flip = LineIconView(c, IconKind.FLIP, C.TEXT, 17f, 1.5f)
        flip.setOnClickListener { flipCamera() }
        ctrl.add(flip)
        ctrlRow.addView(flip, c.llp(c.dp(32), c.dp(30)))
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.background = glass(C.GLASS, c.dpf(8))
        thumb.roundClip(c.dpf(8))
        thumb.visibility = View.GONE
        thumb.setOnClickListener { openLast() }
        ctrlRow.addView(thumb, c.llp(c.dp(30), c.dp(30), 0f, 4, 0, 0, 0))

        val left = LinearLayout(c)
        left.orientation = LinearLayout.VERTICAL
        left.addView(stage, c.llp(MATCH, 0, 1f))
        left.addView(ctrlRow, c.llp(MATCH, c.dp(36), 0f, 0, 6, 0, 0))

        // ----- kolom kanan: efek (2 kolom, bisa digulir) + tombol rana
        val fxCol = LinearLayout(c)
        fxCol.orientation = LinearLayout.VERTICAL
        var rowL: LinearLayout? = null
        for (i in BOOTH_FX.indices) {
            if (i % 2 == 0) {
                rowL = LinearLayout(c)
                fxCol.addView(rowL, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 4))
            }
            val ch = chip(BOOTH_FX[i].name) { selectFx(i) }
            ch.setPadding(c.dp(4), c.dp(5), c.dp(4), c.dp(5))
            fxChips.add(ch)
            ctrl.add(ch)
            rowL?.addView(ch, c.llp(0, WRAP, 1f, if (i % 2 == 1) 4 else 0, 0, 0, 0))
        }
        styleChip(fxChips[0], true)
        val fxScroll = ScrollView(c)
        fxScroll.isVerticalScrollBarEnabled = false
        fxScroll.overScrollMode = OVER_SCROLL_NEVER
        fxScroll.addView(fxCol, FrameLayout.LayoutParams(MATCH, WRAP))

        shutter = FrameLayout(c)
        val ring = GradientDrawable()
        ring.shape = GradientDrawable.OVAL
        ring.setColor(0)
        ring.setStroke(c.dp(3), 0xFFFFFFFF.toInt())
        shutter.background = ring
        val inner = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFFF6B6B.toInt(), 0xFFE0245E.toInt()))
        inner.shape = GradientDrawable.OVAL
        val innerV = FrameLayout(c)
        innerV.background = inner
        innerV.addView(LineIconView(c, IconKind.CAMERA, C.TEXT, 22f, 1.6f), FrameLayout.LayoutParams(MATCH, MATCH))
        shutter.addView(innerV, FrameLayout.LayoutParams(c.dp(42), c.dp(42), Gravity.CENTER))
        shutter.setOnClickListener {
            if (busy) cancelSequence() else startSequence()
        }

        val right = LinearLayout(c)
        right.orientation = LinearLayout.VERTICAL
        right.addView(fxScroll, c.llp(MATCH, 0, 1f))
        val slp2 = c.llp(c.dp(52), c.dp(52), 0f, 0, 6, 0, 0)
        slp2.gravity = Gravity.CENTER_HORIZONTAL
        right.addView(shutter, slp2)

        val row = LinearLayout(c)
        row.addView(left, c.llp(0, MATCH, 1f))
        row.addView(right, c.llp(c.dp(112), MATCH, 0f, 10, 0, 0, 0))
        addView(row, LayoutParams(MATCH, MATCH))
    }

    // ---------------------------------------------------------------- UI kecil

    private fun styleChip(t: TextView, sel: Boolean) {
        t.background = if (sel) rounded(0xFFFFFFFF.toInt(), c.dpf(100)) else glass(C.GLASS2, c.dpf(100))
        t.setTextColor(if (sel) C.BLACK else C.TEXT)
        t.setShadowLayer(0f, 0f, 0f, 0)
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val t = c.tv(text, 11.5f, C.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(c.dp(9), c.dp(5), c.dp(9), c.dp(5))
        t.setOnClickListener { onClick() }
        styleChip(t, false)
        return t
    }

    private fun updateTimerChip() {
        val s = timers[timerIdx]
        timerChip.text = if (s == 0) "Off" else "${s}s"
    }

    private fun selectFx(i: Int) {
        fx = i
        for (k in fxChips.indices) styleChip(fxChips[k], k == i)
        applyFxToPreview()
    }

    private fun selectMode(i: Int) {
        if (busy) return
        mode = i
        for (k in modeChips.indices) styleChip(modeChips[k], k == i)
    }

    private fun setControlsEnabled(on: Boolean) {
        for (v in ctrl) {
            v.isEnabled = on
            v.alpha = if (on) 1f else 0.4f
        }
    }

    private fun applyFxToPreview() {
        tex.setLayerPaint(BOOTH_FX[fx].paint())
        tex.invalidate()
    }

    private fun showMsg(kind: Int, text: String, btn: String, act: () -> Unit) {
        msgKind = kind
        msgText.text = text
        msgBtn.text = btn
        msgBtn.setOnClickListener { act() }
        msgLayer.visibility = View.VISIBLE
    }

    private fun hideMsg() {
        msgKind = 0
        msgLayer.visibility = View.GONE
    }

    private fun hasPerm(): Boolean = c.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    // ---------------------------------------------------------------- siklus hidup (kamera hanya saat terlihat)

    private val openRunnable = Runnable { ensureCamera() }

    override fun onVisible(v: Boolean) {
        if (v == showing) return
        showing = v
        if (v) {
            tries = 0
            registerDisplay()
            updateThumb()
            // tunggu animasi buka panel selesai dulu supaya tidak tersendat
            ui.postDelayed(openRunnable, 520)
        } else {
            stopAll()
        }
    }

    override fun onDetachedFromWindow() {
        if (showing) {
            showing = false
            stopAll()
        }
        super.onDetachedFromWindow()
    }

    private fun stopAll() {
        ui.removeCallbacks(openRunnable)
        cancelSequence()
        closeResultNow()
        closeCamera()
        unregisterDisplay()
        try {
            NotchService.instance?.cameraMode(false)
        } catch (e: Exception) {
        }
        try {
            sound?.release()
        } catch (e: Throwable) {
        }
        sound = null
        tex.setLayerPaint(null)
    }

    /** Dipanggil NotchView berkala saat tab ini terbuka: pulihkan kamera setelah izin diberikan / gagal sesaat. */
    override fun refresh() {
        if (!showing || device != null || opening || busy) return
        if (hasPerm()) {
            if (msgKind == 1) {
                hideMsg()
                tries = 0
            }
            if (msgKind == 0 && tries < 3) {
                tries++
                ensureCamera()
            }
        }
        updateThumb()
    }

    private fun ensureCamera() {
        if (!showing || device != null || opening) return
        if (!hasPerm()) {
            showMsg(1, "Allow camera access to use Photo Booth", "Allow") { requestPerm() }
            return
        }
        if (!tex.isAvailable) return // onSurfaceTextureAvailable memanggil lagi
        hideMsg()
        // Android 11+: kamera hanya boleh dipakai service kalau tipe foreground-nya "camera"
        try {
            NotchService.instance?.cameraMode(true)
        } catch (e: Exception) {
        }
        openCamera()
    }

    private fun requestPerm() {
        try {
            val i = Intent(c, CamPermActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
        } catch (e: Exception) {
        }
    }

    // ---------------------------------------------------------------- kamera (Camera2)

    override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
        if (showing) ensureCamera()
    }

    override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {
        configureTransform(width, height)
    }

    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
        closeCamera()
        return true
    }

    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}

    private val dispListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            ui.post {
                applyAspect()
                if (tex.width > 0) configureTransform(tex.width, tex.height)
            }
        }
    }

    private fun registerDisplay() {
        try {
            (c.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(dispListener, ui)
        } catch (e: Exception) {
        }
    }

    private fun unregisterDisplay() {
        try {
            (c.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(dispListener)
        } catch (e: Exception) {
        }
    }

    private fun pickCamera(mgr: CameraManager): String? {
        var any: String? = null
        for (id in mgr.cameraIdList) {
            val facing = mgr.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING)
            if (any == null) any = id
            if (front && facing == CameraCharacteristics.LENS_FACING_FRONT) return id
            if (!front && facing == CameraCharacteristics.LENS_FACING_BACK) return id
        }
        return any
    }

    /** 4:3 terbesar sampai 1280 lebar (cukup tajam untuk foto booth, ringan di GPU/RAM). */
    private fun choosePreview(sizes: Array<Size>): Size {
        val ratio43 = sizes.filter { it.width * 3 == it.height * 4 && it.width <= 1280 }
        val best = ratio43.maxByOrNull { it.width * it.height }
        if (best != null) return best
        val any = sizes.filter { it.width <= 1280 }.maxByOrNull { it.width * it.height }
        return any ?: sizes[0]
    }

    private fun naturalSize(ps: Size): Pair<Int, Int> =
        if (sensorOrient % 180 == 90) Pair(ps.height, ps.width) else Pair(ps.width, ps.height)

    @Suppress("DEPRECATION")
    private fun displayRot(): Int = (c.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation

    private fun applyAspect() {
        val ps = previewSize ?: return
        val (nw, nh) = naturalSize(ps)
        val rot = displayRot()
        if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) tex.setAspect(nh, nw) else tex.setAspect(nw, nh)
    }

    /** Putar/skala preview sesuai orientasi sensor & layar, lalu cerminkan kamera depan (seperti Photo Booth di Mac). */
    private fun configureTransform(viewW: Int, viewH: Int) {
        val ps = previewSize ?: return
        if (viewW <= 0 || viewH <= 0) return
        val rot = displayRot()
        val (nw, nh) = naturalSize(ps)
        val m = Matrix()
        val vr = RectF(0f, 0f, viewW.toFloat(), viewH.toFloat())
        val cx = vr.centerX()
        val cy = vr.centerY()
        if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) {
            val br = RectF(0f, 0f, nw.toFloat(), nh.toFloat())
            br.offset(cx - br.centerX(), cy - br.centerY())
            m.setRectToRect(vr, br, Matrix.ScaleToFit.FILL)
            val sc = maxOf(viewH.toFloat() / nw, viewW.toFloat() / nh)
            m.postScale(sc, sc, cx, cy)
            m.postRotate(90f * (rot - 2), cx, cy)
        } else if (rot == Surface.ROTATION_180) {
            m.postRotate(180f, cx, cy)
        }
        if (facingFront) m.postScale(-1f, 1f, cx, cy)
        tex.setTransform(m)
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun openCamera() {
        if (!showing || device != null || opening || !tex.isAvailable || !hasPerm()) return
        try {
            val mgr = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = pickCamera(mgr)
            if (id == null) {
                showMsg(2, "No camera found", "Retry") { retry() }
                return
            }
            val cc = mgr.getCameraCharacteristics(id)
            sensorOrient = cc.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            facingFront = cc.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            val af = cc.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
            afContinuous = af != null && af.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            // frame rate preview dibatasi (<= 24 fps) supaya CPU/GPU/baterai hemat
            val ranges = cc.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            fps = ranges?.filter { it.upper <= 24 }?.maxWithOrNull(compareBy<Range<Int>>({ it.upper }, { it.lower }))
            val map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(SurfaceTexture::class.java)
            if (sizes == null || sizes.isEmpty()) {
                showMsg(2, "Camera not supported", "Retry") { retry() }
                return
            }
            previewSize = choosePreview(sizes)
            applyAspect()
            opening = true
            mgr.openCamera(id, stateCb, ui)
        } catch (e: Exception) {
            opening = false
            showMsg(2, "Can't open the camera", "Retry") { retry() }
        }
    }

    private fun retry() {
        hideMsg()
        tries = 0
        ensureCamera()
    }

    private val stateCb = object : CameraDevice.StateCallback() {
        override fun onOpened(cd: CameraDevice) {
            opening = false
            if (!showing) {
                cd.close()
                return
            }
            device = cd
            startPreview(cd)
        }

        override fun onDisconnected(cd: CameraDevice) {
            opening = false
            cd.close()
            if (device === cd) device = null
        }

        override fun onError(cd: CameraDevice, error: Int) {
            opening = false
            cd.close()
            if (device === cd) device = null
            if (showing) showMsg(2, "Camera is busy or blocked", "Retry") { retry() }
        }
    }

    @Suppress("DEPRECATION")
    private fun startPreview(cd: CameraDevice) {
        val st = tex.surfaceTexture ?: return
        val ps = previewSize ?: return
        try {
            st.setDefaultBufferSize(ps.width, ps.height)
            val surface = Surface(st)
            val req = cd.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            req.addTarget(surface)
            if (afContinuous) req.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            fps?.let { req.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
            cd.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (device !== cd || !showing) {
                        s.close()
                        return
                    }
                    session = s
                    try {
                        s.setRepeatingRequest(req.build(), null, ui)
                    } catch (e: Exception) {
                    }
                    applyAspect()
                    applyFxToPreview()
                    if (tex.width > 0) configureTransform(tex.width, tex.height)
                }

                override fun onConfigureFailed(s: CameraCaptureSession) {
                    if (showing) showMsg(2, "Camera error", "Retry") { retry() }
                }
            }, ui)
        } catch (e: Exception) {
            if (showing) showMsg(2, "Camera error", "Retry") { retry() }
        }
    }

    private fun closeCamera() {
        try {
            session?.close()
        } catch (e: Exception) {
        }
        session = null
        try {
            device?.close()
        } catch (e: Exception) {
        }
        device = null
        opening = false
    }

    private fun flipCamera() {
        if (busy || opening) return
        front = !front
        closeCamera()
        ui.postDelayed({ if (showing) ensureCamera() }, 200)
    }

    // ---------------------------------------------------------------- jepret

    private fun startSequence() {
        if (busy || session == null) return
        busy = true
        shots.clear()
        setControlsEnabled(false)
        nextShot(0, if (mode == 0) 1 else 4)
    }

    private fun nextShot(i: Int, total: Int) {
        if (!busy) return
        if (total > 1) {
            status.text = "${i + 1} / $total"
            status.visibility = View.VISIBLE
        } else {
            status.visibility = View.GONE
        }
        val t = timers[timerIdx]
        val secs = if (i == 0) t else (if (t == 0) 1 else 2)
        countdown(secs) {
            capture { bmp ->
                if (!busy) {
                    bmp.recycle()
                    return@capture
                }
                shots.add(bmp)
                if (i + 1 < total) {
                    seq.postDelayed({ nextShot(i + 1, total) }, 450)
                } else {
                    finishSequence()
                }
            }
        }
    }

    private fun countdown(n: Int, done: () -> Unit) {
        if (!busy) return
        if (n <= 0) {
            countNum.visibility = View.GONE
            done()
            return
        }
        countNum.text = n.toString()
        countNum.visibility = View.VISIBLE
        countNum.alpha = 0.2f
        countNum.scaleX = 1.5f
        countNum.scaleY = 1.5f
        countNum.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).start()
        seq.postDelayed({ countdown(n - 1, done) }, 1000)
    }

    /**
     * Kilat menutupi tangkapan. Paint efek dilepas dulu supaya bitmap TextureView pasti mentah, lalu efek dipasang
     * manual (hasil sama dengan preview, tanpa risiko efek ganda). Ukuran bitmap = resolusi asli preview.
     */
    private fun capture(cb: (Bitmap) -> Unit) {
        try {
            if (sound == null) {
                sound = MediaActionSound()
                sound?.load(MediaActionSound.SHUTTER_CLICK)
            }
            sound?.play(MediaActionSound.SHUTTER_CLICK)
        } catch (e: Throwable) {
        }
        flash.animate().cancel()
        flash.alpha = 1f
        tex.setLayerPaint(null)
        tex.invalidate()
        seq.postDelayed({
            var out: Bitmap? = null
            try {
                val ps = previewSize
                val raw: Bitmap? = if (ps != null) {
                    val (nw, nh) = naturalSize(ps)
                    val rot = displayRot()
                    if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) tex.getBitmap(nh, nw) else tex.getBitmap(nw, nh)
                } else {
                    tex.bitmap
                }
                if (raw != null) {
                    val p = BOOTH_FX[fx].paint()
                    if (p == null) {
                        out = raw
                    } else {
                        val b = Bitmap.createBitmap(raw.width, raw.height, Bitmap.Config.ARGB_8888)
                        Canvas(b).drawBitmap(raw, 0f, 0f, p)
                        raw.recycle()
                        out = b
                    }
                }
            } catch (e: Throwable) {
                out = null
            }
            applyFxToPreview()
            flash.animate().alpha(0f).setDuration(380).start()
            if (out == null) {
                Toast.makeText(c, "Couldn't capture, try again", Toast.LENGTH_SHORT).show()
                cancelSequence()
            } else {
                cb(out)
            }
        }, 120)
    }

    private fun cancelSequence() {
        busy = false
        seq.removeCallbacksAndMessages(null)
        countNum.animate().cancel()
        countNum.visibility = View.GONE
        status.visibility = View.GONE
        flash.animate().cancel()
        flash.alpha = 0f
        for (b in shots) b.recycle()
        shots.clear()
        setControlsEnabled(true)
        if (device != null) applyFxToPreview()
    }

    private fun finishSequence() {
        val list = ArrayList(shots)
        shots.clear()
        status.text = "Saving…"
        status.visibility = View.VISIBLE
        val m = mode
        val app = c.applicationContext
        Thread {
            var result: Bitmap? = null
            try {
                result = when (m) {
                    0 -> list[0]
                    1 -> boothGrid(list)
                    else -> boothStrip(list)
                }
            } catch (t: Throwable) {
                result = null
            }
            val bmp = result
            val f = if (bmp != null) BoothStore.save(app, bmp) else null
            if (m != 0) for (b in list) b.recycle()
            ui.post {
                busy = false
                status.visibility = View.GONE
                setControlsEnabled(true)
                if (bmp == null) {
                    Toast.makeText(c, "Couldn't build the photo", Toast.LENGTH_SHORT).show()
                } else if (showing) {
                    showResult(bmp, f)
                } else {
                    bmp.recycle()
                }
                updateThumb()
            }
        }.start()
    }

    // ---------------------------------------------------------------- hasil

    private val autoClose = Runnable { closeResult() }

    private fun showResult(bmp: Bitmap, f: File?) {
        closeResultNow()
        resultBmp = bmp
        resultFile = f
        resultImg.setImageBitmap(bmp)
        resultLayer.alpha = 0f
        resultLayer.visibility = View.VISIBLE
        resultLayer.animate().alpha(1f).setDuration(200).start()
        ui.postDelayed(autoClose, 6000)
    }

    private fun closeResult() {
        ui.removeCallbacks(autoClose)
        resultLayer.animate().cancel()
        resultLayer.animate().alpha(0f).setDuration(160).withEndAction { closeResultNow() }.start()
    }

    /** Lepas bitmap hasil segera (RAM). */
    private fun closeResultNow() {
        ui.removeCallbacks(autoClose)
        resultLayer.animate().cancel()
        resultLayer.visibility = View.GONE
        resultImg.setImageBitmap(null)
        resultBmp?.recycle()
        resultBmp = null
    }

    private fun shareResult() {
        val f = resultFile
        if (f == null) {
            Toast.makeText(c, "Nothing to share", Toast.LENGTH_SHORT).show()
            return
        }
        val go: () -> Unit = {
            try {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "image/jpeg"
                i.putExtra(Intent.EXTRA_STREAM, BoothStore.uriFor(f))
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val ch = Intent.createChooser(i, "Share photo")
                ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                c.startActivity(ch)
            } catch (e: Exception) {
            }
        }
        val ct = closeThen
        if (ct != null) ct(go) else go()
    }

    // ---------------------------------------------------------------- foto terakhir

    private fun updateThumb() {
        val f = BoothStore.items().firstOrNull()
        val sig = if (f == null) "" else f.absolutePath + f.lastModified()
        if (sig == thumbSig) return
        thumbSig = sig
        if (f == null) {
            thumb.setImageBitmap(null)
            thumb.visibility = View.GONE
            return
        }
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(f.absolutePath, o)
            var s = 1
            while (o.outWidth / (s * 2) >= 128 && o.outHeight / (s * 2) >= 128) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            thumb.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath, o2))
            thumb.visibility = View.VISIBLE
        } catch (e: Throwable) {
            thumb.visibility = View.GONE
        }
    }

    private fun openLast() {
        val f = BoothStore.items().firstOrNull() ?: return
        val go: () -> Unit = {
            try {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(BoothStore.uriFor(f), "image/jpeg")
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                c.startActivity(i)
            } catch (e: Exception) {
                Toast.makeText(c, "No app to open photos", Toast.LENGTH_SHORT).show()
            }
        }
        val ct = closeThen
        if (ct != null) ct(go) else go()
    }
}

/**
 * Activity transparan sekejap: satu-satunya cara meminta izin kamera (overlay tidak bisa menampilkan dialog izin).
 * Setelah dijawab langsung menutup dan membuka lagi tab Booth di notch.
 */
class CamPermActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            done()
        } else {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 9)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        done()
    }

    private fun done() {
        finish()
        overridePendingTransition(0, 0)
        Bus.changed()
        NotchService.instance?.openTab(BoothPanel.PANEL)
    }
}
